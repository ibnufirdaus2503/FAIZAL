﻿Public Class frmHelpCustomer
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_CUSTOMER()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT A.* ,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.CODH_FLNM='CODE_PROP' and B.codd_valu=CODE_PROP" & vbLf

        If txtCustomerHelpCari.Text <> "" Then
            SQL_C += "WHERE cust_name like '%" & txtCustomerHelpCari.Text & "%'"
        End If
        SQL_C += "ORDER BY A.cust_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpCustomer_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("cust_addr")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub btnCloseCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCustomer.Click
        Me.Close()
    End Sub
 
    Private Sub spdHelpCustomer_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpCustomer.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHelpCustomer_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdHelpCustomer_Sheet1.Cells.Item(e.Row, 1).Text
            .Help_str3 = spdHelpCustomer_Sheet1.Cells.Item(e.Row, 2).Text



        End With

        Me.Close()
    End Sub

    Private Sub frmHelpCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_CUSTOMER()
    End Sub

    
    Private Sub spdHelpCustomer_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpCustomer.CellClick

    End Sub

    Private Sub btnCariCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariCustomer.Click
        FP_LIST_CUSTOMER()
    End Sub
End Class