﻿
Public Class frmControlPO
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_DETAIL_PO()
        Dim i, vModel As Integer

 

        SQL_C = ""
        SQL_C += "SELECT  cust_shrt,A.ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111) ordh_date," & vbLf
        SQL_C += "CONVERT(VARCHAR(10),ordh_etdh,111) ordh_etdh,ordh_nctr, CONVERT(VARCHAR(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "A.CODE_PROD, ordh_stat, cust_name, colr_name,A.modl_idxx" & vbLf
        SQL_C += ",modl_name,E.codd_desc vBran,F.codd_desc vProd, SUM(ordd_qtyx) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color B ON B.colr_idxx=A.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model C ON C.modl_idxx=A.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer D ON D.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_BRAN' AND E.codd_valu=C.CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common F ON F.codh_flnm='CODE_PROD' AND F.codd_valu=A.CODE_PROD" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_detail G ON A.ordh_poxx=G.ordh_poxx" & vbLf
        SQL_C += "WHERE ordh_stat = 0 " & vbLf
        SQL_C += "GROUP BY    cust_shrt,A.ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111)  ," & vbLf
        SQL_C += "CONVERT(VARCHAR(10),ordh_etdh,111)  ,ordh_nctr, CONVERT(VARCHAR(10),ordh_dctr,111)  ," & vbLf
        SQL_C += "A.CODE_PROD, ordh_stat, cust_name, colr_name,A.modl_idxx" & vbLf
        SQL_C += ",modl_name,E.codd_desc  ,F.codd_desc  " & vbLf
        SQL_C += "ORDER BY A.ordh_poxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPO_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_date")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_etdh")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_nctr")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("ordh_dctr")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vBran")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vProd")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("modl_name")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("colr_name")
                '  .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("vGender")
                vModel = clsCom.gv_DataRdr("modl_idxx")

                .Cells.Item(.RowCount - 1, 8).Text = vModel.ToString("D4")



                For i = 12 To .ColumnCount - 1
                    If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("ordh_etdh") Then
                        .Cells.Item(.RowCount - 1, i).Text = clsCom.gv_DataRdr("QTY")
                    End If
                Next

          

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_HEAD()
        Dim i As Integer
        Dim vLot, vModel As Integer

        Dim OldPO As String


        SQL_C = ""
        SQL_C += "SELECT  cust_shrt,A.ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111) ordh_date," & vbLf
        SQL_C += "CONVERT(VARCHAR(10),ordh_etdh,111) ordh_etdh,ordh_nctr, CONVERT(VARCHAR(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "A.CODE_PROD, ordh_stat, cust_name, colr_name,A.modl_idxx" & vbLf
        SQL_C += ",modl_name,E.codd_desc vBran,F.codd_desc vProd, CONVERT(VARCHAR(10),lotx_etdx,111) lotx_etdx,G.lotx_idxx,SUM(lotd_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color B ON B.colr_idxx=A.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model C ON C.modl_idxx=A.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer D ON D.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_BRAN' AND E.codd_valu=C.CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common F ON F.codh_flnm='CODE_PROD' AND F.codd_valu=A.CODE_PROD" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot G ON G.ordh_poxx=A.ordh_poxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot_size H ON G.lotx_idxx=H.lotx_idxx" & vbLf
        SQL_C += "WHERE ordh_stat = 0 " & vbLf
        SQL_C += "GROUP BY    cust_shrt,A.ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111)  ," & vbLf
        SQL_C += "CONVERT(VARCHAR(10),ordh_etdh,111)  ,ordh_nctr, CONVERT(VARCHAR(10),ordh_dctr,111)  ," & vbLf
        SQL_C += "A.CODE_PROD, ordh_stat, cust_name, colr_name,A.modl_idxx" & vbLf
        SQL_C += ",modl_name,E.codd_desc  ,F.codd_desc  ,lotx_etdx,G.lotx_idxx" & vbLf
        SQL_C += "ORDER BY A.ordh_poxx,lotx_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                If OldPO <> clsCom.gv_DataRdr("ordh_poxx") Then
                    .RowCount = .RowCount + 1
                    .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("ordh_poxx")
                    .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_date")
                    .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_etdh")
                    .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_nctr")
                    .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("ordh_dctr")
                    .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("cust_name")
                    .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vBran")
                    .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vProd")
                    .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("modl_name")
                    .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("colr_name")
                    '  .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("vGender")
                    vModel = clsCom.gv_DataRdr("modl_idxx")
                    vLot = clsCom.gv_DataRdr("lotx_idxx")
                    .Cells.Item(.RowCount - 1, 8).Text = vModel.ToString("D4")
                    .Cells.Item(.RowCount - 1, 11).Text = vLot.ToString("D7")
                Else
                    .RowCount = .RowCount + 1
                    vLot = clsCom.gv_DataRdr("lotx_idxx")
                    .Cells.Item(.RowCount - 1, 11).Text = vLot.ToString("D7")
                End If
                

                For i = 13 To .ColumnCount - 1
                    If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("lotx_etdx") Then
                        .Cells.Item(.RowCount - 1, i).Text = clsCom.gv_DataRdr("QTY")
                    End If
                Next

                OldPO = clsCom.gv_DataRdr("ordh_poxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_HEADER_LOT()
        Dim vTotal As Integer
        SQL_C = ""
        SQL_C += "SELECT   CONVERT(VARCHAR(10),lotx_etdx,111) lotx_etdx,SUM(lotd_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot G ON G.ordh_poxx=A.ordh_poxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot_size H ON G.lotx_idxx=H.lotx_idxx" & vbLf
        SQL_C += "WHERE ordh_stat = 0 " & vbLf
        SQL_C += "GROUP BY CONVERT(VARCHAR(10),lotx_etdx,111) " & vbLf
        SQL_C += "ORDER BY  CONVERT(VARCHAR(10),lotx_etdx,111) " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .ColumnCount = 13
            vTotal = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 65
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("lotx_etdx")
                .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                vTotal = vTotal + Val(clsCom.gv_DataRdr("QTY"))
                ' .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                ' .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                ' .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .ColumnHeader.Cells.Item(1, 12).Text = vTotal

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_HEADER_PO()
        Dim vTotal As Integer
        SQL_C = ""
        SQL_C += "SELECT   CONVERT(VARCHAR(10),ordh_etdh,111) ordh_etdh,SUM(ordd_qtyx) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_detail B ON A.ordh_poxx=B.ordh_poxx" & vbLf

        SQL_C += "WHERE ordh_stat = 0 " & vbLf
        SQL_C += "GROUP BY CONVERT(VARCHAR(10),ordh_etdh,111) " & vbLf
        SQL_C += "ORDER BY  CONVERT(VARCHAR(10),ordh_etdh,111) " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPO_Sheet1
            .ColumnCount = 12
            vTotal = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 65
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordh_etdh")
                .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                vTotal = vTotal + Val(clsCom.gv_DataRdr("QTY"))
                ' .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                ' .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                ' .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .ColumnHeader.Cells.Item(1, 11).Text = vTotal

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub frmControlPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_HEADER_LOT()
        FP_HEAD()

        FP_HEADER_PO()
        FP_DETAIL_PO()
    End Sub

    Private Sub spdPO_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs)

    End Sub
End Class