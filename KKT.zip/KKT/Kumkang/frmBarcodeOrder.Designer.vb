﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBarcodeOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim CheckBoxCellType1 As FarPoint.Win.Spread.CellType.CheckBoxCellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.FpSpread2 = New FarPoint.Win.Spread.FpSpread
        Me.SheetView2 = New FarPoint.Win.Spread.SheetView
        Me.FpSpread3 = New FarPoint.Win.Spread.FpSpread
        Me.SheetView3 = New FarPoint.Win.Spread.SheetView
        Me.FpSpread1 = New FarPoint.Win.Spread.FpSpread
        Me.SheetView1 = New FarPoint.Win.Spread.SheetView
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.txtColorCari = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtModelCari = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtLOT = New System.Windows.Forms.TextBox
        Me.btnSaveLot = New System.Windows.Forms.Button
        Me.btnDelLot = New System.Windows.Forms.Button
        Me.btnCloseLot = New System.Windows.Forms.Button
        Me.pnlLot = New System.Windows.Forms.Panel
        Me.dtETD = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.pnlHelpSizeUpdate = New System.Windows.Forms.Panel
        Me.btnCloseSize = New System.Windows.Forms.Button
        Me.btnSaveSize = New System.Windows.Forms.Button
        Me.spdUpdateSize = New FarPoint.Win.Spread.FpSpread
        Me.spdUpdateSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SheetView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SheetView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SheetView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.pnlLot.SuspendLayout()
        Me.pnlHelpSizeUpdate.SuspendLayout()
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, 1"
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdHead.HorizontalScrollBar.TabIndex = 10
        Me.spdHead.Location = New System.Drawing.Point(4, 270)
        Me.spdHead.Name = "spdHead"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = ""
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer6
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = ""
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer6
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(558, 289)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 9
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdHead.VerticalScrollBar.TabIndex = 11
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 11
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 0).Value = 1
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 1).Value = 2
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 2).Value = 3
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 3).Value = 4
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 4).Value = 5
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 5).Value = 12
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 6).Value = 13
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 7).Value = 14
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 8).Value = 15
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 9).Value = 16
        Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 10).Value = 17
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Customer"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Id Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Id Customer"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Id Product"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Id Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "Id Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "id gender"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHead_Sheet1.Columns.Get(0).Label = "ID Model"
        Me.spdHead_Sheet1.Columns.Get(0).Width = 51.0!
        Me.spdHead_Sheet1.Columns.Get(1).Label = "Brand"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 71.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "Model"
        Me.spdHead_Sheet1.Columns.Get(2).Locked = False
        Me.spdHead_Sheet1.Columns.Get(2).Width = 114.0!
        Me.spdHead_Sheet1.Columns.Get(3).Label = "Color"
        Me.spdHead_Sheet1.Columns.Get(3).Width = 130.0!
        Me.spdHead_Sheet1.Columns.Get(4).Label = "Customer"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 130.0!
        Me.spdHead_Sheet1.Columns.Get(5).Label = "Id Brand"
        Me.spdHead_Sheet1.Columns.Get(5).Visible = False
        Me.spdHead_Sheet1.Columns.Get(6).Label = "Id Customer"
        Me.spdHead_Sheet1.Columns.Get(6).Visible = False
        Me.spdHead_Sheet1.Columns.Get(6).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(7).Label = "Id Product"
        Me.spdHead_Sheet1.Columns.Get(7).Visible = False
        Me.spdHead_Sheet1.Columns.Get(7).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(8).Label = "Id Color"
        Me.spdHead_Sheet1.Columns.Get(8).Visible = False
        Me.spdHead_Sheet1.Columns.Get(9).Label = "Id Model"
        Me.spdHead_Sheet1.Columns.Get(9).Visible = False
        Me.spdHead_Sheet1.Columns.Get(9).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(10).Label = "id gender"
        Me.spdHead_Sheet1.Columns.Get(10).Visible = False
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        '
        'FpSpread2
        '
        Me.FpSpread2.AccessibleDescription = "FpSpread2, Sheet1, Row 0, Column 0, "
        Me.FpSpread2.BackColor = System.Drawing.SystemColors.Control
        Me.FpSpread2.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread2.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.FpSpread2.HorizontalScrollBar.TabIndex = 16
        Me.FpSpread2.Location = New System.Drawing.Point(562, 56)
        Me.FpSpread2.Name = "FpSpread2"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = ""
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer7
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = ""
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer7
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.FpSpread2.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.FpSpread2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FpSpread2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.SheetView2})
        Me.FpSpread2.Size = New System.Drawing.Size(422, 502)
        Me.FpSpread2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.FpSpread2.TabIndex = 11
        Me.FpSpread2.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread2.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread2.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.FpSpread2.VerticalScrollBar.TabIndex = 17
        Me.FpSpread2.VisualStyles = FarPoint.Win.VisualStyles.Off
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        '
        'SheetView2
        '
        Me.SheetView2.Reset()
        Me.SheetView2.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.SheetView2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.SheetView2.ColumnCount = 10
        Me.SheetView2.RowCount = 1
        Me.SheetView2.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 3).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 3).Value = 1
        Me.SheetView2.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 4).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 4).Value = 12
        Me.SheetView2.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 5).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 5).Value = 13
        Me.SheetView2.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 6).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 6).Value = 14
        Me.SheetView2.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 7).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 7).Value = 15
        Me.SheetView2.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 8).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 8).Value = 16
        Me.SheetView2.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView2.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView2.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView2.Cells.Get(0, 9).ParseFormatString = "n"
        Me.SheetView2.Cells.Get(0, 9).Value = 17
        Me.SheetView2.ColumnHeader.Cells.Get(0, 0).Value = "LOT Barcode"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 1).Value = "Date"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 2).Value = "Mold Code"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 3).Value = "Component"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 4).Value = "Id Brand"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 5).Value = "Id Customer"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 6).Value = "Id Product"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 7).Value = "Id Color"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 8).Value = "Id Model"
        Me.SheetView2.ColumnHeader.Cells.Get(0, 9).Value = "id gender"
        Me.SheetView2.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.SheetView2.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.SheetView2.Columns.Get(0).Label = "LOT Barcode"
        Me.SheetView2.Columns.Get(0).Width = 78.0!
        Me.SheetView2.Columns.Get(1).Label = "Date"
        Me.SheetView2.Columns.Get(1).Width = 85.0!
        Me.SheetView2.Columns.Get(2).Label = "Mold Code"
        Me.SheetView2.Columns.Get(2).Width = 99.0!
        Me.SheetView2.Columns.Get(3).Label = "Component"
        Me.SheetView2.Columns.Get(3).Width = 104.0!
        Me.SheetView2.Columns.Get(4).Label = "Id Brand"
        Me.SheetView2.Columns.Get(4).Visible = False
        Me.SheetView2.Columns.Get(5).Label = "Id Customer"
        Me.SheetView2.Columns.Get(5).Visible = False
        Me.SheetView2.Columns.Get(5).Width = 83.0!
        Me.SheetView2.Columns.Get(6).Label = "Id Product"
        Me.SheetView2.Columns.Get(6).Visible = False
        Me.SheetView2.Columns.Get(6).Width = 83.0!
        Me.SheetView2.Columns.Get(7).Label = "Id Color"
        Me.SheetView2.Columns.Get(7).Visible = False
        Me.SheetView2.Columns.Get(8).Label = "Id Model"
        Me.SheetView2.Columns.Get(8).Visible = False
        Me.SheetView2.Columns.Get(8).Width = 83.0!
        Me.SheetView2.Columns.Get(9).Label = "id gender"
        Me.SheetView2.Columns.Get(9).Visible = False
        Me.SheetView2.RowHeader.Columns.Default.Resizable = True
        Me.SheetView2.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.SheetView2.SheetCornerStyle.Parent = "CornerSeashell"
        Me.SheetView2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'FpSpread3
        '
        Me.FpSpread3.AccessibleDescription = "FpSpread3, Sheet1, Row 0, Column 0, "
        Me.FpSpread3.BackColor = System.Drawing.SystemColors.Control
        Me.FpSpread3.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread3.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread3.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.FpSpread3.HorizontalScrollBar.TabIndex = 14
        Me.FpSpread3.Location = New System.Drawing.Point(983, 56)
        Me.FpSpread3.Name = "FpSpread3"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = ""
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        NamedStyle9.Renderer = EnhancedColumnHeaderRenderer8
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = ""
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        NamedStyle10.Renderer = EnhancedRowHeaderRenderer8
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.FpSpread3.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.FpSpread3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FpSpread3.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.SheetView3})
        Me.FpSpread3.Size = New System.Drawing.Size(178, 446)
        Me.FpSpread3.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.FpSpread3.TabIndex = 12
        Me.FpSpread3.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread3.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread3.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.FpSpread3.VerticalScrollBar.TabIndex = 15
        Me.FpSpread3.VisualStyles = FarPoint.Win.VisualStyles.Off
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        '
        'SheetView3
        '
        Me.SheetView3.Reset()
        Me.SheetView3.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.SheetView3.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.SheetView3.ColumnCount = 8
        Me.SheetView3.RowCount = 1
        Me.SheetView3.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 1).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 1).Value = 1
        Me.SheetView3.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 2).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 2).Value = 12
        Me.SheetView3.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 3).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 3).Value = 13
        Me.SheetView3.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 4).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 4).Value = 14
        Me.SheetView3.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 5).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 5).Value = 15
        Me.SheetView3.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 6).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 6).Value = 16
        Me.SheetView3.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView3.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView3.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView3.Cells.Get(0, 7).ParseFormatString = "n"
        Me.SheetView3.Cells.Get(0, 7).Value = 17
        Me.SheetView3.ColumnHeader.Cells.Get(0, 0).Value = "Size"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 1).Value = "Qty"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 2).Value = "Id Brand"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 3).Value = "Id Customer"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 4).Value = "Id Product"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 5).Value = "Id Color"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 6).Value = "Id Model"
        Me.SheetView3.ColumnHeader.Cells.Get(0, 7).Value = "id gender"
        Me.SheetView3.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.SheetView3.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.SheetView3.Columns.Get(0).Label = "Size"
        Me.SheetView3.Columns.Get(0).Width = 74.0!
        Me.SheetView3.Columns.Get(1).Label = "Qty"
        Me.SheetView3.Columns.Get(1).Width = 47.0!
        Me.SheetView3.Columns.Get(2).Label = "Id Brand"
        Me.SheetView3.Columns.Get(2).Visible = False
        Me.SheetView3.Columns.Get(3).Label = "Id Customer"
        Me.SheetView3.Columns.Get(3).Visible = False
        Me.SheetView3.Columns.Get(3).Width = 83.0!
        Me.SheetView3.Columns.Get(4).Label = "Id Product"
        Me.SheetView3.Columns.Get(4).Visible = False
        Me.SheetView3.Columns.Get(4).Width = 83.0!
        Me.SheetView3.Columns.Get(5).Label = "Id Color"
        Me.SheetView3.Columns.Get(5).Visible = False
        Me.SheetView3.Columns.Get(6).Label = "Id Model"
        Me.SheetView3.Columns.Get(6).Visible = False
        Me.SheetView3.Columns.Get(6).Width = 83.0!
        Me.SheetView3.Columns.Get(7).Label = "id gender"
        Me.SheetView3.Columns.Get(7).Visible = False
        Me.SheetView3.RowHeader.Columns.Default.Resizable = True
        Me.SheetView3.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.SheetView3.SheetCornerStyle.Parent = "CornerSeashell"
        Me.SheetView3.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        '
        'FpSpread1
        '
        Me.FpSpread1.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.FpSpread1.BackColor = System.Drawing.SystemColors.Control
        Me.FpSpread1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread1.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.FpSpread1.HorizontalScrollBar.TabIndex = 20
        Me.FpSpread1.Location = New System.Drawing.Point(1161, 55)
        Me.FpSpread1.Name = "FpSpread1"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = ""
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer9
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = ""
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer9
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.FpSpread1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.FpSpread1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FpSpread1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.SheetView1})
        Me.FpSpread1.Size = New System.Drawing.Size(199, 447)
        Me.FpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.FpSpread1.TabIndex = 13
        Me.FpSpread1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.FpSpread1.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.FpSpread1.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.FpSpread1.VerticalScrollBar.TabIndex = 21
        Me.FpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        '
        'SheetView1
        '
        Me.SheetView1.Reset()
        Me.SheetView1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.SheetView1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.SheetView1.ColumnCount = 9
        Me.SheetView1.RowCount = 1
        Me.SheetView1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 2).Value = 1
        Me.SheetView1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 3).Value = 12
        Me.SheetView1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 4).Value = 13
        Me.SheetView1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 5).Value = 14
        Me.SheetView1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 6).Value = 15
        Me.SheetView1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 7).Value = 16
        Me.SheetView1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.SheetView1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.SheetView1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.SheetView1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.SheetView1.Cells.Get(0, 8).Value = 17
        Me.SheetView1.ColumnHeader.Cells.Get(0, 0).Value = "-"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 1).Value = "ID Barcode"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 2).Value = "Qty"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 3).Value = "Id Brand"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 4).Value = "Id Customer"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 5).Value = "Id Product"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 6).Value = "Id Color"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 7).Value = "Id Model"
        Me.SheetView1.ColumnHeader.Cells.Get(0, 8).Value = "id gender"
        Me.SheetView1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.SheetView1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.SheetView1.Columns.Get(0).CellType = CheckBoxCellType1
        Me.SheetView1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.SheetView1.Columns.Get(0).Label = "-"
        Me.SheetView1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.SheetView1.Columns.Get(0).Width = 25.0!
        Me.SheetView1.Columns.Get(1).Label = "ID Barcode"
        Me.SheetView1.Columns.Get(1).Width = 79.0!
        Me.SheetView1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.SheetView1.Columns.Get(2).Label = "Qty"
        Me.SheetView1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.SheetView1.Columns.Get(2).Width = 37.0!
        Me.SheetView1.Columns.Get(3).Label = "Id Brand"
        Me.SheetView1.Columns.Get(3).Visible = False
        Me.SheetView1.Columns.Get(4).Label = "Id Customer"
        Me.SheetView1.Columns.Get(4).Visible = False
        Me.SheetView1.Columns.Get(4).Width = 83.0!
        Me.SheetView1.Columns.Get(5).Label = "Id Product"
        Me.SheetView1.Columns.Get(5).Visible = False
        Me.SheetView1.Columns.Get(5).Width = 83.0!
        Me.SheetView1.Columns.Get(6).Label = "Id Color"
        Me.SheetView1.Columns.Get(6).Visible = False
        Me.SheetView1.Columns.Get(7).Label = "Id Model"
        Me.SheetView1.Columns.Get(7).Visible = False
        Me.SheetView1.Columns.Get(7).Width = 83.0!
        Me.SheetView1.Columns.Get(8).Label = "id gender"
        Me.SheetView1.Columns.Get(8).Visible = False
        Me.SheetView1.RowHeader.Columns.Default.Resizable = True
        Me.SheetView1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.SheetView1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.SheetView1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(4, 270)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(36, 38)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Add"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(562, 57)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 38)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Add"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(983, 57)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(36, 38)
        Me.Button3.TabIndex = 16
        Me.Button3.Text = "Add"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(983, 508)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(178, 49)
        Me.Button4.TabIndex = 17
        Me.Button4.Text = "Create Barcode"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(1161, 508)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(198, 49)
        Me.Button5.TabIndex = 18
        Me.Button5.Text = "Print Barcode"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.txtColorCari)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.txtModelCari)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Location = New System.Drawing.Point(3, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1356, 36)
        Me.Panel2.TabIndex = 19
        '
        'txtColorCari
        '
        Me.txtColorCari.Location = New System.Drawing.Point(219, 10)
        Me.txtColorCari.Name = "txtColorCari"
        Me.txtColorCari.Size = New System.Drawing.Size(122, 20)
        Me.txtColorCari.TabIndex = 12
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(182, 13)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Color"
        '
        'txtModelCari
        '
        Me.txtModelCari.Location = New System.Drawing.Point(50, 9)
        Me.txtModelCari.Name = "txtModelCari"
        Me.txtModelCari.Size = New System.Drawing.Size(122, 20)
        Me.txtModelCari.TabIndex = 10
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(11, 11)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Model"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "LOT"
        '
        'txtLOT
        '
        Me.txtLOT.BackColor = System.Drawing.SystemColors.Info
        Me.txtLOT.Location = New System.Drawing.Point(80, 17)
        Me.txtLOT.Name = "txtLOT"
        Me.txtLOT.Size = New System.Drawing.Size(128, 20)
        Me.txtLOT.TabIndex = 2
        '
        'btnSaveLot
        '
        Me.btnSaveLot.Location = New System.Drawing.Point(18, 121)
        Me.btnSaveLot.Name = "btnSaveLot"
        Me.btnSaveLot.Size = New System.Drawing.Size(72, 27)
        Me.btnSaveLot.TabIndex = 4
        Me.btnSaveLot.Text = "Save"
        Me.btnSaveLot.UseVisualStyleBackColor = True
        '
        'btnDelLot
        '
        Me.btnDelLot.Location = New System.Drawing.Point(94, 119)
        Me.btnDelLot.Name = "btnDelLot"
        Me.btnDelLot.Size = New System.Drawing.Size(72, 27)
        Me.btnDelLot.TabIndex = 5
        Me.btnDelLot.Text = "Delete"
        Me.btnDelLot.UseVisualStyleBackColor = True
        '
        'btnCloseLot
        '
        Me.btnCloseLot.Location = New System.Drawing.Point(172, 119)
        Me.btnCloseLot.Name = "btnCloseLot"
        Me.btnCloseLot.Size = New System.Drawing.Size(72, 27)
        Me.btnCloseLot.TabIndex = 60
        Me.btnCloseLot.Text = "Close"
        Me.btnCloseLot.UseVisualStyleBackColor = True
        '
        'pnlLot
        '
        Me.pnlLot.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlLot.Controls.Add(Me.ComboBox1)
        Me.pnlLot.Controls.Add(Me.Label1)
        Me.pnlLot.Controls.Add(Me.btnCloseLot)
        Me.pnlLot.Controls.Add(Me.dtETD)
        Me.pnlLot.Controls.Add(Me.btnDelLot)
        Me.pnlLot.Controls.Add(Me.btnSaveLot)
        Me.pnlLot.Controls.Add(Me.txtLOT)
        Me.pnlLot.Controls.Add(Me.Label5)
        Me.pnlLot.Controls.Add(Me.Label6)
        Me.pnlLot.Location = New System.Drawing.Point(617, 111)
        Me.pnlLot.Name = "pnlLot"
        Me.pnlLot.Size = New System.Drawing.Size(250, 156)
        Me.pnlLot.TabIndex = 46
        Me.pnlLot.Visible = False
        '
        'dtETD
        '
        Me.dtETD.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtETD.Location = New System.Drawing.Point(80, 43)
        Me.dtETD.Name = "dtETD"
        Me.dtETD.Size = New System.Drawing.Size(128, 20)
        Me.dtETD.TabIndex = 59
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 46)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Date"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Component"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(80, 71)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(128, 21)
        Me.ComboBox1.TabIndex = 62
        '
        'pnlHelpSizeUpdate
        '
        Me.pnlHelpSizeUpdate.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnCloseSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnSaveSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.spdUpdateSize)
        Me.pnlHelpSizeUpdate.Location = New System.Drawing.Point(831, 270)
        Me.pnlHelpSizeUpdate.Name = "pnlHelpSizeUpdate"
        Me.pnlHelpSizeUpdate.Size = New System.Drawing.Size(517, 141)
        Me.pnlHelpSizeUpdate.TabIndex = 71
        Me.pnlHelpSizeUpdate.Visible = False
        '
        'btnCloseSize
        '
        Me.btnCloseSize.Location = New System.Drawing.Point(3, 104)
        Me.btnCloseSize.Name = "btnCloseSize"
        Me.btnCloseSize.Size = New System.Drawing.Size(511, 32)
        Me.btnCloseSize.TabIndex = 15
        Me.btnCloseSize.Text = "Close"
        Me.btnCloseSize.UseVisualStyleBackColor = True
        '
        'btnSaveSize
        '
        Me.btnSaveSize.Location = New System.Drawing.Point(3, 71)
        Me.btnSaveSize.Name = "btnSaveSize"
        Me.btnSaveSize.Size = New System.Drawing.Size(511, 32)
        Me.btnSaveSize.TabIndex = 14
        Me.btnSaveSize.Text = "Save"
        Me.btnSaveSize.UseVisualStyleBackColor = True
        '
        'spdUpdateSize
        '
        Me.spdUpdateSize.AccessibleDescription = "spdUpdateSize, Sheet1, Row 0, Column 0, "
        Me.spdUpdateSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdUpdateSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdUpdateSize.HorizontalScrollBar.TabIndex = 4
        Me.spdUpdateSize.Location = New System.Drawing.Point(3, 3)
        Me.spdUpdateSize.Name = "spdUpdateSize"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer5
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer5
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdUpdateSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdUpdateSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdUpdateSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdUpdateSize_Sheet1})
        Me.spdUpdateSize.Size = New System.Drawing.Size(511, 65)
        Me.spdUpdateSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdUpdateSize.TabIndex = 13
        Me.spdUpdateSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdUpdateSize.VerticalScrollBar.TabIndex = 5
        Me.spdUpdateSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdUpdateSize_Sheet1
        '
        Me.spdUpdateSize_Sheet1.Reset()
        Me.spdUpdateSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdUpdateSize_Sheet1.ColumnCount = 30
        Me.spdUpdateSize_Sheet1.ColumnHeader.RowCount = 0
        Me.spdUpdateSize_Sheet1.RowCount = 2
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 13).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 13).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 14).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 14).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 15).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 15).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 16).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 16).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 17).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 17).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 18).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 18).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 19).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 19).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 20).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 20).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 21).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 21).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 22).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 22).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 23).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 23).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 24).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 24).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 25).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 25).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 26).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 26).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 27).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 27).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 28).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 28).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 29).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 29).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 13).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 13).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 14).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 14).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 15).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 15).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 16).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 16).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 17).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 17).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 18).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 18).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 19).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 19).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 20).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 20).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 21).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 21).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 22).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 22).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 23).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 23).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 24).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 24).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 25).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 25).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 26).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 26).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 27).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 27).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 28).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 28).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 29).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 29).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdUpdateSize_Sheet1.Columns.Get(0).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(1).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(2).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(3).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(4).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(5).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(6).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(7).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(8).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(9).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(10).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(11).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(12).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(13).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(14).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(15).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(16).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(17).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(18).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(19).Width = 55.0!
        Me.spdUpdateSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdUpdateSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdUpdateSize_Sheet1.Rows.Get(0).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmBarcodeOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.pnlHelpSizeUpdate)
        Me.Controls.Add(Me.pnlLot)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.FpSpread1)
        Me.Controls.Add(Me.FpSpread3)
        Me.Controls.Add(Me.FpSpread2)
        Me.Controls.Add(Me.spdHead)
        Me.Name = "frmBarcodeOrder"
        Me.Text = "Barcode Order"
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SheetView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SheetView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FpSpread1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SheetView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnlLot.ResumeLayout(False)
        Me.pnlLot.PerformLayout()
        Me.pnlHelpSizeUpdate.ResumeLayout(False)
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents SheetView2 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread3 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents SheetView3 As FarPoint.Win.Spread.SheetView
    Friend WithEvents FpSpread1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents SheetView1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtColorCari As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtModelCari As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtLOT As System.Windows.Forms.TextBox
    Friend WithEvents btnSaveLot As System.Windows.Forms.Button
    Friend WithEvents btnDelLot As System.Windows.Forms.Button
    Friend WithEvents btnCloseLot As System.Windows.Forms.Button
    Friend WithEvents pnlLot As System.Windows.Forms.Panel
    Friend WithEvents dtETD As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pnlHelpSizeUpdate As System.Windows.Forms.Panel
    Friend WithEvents btnCloseSize As System.Windows.Forms.Button
    Friend WithEvents btnSaveSize As System.Windows.Forms.Button
    Friend WithEvents spdUpdateSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdUpdateSize_Sheet1 As FarPoint.Win.Spread.SheetView
End Class
