﻿Public Class frmHelpBuilding
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_BUILDING()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common A where codh_flnm='CODE_BUIL'" & vbLf
        SQL_C += "ORDER BY A.codd_desc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBuilding_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmHelpBuilding_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_BUILDING()
    End Sub

    Private Sub spdBuilding_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBuilding.CellClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdBuilding_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdBuilding_Sheet1.Cells.Item(e.Row, 1).Text



        End With

        Me.Close()
    End Sub
End Class