﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEntryPoPlanning
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.cboProductCari = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnCustomer = New System.Windows.Forms.Button
        Me.txtCustomerCari = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlKontrak = New System.Windows.Forms.Panel
        Me.txtIdColor = New System.Windows.Forms.TextBox
        Me.txtBrand = New System.Windows.Forms.TextBox
        Me.cboCustomer = New System.Windows.Forms.ComboBox
        Me.spdComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.txtStyle = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtPO = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtColor = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnColor = New System.Windows.Forms.Button
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtDesc = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.dtContract = New System.Windows.Forms.DateTimePicker
        Me.txtIdCustomer = New System.Windows.Forms.TextBox
        Me.cboProduct = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.cboGender = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtIdModel = New System.Windows.Forms.TextBox
        Me.btnModel = New System.Windows.Forms.Button
        Me.txtModel = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnSize = New System.Windows.Forms.Button
        Me.spdSize = New FarPoint.Win.Spread.FpSpread
        Me.spdSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Panel2.SuspendLayout()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlKontrak.SuspendLayout()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.cboProductCari)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.btnCustomer)
        Me.Panel2.Controls.Add(Me.txtCustomerCari)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.TextBox9)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.TextBox8)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Location = New System.Drawing.Point(7, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1341, 36)
        Me.Panel2.TabIndex = 11
        '
        'cboProductCari
        '
        Me.cboProductCari.BackColor = System.Drawing.SystemColors.HighlightText
        Me.cboProductCari.FormattingEnabled = True
        Me.cboProductCari.Location = New System.Drawing.Point(354, 7)
        Me.cboProductCari.Name = "cboProductCari"
        Me.cboProductCari.Size = New System.Drawing.Size(107, 21)
        Me.cboProductCari.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(308, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Product"
        '
        'btnCustomer
        '
        Me.btnCustomer.Location = New System.Drawing.Point(245, 7)
        Me.btnCustomer.Name = "btnCustomer"
        Me.btnCustomer.Size = New System.Drawing.Size(42, 24)
        Me.btnCustomer.TabIndex = 26
        Me.btnCustomer.Text = ">>"
        Me.btnCustomer.UseVisualStyleBackColor = True
        '
        'txtCustomerCari
        '
        Me.txtCustomerCari.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtCustomerCari.Location = New System.Drawing.Point(76, 9)
        Me.txtCustomerCari.Name = "txtCustomerCari"
        Me.txtCustomerCari.Size = New System.Drawing.Size(166, 20)
        Me.txtCustomerCari.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(19, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Customer"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(678, 10)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(122, 20)
        Me.TextBox9.TabIndex = 12
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(641, 13)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Color"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(511, 10)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(122, 20)
        Me.TextBox8.TabIndex = 10
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(472, 12)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Model"
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdContract, Sheet1, Row 0, Column 0, "
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdHead.HorizontalScrollBar.TabIndex = 22
        Me.spdHead.Location = New System.Drawing.Point(7, 44)
        Me.spdHead.Name = "spdHead"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(1345, 301)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 12
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdHead.VerticalScrollBar.TabIndex = 23
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 17
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "NO. PO"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "PO Date"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "ETD"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "No. Contract"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Contract Date"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Customer"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Product"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "Style"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "Remark"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "Id Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 13).Value = "Id Customer"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 14).Value = "Id Product"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 15).Value = "Id Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 16).Value = "Id Model"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHead_Sheet1.Columns.Get(0).Label = "NO. PO"
        Me.spdHead_Sheet1.Columns.Get(0).Width = 129.0!
        Me.spdHead_Sheet1.Columns.Get(1).Label = "PO Date"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 97.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "ETD"
        Me.spdHead_Sheet1.Columns.Get(2).Width = 93.0!
        Me.spdHead_Sheet1.Columns.Get(3).Label = "No. Contract"
        Me.spdHead_Sheet1.Columns.Get(3).Width = 127.0!
        Me.spdHead_Sheet1.Columns.Get(4).Label = "Contract Date"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 93.0!
        Me.spdHead_Sheet1.Columns.Get(5).Label = "Customer"
        Me.spdHead_Sheet1.Columns.Get(5).Width = 206.0!
        Me.spdHead_Sheet1.Columns.Get(7).Label = "Product"
        Me.spdHead_Sheet1.Columns.Get(7).Width = 75.0!
        Me.spdHead_Sheet1.Columns.Get(8).Label = "Model"
        Me.spdHead_Sheet1.Columns.Get(8).Width = 118.0!
        Me.spdHead_Sheet1.Columns.Get(9).Label = "Color"
        Me.spdHead_Sheet1.Columns.Get(9).Width = 107.0!
        Me.spdHead_Sheet1.Columns.Get(10).Label = "Style"
        Me.spdHead_Sheet1.Columns.Get(10).Width = 97.0!
        Me.spdHead_Sheet1.Columns.Get(11).Label = "Remark"
        Me.spdHead_Sheet1.Columns.Get(11).Width = 177.0!
        Me.spdHead_Sheet1.Columns.Get(13).Label = "Id Customer"
        Me.spdHead_Sheet1.Columns.Get(13).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(14).Label = "Id Product"
        Me.spdHead_Sheet1.Columns.Get(14).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(16).Label = "Id Model"
        Me.spdHead_Sheet1.Columns.Get(16).Width = 83.0!
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlKontrak
        '
        Me.pnlKontrak.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlKontrak.Controls.Add(Me.ComboBox1)
        Me.pnlKontrak.Controls.Add(Me.txtIdColor)
        Me.pnlKontrak.Controls.Add(Me.txtBrand)
        Me.pnlKontrak.Controls.Add(Me.cboCustomer)
        Me.pnlKontrak.Controls.Add(Me.spdComponent)
        Me.pnlKontrak.Controls.Add(Me.txtStyle)
        Me.pnlKontrak.Controls.Add(Me.Label5)
        Me.pnlKontrak.Controls.Add(Me.txtPO)
        Me.pnlKontrak.Controls.Add(Me.Label1)
        Me.pnlKontrak.Controls.Add(Me.txtColor)
        Me.pnlKontrak.Controls.Add(Me.Label7)
        Me.pnlKontrak.Controls.Add(Me.btnColor)
        Me.pnlKontrak.Controls.Add(Me.Label14)
        Me.pnlKontrak.Controls.Add(Me.txtDesc)
        Me.pnlKontrak.Controls.Add(Me.Label11)
        Me.pnlKontrak.Controls.Add(Me.dtContract)
        Me.pnlKontrak.Controls.Add(Me.txtIdCustomer)
        Me.pnlKontrak.Controls.Add(Me.cboProduct)
        Me.pnlKontrak.Controls.Add(Me.Label21)
        Me.pnlKontrak.Controls.Add(Me.Label16)
        Me.pnlKontrak.Controls.Add(Me.Label20)
        Me.pnlKontrak.Controls.Add(Me.Label10)
        Me.pnlKontrak.Controls.Add(Me.cboGender)
        Me.pnlKontrak.Controls.Add(Me.Label19)
        Me.pnlKontrak.Controls.Add(Me.txtIdModel)
        Me.pnlKontrak.Controls.Add(Me.btnModel)
        Me.pnlKontrak.Controls.Add(Me.txtModel)
        Me.pnlKontrak.Controls.Add(Me.Label3)
        Me.pnlKontrak.Location = New System.Drawing.Point(6, 351)
        Me.pnlKontrak.Name = "pnlKontrak"
        Me.pnlKontrak.Size = New System.Drawing.Size(1342, 118)
        Me.pnlKontrak.TabIndex = 13
        '
        'txtIdColor
        '
        Me.txtIdColor.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdColor.Location = New System.Drawing.Point(592, 30)
        Me.txtIdColor.Name = "txtIdColor"
        Me.txtIdColor.Size = New System.Drawing.Size(42, 20)
        Me.txtIdColor.TabIndex = 69
        '
        'txtBrand
        '
        Me.txtBrand.BackColor = System.Drawing.SystemColors.Info
        Me.txtBrand.Location = New System.Drawing.Point(308, 28)
        Me.txtBrand.Name = "txtBrand"
        Me.txtBrand.Size = New System.Drawing.Size(278, 20)
        Me.txtBrand.TabIndex = 68
        '
        'cboCustomer
        '
        Me.cboCustomer.BackColor = System.Drawing.SystemColors.Info
        Me.cboCustomer.FormattingEnabled = True
        Me.cboCustomer.Location = New System.Drawing.Point(308, 49)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.Size = New System.Drawing.Size(278, 21)
        Me.cboCustomer.TabIndex = 67
        '
        'spdComponent
        '
        Me.spdComponent.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdComponent.HorizontalScrollBar.TabIndex = 2
        Me.spdComponent.Location = New System.Drawing.Point(960, 5)
        Me.spdComponent.Name = "spdComponent"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdComponent_Sheet1})
        Me.spdComponent.Size = New System.Drawing.Size(379, 106)
        Me.spdComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdComponent.TabIndex = 66
        Me.spdComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdComponent.VerticalScrollBar.TabIndex = 3
        Me.spdComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdComponent_Sheet1
        '
        Me.spdComponent_Sheet1.Reset()
        Me.spdComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdComponent_Sheet1.ColumnCount = 3
        Me.spdComponent_Sheet1.RowCount = 1
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Component"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Mold Code"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Moldshop"
        Me.spdComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdComponent_Sheet1.Columns.Get(0).Label = "Component"
        Me.spdComponent_Sheet1.Columns.Get(0).Width = 112.0!
        Me.spdComponent_Sheet1.Columns.Get(1).Label = "Mold Code"
        Me.spdComponent_Sheet1.Columns.Get(1).Width = 102.0!
        Me.spdComponent_Sheet1.Columns.Get(2).Label = "Moldshop"
        Me.spdComponent_Sheet1.Columns.Get(2).Width = 107.0!
        Me.spdComponent_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'txtStyle
        '
        Me.txtStyle.BackColor = System.Drawing.SystemColors.Info
        Me.txtStyle.Location = New System.Drawing.Point(746, 29)
        Me.txtStyle.Name = "txtStyle"
        Me.txtStyle.Size = New System.Drawing.Size(166, 20)
        Me.txtStyle.TabIndex = 65
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(712, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "Style"
        '
        'txtPO
        '
        Me.txtPO.BackColor = System.Drawing.SystemColors.Info
        Me.txtPO.Location = New System.Drawing.Point(77, 7)
        Me.txtPO.Name = "txtPO"
        Me.txtPO.Size = New System.Drawing.Size(166, 20)
        Me.txtPO.TabIndex = 55
        Me.txtPO.Text = "PO/IR/II/2025/01"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(55, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 13)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "PO"
        '
        'txtColor
        '
        Me.txtColor.BackColor = System.Drawing.SystemColors.Info
        Me.txtColor.Location = New System.Drawing.Point(308, 96)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(278, 20)
        Me.txtColor.TabIndex = 60
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(277, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 59
        Me.Label7.Text = "Color"
        '
        'btnColor
        '
        Me.btnColor.Location = New System.Drawing.Point(592, 95)
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(42, 24)
        Me.btnColor.TabIndex = 61
        Me.btnColor.Text = ">>"
        Me.btnColor.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(710, 64)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 13)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "Desc"
        '
        'txtDesc
        '
        Me.txtDesc.BackColor = System.Drawing.SystemColors.Info
        Me.txtDesc.Location = New System.Drawing.Point(746, 52)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(166, 45)
        Me.txtDesc.TabIndex = 53
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(29, 30)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 52
        Me.Label11.Text = "Date PO"
        '
        'dtContract
        '
        Me.dtContract.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtContract.Location = New System.Drawing.Point(77, 28)
        Me.dtContract.Name = "dtContract"
        Me.dtContract.Size = New System.Drawing.Size(166, 20)
        Me.dtContract.TabIndex = 51
        '
        'txtIdCustomer
        '
        Me.txtIdCustomer.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdCustomer.Location = New System.Drawing.Point(592, 52)
        Me.txtIdCustomer.Name = "txtIdCustomer"
        Me.txtIdCustomer.Size = New System.Drawing.Size(42, 20)
        Me.txtIdCustomer.TabIndex = 47
        '
        'cboProduct
        '
        Me.cboProduct.BackColor = System.Drawing.SystemColors.Info
        Me.cboProduct.FormattingEnabled = True
        Me.cboProduct.Location = New System.Drawing.Point(308, 73)
        Me.cboProduct.Name = "cboProduct"
        Me.cboProduct.Size = New System.Drawing.Size(278, 21)
        Me.cboProduct.TabIndex = 45
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(264, 76)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(44, 13)
        Me.Label21.TabIndex = 42
        Me.Label21.Text = "Product"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(13, 54)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 13)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "Type Order"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(257, 55)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(51, 13)
        Me.Label20.TabIndex = 38
        Me.Label20.Text = "Customer"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(273, 33)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Brand"
        '
        'cboGender
        '
        Me.cboGender.BackColor = System.Drawing.SystemColors.Info
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Location = New System.Drawing.Point(746, 6)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(166, 21)
        Me.cboGender.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(700, 9)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(42, 13)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "Gender"
        '
        'txtIdModel
        '
        Me.txtIdModel.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdModel.Location = New System.Drawing.Point(592, 74)
        Me.txtIdModel.Name = "txtIdModel"
        Me.txtIdModel.Size = New System.Drawing.Size(42, 20)
        Me.txtIdModel.TabIndex = 26
        '
        'btnModel
        '
        Me.btnModel.Location = New System.Drawing.Point(592, 4)
        Me.btnModel.Name = "btnModel"
        Me.btnModel.Size = New System.Drawing.Size(42, 24)
        Me.btnModel.TabIndex = 22
        Me.btnModel.Text = ">>"
        Me.btnModel.UseVisualStyleBackColor = True
        '
        'txtModel
        '
        Me.txtModel.BackColor = System.Drawing.SystemColors.Info
        Me.txtModel.Location = New System.Drawing.Point(308, 6)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(278, 20)
        Me.txtModel.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(272, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Model"
        '
        'btnSize
        '
        Me.btnSize.Location = New System.Drawing.Point(6, 475)
        Me.btnSize.Name = "btnSize"
        Me.btnSize.Size = New System.Drawing.Size(37, 34)
        Me.btnSize.TabIndex = 15
        Me.btnSize.Text = ">>"
        Me.btnSize.UseVisualStyleBackColor = True
        '
        'spdSize
        '
        Me.spdSize.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, "
        Me.spdSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdSize.HorizontalScrollBar.TabIndex = 0
        Me.spdSize.Location = New System.Drawing.Point(6, 475)
        Me.spdSize.Name = "spdSize"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSize_Sheet1})
        Me.spdSize.Size = New System.Drawing.Size(1333, 75)
        Me.spdSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSize.TabIndex = 14
        Me.spdSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdSize.VerticalScrollBar.TabIndex = 1
        Me.spdSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSize_Sheet1
        '
        Me.spdSize_Sheet1.Reset()
        Me.spdSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSize_Sheet1.ColumnCount = 0
        Me.spdSize_Sheet1.RowCount = 1
        Me.spdSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        Me.spdSize.SetActiveViewport(0, 0, 1)
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.SystemColors.Info
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(75, 52)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(168, 21)
        Me.ComboBox1.TabIndex = 70
        '
        'frmEntryPoPlanning
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.btnSize)
        Me.Controls.Add(Me.spdSize)
        Me.Controls.Add(Me.pnlKontrak)
        Me.Controls.Add(Me.spdHead)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "frmEntryPoPlanning"
        Me.Text = "frmEntryPoPlanning"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlKontrak.ResumeLayout(False)
        Me.pnlKontrak.PerformLayout()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cboProductCari As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnCustomer As System.Windows.Forms.Button
    Friend WithEvents txtCustomerCari As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlKontrak As System.Windows.Forms.Panel
    Friend WithEvents txtIdColor As System.Windows.Forms.TextBox
    Friend WithEvents txtBrand As System.Windows.Forms.TextBox
    Friend WithEvents cboCustomer As System.Windows.Forms.ComboBox
    Friend WithEvents spdComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdComponent_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents txtStyle As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPO As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtColor As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnColor As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents dtContract As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtIdCustomer As System.Windows.Forms.TextBox
    Friend WithEvents cboProduct As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtIdModel As System.Windows.Forms.TextBox
    Friend WithEvents btnModel As System.Windows.Forms.Button
    Friend WithEvents txtModel As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSize As System.Windows.Forms.Button
    Friend WithEvents spdSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
End Class
