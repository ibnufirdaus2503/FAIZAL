﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrderCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer11 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle21 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle22 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle23 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer6 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle24 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType6 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer12 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer13 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle25 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle26 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle27 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer7 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle28 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType7 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer14 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer15 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle29 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle30 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle31 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer8 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle32 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType8 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer16 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.pnlKontrak = New System.Windows.Forms.Panel
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtDescContract = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.dtContract = New System.Windows.Forms.DateTimePicker
        Me.btnCloseContract = New System.Windows.Forms.Button
        Me.btnDeleteContract = New System.Windows.Forms.Button
        Me.btnSaveContract = New System.Windows.Forms.Button
        Me.txtIdCustomer = New System.Windows.Forms.TextBox
        Me.btnHelpCustomer = New System.Windows.Forms.Button
        Me.cboProduct = New System.Windows.Forms.ComboBox
        Me.cboBrand = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtNoKontrak = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtCustomer = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.cboGender = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtIdModel = New System.Windows.Forms.TextBox
        Me.btnModel = New System.Windows.Forms.Button
        Me.txtModel = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtIdColor = New System.Windows.Forms.TextBox
        Me.btnColor = New System.Windows.Forms.Button
        Me.txtColor = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.dtPO = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtPO = New System.Windows.Forms.TextBox
        Me.spdSize = New FarPoint.Win.Spread.FpSpread
        Me.spdSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdContract = New FarPoint.Win.Spread.FpSpread
        Me.spdContract_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnSize = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.cboProductCari = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnCustomer = New System.Windows.Forms.Button
        Me.txtCustomerCari = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.pnlHelpColor = New System.Windows.Forms.Panel
        Me.btnCloseColor = New System.Windows.Forms.Button
        Me.spdHelpColor = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpColor_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.txtHelpCariColor = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.pnlPO = New System.Windows.Forms.Panel
        Me.txtDesc = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtStyle = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.dtETD = New System.Windows.Forms.DateTimePicker
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnClosePO = New System.Windows.Forms.Button
        Me.btnDeletePO = New System.Windows.Forms.Button
        Me.btnSavePO = New System.Windows.Forms.Button
        Me.spdPO = New FarPoint.Win.Spread.FpSpread
        Me.spdPO_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlModel = New System.Windows.Forms.Panel
        Me.pnlUpdateSize = New System.Windows.Forms.Panel
        Me.btnSizeUpdate = New System.Windows.Forms.Button
        Me.btnCloseSizeUpdate = New System.Windows.Forms.Button
        Me.spdSizeUpdate = New FarPoint.Win.Spread.FpSpread
        Me.spdSizeUpdate_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnCariModel = New System.Windows.Forms.Button
        Me.btnCloseModel = New System.Windows.Forms.Button
        Me.spdHelpModel = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpModel_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.txtHelpModelCari = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.btnOrder = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.pnlHelpSizeUpdate = New System.Windows.Forms.Panel
        Me.btnCloseSize = New System.Windows.Forms.Button
        Me.btnSaveSize = New System.Windows.Forms.Button
        Me.spdUpdateSize = New FarPoint.Win.Spread.FpSpread
        Me.spdUpdateSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlKontrak.SuspendLayout()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdContract, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdContract_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.pnlHelpColor.SuspendLayout()
        CType(Me.spdHelpColor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpColor_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlPO.SuspendLayout()
        CType(Me.spdPO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdPO_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlModel.SuspendLayout()
        Me.pnlUpdateSize.SuspendLayout()
        CType(Me.spdSizeUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSizeUpdate_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpModel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpModel_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpSizeUpdate.SuspendLayout()
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = "EnhancedColumnHeaderRenderer8"
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = "EnhancedRowHeaderRenderer8"
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer10.Name = "EnhancedColumnHeaderRenderer10"
        EnhancedColumnHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer10.TextRotationAngle = 0
        EnhancedRowHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer10.Name = "EnhancedRowHeaderRenderer10"
        EnhancedRowHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer10.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer11.Name = "EnhancedColumnHeaderRenderer11"
        EnhancedColumnHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer11.TextRotationAngle = 0
        EnhancedRowHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer11.Name = "EnhancedRowHeaderRenderer11"
        EnhancedRowHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer11.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer12.Name = "EnhancedColumnHeaderRenderer12"
        EnhancedColumnHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer12.TextRotationAngle = 0
        EnhancedRowHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer12.Name = "EnhancedRowHeaderRenderer12"
        EnhancedRowHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer12.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer13.Name = "EnhancedColumnHeaderRenderer13"
        EnhancedColumnHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer13.TextRotationAngle = 0
        EnhancedRowHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer13.Name = "EnhancedRowHeaderRenderer13"
        EnhancedRowHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer13.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer14.Name = "EnhancedColumnHeaderRenderer14"
        EnhancedColumnHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer14.TextRotationAngle = 0
        EnhancedRowHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer14.Name = "EnhancedRowHeaderRenderer14"
        EnhancedRowHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer14.TextRotationAngle = 0
        '
        'pnlKontrak
        '
        Me.pnlKontrak.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlKontrak.Controls.Add(Me.Label14)
        Me.pnlKontrak.Controls.Add(Me.txtDescContract)
        Me.pnlKontrak.Controls.Add(Me.Label11)
        Me.pnlKontrak.Controls.Add(Me.dtContract)
        Me.pnlKontrak.Controls.Add(Me.btnCloseContract)
        Me.pnlKontrak.Controls.Add(Me.btnDeleteContract)
        Me.pnlKontrak.Controls.Add(Me.btnSaveContract)
        Me.pnlKontrak.Controls.Add(Me.txtIdCustomer)
        Me.pnlKontrak.Controls.Add(Me.btnHelpCustomer)
        Me.pnlKontrak.Controls.Add(Me.cboProduct)
        Me.pnlKontrak.Controls.Add(Me.cboBrand)
        Me.pnlKontrak.Controls.Add(Me.Label21)
        Me.pnlKontrak.Controls.Add(Me.txtNoKontrak)
        Me.pnlKontrak.Controls.Add(Me.Label16)
        Me.pnlKontrak.Controls.Add(Me.Label20)
        Me.pnlKontrak.Controls.Add(Me.txtCustomer)
        Me.pnlKontrak.Controls.Add(Me.Label10)
        Me.pnlKontrak.Controls.Add(Me.cboGender)
        Me.pnlKontrak.Controls.Add(Me.Label19)
        Me.pnlKontrak.Controls.Add(Me.txtIdModel)
        Me.pnlKontrak.Controls.Add(Me.btnModel)
        Me.pnlKontrak.Controls.Add(Me.txtModel)
        Me.pnlKontrak.Controls.Add(Me.Label3)
        Me.pnlKontrak.Location = New System.Drawing.Point(46, 88)
        Me.pnlKontrak.Name = "pnlKontrak"
        Me.pnlKontrak.Size = New System.Drawing.Size(302, 258)
        Me.pnlKontrak.TabIndex = 1
        Me.pnlKontrak.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(31, 186)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 13)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "Desc"
        '
        'txtDescContract
        '
        Me.txtDescContract.BackColor = System.Drawing.SystemColors.Info
        Me.txtDescContract.Location = New System.Drawing.Point(67, 167)
        Me.txtDescContract.Multiline = True
        Me.txtDescContract.Name = "txtDescContract"
        Me.txtDescContract.Size = New System.Drawing.Size(166, 45)
        Me.txtDescContract.TabIndex = 53
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(34, 31)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 13)
        Me.Label11.TabIndex = 52
        Me.Label11.Text = "Date"
        '
        'dtContract
        '
        Me.dtContract.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtContract.Location = New System.Drawing.Point(67, 28)
        Me.dtContract.Name = "dtContract"
        Me.dtContract.Size = New System.Drawing.Size(166, 20)
        Me.dtContract.TabIndex = 51
        '
        'btnCloseContract
        '
        Me.btnCloseContract.Location = New System.Drawing.Point(191, 222)
        Me.btnCloseContract.Name = "btnCloseContract"
        Me.btnCloseContract.Size = New System.Drawing.Size(72, 27)
        Me.btnCloseContract.TabIndex = 50
        Me.btnCloseContract.Text = "Close"
        Me.btnCloseContract.UseVisualStyleBackColor = True
        '
        'btnDeleteContract
        '
        Me.btnDeleteContract.Location = New System.Drawing.Point(117, 223)
        Me.btnDeleteContract.Name = "btnDeleteContract"
        Me.btnDeleteContract.Size = New System.Drawing.Size(72, 27)
        Me.btnDeleteContract.TabIndex = 49
        Me.btnDeleteContract.Text = "Delete"
        Me.btnDeleteContract.UseVisualStyleBackColor = True
        '
        'btnSaveContract
        '
        Me.btnSaveContract.Location = New System.Drawing.Point(42, 222)
        Me.btnSaveContract.Name = "btnSaveContract"
        Me.btnSaveContract.Size = New System.Drawing.Size(72, 27)
        Me.btnSaveContract.TabIndex = 48
        Me.btnSaveContract.Text = "Save"
        Me.btnSaveContract.UseVisualStyleBackColor = True
        '
        'txtIdCustomer
        '
        Me.txtIdCustomer.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdCustomer.Location = New System.Drawing.Point(239, 97)
        Me.txtIdCustomer.Name = "txtIdCustomer"
        Me.txtIdCustomer.Size = New System.Drawing.Size(42, 20)
        Me.txtIdCustomer.TabIndex = 47
        '
        'btnHelpCustomer
        '
        Me.btnHelpCustomer.Location = New System.Drawing.Point(239, 48)
        Me.btnHelpCustomer.Name = "btnHelpCustomer"
        Me.btnHelpCustomer.Size = New System.Drawing.Size(42, 24)
        Me.btnHelpCustomer.TabIndex = 46
        Me.btnHelpCustomer.Text = ">>"
        Me.btnHelpCustomer.UseVisualStyleBackColor = True
        '
        'cboProduct
        '
        Me.cboProduct.BackColor = System.Drawing.SystemColors.Info
        Me.cboProduct.FormattingEnabled = True
        Me.cboProduct.Location = New System.Drawing.Point(67, 97)
        Me.cboProduct.Name = "cboProduct"
        Me.cboProduct.Size = New System.Drawing.Size(166, 21)
        Me.cboProduct.TabIndex = 45
        '
        'cboBrand
        '
        Me.cboBrand.BackColor = System.Drawing.SystemColors.Info
        Me.cboBrand.FormattingEnabled = True
        Me.cboBrand.Location = New System.Drawing.Point(67, 73)
        Me.cboBrand.Name = "cboBrand"
        Me.cboBrand.Size = New System.Drawing.Size(166, 21)
        Me.cboBrand.TabIndex = 44
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(20, 100)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(44, 13)
        Me.Label21.TabIndex = 42
        Me.Label21.Text = "Product"
        '
        'txtNoKontrak
        '
        Me.txtNoKontrak.BackColor = System.Drawing.SystemColors.Info
        Me.txtNoKontrak.Location = New System.Drawing.Point(67, 5)
        Me.txtNoKontrak.Name = "txtNoKontrak"
        Me.txtNoKontrak.Size = New System.Drawing.Size(166, 20)
        Me.txtNoKontrak.TabIndex = 41
        Me.txtNoKontrak.Text = "KN/IR/II/2025/01"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(1, 10)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 13)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "No. Kontrak"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(30, 76)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(35, 13)
        Me.Label20.TabIndex = 38
        Me.Label20.Text = "Brand"
        '
        'txtCustomer
        '
        Me.txtCustomer.BackColor = System.Drawing.SystemColors.Info
        Me.txtCustomer.Location = New System.Drawing.Point(68, 51)
        Me.txtCustomer.Name = "txtCustomer"
        Me.txtCustomer.Size = New System.Drawing.Size(166, 20)
        Me.txtCustomer.TabIndex = 34
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Customer"
        '
        'cboGender
        '
        Me.cboGender.BackColor = System.Drawing.SystemColors.Info
        Me.cboGender.FormattingEnabled = True
        Me.cboGender.Location = New System.Drawing.Point(67, 120)
        Me.cboGender.Name = "cboGender"
        Me.cboGender.Size = New System.Drawing.Size(166, 21)
        Me.cboGender.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(23, 124)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(42, 13)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "Gender"
        '
        'txtIdModel
        '
        Me.txtIdModel.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdModel.Location = New System.Drawing.Point(239, 74)
        Me.txtIdModel.Name = "txtIdModel"
        Me.txtIdModel.Size = New System.Drawing.Size(42, 20)
        Me.txtIdModel.TabIndex = 26
        '
        'btnModel
        '
        Me.btnModel.Location = New System.Drawing.Point(235, 142)
        Me.btnModel.Name = "btnModel"
        Me.btnModel.Size = New System.Drawing.Size(42, 24)
        Me.btnModel.TabIndex = 22
        Me.btnModel.Text = ">>"
        Me.btnModel.UseVisualStyleBackColor = True
        '
        'txtModel
        '
        Me.txtModel.BackColor = System.Drawing.SystemColors.Info
        Me.txtModel.Location = New System.Drawing.Point(67, 144)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(166, 20)
        Me.txtModel.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Model"
        '
        'txtIdColor
        '
        Me.txtIdColor.BackColor = System.Drawing.SystemColors.Info
        Me.txtIdColor.Location = New System.Drawing.Point(201, 97)
        Me.txtIdColor.Name = "txtIdColor"
        Me.txtIdColor.Size = New System.Drawing.Size(42, 20)
        Me.txtIdColor.TabIndex = 27
        '
        'btnColor
        '
        Me.btnColor.Location = New System.Drawing.Point(197, 70)
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(42, 24)
        Me.btnColor.TabIndex = 23
        Me.btnColor.Text = ">>"
        Me.btnColor.UseVisualStyleBackColor = True
        '
        'txtColor
        '
        Me.txtColor.BackColor = System.Drawing.SystemColors.Info
        Me.txtColor.Location = New System.Drawing.Point(31, 69)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(166, 20)
        Me.txtColor.TabIndex = 17
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(0, 72)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Color"
        '
        'dtPO
        '
        Me.dtPO.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtPO.Location = New System.Drawing.Point(29, 24)
        Me.dtPO.Name = "dtPO"
        Me.dtPO.Size = New System.Drawing.Size(166, 20)
        Me.dtPO.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Date"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "PO"
        '
        'txtPO
        '
        Me.txtPO.BackColor = System.Drawing.SystemColors.Info
        Me.txtPO.Location = New System.Drawing.Point(29, 3)
        Me.txtPO.Name = "txtPO"
        Me.txtPO.Size = New System.Drawing.Size(166, 20)
        Me.txtPO.TabIndex = 5
        Me.txtPO.Text = "PO/IR/II/2025/01"
        '
        'spdSize
        '
        Me.spdSize.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, "
        Me.spdSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdSize.HorizontalScrollBar.TabIndex = 0
        Me.spdSize.Location = New System.Drawing.Point(5, 377)
        Me.spdSize.Name = "spdSize"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSize_Sheet1})
        Me.spdSize.Size = New System.Drawing.Size(807, 106)
        Me.spdSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSize.TabIndex = 6
        Me.spdSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdSize.VerticalScrollBar.TabIndex = 1
        Me.spdSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSize_Sheet1
        '
        Me.spdSize_Sheet1.Reset()
        Me.spdSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSize_Sheet1.ColumnCount = 0
        Me.spdSize_Sheet1.RowCount = 1
        Me.spdSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        Me.spdSize.SetActiveViewport(0, 0, 1)
        '
        'spdContract
        '
        Me.spdContract.AccessibleDescription = "spdContract, Sheet1, Row 0, Column 0, "
        Me.spdContract.BackColor = System.Drawing.SystemColors.Control
        Me.spdContract.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdContract.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdContract.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdContract.HorizontalScrollBar.TabIndex = 16
        Me.spdContract.Location = New System.Drawing.Point(4, 67)
        Me.spdContract.Name = "spdContract"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer13
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer13
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdContract.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdContract.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdContract.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdContract_Sheet1})
        Me.spdContract.Size = New System.Drawing.Size(808, 307)
        Me.spdContract.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdContract.TabIndex = 7
        Me.spdContract.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdContract.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdContract.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdContract.VerticalScrollBar.TabIndex = 17
        Me.spdContract.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdContract_Sheet1
        '
        Me.spdContract_Sheet1.Reset()
        Me.spdContract_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdContract_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdContract_Sheet1.ColumnCount = 10
        Me.spdContract_Sheet1.RowCount = 1
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "No. Contract"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Date"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Customer"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Brand"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Product"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Model"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Id Brand"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Id Customer"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Id Product"
        Me.spdContract_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "Id Model"
        Me.spdContract_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdContract_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdContract_Sheet1.Columns.Get(0).Label = "No. Contract"
        Me.spdContract_Sheet1.Columns.Get(0).Width = 127.0!
        Me.spdContract_Sheet1.Columns.Get(1).Label = "Date"
        Me.spdContract_Sheet1.Columns.Get(1).Width = 93.0!
        Me.spdContract_Sheet1.Columns.Get(2).Label = "Customer"
        Me.spdContract_Sheet1.Columns.Get(2).Width = 270.0!
        Me.spdContract_Sheet1.Columns.Get(4).Label = "Product"
        Me.spdContract_Sheet1.Columns.Get(4).Width = 113.0!
        Me.spdContract_Sheet1.Columns.Get(5).Label = "Model"
        Me.spdContract_Sheet1.Columns.Get(5).Width = 150.0!
        Me.spdContract_Sheet1.Columns.Get(7).Label = "Id Customer"
        Me.spdContract_Sheet1.Columns.Get(7).Width = 83.0!
        Me.spdContract_Sheet1.Columns.Get(8).Label = "Id Product"
        Me.spdContract_Sheet1.Columns.Get(8).Width = 83.0!
        Me.spdContract_Sheet1.Columns.Get(9).Label = "Id Model"
        Me.spdContract_Sheet1.Columns.Get(9).Width = 83.0!
        Me.spdContract_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdContract_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdContract_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdContract_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnSize
        '
        Me.btnSize.Location = New System.Drawing.Point(5, 377)
        Me.btnSize.Name = "btnSize"
        Me.btnSize.Size = New System.Drawing.Size(37, 34)
        Me.btnSize.TabIndex = 8
        Me.btnSize.Text = ">>"
        Me.btnSize.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.cboProductCari)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.btnCustomer)
        Me.Panel2.Controls.Add(Me.txtCustomerCari)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.TextBox9)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.TextBox8)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Location = New System.Drawing.Point(4, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1345, 60)
        Me.Panel2.TabIndex = 9
        '
        'cboProductCari
        '
        Me.cboProductCari.BackColor = System.Drawing.SystemColors.Info
        Me.cboProductCari.FormattingEnabled = True
        Me.cboProductCari.Location = New System.Drawing.Point(414, 21)
        Me.cboProductCari.Name = "cboProductCari"
        Me.cboProductCari.Size = New System.Drawing.Size(107, 21)
        Me.cboProductCari.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(363, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Product"
        '
        'btnCustomer
        '
        Me.btnCustomer.Location = New System.Drawing.Point(245, 21)
        Me.btnCustomer.Name = "btnCustomer"
        Me.btnCustomer.Size = New System.Drawing.Size(42, 24)
        Me.btnCustomer.TabIndex = 26
        Me.btnCustomer.Text = ">>"
        Me.btnCustomer.UseVisualStyleBackColor = True
        '
        'txtCustomerCari
        '
        Me.txtCustomerCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtCustomerCari.Location = New System.Drawing.Point(76, 23)
        Me.txtCustomerCari.Name = "txtCustomerCari"
        Me.txtCustomerCari.Size = New System.Drawing.Size(166, 20)
        Me.txtCustomerCari.TabIndex = 19
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(19, 29)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Customer"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(746, 26)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(122, 20)
        Me.TextBox9.TabIndex = 12
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(709, 29)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Color"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(575, 24)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(122, 20)
        Me.TextBox8.TabIndex = 10
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(538, 26)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Model"
        '
        'pnlHelpColor
        '
        Me.pnlHelpColor.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpColor.Controls.Add(Me.btnCloseColor)
        Me.pnlHelpColor.Controls.Add(Me.spdHelpColor)
        Me.pnlHelpColor.Controls.Add(Me.txtHelpCariColor)
        Me.pnlHelpColor.Controls.Add(Me.Label18)
        Me.pnlHelpColor.Location = New System.Drawing.Point(1087, 100)
        Me.pnlHelpColor.Name = "pnlHelpColor"
        Me.pnlHelpColor.Size = New System.Drawing.Size(257, 260)
        Me.pnlHelpColor.TabIndex = 15
        Me.pnlHelpColor.Visible = False
        '
        'btnCloseColor
        '
        Me.btnCloseColor.Location = New System.Drawing.Point(3, 233)
        Me.btnCloseColor.Name = "btnCloseColor"
        Me.btnCloseColor.Size = New System.Drawing.Size(251, 24)
        Me.btnCloseColor.TabIndex = 14
        Me.btnCloseColor.Text = "Close"
        Me.btnCloseColor.UseVisualStyleBackColor = True
        '
        'spdHelpColor
        '
        Me.spdHelpColor.AccessibleDescription = "spdHelpColor, Sheet1, Row 0, Column 0, "
        Me.spdHelpColor.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpColor.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpColor.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpColor.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdHelpColor.HorizontalScrollBar.TabIndex = 14
        Me.spdHelpColor.Location = New System.Drawing.Point(0, 32)
        Me.spdHelpColor.Name = "spdHelpColor"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.Renderer = EnhancedColumnHeaderRenderer9
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.Renderer = EnhancedRowHeaderRenderer9
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdHelpColor.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdHelpColor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpColor.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpColor_Sheet1})
        Me.spdHelpColor.Size = New System.Drawing.Size(251, 195)
        Me.spdHelpColor.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpColor.TabIndex = 13
        Me.spdHelpColor.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpColor.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpColor.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdHelpColor.VerticalScrollBar.TabIndex = 15
        Me.spdHelpColor.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpColor_Sheet1
        '
        Me.spdHelpColor_Sheet1.Reset()
        Me.spdHelpColor_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpColor_Sheet1.ColumnCount = 2
        Me.spdHelpColor_Sheet1.RowCount = 1
        Me.spdHelpColor_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHelpColor_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Color"
        Me.spdHelpColor_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpColor_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpColor_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHelpColor_Sheet1.Columns.Get(0).Width = 38.0!
        Me.spdHelpColor_Sheet1.Columns.Get(1).Label = "Color"
        Me.spdHelpColor_Sheet1.Columns.Get(1).Width = 157.0!
        Me.spdHelpColor_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdHelpColor_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpColor_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'txtHelpCariColor
        '
        Me.txtHelpCariColor.Location = New System.Drawing.Point(72, 6)
        Me.txtHelpCariColor.Name = "txtHelpCariColor"
        Me.txtHelpCariColor.Size = New System.Drawing.Size(127, 20)
        Me.txtHelpCariColor.TabIndex = 12
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(15, 9)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(31, 13)
        Me.Label18.TabIndex = 11
        Me.Label18.Text = "Color"
        '
        'pnlPO
        '
        Me.pnlPO.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlPO.Controls.Add(Me.txtDesc)
        Me.pnlPO.Controls.Add(Me.Label9)
        Me.pnlPO.Controls.Add(Me.txtStyle)
        Me.pnlPO.Controls.Add(Me.Label8)
        Me.pnlPO.Controls.Add(Me.dtETD)
        Me.pnlPO.Controls.Add(Me.Label4)
        Me.pnlPO.Controls.Add(Me.btnClosePO)
        Me.pnlPO.Controls.Add(Me.btnDeletePO)
        Me.pnlPO.Controls.Add(Me.btnSavePO)
        Me.pnlPO.Controls.Add(Me.txtPO)
        Me.pnlPO.Controls.Add(Me.Label1)
        Me.pnlPO.Controls.Add(Me.dtPO)
        Me.pnlPO.Controls.Add(Me.Label2)
        Me.pnlPO.Controls.Add(Me.txtColor)
        Me.pnlPO.Controls.Add(Me.Label7)
        Me.pnlPO.Controls.Add(Me.btnColor)
        Me.pnlPO.Controls.Add(Me.txtIdColor)
        Me.pnlPO.Location = New System.Drawing.Point(834, 119)
        Me.pnlPO.Name = "pnlPO"
        Me.pnlPO.Size = New System.Drawing.Size(247, 211)
        Me.pnlPO.TabIndex = 32
        Me.pnlPO.Visible = False
        '
        'txtDesc
        '
        Me.txtDesc.BackColor = System.Drawing.SystemColors.Info
        Me.txtDesc.Location = New System.Drawing.Point(31, 114)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(166, 45)
        Me.txtDesc.TabIndex = 29
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1, 130)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 13)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Desc"
        '
        'txtStyle
        '
        Me.txtStyle.BackColor = System.Drawing.SystemColors.Info
        Me.txtStyle.Location = New System.Drawing.Point(31, 91)
        Me.txtStyle.Name = "txtStyle"
        Me.txtStyle.Size = New System.Drawing.Size(166, 20)
        Me.txtStyle.TabIndex = 27
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(1, 94)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 13)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Style"
        '
        'dtETD
        '
        Me.dtETD.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtETD.Location = New System.Drawing.Point(30, 46)
        Me.dtETD.Name = "dtETD"
        Me.dtETD.Size = New System.Drawing.Size(81, 20)
        Me.dtETD.TabIndex = 25
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "ETD"
        '
        'btnClosePO
        '
        Me.btnClosePO.Location = New System.Drawing.Point(157, 168)
        Me.btnClosePO.Name = "btnClosePO"
        Me.btnClosePO.Size = New System.Drawing.Size(72, 27)
        Me.btnClosePO.TabIndex = 6
        Me.btnClosePO.Text = "Close"
        Me.btnClosePO.UseVisualStyleBackColor = True
        '
        'btnDeletePO
        '
        Me.btnDeletePO.Location = New System.Drawing.Point(83, 169)
        Me.btnDeletePO.Name = "btnDeletePO"
        Me.btnDeletePO.Size = New System.Drawing.Size(72, 27)
        Me.btnDeletePO.TabIndex = 5
        Me.btnDeletePO.Text = "Delete"
        Me.btnDeletePO.UseVisualStyleBackColor = True
        '
        'btnSavePO
        '
        Me.btnSavePO.Location = New System.Drawing.Point(8, 168)
        Me.btnSavePO.Name = "btnSavePO"
        Me.btnSavePO.Size = New System.Drawing.Size(72, 27)
        Me.btnSavePO.TabIndex = 4
        Me.btnSavePO.Text = "Save"
        Me.btnSavePO.UseVisualStyleBackColor = True
        '
        'spdPO
        '
        Me.spdPO.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdPO.BackColor = System.Drawing.SystemColors.Control
        Me.spdPO.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdPO.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdPO.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdPO.HorizontalScrollBar.TabIndex = 10
        Me.spdPO.Location = New System.Drawing.Point(811, 67)
        Me.spdPO.Name = "spdPO"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer12
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer12
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdPO.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdPO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdPO.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdPO_Sheet1})
        Me.spdPO.Size = New System.Drawing.Size(540, 307)
        Me.spdPO.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdPO.TabIndex = 33
        Me.spdPO.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdPO.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdPO.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdPO.VerticalScrollBar.TabIndex = 11
        Me.spdPO.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdPO_Sheet1
        '
        Me.spdPO_Sheet1.Reset()
        Me.spdPO_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdPO_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdPO_Sheet1.ColumnCount = 5
        Me.spdPO_Sheet1.RowCount = 1
        Me.spdPO_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "PO"
        Me.spdPO_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Date"
        Me.spdPO_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "ETD"
        Me.spdPO_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Color"
        Me.spdPO_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Color Id"
        Me.spdPO_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdPO_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdPO_Sheet1.Columns.Get(0).Label = "PO"
        Me.spdPO_Sheet1.Columns.Get(0).Width = 146.0!
        Me.spdPO_Sheet1.Columns.Get(1).Label = "Date"
        Me.spdPO_Sheet1.Columns.Get(1).Width = 99.0!
        Me.spdPO_Sheet1.Columns.Get(2).Label = "ETD"
        Me.spdPO_Sheet1.Columns.Get(2).Width = 100.0!
        Me.spdPO_Sheet1.Columns.Get(3).Label = "Color"
        Me.spdPO_Sheet1.Columns.Get(3).Width = 151.0!
        Me.spdPO_Sheet1.Columns.Get(4).Label = "Color Id"
        Me.spdPO_Sheet1.Columns.Get(4).Width = 42.0!
        Me.spdPO_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdPO_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdPO_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdPO_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlModel
        '
        Me.pnlModel.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlModel.Controls.Add(Me.pnlUpdateSize)
        Me.pnlModel.Controls.Add(Me.btnCariModel)
        Me.pnlModel.Controls.Add(Me.btnCloseModel)
        Me.pnlModel.Controls.Add(Me.spdHelpModel)
        Me.pnlModel.Controls.Add(Me.txtHelpModelCari)
        Me.pnlModel.Controls.Add(Me.Label17)
        Me.pnlModel.Location = New System.Drawing.Point(364, 103)
        Me.pnlModel.Name = "pnlModel"
        Me.pnlModel.Size = New System.Drawing.Size(257, 260)
        Me.pnlModel.TabIndex = 34
        Me.pnlModel.Visible = False
        '
        'pnlUpdateSize
        '
        Me.pnlUpdateSize.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlUpdateSize.Controls.Add(Me.btnSizeUpdate)
        Me.pnlUpdateSize.Controls.Add(Me.btnCloseSizeUpdate)
        Me.pnlUpdateSize.Controls.Add(Me.spdSizeUpdate)
        Me.pnlUpdateSize.Location = New System.Drawing.Point(246, 0)
        Me.pnlUpdateSize.Name = "pnlUpdateSize"
        Me.pnlUpdateSize.Size = New System.Drawing.Size(183, 369)
        Me.pnlUpdateSize.TabIndex = 18
        Me.pnlUpdateSize.Visible = False
        '
        'btnSizeUpdate
        '
        Me.btnSizeUpdate.Location = New System.Drawing.Point(1, 315)
        Me.btnSizeUpdate.Name = "btnSizeUpdate"
        Me.btnSizeUpdate.Size = New System.Drawing.Size(176, 24)
        Me.btnSizeUpdate.TabIndex = 15
        Me.btnSizeUpdate.Text = "Update"
        Me.btnSizeUpdate.UseVisualStyleBackColor = True
        '
        'btnCloseSizeUpdate
        '
        Me.btnCloseSizeUpdate.Location = New System.Drawing.Point(1, 340)
        Me.btnCloseSizeUpdate.Name = "btnCloseSizeUpdate"
        Me.btnCloseSizeUpdate.Size = New System.Drawing.Size(176, 24)
        Me.btnCloseSizeUpdate.TabIndex = 14
        Me.btnCloseSizeUpdate.Text = "Close"
        Me.btnCloseSizeUpdate.UseVisualStyleBackColor = True
        '
        'spdSizeUpdate
        '
        Me.spdSizeUpdate.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdSizeUpdate.BackColor = System.Drawing.SystemColors.Control
        Me.spdSizeUpdate.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSizeUpdate.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSizeUpdate.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdSizeUpdate.HorizontalScrollBar.TabIndex = 0
        Me.spdSizeUpdate.Location = New System.Drawing.Point(5, 6)
        Me.spdSizeUpdate.Name = "spdSizeUpdate"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer10
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer10
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdSizeUpdate.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdSizeUpdate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSizeUpdate.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSizeUpdate_Sheet1})
        Me.spdSizeUpdate.Size = New System.Drawing.Size(172, 305)
        Me.spdSizeUpdate.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSizeUpdate.TabIndex = 13
        Me.spdSizeUpdate.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSizeUpdate.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSizeUpdate.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdSizeUpdate.VerticalScrollBar.TabIndex = 1
        Me.spdSizeUpdate.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSizeUpdate_Sheet1
        '
        Me.spdSizeUpdate_Sheet1.Reset()
        Me.spdSizeUpdate_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSizeUpdate_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSizeUpdate_Sheet1.ColumnCount = 2
        Me.spdSizeUpdate_Sheet1.RowCount = 50
        Me.spdSizeUpdate_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "SIZE"
        Me.spdSizeUpdate_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "QTY"
        Me.spdSizeUpdate_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSizeUpdate_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSizeUpdate_Sheet1.Columns.Get(0).Label = "SIZE"
        Me.spdSizeUpdate_Sheet1.Columns.Get(0).Width = 52.0!
        Me.spdSizeUpdate_Sheet1.Columns.Get(1).Label = "QTY"
        Me.spdSizeUpdate_Sheet1.Columns.Get(1).Width = 63.0!
        Me.spdSizeUpdate_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdSizeUpdate_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSizeUpdate_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSizeUpdate_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnCariModel
        '
        Me.btnCariModel.Location = New System.Drawing.Point(205, 6)
        Me.btnCariModel.Name = "btnCariModel"
        Me.btnCariModel.Size = New System.Drawing.Size(46, 24)
        Me.btnCariModel.TabIndex = 26
        Me.btnCariModel.Text = ">>"
        Me.btnCariModel.UseVisualStyleBackColor = True
        '
        'btnCloseModel
        '
        Me.btnCloseModel.Location = New System.Drawing.Point(3, 233)
        Me.btnCloseModel.Name = "btnCloseModel"
        Me.btnCloseModel.Size = New System.Drawing.Size(251, 24)
        Me.btnCloseModel.TabIndex = 14
        Me.btnCloseModel.Text = "Close"
        Me.btnCloseModel.UseVisualStyleBackColor = True
        '
        'spdHelpModel
        '
        Me.spdHelpModel.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdHelpModel.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpModel.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpModel.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer11.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpModel.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer11
        Me.spdHelpModel.HorizontalScrollBar.TabIndex = 14
        Me.spdHelpModel.Location = New System.Drawing.Point(3, 32)
        Me.spdHelpModel.Name = "spdHelpModel"
        NamedStyle21.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle21.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle21.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle21.Renderer = EnhancedColumnHeaderRenderer8
        NamedStyle21.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle22.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle22.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle22.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle22.Renderer = EnhancedRowHeaderRenderer8
        NamedStyle22.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle23.BackColor = System.Drawing.Color.DimGray
        NamedStyle23.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle23.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer6.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer6.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer6.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle23.Renderer = EnhancedCornerRenderer6
        NamedStyle23.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle24.BackColor = System.Drawing.SystemColors.Window
        NamedStyle24.CellType = GeneralCellType6
        NamedStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle24.Renderer = GeneralCellType6
        Me.spdHelpModel.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle21, NamedStyle22, NamedStyle23, NamedStyle24})
        Me.spdHelpModel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpModel.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpModel_Sheet1})
        Me.spdHelpModel.Size = New System.Drawing.Size(251, 195)
        Me.spdHelpModel.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpModel.TabIndex = 13
        Me.spdHelpModel.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpModel.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer12.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpModel.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer12
        Me.spdHelpModel.VerticalScrollBar.TabIndex = 15
        Me.spdHelpModel.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpModel_Sheet1
        '
        Me.spdHelpModel_Sheet1.Reset()
        Me.spdHelpModel_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpModel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpModel_Sheet1.ColumnCount = 2
        Me.spdHelpModel_Sheet1.RowCount = 1
        Me.spdHelpModel_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHelpModel_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Model"
        Me.spdHelpModel_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpModel_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpModel_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHelpModel_Sheet1.Columns.Get(0).Width = 38.0!
        Me.spdHelpModel_Sheet1.Columns.Get(1).Label = "Model"
        Me.spdHelpModel_Sheet1.Columns.Get(1).Width = 157.0!
        Me.spdHelpModel_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdHelpModel_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpModel_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpModel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'txtHelpModelCari
        '
        Me.txtHelpModelCari.Location = New System.Drawing.Point(72, 6)
        Me.txtHelpModelCari.Name = "txtHelpModelCari"
        Me.txtHelpModelCari.Size = New System.Drawing.Size(127, 20)
        Me.txtHelpModelCari.TabIndex = 12
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(15, 9)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(36, 13)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "Model"
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(6, 70)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(34, 29)
        Me.btnOrder.TabIndex = 35
        Me.btnOrder.Text = "Add"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(811, 67)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 40)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "Add"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'pnlHelpSizeUpdate
        '
        Me.pnlHelpSizeUpdate.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnCloseSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnSaveSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.spdUpdateSize)
        Me.pnlHelpSizeUpdate.Location = New System.Drawing.Point(201, 380)
        Me.pnlHelpSizeUpdate.Name = "pnlHelpSizeUpdate"
        Me.pnlHelpSizeUpdate.Size = New System.Drawing.Size(517, 141)
        Me.pnlHelpSizeUpdate.TabIndex = 37
        Me.pnlHelpSizeUpdate.Visible = False
        '
        'btnCloseSize
        '
        Me.btnCloseSize.Location = New System.Drawing.Point(3, 104)
        Me.btnCloseSize.Name = "btnCloseSize"
        Me.btnCloseSize.Size = New System.Drawing.Size(511, 32)
        Me.btnCloseSize.TabIndex = 15
        Me.btnCloseSize.Text = "Close"
        Me.btnCloseSize.UseVisualStyleBackColor = True
        '
        'btnSaveSize
        '
        Me.btnSaveSize.Location = New System.Drawing.Point(3, 71)
        Me.btnSaveSize.Name = "btnSaveSize"
        Me.btnSaveSize.Size = New System.Drawing.Size(511, 32)
        Me.btnSaveSize.TabIndex = 14
        Me.btnSaveSize.Text = "Save"
        Me.btnSaveSize.UseVisualStyleBackColor = True
        '
        'spdUpdateSize
        '
        Me.spdUpdateSize.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdUpdateSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdUpdateSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer13.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer13.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer13.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer13.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer13.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer13
        Me.spdUpdateSize.HorizontalScrollBar.TabIndex = 0
        Me.spdUpdateSize.Location = New System.Drawing.Point(3, 4)
        Me.spdUpdateSize.Name = "spdUpdateSize"
        NamedStyle25.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle25.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle25.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle25.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle26.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle26.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle26.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle26.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle27.BackColor = System.Drawing.Color.DimGray
        NamedStyle27.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle27.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer7.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer7.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer7.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle27.Renderer = EnhancedCornerRenderer7
        NamedStyle27.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle28.BackColor = System.Drawing.SystemColors.Window
        NamedStyle28.CellType = GeneralCellType7
        NamedStyle28.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle28.Renderer = GeneralCellType7
        Me.spdUpdateSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle25, NamedStyle26, NamedStyle27, NamedStyle28})
        Me.spdUpdateSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdUpdateSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdUpdateSize_Sheet1})
        Me.spdUpdateSize.Size = New System.Drawing.Size(511, 65)
        Me.spdUpdateSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdUpdateSize.TabIndex = 13
        Me.spdUpdateSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer14.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer14.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer14.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer14.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer14.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer14
        Me.spdUpdateSize.VerticalScrollBar.TabIndex = 1
        Me.spdUpdateSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdUpdateSize_Sheet1
        '
        Me.spdUpdateSize_Sheet1.Reset()
        Me.spdUpdateSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdUpdateSize_Sheet1.ColumnCount = 30
        Me.spdUpdateSize_Sheet1.ColumnHeader.RowCount = 0
        Me.spdUpdateSize_Sheet1.RowCount = 2
        Me.spdUpdateSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdUpdateSize_Sheet1.Columns.Get(0).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(1).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(2).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(3).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(4).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(5).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(6).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(7).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(8).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(9).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(10).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(11).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(12).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(13).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(14).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(15).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(16).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(17).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(18).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(19).Width = 55.0!
        Me.spdUpdateSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdUpdateSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdUpdateSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdComponent
        '
        Me.spdComponent.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer15.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer15
        Me.spdComponent.HorizontalScrollBar.TabIndex = 2
        Me.spdComponent.Location = New System.Drawing.Point(814, 377)
        Me.spdComponent.Name = "spdComponent"
        NamedStyle29.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle29.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle29.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle29.Renderer = EnhancedColumnHeaderRenderer14
        NamedStyle29.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle30.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle30.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle30.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle30.Renderer = EnhancedRowHeaderRenderer14
        NamedStyle30.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle31.BackColor = System.Drawing.Color.DimGray
        NamedStyle31.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle31.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer8.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer8.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer8.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle31.Renderer = EnhancedCornerRenderer8
        NamedStyle31.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle32.BackColor = System.Drawing.SystemColors.Window
        NamedStyle32.CellType = GeneralCellType8
        NamedStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle32.Renderer = GeneralCellType8
        Me.spdComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle29, NamedStyle30, NamedStyle31, NamedStyle32})
        Me.spdComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdComponent_Sheet1})
        Me.spdComponent.Size = New System.Drawing.Size(533, 106)
        Me.spdComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdComponent.TabIndex = 38
        Me.spdComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer16.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer16
        Me.spdComponent.VerticalScrollBar.TabIndex = 3
        Me.spdComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdComponent_Sheet1
        '
        Me.spdComponent_Sheet1.Reset()
        Me.spdComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdComponent_Sheet1.ColumnCount = 3
        Me.spdComponent_Sheet1.RowCount = 1
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Component"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Mold Code"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Moldshop"
        Me.spdComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdComponent_Sheet1.Columns.Get(0).Label = "Component"
        Me.spdComponent_Sheet1.Columns.Get(0).Width = 112.0!
        Me.spdComponent_Sheet1.Columns.Get(1).Label = "Mold Code"
        Me.spdComponent_Sheet1.Columns.Get(1).Width = 102.0!
        Me.spdComponent_Sheet1.Columns.Get(2).Label = "Moldshop"
        Me.spdComponent_Sheet1.Columns.Get(2).Width = 107.0!
        Me.spdComponent_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmOrderCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.spdComponent)
        Me.Controls.Add(Me.pnlHelpSizeUpdate)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.pnlKontrak)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.pnlModel)
        Me.Controls.Add(Me.pnlPO)
        Me.Controls.Add(Me.pnlHelpColor)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnSize)
        Me.Controls.Add(Me.spdSize)
        Me.Controls.Add(Me.spdContract)
        Me.Controls.Add(Me.spdPO)
        Me.Name = "frmOrderCustomer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmOrderCustomer"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pnlKontrak.ResumeLayout(False)
        Me.pnlKontrak.PerformLayout()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdContract, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdContract_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnlHelpColor.ResumeLayout(False)
        Me.pnlHelpColor.PerformLayout()
        CType(Me.spdHelpColor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpColor_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlPO.ResumeLayout(False)
        Me.pnlPO.PerformLayout()
        CType(Me.spdPO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdPO_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlModel.ResumeLayout(False)
        Me.pnlModel.PerformLayout()
        Me.pnlUpdateSize.ResumeLayout(False)
        CType(Me.spdSizeUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSizeUpdate_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpModel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpModel_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpSizeUpdate.ResumeLayout(False)
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlKontrak As System.Windows.Forms.Panel
    Friend WithEvents txtPO As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dtPO As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtColor As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtModel As System.Windows.Forms.TextBox
    Friend WithEvents spdSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdContract As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdContract_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnSize As System.Windows.Forms.Button
    Friend WithEvents btnModel As System.Windows.Forms.Button
    Friend WithEvents btnColor As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtIdColor As System.Windows.Forms.TextBox
    Friend WithEvents txtIdModel As System.Windows.Forms.TextBox
    Friend WithEvents pnlHelpColor As System.Windows.Forms.Panel
    Friend WithEvents btnCloseColor As System.Windows.Forms.Button
    Friend WithEvents spdHelpColor As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpColor_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents txtHelpCariColor As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cboGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents btnCustomer As System.Windows.Forms.Button
    Friend WithEvents txtCustomerCari As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cboProductCari As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtCustomer As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label

    Private Sub spdHelpColor_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpColor.CellClick

    End Sub
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtNoKontrak As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents cboProduct As System.Windows.Forms.ComboBox
    Friend WithEvents cboBrand As System.Windows.Forms.ComboBox
    Friend WithEvents btnHelpCustomer As System.Windows.Forms.Button
    Friend WithEvents txtIdCustomer As System.Windows.Forms.TextBox
    Friend WithEvents pnlPO As System.Windows.Forms.Panel
    Friend WithEvents btnClosePO As System.Windows.Forms.Button
    Friend WithEvents btnDeletePO As System.Windows.Forms.Button
    Friend WithEvents btnSavePO As System.Windows.Forms.Button
    Friend WithEvents dtETD As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents spdPO As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdPO_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlModel As System.Windows.Forms.Panel
    Friend WithEvents pnlUpdateSize As System.Windows.Forms.Panel
    Friend WithEvents btnSizeUpdate As System.Windows.Forms.Button
    Friend WithEvents btnCloseSizeUpdate As System.Windows.Forms.Button
    Friend WithEvents spdSizeUpdate As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSizeUpdate_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnCariModel As System.Windows.Forms.Button
    Friend WithEvents btnCloseModel As System.Windows.Forms.Button
    Friend WithEvents spdHelpModel As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpModel_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents txtHelpModelCari As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtStyle As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnCloseContract As System.Windows.Forms.Button
    Friend WithEvents btnDeleteContract As System.Windows.Forms.Button
    Friend WithEvents btnSaveContract As System.Windows.Forms.Button
    Friend WithEvents txtDescContract As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents dtContract As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents pnlHelpSizeUpdate As System.Windows.Forms.Panel
    Friend WithEvents btnCloseSize As System.Windows.Forms.Button
    Friend WithEvents btnSaveSize As System.Windows.Forms.Button
    Friend WithEvents spdUpdateSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdUpdateSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdComponent_Sheet1 As FarPoint.Win.Spread.SheetView
End Class
