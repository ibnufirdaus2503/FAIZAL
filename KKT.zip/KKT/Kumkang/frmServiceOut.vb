﻿Public Class frmServiceOut
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold As Integer
    Dim ROW As Integer
    Public Sub cmdInsert()
        FP_CLEAR()
    End Sub
    Public Sub cmdUpdate()

    End Sub
    Public Sub cmdInquery()
        FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()


    End Sub
    Public Sub cmdPrint()
        FP_PRINT()
    End Sub
    Private Sub FP_INIT()
        FP_COMBO_TYPE()
        FP_LIST_HEAD()
        FP_COMBO_CAR()
    End Sub
    Private Sub FP_COMBO_CAR()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_CARX' " & vbLf
        SQL_C += "ORDER BY codd_desc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboMobil
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub FP_QUERY_REPORT()
        SQL_C = ""
        SQL_C = SQL_C + "SELECT A.molh_idxx,model_name,codd_desc,MoldSet,qty" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT " & vbLf
        SQL_C = SQL_C + "molh_idxx," & vbLf
        SQL_C = SQL_C + "STUFF((" & vbLf
        SQL_C = SQL_C + "	SELECT ',' + mols_size+'('+ mold_idxx+')'" & vbLf
        SQL_C = SQL_C + "	FROM KKTERP.dbo.mold_detail_service t1" & vbLf
        SQL_C = SQL_C + "WHERE t1.molh_idxx = t2.molh_idxx And t1.serh_idxx = " & txtIdHeader.Text & vbLf
        SQL_C = SQL_C + "		FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'), 1, 1, '') AS MoldSet " & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + " KKTERP.dbo.mold_detail_service t2 " & vbLf
        SQL_C = SQL_C + " GROUP BY " & vbLf
        SQL_C = SQL_C + " molh_idxx " & vbLf
        SQL_C = SQL_C + ") A" & vbLf
        SQL_C = SQL_C + " INNER Join " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT molh_idxx,molh_code ,customer_name,brand_name,model_name,vend_name moldshop,codd_desc" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.mold_header A" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.vmodel B ON A.modl_idxx=B.model_id " & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' AND C.codd_valu=CODE_COMP" & vbLf
        SQL_C = SQL_C + ") B ON A.molh_idxx=B.molh_idxx" & vbLf
        SQL_C = SQL_C + "INNER Join " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT molh_idxx,count(mold_idxx) qty" & vbLf
        SQL_C = SQL_C + "FROM  KKTERP.dbo.mold_detail_service " & vbLf
        SQL_C = SQL_C + "WHERE serh_idxx =  " & txtIdHeader.Text & vbLf
        SQL_C = SQL_C + "GROUP BY molh_idxx" & vbLf
        SQL_C = SQL_C + ") C ON A.molh_idxx=C.molh_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdReport_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("MoldSet")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("qty")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    
    Sub FP_PRINT()
        Dim SQL_C As String
        Dim k As Int16



        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.TEMP_PRINT WHERE TEMP_USER='SJ'"

        '/* Execute
        clsCom.GP_ExeSql(SQL_C)

        With spdReport_Sheet1
            For k = 0 To .RowCount - 1
                SQL_C = ""
                SQL_C = SQL_C + " INSERT INTO KKTERP.dbo.TEMP_PRINT (TEMP_USER,TEMP_VA01,TEMP_VA02,TEMP_VA03,TEMP_VA04,TEMP_VA05,TEMP_VA06,TEMP_IN01,TEMP_IN02,TEMP_TX01) VALUES ('SJ','" & txtSJ.Text & "','" & dtSJ.Value & "','" & txtMoldshop.Text & "','" & Strings.Trim(Strings.Left(cboMobil.Text, 40)) & "','" & txtNoMobil.Text & "','" & .Cells.Item(k, 0).Text + " " + .Cells.Item(k, 1).Text + " " + .Cells.Item(k, 2).Text & "'," & k + 1 & "," & .Cells.Item(k, 3).Text & ",'" & txtKeterangan.Text & "')" & vbLf

                clsCom.GP_ExeSql(SQL_C)
            Next
           

            '/* Execute

        End With

        frmReport.ShowDialog()


        ' clsVAR.gv_Help(0).Help_str1 = "SJ"




    End Sub
    Private Sub FP_LIST_HEAD_SET_MOLD()
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT  mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_service A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where serh_idxx = " & txtIdHeader.Text
        SQL_C += " group by mols_size,mold_idxx" & vbLf
        SQL_C += "order by vseqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_CLEAR()
        txtIdHeader.Text = ""
        txtIdMoldshop.Text = ""
        txtMoldshop.Text = ""
        txtSJ.Text = ""
    End Sub
    Private Sub FP_LIST_FILL()



        With spdHead_Sheet1.Cells

           

            txtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text
            dtSJ.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text

            cboType.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 3).Text & Space(100) & .Item(spdHead_Sheet1.ActiveRowIndex, 11).Text
            cboMobil.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text & Space(100) & .Item(spdHead_Sheet1.ActiveRowIndex, 9).Text
            txtMoldshop.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 2).Text
            txtIdMoldshop.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 8).Text

            txtIdHeader.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 7).Text
            txtKeterangan.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 6).Text
            txtNoMobil.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 5).Text
        End With
    End Sub
    Private Sub FP_LIST_HEAD_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT DISTINCT A.molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name,QTY" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null AND molh_idxx in (SELECT molh_idxx FROM  KKTERP.dbo.mold_detail_service where serh_idxx=" & txtIdHeader.Text & ")" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,mols_size,count(mold_idxx) qty" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  molh_idxx,mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_service A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where serh_idxx =   " & txtIdHeader.Text & "" & vbLf
        SQL_C += "group by molh_idxx,mols_size,mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY molh_idxx,mols_size" & vbLf
        SQL_C += ")B ON A.molh_idxx=B.molh_idxx" & vbLf
        SQL_C += "ORDER BY codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD()

        SQL_C = ""
 
        SQL_C += "SELECT serh_idxx,serh_sjxx,convert(varchar(10),serh_date,111) serh_date,B.codd_desc VTYPE,CODE_MOTR,vend_name,A.vend_idxx,A.CODE_VEND,D.codd_desc VCAR,serh_carx,serh_desc,CODE_CARX" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header_service A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_MOTR' AND CODE_MOTR=codd_valu" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.VendorMold C on C.vend_idxx=A.vend_idxx AND C.CODE_VEND=A.CODE_VEND" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_CARX' AND CODE_CARX=D.codd_valu" & vbLf
        SQL_C += "WHERE serh_idxx Is Not null " & vbLf
        SQL_C += "order by serh_date" & vbLf
 

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("serh_date")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("serh_sjxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vend_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("VTYPE")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("VCAR")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("serh_carx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("serh_desc")

                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("serh_idxx")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("vend_idxx")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("CODE_MOTR")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("CODE_VEND")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("CODE_CARX")


              


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_LIST_SET_MOLD(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += "where CODE_INOT=1 AND  molh_idxx = " & spdHelpComponent_Sheet1.Cells.Item(ID, 0).Text & " AND CODE_BUIL='8A'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY mols_size,mold_idxx" & vbLf
        SQL_C += "ORDER BY vseqn " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpSize_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null " & vbLf

        If txtModelHelpCari.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModelHelpCari.Text & "%'"
        End If
        SQL_C += " order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_TYPE()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_MOTR' AND cod1_valu='O'" & vbLf
        SQL_C += "ORDER BY codd_desc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboType
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmServiceOut_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        

        FP_INIT()
    End Sub

    Private Sub btnMoldshop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoldshop.Click
        frmHelpMoldshop.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdMoldshop.Text = .Help_str1
            txtMoldshop.Text = .Help_str2





        End With

errHandle:
    End Sub

    Private Sub btnHelpUpdateSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpUpdateSize.Click
        If txtMoldshop.Text = "" Or txtSJ.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        pnlUpdateMold.Visible = True
    End Sub

    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariModel.Click
        FP_LIST_HELP_COMPONENT()
    End Sub

    Private Sub spdHelpComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpComponent.CellClick
        code_mold = e.Row
        FP_LIST_SET_MOLD(code_mold)
    End Sub

    Private Sub spdHelpSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpSize.CellClick

        If spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor <> Color.LimeGreen Then
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.LimeGreen
        Else
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.White
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim i, j As Integer

        If txtIdHeader.Text = "" Then
            

            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.mold_header_service (serh_sjxx,serh_date,vend_idxx,CODE_MOTR,CODE_CARX,serh_carx,serh_desc)  VALUES ('" & txtSJ.Text & "','" & dtSJ.Text & "'," & txtIdMoldshop.Text & "," & Strings.Trim(Strings.Right(cboType.Text, 5)) & "," & Strings.Trim(Strings.Right(cboMobil.Text, 5)) & ",'" & txtNoMobil.Text & "','" & txtKeterangan.Text & "')"

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "SELECT TOP 1 serh_idxx FROM KKTERP.dbo.mold_header_service ORDER BY serh_idxx desc"

            clsCom.GP_ExeSqlReader(SQL_C)

            clsCom.gv_DataRdr.Read()
            txtIdHeader.Text = clsCom.gv_DataRdr("serh_idxx")

            clsCom.gv_ExeSqlReaderEnd()

           


        End If

        With spdHelpSize_Sheet1

            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    If .Cells.Item(j, i).BackColor = Color.LimeGreen Then
 
                        SQL_C = ""
                        SQL_C += "INSERT INTO KKTERP.dbo.mold_detail_service (serh_idxx,molh_idxx,mold_idxx,mols_size) VALUES (" & txtIdHeader.Text & "," & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & ",'" & .Cells.Item(j, i).Text & "','" & .ColumnHeader.Cells.Item(0, i).Text & "')"

                        clsCom.GP_ExeSql(SQL_C)

                        SQL_C = ""
                        SQL_C += "UPDATE KKTERP.dbo.mold_stock SET CODE_MOTR=" & Strings.Trim(Strings.Right(cboType.Text, 5)) & ",CODE_INOT=2,CODE_BUIL='',vend_idxx=" & txtIdMoldshop.Text & " where mold_idxx='" & .Cells.Item(j, i).Text & "' AND molh_idxx=" & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & " AND mols_size='" & .ColumnHeader.Cells.Item(0, i).Text & "'"

                        clsCom.GP_ExeSql(SQL_C)

                    End If
                Next
            Next

        End With

        'FP_CLEAR()
        FP_LIST_HEAD_COMPONENT()
        FP_LIST_HEAD()

        pnlUpdateMold.Visible = False
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        FP_LIST_FILL()
        FP_LIST_HEAD_COMPONENT()
        FP_QUERY_REPORT()
    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        If e.Column = 7 Then
            pnlUpdateMold.Visible = True

            With spdComponent_Sheet1.Cells
                spdHelpComponent_Sheet1.Cells.Item(0, 0).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 1).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 1).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 2).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 2).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 3).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 3).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 4).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 4).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 5).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 5).Text
                '  spdHelpComponent_Sheet1.Cells.Item(0, 6).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 6).Text
            End With
        End If
        FP_LIST_HEAD_SET_MOLD()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlUpdateMold.Visible = False
    End Sub
End Class