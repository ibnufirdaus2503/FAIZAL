﻿Public Class frmModelMold
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vRowProduct, VIDBuilding As String
    Private Sub FP_LIST_BUILDING()

        Dim i As Integer
       
        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.mold_building where molh_idxx=" & vRowProduct

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("QTY") = 0 Then
            spdBuilding_Sheet1.RowCount = 0
            spdBuilding_Sheet1.ColumnCount = 3
            Exit Sub
        End If

        clsCom.gv_ExeSqlReaderEnd()

        
        SQL_C = ""
        SQL_C += "EXEC SIZE_SEQN  " & vRowProduct

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBuilding_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read


                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CODE_BUIL")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("varea")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vbuil")

                For i = 3 To .ColumnCount - 1

                    If clsCom.gv_DataRdr(i) Is DBNull.Value Then

                    Else
                        .Cells.Item(.RowCount - 1, i).Text = "x"
                    End If

                Next





            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SIZE_HEADER()
        SQL_C = ""
        SQL_C += "SELECT mols_size,mols_seqn FROM KKTERP.dbo.mold_size WHERE molh_idxx= " & vRowProduct & "ORDER BY mols_seqn"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBuilding_Sheet1
            .ColumnCount = 3
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                ' .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_LIST_SIZE_BUILDING()
        Dim SQL_C As String

        'SQL_C = ""
        'SQL_C += "SELECT molh_idxx,mols_size,mols_cavi " & vbLf
        'SQL_C += "FROM KKTERP.dbo.mold_size" & vbLf
        'SQL_C += "WHERE molh_idxx=" & vRowProduct
        'SQL_C += "order by mols_seqn" & vbLf


        SQL_C = ""
        SQL_C += "SELECT A.molh_idxx,A.mols_size,mols_cavi,isnull(B.mols_size,0) vsize,vbuilding,CODE_BUIL" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
        SQL_C += "LEFT JOIN " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,CODE_BUIL,codd_desc vbuilding,mols_size" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_building A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BUIL' AND B.codd_valu=CODE_BUIL" & vbLf
        SQL_C += "where molh_idxx =   " & vRowProduct & " AND CODE_BUIL='" & VIDBuilding & "'" & vbLf
        SQL_C += ") B ON A.molh_idxx=B.molh_idxx AND A.mols_size=B.mols_size" & vbLf
        SQL_C += "WHERE A.molh_idxx=" & vRowProduct & "order by mols_seqn" & vbLf





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeBuilding_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                If clsCom.gv_DataRdr("vsize") <> "0" Then
                    .Cells.Item(.RowCount - 1, 0).Value = 1
                Else
                    .Cells.Item(.RowCount - 1, 0).Value = 0
                End If

                cboBuilding.Text = clsCom.gv_DataRdr("vbuilding") & Space(100) & clsCom.gv_DataRdr("CODE_BUIL")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("mols_cavi")

            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_BUILDING()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu id_build,codd_desc name_build ,cod1_valu CODE_AREA FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_BUIL'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboBuilding
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("name_build") & Space(100) & clsCom.gv_DataRdr("id_build"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_PRESS()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu ,codd_desc   FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_PRES'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboPress
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,B.codd_desc,CODE_COMP "
        SQL_C += "FROM KKTERP.dbo.mold_header A"
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP"
        SQL_C += "where A.modl_idxx = "

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SIZE()
        Dim SQL_C As String
         
        SQL_C = ""
        SQL_C += "SELECT molh_idxx,mols_size,mols_cavi " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size" & vbLf
        SQL_C += "WHERE molh_idxx=" & vRowProduct
        SQL_C += "order by mols_seqn" & vbLf





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
     
    Private Sub FP_INSERT()


        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.mold_header where modl_idxx=" & txtIdModel.Text & " AND CODE_COMP='" & Strings.Trim(Strings.Right(cboProduct.Text, 3)) & "'"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.mold_header (modl_idxx,CODE_COMP,molh_code,CODE_PRES,molh_pack) values (" & txtIdModel.Text & ",'" & Strings.Trim(Strings.Right(cboProduct.Text, 3)) & "','" & txtMoldCode.Text & "'," & Strings.Right(cboPress.Text, 1) & "," & txtQty.Text & ")" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.mold_header  SET molh_pack=" & txtQty.Text & ",molh_code='" & txtMoldCode.Text & "', CODE_PRES=" & Strings.Right(cboPress.Text, 1) & " WHERE molh_idxx=" & txtIdMold.Text

            clsCom.GP_ExeSql(SQL_C)

        End If
    End Sub
    Private Sub FP_COMBO_PRODUCT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT component_id,component_name FROM KKTERP.dbo.vProduct order by component_name" & vbLf
       
        clsCom.GP_ExeSqlReader(SQL_C)

        With cboProduct
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("component_name") & Space(100) & clsCom.gv_DataRdr("component_id"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub btnHelpModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpModel.Click
        frmHelpModel.ShowDialog()
        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtCustomer.Text = .Help_str2
            txtModelName.Text = .Help_str1
            txtBrand.Text = .Help_str3
            txtIdModel.Text = .Help_str4
            txtMoldshop.Text = .Help_str7

        End With

      

     

        spdSize_Sheet1.RowCount = 0
        spdBuilding_Sheet1.RowCount = 0
        FP_LIST_PRODUCT()
errHandle:
    End Sub

    Private Sub btnMoldCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoldCode.Click
        txtMoldCode.Text = ""

        pnlMoldCode.Visible = True
        FP_COMBO_PRODUCT()
        FP_COMBO_PRESS()
    End Sub

    Private Sub btnSaveHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveHead.Click
        If txtMoldCode.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If

        FP_INSERT()
        FP_LIST_PRODUCT()
        pnlMoldCode.Visible = False
    End Sub

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer
        pnlHelpSizeUpdate.Visible = False
        With spdSizeUpdate_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text = "" Then
                    Exit Sub
                End If

                SQL_C = ""
                SQL_C = SQL_C + " select count(*) qty from KKTERP.dbo.mold_size where  molh_idxx=" & vRowProduct & " and mols_size='" & .Cells.Item(0, i).Text & "'"

                clsCom.GP_ExeSqlReader(SQL_C)

               clsCom.gv_DataRdr.Read
                If clsCom.gv_DataRdr("qty") <> 0 Then
                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C = SQL_C + " UPDATE KKTERP.dbo.mold_size SET mols_cavi=" & .Cells.Item(1, i).Text & "  where  molh_idxx=" & vRowProduct & " and mols_size='" & .Cells.Item(0, i).Text & "'"

                    clsCom.GP_ExeSqlReader(SQL_C)
                Else
                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C = SQL_C + "insert into KKTERP.dbo.mold_size (molh_idxx,mols_size,mols_cavi,mols_seqn) VALUES (" & vRowProduct & ", '" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & "," & i + 1 & ")"

                    clsCom.GP_ExeSql(SQL_C)
                End If



               
            Next

        End With

        FP_LIST_SIZE()
        FP_LIST_SIZE_HEADER()
        FP_LIST_BUILDING()


    End Sub

    Private Sub spdProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellClick
        vRowProduct = spdProduct.ActiveSheet.Cells(e.Row, 0).Value
        FP_LIST_SIZE()
        FP_LIST_SIZE_HEADER()
        FP_LIST_BUILDING()

    End Sub

    Private Sub btnSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
        Dim i, j As Integer


        With spdSizeUpdate_Sheet1
            For i = 0 To .RowCount - 1
                For j = 0 To .ColumnCount - 1
                    .Cells.Item(i, j).Text = ""
                Next
            Next

        End With
        pnlHelpSizeUpdate.Visible = True
    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    Private Sub spdProduct_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellDoubleClick

        FP_COMBO_PRESS()
        FP_COMBO_PRODUCT()
        pnlMoldCode.Visible = True
        With spdProduct_Sheet1.Cells
            txtMoldCode.Text = .Item(e.Row, 2).Text
            txtIdMold.Text = .Item(e.Row, 0).Text
            txtQty.Text = .Item(e.Row, 4).Text
            cboPress.Text = .Item(e.Row, 3).Text & Space(100) & .Item(e.Row, 5).Text
            cboProduct.Text = .Item(e.Row, 1).Text & Space(100) & .Item(e.Row, 6).Text

        End With
    End Sub

    Private Sub btnDelHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelHead.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_header  WHERE molh_idxx=" & txtIdMold.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_size  WHERE molh_idxx=" & txtIdMold.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_building WHERE molh_idxx=" & txtIdMold.Text & "  "

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_PRODUCT()

        spdSize_Sheet1.RowCount = 0
        spdBuilding_Sheet1.RowCount = 0

        pnlMoldCode.Visible = False
    End Sub

    Private Sub btnCloseHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseHead.Click
        pnlMoldCode.Visible = False
    End Sub

    Private Sub btnBuilding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuilding.Click
        pnlSizeGedung.Visible = True
        VIDBuilding = 0
        FP_COMBO_BUILDING()
        FP_LIST_SIZE_BUILDING()
    End Sub

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        Dim i As Integer
        With spdSizeBuilding_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = 1

            Next

        End With
    End Sub

    Private Sub btnUncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUncheck.Click
        Dim i As Integer
        With spdSizeBuilding_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = 0

            Next

        End With
    End Sub

    Private Sub cmdSaveSizeBuilding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveSizeBuilding.Click
        Dim i As Integer
        pnlSizeGedung.Visible = False

        If cboBuilding.Text = "" Then
            MsgBox("Pilih gedung dulu")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_building WHERE molh_idxx=" & vRowProduct & " AND CODE_BUIL='" & Strings.Trim(Strings.Right(cboBuilding.Text, 5)) & "'"

        clsCom.GP_ExeSql(SQL_C)


        With spdSizeBuilding_Sheet1
            For i = 0 To .RowCount - 1
                If .Cells.Item(i, 0).Value = 1 Or .Cells.Item(i, 0).Value = True Then



                    SQL_C = ""
                    SQL_C = SQL_C + "insert into KKTERP.dbo.mold_building (molh_idxx,mols_size,CODE_BUIL) VALUES (" & vRowProduct & ", '" & .Cells.Item(i, 1).Text & "','" & Strings.Trim(Strings.Right(cboBuilding.Text, 5)) & "')"

                    clsCom.GP_ExeSql(SQL_C)
                End If
            Next

        End With

        FP_LIST_SIZE_HEADER()
        FP_LIST_BUILDING()

    End Sub

    
    Private Sub btnCloseSizeBuilding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSizeBuilding.Click
        pnlSizeGedung.Visible = False
    End Sub

    Private Sub spdBuilding_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBuilding.CellClick
        VIDBuilding = spdBuilding.ActiveSheet.Cells(e.Row, 0).Value
        FP_COMBO_BUILDING()
    End Sub

    Private Sub spdBuilding_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBuilding.CellDoubleClick

        cboBuilding.Text = spdBuilding.ActiveSheet.Cells(e.Row, 2).Text & Space(100) & spdBuilding.ActiveSheet.Cells(e.Row, 0).Text

        pnlSizeGedung.Visible = True
        FP_LIST_SIZE_BUILDING()
    End Sub

    Private Sub btnDeleteBuilding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteBuilding.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_building WHERE molh_idxx=" & vRowProduct & " AND CODE_BUIL='" & Strings.Trim(Strings.Right(cboBuilding.Text, 5)) & "'"

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_SIZE_HEADER()
        FP_LIST_BUILDING()

        pnlSizeGedung.Visible = False

    End Sub
    Private Sub FP_LIST_PRODUCT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,ISNULL(B.codd_desc,'') vComp,ISNULL(CODE_COMP,'') CODE_COMP,ISNULL(CODE_PRES,'') CODE_PRES,ISNULL(C.CODD_DESC,'') vPress,ISNULL(molh_paCK,0) vPack" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C on C.codh_flnm='CODE_PRES' and C.codd_valu=CODE_PRES" & vbLf
        SQL_C += "where A.modl_idxx=" & txtIdModel.Text





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProduct_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("vComp")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vPress")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("VPACK")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("CODE_PRES")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("CODE_COMP")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    

    Private Sub spdSize_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellDoubleClick
        If MsgBox("Apakah data akan di hapus ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            SQL_C = ""
            SQL_C = SQL_C + " delete KKTERP.dbo.mold_size    where  molh_idxx=" & vRowProduct & " and mols_size='" & spdSize_Sheet1.Cells.Item(e.Row, 0).Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)

            FP_LIST_SIZE()

        End If
    End Sub
End Class