﻿Public Class frmHelpDelivery
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_HEAD()
        Dim SQL_C As String
        SQL_C = ""
        
        SQL_C += "SELECT CUST_IDXX,CUST_NAME,'CUST' vstat FROM KKTERP.dbo.CUSTOMER" & vbLf
        SQL_C += "UNION ALL" & vbLf
        SQL_C += "SELECT VEND_IDXX,VEND_NAME,'VEND' vstat FROM KKTERP.dbo.VENDOR WHERE VEND_MSHP=1" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CUST_IDXX")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("CUST_NAME")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vstat")

            End While


            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

   

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHead_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdHead_Sheet1.Cells.Item(e.Row, 1).Text
            .Help_str3 = spdHead_Sheet1.Cells.Item(e.Row, 2).Text
          

        End With

        Me.Close()
    End Sub

    Private Sub frmHelpDelivery_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_HEAD()
    End Sub

    
    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

    End Sub
End Class