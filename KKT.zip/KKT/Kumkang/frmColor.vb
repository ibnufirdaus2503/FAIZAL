﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmColor
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub ReleaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Public Sub cmdInsert()
        txtCode.Text = ""
        txtDesc.Text = ""
        txtDesc.Focus()


    End Sub
    Public Sub cmdUpdate()
        If txtDesc.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        Cursor = Cursors.WaitCursor
        If txtCode.Text = "" Then


            SQL_C = ""
            SQL_C = SQL_C + "SELECT COUNT(*) QTY FROM KKTERP.dbo.color WHERE colr_name='" & txtDesc.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr.Item(0) = 0 Then
                clsCom.gv_ExeSqlReaderEnd()

                FP_INSERT()
            Else
                clsCom.gv_ExeSqlReaderEnd()
                FP_MODIFY()
            End If



        Else
            FP_MODIFY()
        End If

        txtCode.Text = ""
        txtDesc.Text = ""

        Call FP_LIST_HEAD()
        Cursor = Cursors.Default

    End Sub
    Public Sub cmdInquery()

    End Sub
    Public Sub cmdDelete()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.color  WHERE colr_idxx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_MODIFY()
        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.color  SET colr_name='" & txtDesc.Text & "' WHERE colr_idxx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

    End Sub
    Private Sub FP_INSERT()


        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.color (colr_name) VALUES ('" & txtDesc.Text & "')" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_DELETE()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.color  WHERE colr_iddx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_LIST_HEAD()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT colr_idxx,colr_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.color" & vbLf
        SQL_C += "order by colr_name asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("colr_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("colr_name")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub



    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        With spdHead_Sheet1.Cells
            txtCode.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
            txtDesc.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text

        End With
    End Sub

    Private Sub frmcolor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_INIT()
    End Sub

     
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Dim excelApp As New Excel.Application()
        '  Dim excelWorkbook As Excel.Workbook = Nothing
        '  Dim excelWorksheet As Excel.Worksheet = Nothing

        Dim xlaapp As New Excel.Application()
        Dim xlworkbook As Excel.Workbook = Nothing
        Dim xlworksheet As Excel.Worksheet = Nothing

        'Dim xlaapp As Microsoft.Office.Interop.Excel.Application
        'Dim xlworkbook As Microsoft.Office.Interop.Excel.Workbook
        'Dim xlworksheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misvalue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer

        SaveFileDialog1.Filter = "Excel Files(*.xlsx)|*.xlsx"

        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
          
            xlaapp = New Microsoft.Office.Interop.Excel.Application
            xlworkbook = xlaapp.Workbooks.Add(misvalue)
            xlworksheet = xlworkbook.Sheets("sheet1")

            With spdHead_Sheet1
                For i = 0 To .RowCount - 1
                    For j = 0 To .ColumnCount - 1
                        xlworksheet.Cells(i + 2, j + 1) = .Cells.Item(i, j).Text
                        xlworksheet.Cells(i + 2, j + 1).Font.Color = System.Drawing.ColorTranslator.ToOle(Color.Red)

                        xlworksheet.Range("A1").Interior.Color = RGB(255, 255, 0) ' Kuning
                        ' Mengatur lebar kolom A menjadi 25 karakter
                        xlworksheet.Columns("A").ColumnWidth = 25

                        ' Atau untuk kolom ke-1 (A)
                        xlworksheet.Columns(1).ColumnWidth = 25

                        ' Mengatur tinggi baris 1 menjadi 30 poin
                        xlworksheet.Rows(1).RowHeight = 30
                        With xlworksheet.Range("B2:D4").Interior
                            .Pattern = Excel.XlPattern.xlPatternLinearGradient
                            .Gradient.Degree = 90
                            .Color = RGB(255, 0, 0) ' Merah
                            .TintAndShade = 0.5
                        End With

                        'pilih semua cell yang terisi dan beri border
                        Dim cell As Excel.Range = xlworksheet.Cells(i + 2, j + 1)


                        ' Tambahkan border ke semua sisi
                        With cell.Borders
                            .LineStyle = Excel.XlLineStyle.xlContinuous
                            .Weight = Excel.XlBorderWeight.xlThin
                        End With

                        ' span
                        Dim mergedRange As Excel.Range = xlworksheet.Range("A1:C1")
                        mergedRange.Merge()
                        mergedRange.Value = "Judul Tabel"
                    Next
                Next

                xlworksheet.SaveAs(SaveFileDialog1.FileName)
                xlworkbook.Close()
                xlaapp.Quit()

            End With
        End If

        'Try
        '    ' Buat workbook baru
        '    excelWorkbook = excelApp.Workbooks.Add()
        '    excelWorksheet = CType(excelWorkbook.Sheets(1), Excel.Worksheet)

        '    ' Isi data
        '    excelWorksheet.Range("A1").Value = "Nama"
        '    excelWorksheet.Range("B1").Value = "Usia"
        '    excelWorksheet.Range("A2").Value = "John"
        '    excelWorksheet.Range("B2").Value = 30

        '    ' Simpan file
        '    excelWorkbook.SaveAs("C:\DataExcel2021.xlsx")

        '    excelWorkbook.
        '    excelWorkbook.Close()

        '    ' Tampilkan Excel
        '    excelApp.Visible = True
        'Catch ex As Exception
        '    MessageBox.Show("Error: " & ex.Message)
        'Finally
        '    ' Bersihkan objek COM
        '    If excelWorksheet IsNot Nothing Then ReleaseObject(excelWorksheet)
        '    If excelWorkbook IsNot Nothing Then ReleaseObject(excelWorkbook)
        '    If excelApp IsNot Nothing Then ReleaseObject(excelApp)
        'End Try



        ReleaseObject(xlaapp)
        ReleaseObject(xlworkbook)
        ReleaseObject(xlworksheet)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim xlApp As New Excel.Application
        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Add()
        Dim xlWorkSheet As Excel.Worksheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)

        ' Merge A1 to C1 untuk judul
        Dim headerRange As Excel.Range = xlWorkSheet.Range("A1:C1")
        headerRange.Merge()
        headerRange.Value = "Data Karyawan"
        headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
        headerRange.Font.Bold = True

        ' Isi data di bawahnya
        xlWorkSheet.Cells(2, 1).Value = "Nama"
        xlWorkSheet.Cells(2, 2).Value = "Jabatan"
        xlWorkSheet.Cells(2, 3).Value = "Umur"

        ' Simpan dan tutup
        Dim savePath As String = "C:\Temp\MergedExcel.xlsx"
        xlWorkSheet.SaveAs(savePath)
        xlWorkBook.Close(False)
        xlApp.Quit()

        ReleaseObject(headerRange)
        ReleaseObject(xlWorkSheet)
        ReleaseObject(xlWorkBook)
        ReleaseObject(xlApp)

        MessageBox.Show("Berhasil ekspor dengan merged cell.")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim xlApp As New Excel.Application
        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Add()
        Dim xlWorkSheet As Excel.Worksheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)
        xlApp.Visible = True
        Dim mergeRange As Excel.Range = xlWorkSheet.Range(xlWorkSheet.Cells(1, 1), xlWorkSheet.Cells(1, 3))
        mergeRange.Merge()
        mergeRange.Value = "Judul Tabel"
        mergeRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter


        ReleaseObject(xlWorkSheet)
        ReleaseObject(xlWorkBook)
        ReleaseObject(xlApp)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim xlApp As New Excel.Application
        xlApp.Visible = True ' Tampilkan Excel langsung

        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Add()
        Dim xlWorkSheet As Excel.Worksheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)

        ' Isi data
        xlWorkSheet.Cells(1, 1).Value = "Nama"
        xlWorkSheet.Cells(1, 2).Value = "Umur"
        xlWorkSheet.Cells(2, 1).Value = "Budi"
        xlWorkSheet.Cells(2, 2).Value = 25

        ' Merge cell judul
        Dim headerRange As Excel.Range = xlWorkSheet.Range(xlWorkSheet.Cells(1, 1), xlWorkSheet.Cells(1, 2))
        headerRange.Merge()
        headerRange.Value = "Data Karyawan"
        headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
        headerRange.Font.Bold = True

        ' Di sini file belum disimpan. Excel sudah terbuka dan bisa diedit langsung oleh user.

        ' === Simpan secara manual jika perlu ===
        'Dim savePath As String = "C:\Temp\Laporan.xlsx"
        'xlWorkSheet.SaveAs(savePath)
        'MessageBox.Show("Disimpan di: " & savePath)

        ' Jangan tutup Excel jika ingin user edit dulu

        'ReleaseObject(headerRange)
        'ReleaseObject(xlWorkSheet)
        'ReleaseObject(xlWorkBook)
        'ReleaseObject(xlApp)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim xlApp As New Excel.Application
        xlApp.Visible = True

        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Add()
        Dim xlWorkSheet As Excel.Worksheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)

        ' Isi data
        xlWorkSheet.Cells(1, 1).Value = "Nama"
        xlWorkSheet.Cells(1, 2).Value = "Umur"
        xlWorkSheet.Cells(2, 1).Value = "Budi"
        xlWorkSheet.Cells(2, 2).Value = 25

        ' Mengatur warna font (ForeColor) untuk header
        xlWorkSheet.Cells(1, 1).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue)
        xlWorkSheet.Cells(1, 2).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Blue)

        ' Mengatur warna font untuk cell lain (misalnya red untuk umur)
        xlWorkSheet.Cells(2, 2).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red)

        ' Simpan file
        Dim savePath As String = "C:\Temp\ExcelWithForeColor.xlsx"
        xlWorkSheet.SaveAs(savePath)

        ' Tutup workbook dan aplikasi
        xlWorkBook.Close(False)
        xlApp.Quit()

        ReleaseObject(xlWorkSheet)
        ReleaseObject(xlWorkBook)
        ReleaseObject(xlApp)

        MessageBox.Show("Excel berhasil diekspor dengan ForeColor.")
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

    End Sub
End Class