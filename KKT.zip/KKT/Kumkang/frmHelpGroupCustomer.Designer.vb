﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHelpGroupCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.spdHelpCustomer = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpCustomer_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnCloseCustomer = New System.Windows.Forms.Button
        Me.pnlHelpCustomer = New System.Windows.Forms.Panel
        Me.btnCariCustomer = New System.Windows.Forms.Button
        Me.txtCustomerHelpCari = New System.Windows.Forms.TextBox
        CType(Me.spdHelpCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpCustomer_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpCustomer.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        '
        'spdHelpCustomer
        '
        Me.spdHelpCustomer.AccessibleDescription = "spdHelpCustomer, Sheet1, Row 0, Column 0, "
        Me.spdHelpCustomer.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpCustomer.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpCustomer.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpCustomer.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdHelpCustomer.HorizontalScrollBar.TabIndex = 14
        Me.spdHelpCustomer.Location = New System.Drawing.Point(5, 48)
        Me.spdHelpCustomer.Name = "spdHelpCustomer"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer1
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer1
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdHelpCustomer.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdHelpCustomer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpCustomer.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpCustomer_Sheet1})
        Me.spdHelpCustomer.Size = New System.Drawing.Size(229, 306)
        Me.spdHelpCustomer.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpCustomer.TabIndex = 27
        Me.spdHelpCustomer.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpCustomer.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpCustomer.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdHelpCustomer.VerticalScrollBar.TabIndex = 15
        Me.spdHelpCustomer.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpCustomer_Sheet1
        '
        Me.spdHelpCustomer_Sheet1.Reset()
        Me.spdHelpCustomer_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpCustomer_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpCustomer_Sheet1.ColumnCount = 2
        Me.spdHelpCustomer_Sheet1.RowCount = 1
        Me.spdHelpCustomer_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Id Customer"
        Me.spdHelpCustomer_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Group Customer"
        Me.spdHelpCustomer_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpCustomer_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpCustomer_Sheet1.Columns.Get(0).Label = "Id Customer"
        Me.spdHelpCustomer_Sheet1.Columns.Get(0).Locked = False
        Me.spdHelpCustomer_Sheet1.Columns.Get(0).Visible = False
        Me.spdHelpCustomer_Sheet1.Columns.Get(0).Width = 56.0!
        Me.spdHelpCustomer_Sheet1.Columns.Get(1).Label = "Group Customer"
        Me.spdHelpCustomer_Sheet1.Columns.Get(1).Width = 176.0!
        Me.spdHelpCustomer_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHelpCustomer_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpCustomer_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpCustomer_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnCloseCustomer
        '
        Me.btnCloseCustomer.Location = New System.Drawing.Point(5, 356)
        Me.btnCloseCustomer.Name = "btnCloseCustomer"
        Me.btnCloseCustomer.Size = New System.Drawing.Size(229, 33)
        Me.btnCloseCustomer.TabIndex = 26
        Me.btnCloseCustomer.Text = "Close"
        Me.btnCloseCustomer.UseVisualStyleBackColor = True
        '
        'pnlHelpCustomer
        '
        Me.pnlHelpCustomer.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpCustomer.Controls.Add(Me.btnCariCustomer)
        Me.pnlHelpCustomer.Controls.Add(Me.txtCustomerHelpCari)
        Me.pnlHelpCustomer.Location = New System.Drawing.Point(5, 2)
        Me.pnlHelpCustomer.Name = "pnlHelpCustomer"
        Me.pnlHelpCustomer.Size = New System.Drawing.Size(229, 44)
        Me.pnlHelpCustomer.TabIndex = 25
        '
        'btnCariCustomer
        '
        Me.btnCariCustomer.Location = New System.Drawing.Point(176, 13)
        Me.btnCariCustomer.Name = "btnCariCustomer"
        Me.btnCariCustomer.Size = New System.Drawing.Size(46, 24)
        Me.btnCariCustomer.TabIndex = 25
        Me.btnCariCustomer.Text = ">>"
        Me.btnCariCustomer.UseVisualStyleBackColor = True
        '
        'txtCustomerHelpCari
        '
        Me.txtCustomerHelpCari.Location = New System.Drawing.Point(5, 14)
        Me.txtCustomerHelpCari.Name = "txtCustomerHelpCari"
        Me.txtCustomerHelpCari.Size = New System.Drawing.Size(165, 20)
        Me.txtCustomerHelpCari.TabIndex = 12
        '
        'frmHelpGroupCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(236, 391)
        Me.Controls.Add(Me.spdHelpCustomer)
        Me.Controls.Add(Me.btnCloseCustomer)
        Me.Controls.Add(Me.pnlHelpCustomer)
        Me.Name = "frmHelpGroupCustomer"
        Me.Text = "Group Customer"
        CType(Me.spdHelpCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpCustomer_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpCustomer.ResumeLayout(False)
        Me.pnlHelpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdHelpCustomer As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpCustomer_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnCloseCustomer As System.Windows.Forms.Button
    Friend WithEvents pnlHelpCustomer As System.Windows.Forms.Panel
    Friend WithEvents btnCariCustomer As System.Windows.Forms.Button
    Friend WithEvents txtCustomerHelpCari As System.Windows.Forms.TextBox
End Class
