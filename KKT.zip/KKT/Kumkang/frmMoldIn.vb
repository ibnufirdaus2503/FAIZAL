﻿Public Class frmMoldIn
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold As Integer
    Dim CODE_BUIL As Integer
    Dim ROW As Integer
    Private Sub FP_LIST_HEAD_SET_MOLD()
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0

        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT  mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_in A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where inmh_idxx = " & txtIdHeader.Text & vbLf
        SQL_C += " group by mols_size,mold_idxx" & vbLf
        SQL_C += "order by vseqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_CLEAR()
        txtIdHeader.Text = ""
        txtIdMoldshop.Text = ""
        txtMoldshop.Text = ""
        txtSJ.Text = ""
    End Sub
    Private Sub FP_LIST_FILL()



        With spdHead_Sheet1.Cells

            txtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text
            dtSJ.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text

            txtIdHeader.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text
        End With
    End Sub
    Private Sub FP_LIST_HEAD_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT DISTINCT A.molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name,QTY" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null AND molh_idxx in (SELECT molh_idxx FROM  KKTERP.dbo.mold_detail_in where inmh_idxx=" & txtIdHeader.Text & ")" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,mols_size,count(mold_idxx) qty" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  molh_idxx,mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_in A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where inmh_idxx =   " & txtIdHeader.Text & "" & vbLf
        SQL_C += "group by molh_idxx,mols_size,mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY molh_idxx,mols_size" & vbLf
        SQL_C += ")B ON A.molh_idxx=B.molh_idxx" & vbLf
        SQL_C += "ORDER BY codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD()

        SQL_C = ""

        SQL_C += "SELECT inmh_idxx,inmh_sjxx,convert(varchar(10),inmh_date,111) inmh_date" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header_in A" & vbLf
        SQL_C += "WHERE inmh_idxx is not null" & vbLf



        SQL_C += " order by inmh_date" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("inmh_date")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("inmh_sjxx")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("inmh_idxx")



            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_LIST_SET_MOLD(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        Dim VCODE As Integer
        vRow = 0
        Old_Size = ""

        If Strings.Trim(Strings.Right(cboType.Text, 5)) = 6 Then
            VCODE = 1
        ElseIf Strings.Trim(Strings.Right(cboType.Text, 5)) = 3 Then
            VCODE = 8
        ElseIf Strings.Trim(Strings.Right(cboType.Text, 5)) = 2 Then
            VCODE = 7
        End If

        SQL_C = ""
        SQL_C += "SELECT mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += "where CODE_INOT=2 AND  CODE_MOTR=" & VCODE & " AND  molh_idxx = " & spdHelpComponent_Sheet1.Cells.Item(ID, 0).Text & " AND vend_idxx= " & txtIdMoldshop.Text & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY mols_size,mold_idxx" & vbLf
        SQL_C += "ORDER BY vseqn " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpSize_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null " & vbLf

        If txtModelHelpCari.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModelHelpCari.Text & "%'"
        End If
        SQL_C += " order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_TYPE()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_MOTR' AND cod1_valu='I' AND codd_valu not in (4,5)" & vbLf
        SQL_C += "ORDER BY codd_desc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboType
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmMoldIn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_COMBO_TYPE()
        FP_LIST_HEAD()
    End Sub

    Private Sub btnMoldshop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoldshop.Click
        frmHelpMoldshop.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdMoldshop.Text = .Help_str1
            txtMoldshop.Text = .Help_str2





        End With

errHandle:
    End Sub

    Private Sub btnHelpUpdateSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpUpdateSize.Click
        If txtMoldshop.Text = "" Or txtSJ.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        pnlUpdateMold.Visible = True
    End Sub

    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariModel.Click
        FP_LIST_HELP_COMPONENT()
    End Sub

    Private Sub spdHelpComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpComponent.CellClick
        code_mold = e.Row
        FP_LIST_SET_MOLD(code_mold)
    End Sub

    Private Sub spdHelpSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpSize.CellClick
        If spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor <> Color.LimeGreen Then
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.LimeGreen
        Else
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.White
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim i, j As Integer

        If txtIdHeader.Text = "" Then


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.mold_header_in (inmh_sjxx,inmh_date,vend_idxx,CODE_MOTR)  VALUES ('" & txtSJ.Text & "','" & dtSJ.Text & "'," & txtIdMoldshop.Text & "," & Strings.Trim(Strings.Right(cboType.Text, 5)) & ")"

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "SELECT TOP 1 inmh_idxx FROM KKTERP.dbo.mold_header_in ORDER BY inmh_idxx desc"

            clsCom.GP_ExeSqlReader(SQL_C)

            clsCom.gv_DataRdr.Read()
            txtIdHeader.Text = clsCom.gv_DataRdr("inmh_idxx")

            clsCom.gv_ExeSqlReaderEnd()




        End If

        With spdHelpSize_Sheet1

            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    If .Cells.Item(j, i).BackColor = Color.LimeGreen Then

                        SQL_C = ""
                        SQL_C += "INSERT INTO KKTERP.dbo.mold_detail_in (inmh_idxx,molh_idxx,mold_idxx,mols_size) VALUES (" & txtIdHeader.Text & "," & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & ",'" & .Cells.Item(j, i).Text & "','" & .ColumnHeader.Cells.Item(0, i).Text & "')"

                        clsCom.GP_ExeSql(SQL_C)

                        SQL_C = ""
                        SQL_C += "UPDATE KKTERP.dbo.mold_stock SET vend_idxx=null,CODE_MOTR=" & Strings.Trim(Strings.Right(cboType.Text, 5)) & ",CODE_INOT=1,CODE_BUIL='8A'  where mold_idxx='" & .Cells.Item(j, i).Text & "' AND molh_idxx=" & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & " AND mols_size='" & .ColumnHeader.Cells.Item(0, i).Text & "'"

                        clsCom.GP_ExeSql(SQL_C)

                    End If
                Next
            Next

        End With

        'FP_CLEAR()
        FP_LIST_HEAD_COMPONENT()
        FP_LIST_HEAD()

        pnlUpdateMold.Visible = False
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        FP_LIST_FILL()
        FP_LIST_HEAD_COMPONENT()
    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        If e.Column = 7 Then
            pnlUpdateMold.Visible = True

            With spdComponent_Sheet1.Cells
                spdHelpComponent_Sheet1.Cells.Item(0, 0).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 1).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 1).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 2).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 2).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 3).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 3).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 4).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 4).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 5).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 5).Text
                '  spdHelpComponent_Sheet1.Cells.Item(0, 6).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 6).Text
            End With
        End If
        FP_LIST_HEAD_SET_MOLD()
    End Sub
End Class