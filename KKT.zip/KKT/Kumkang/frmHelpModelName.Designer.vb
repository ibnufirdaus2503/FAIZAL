﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHelpModelName
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Me.spdMaster = New FarPoint.Win.Spread.FpSpread
        Me.spdMaster_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlHelpCustomer = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnCariMold = New System.Windows.Forms.Button
        Me.txtMold = New System.Windows.Forms.TextBox
        Me.btnCloseMold = New System.Windows.Forms.Button
        CType(Me.spdMaster, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdMaster_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpCustomer.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        '
        'spdMaster
        '
        Me.spdMaster.AccessibleDescription = "spdMaster, Sheet1, Row 0, Column 0, "
        Me.spdMaster.BackColor = System.Drawing.SystemColors.Control
        Me.spdMaster.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMaster.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMaster.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdMaster.HorizontalScrollBar.TabIndex = 6
        Me.spdMaster.Location = New System.Drawing.Point(3, 49)
        Me.spdMaster.Name = "spdMaster"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer4
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer4
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdMaster.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdMaster.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdMaster.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdMaster_Sheet1})
        Me.spdMaster.Size = New System.Drawing.Size(582, 322)
        Me.spdMaster.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdMaster.TabIndex = 45
        Me.spdMaster.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMaster.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMaster.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdMaster.VerticalScrollBar.TabIndex = 7
        Me.spdMaster.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdMaster_Sheet1
        '
        Me.spdMaster_Sheet1.Reset()
        Me.spdMaster_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdMaster_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdMaster_Sheet1.ColumnCount = 8
        Me.spdMaster_Sheet1.RowCount = 1
        Me.spdMaster_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 0).Value = 0
        Me.spdMaster_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdMaster_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 2).Value = 2
        Me.spdMaster_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 3).Value = 3
        Me.spdMaster_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 4).Value = 4
        Me.spdMaster_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 5).Value = 5
        Me.spdMaster_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 6).Value = 6
        Me.spdMaster_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdMaster_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdMaster_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdMaster_Sheet1.Cells.Get(0, 7).Value = 7
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID brand"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "ID MOLD NAME"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "ID GCUS"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "ID VENDOR"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "BRAND"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Mold Name"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Group Customer"
        Me.spdMaster_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Vendor"
        Me.spdMaster_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdMaster_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdMaster_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdMaster_Sheet1.Columns.Get(0).Label = "ID brand"
        Me.spdMaster_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdMaster_Sheet1.Columns.Get(0).Visible = False
        Me.spdMaster_Sheet1.Columns.Get(0).Width = 36.0!
        Me.spdMaster_Sheet1.Columns.Get(1).Label = "ID MOLD NAME"
        Me.spdMaster_Sheet1.Columns.Get(1).Visible = False
        Me.spdMaster_Sheet1.Columns.Get(2).Label = "ID GCUS"
        Me.spdMaster_Sheet1.Columns.Get(2).Visible = False
        Me.spdMaster_Sheet1.Columns.Get(3).Label = "ID VENDOR"
        Me.spdMaster_Sheet1.Columns.Get(3).Visible = False
        Me.spdMaster_Sheet1.Columns.Get(4).Label = "BRAND"
        Me.spdMaster_Sheet1.Columns.Get(4).Width = 94.0!
        Me.spdMaster_Sheet1.Columns.Get(5).Label = "Mold Name"
        Me.spdMaster_Sheet1.Columns.Get(5).Width = 143.0!
        Me.spdMaster_Sheet1.Columns.Get(6).Label = "Group Customer"
        Me.spdMaster_Sheet1.Columns.Get(6).Width = 126.0!
        Me.spdMaster_Sheet1.Columns.Get(7).Label = "Vendor"
        Me.spdMaster_Sheet1.Columns.Get(7).Width = 160.0!
        Me.spdMaster_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdMaster_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdMaster_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdMaster_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlHelpCustomer
        '
        Me.pnlHelpCustomer.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpCustomer.Controls.Add(Me.Label2)
        Me.pnlHelpCustomer.Controls.Add(Me.btnCariMold)
        Me.pnlHelpCustomer.Controls.Add(Me.txtMold)
        Me.pnlHelpCustomer.Location = New System.Drawing.Point(3, -1)
        Me.pnlHelpCustomer.Name = "pnlHelpCustomer"
        Me.pnlHelpCustomer.Size = New System.Drawing.Size(582, 44)
        Me.pnlHelpCustomer.TabIndex = 46
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Mold Name"
        '
        'btnCariMold
        '
        Me.btnCariMold.Location = New System.Drawing.Point(298, 10)
        Me.btnCariMold.Name = "btnCariMold"
        Me.btnCariMold.Size = New System.Drawing.Size(46, 24)
        Me.btnCariMold.TabIndex = 25
        Me.btnCariMold.Text = ">>"
        Me.btnCariMold.UseVisualStyleBackColor = True
        '
        'txtMold
        '
        Me.txtMold.Location = New System.Drawing.Point(103, 13)
        Me.txtMold.Name = "txtMold"
        Me.txtMold.Size = New System.Drawing.Size(189, 20)
        Me.txtMold.TabIndex = 12
        '
        'btnCloseMold
        '
        Me.btnCloseMold.Location = New System.Drawing.Point(3, 377)
        Me.btnCloseMold.Name = "btnCloseMold"
        Me.btnCloseMold.Size = New System.Drawing.Size(582, 33)
        Me.btnCloseMold.TabIndex = 47
        Me.btnCloseMold.Text = "Close"
        Me.btnCloseMold.UseVisualStyleBackColor = True
        '
        'frmHelpModelName
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(588, 418)
        Me.Controls.Add(Me.btnCloseMold)
        Me.Controls.Add(Me.pnlHelpCustomer)
        Me.Controls.Add(Me.spdMaster)
        Me.Name = "frmHelpModelName"
        Me.Text = "frmHelpModelName"
        CType(Me.spdMaster, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdMaster_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpCustomer.ResumeLayout(False)
        Me.pnlHelpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdMaster As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdMaster_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlHelpCustomer As System.Windows.Forms.Panel
    Friend WithEvents btnCariMold As System.Windows.Forms.Button
    Friend WithEvents txtMold As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnCloseMold As System.Windows.Forms.Button
End Class
