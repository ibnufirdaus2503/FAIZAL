﻿Public Class frmReturPO
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vMolhId As Integer

    Public Sub cmdInsert()
        Dim IdRetur As Integer

        SQL_C = ""
        SQL_C += " SELECT IDENT_CURRENT('retur') AS LastID" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        IdRetur = clsCom.gv_DataRdr("LastID") + 1

        clsCom.gv_ExeSqlReaderEnd()

        txtIdRetur.Text = IdRetur.ToString("D7")

    End Sub
    Sub FP_SIZE_SUMMARY()
        Dim Old_Comp As String


        SQL_C = ""
        SQL_C += "SELECT X.*,CODD_DESC,MOLH_CODE" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT " & vbLf
        SQL_C += "molh_idxx,CODE_LRXX," & vbLf
        SQL_C += "STUFF(" & vbLf
        SQL_C += "		(" & vbLf
        SQL_C += "			SELECT ',' + retd_size+'('+ cast(qty as varchar)+')'" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "				(" & vbLf
        SQL_C += "					SELECT molh_idxx,CODE_LRXX,retd_size,sum(retd_qtyx) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.retur_detail " & vbLf
        SQL_C += "where retr_idxx = 6 " & vbLf
        SQL_C += "					group by molh_idxx,CODE_LRXX,retd_size" & vbLf
        SQL_C += "				) t1" & vbLf
        SQL_C += "WHERE(t1.molh_idxx = t2.molh_idxx And t1.CODE_LRXX = t2.CODE_LRXX)" & vbLf
        SQL_C += "			FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'), 1, 1, '') AS MoldSet " & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "	(" & vbLf
        SQL_C += "		SELECT molh_idxx,CODE_LRXX,retd_size,sum(retd_qtyx) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.retur_detail " & vbLf
        SQL_C += "where(retr_idxx = 6)" & vbLf
        SQL_C += "		group by molh_idxx,CODE_LRXX,retd_size" & vbLf
        SQL_C += "	) t2 " & vbLf
        SQL_C += "GROUP BY molh_idxx,CODE_LRXX " & vbLf
        SQL_C += ") X" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header Y ON X.molh_idxx=Y.molh_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common Z ON Z.codh_flnm='CODE_COMP' AND Z.codd_valu=Y.CODE_COMP" & vbLf
        SQL_C += "ORDER BY molh_idxx ,CODE_LRXX" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeSummary_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read


                If Old_Comp <> clsCom.gv_DataRdr("CODD_DESC") Then
                    .RowCount = .RowCount + 1

                    .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CODD_DESC")
                    .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("MOLH_CODE")
                    .Cells.Item(.RowCount - 1, clsCom.gv_DataRdr("CODE_LRXX") + 2).Text = clsCom.gv_DataRdr("MOLDSET")
                Else
                    .Cells.Item(.RowCount - 1, clsCom.gv_DataRdr("CODE_LRXX") + 2).Text = clsCom.gv_DataRdr("MOLDSET")
                End If

                Old_Comp = clsCom.gv_DataRdr("CODD_DESC")

            End While
        End With





        clsCom.gv_ExeSqlReaderEnd()




    End Sub
    Private Sub FP_SIZE_DETAIL()

        Dim i, j, vTotal As Integer
        SQL_C = ""
        SQL_C += "SELECT retd_size,retd_qtyx,CODE_LRXX " & vbLf
        SQL_C += "FROM KKTERP.dbo.retur_detail " & vbLf
        SQL_C += "WHERE retr_idxx =  " & Val(txtIdRetur.Text) & vbLf
        SQL_C += "AND  molh_idxx =  " & vMolhId & vbLf
        SQL_C += "ORDER BY CODE_LRXX" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeReport_Sheet1
            ' .RowCount = 0
            While clsCom.gv_DataRdr.Read

                For i = 3 To .ColumnCount - 1
                    If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("retd_size") Then
                        .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX"), i).Text = clsCom.gv_DataRdr("retd_qtyx")
                        .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX"), i).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                        .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX"), i).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                    End If
                Next

            End While

            For i = 0 To .RowCount - 1
                vTotal = 0
                For j = 3 To .ColumnCount - 1
                    vTotal = vTotal + Val(.Cells.Item(i, j).Text)
                Next
                .Cells.Item(i, 1).Text = vTotal
                .Cells.Item(i, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(i, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
            Next
        End With





        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_HEAD()
        Dim Retur_Id, PO_Id, Model_Id As Integer

        SQL_C = ""
        SQL_C += "SELECT A.ordh_idxx,retr_idxx,convert(varchar(10),retr_date,111) tgl," & vbLf
        SQL_C += "isnull(retr_desc,'') retr_desc,A.ordh_idxx,model_name,colr_name,customer_name,CONVERT(VARCHAR(10),sjxh_date,111) DATE_SJ,b.sjxh_idxx,model_id," & vbLf
        SQL_C += "ordh_poxx, sjxh_noxx,B.mclr_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.retur A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_header B ON A.ordh_idxx=B.ordh_idxx " & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.surat_jalanh C ON B.sjxh_idxx=C.sjxh_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vMOdelColor D on D.mclr_idxx=B.mclr_idxx" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                Retur_Id = clsCom.gv_DataRdr("retr_idxx")
                PO_Id = clsCom.gv_DataRdr("ordh_idxx")
                Model_Id = clsCom.gv_DataRdr("model_id")

                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = Retur_Id.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("tgl")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 5).Text = Model_Id.ToString("D4")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("retr_desc")
                .Cells.Item(.RowCount - 1, 10).Text = PO_Id.ToString("D7")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("sjxh_idxx")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("retr_desc")
                .Cells.Item(.RowCount - 1, 10).Text = PO_Id.ToString("D7")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("sjxh_idxx")
                .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("DATE_SJ")
                ' .Cells.Item(.RowCount - 1, 13).Text = clsCom.gv_DataRdr("DATE_SJ")
                .Cells.Item(.RowCount - 1, 14).Text = clsCom.gv_DataRdr("mclr_idxx")

            End While
        End With





        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Private Sub FP_SIZE_SHEET()

        SQL_C = ""
        SQL_C += "select   MOLH_IDXX,MOLS_SIZE,min(GROP_SEQN) GROP_SEQN" & vbLf
        SQL_C += "from" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select mclr_idxx, ordd_size,ordd_qtyx " & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_detail B ON A.ordh_idxx=B.ordh_idxx" & vbLf
        SQL_C += "where a.ordh_idxx =  " & Val(txtID.Text) & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select c.MOLH_IDXX, MOLH_CODE,CODD_DESC,mols_size,GROP_SIZE,CODE_SIZE,GROP_SEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx=3 AND COD1_VALU='CP'" & vbLf
        SQL_C += ") B ON A.ordd_size=B.code_size" & vbLf
        SQL_C += "WHERE  MOLH_IDXX=" & vMolhId & vbLf
        SQL_C += "GROUP BY MOLH_IDXX,MOLS_SIZE " & vbLf
        SQL_C += "order by MOLH_IDXX,GROP_SEQN" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeReport_Sheet1
            .ColumnCount = 2
            While clsCom.gv_DataRdr.Read

                '    .RowHeader.Rows.Item(0).Height = 40
                .ColumnCount = .ColumnCount + 1

                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 40
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("MOLS_SIZE")


                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

            End While
        End With





        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub FP_COMBO_UNIT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc  FROM KKTERP.dbo.code_common where codh_flnm='CODE_LRXX'"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboUnit
            .Items.Clear()

            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SIZE_COMPONENT()

        SQL_C = ""
        SQL_C += "select   MOLH_IDXX,MOLS_SIZE,min(GROP_SEQN) GROP_SEQN" & vbLf
        SQL_C += "from" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select mclr_idxx, ordd_size,ordd_qtyx " & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_detail B ON A.ordh_idxx=B.ordh_idxx" & vbLf
        SQL_C += "where a.ordh_idxx =  " & Val(txtID.Text) & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select c.MOLH_IDXX, MOLH_CODE,CODD_DESC,mols_size,GROP_SIZE,CODE_SIZE,GROP_SEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx= " & Val(txtID.Text) & " AND COD1_VALU='CP'" & vbLf
        SQL_C += ") B ON A.ordd_size=B.code_size" & vbLf
        SQL_C += "WHERE  MOLH_IDXX=" & vMolhId & vbLf
        SQL_C += "group by  MOLH_IDXX,MOLS_SIZE" & vbLf
        SQL_C += "order by MOLH_IDXX,GROP_SEQN" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                .RowHeader.Rows.Item(0).Height = 40
                .ColumnCount = .ColumnCount + 1
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

            End While
        End With





        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_COMPONENT()

        SQL_C = ""
        SQL_C += "SELECT mcom_idxx,CODD_DESC,MOLH_IDXX,D.MOLH_CODE,MODL_CHIP" & vbLf
        SQL_C += "FROM KKTERP.DBO.MATERIAL_COMPONENT A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.CODE_COMMON B ON B.CODH_FLNM='CODE_COMP' AND B.CODD_VALU=CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL_COLOR C ON A.MCLR_IDXX=C.MCLR_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MOLD_HEADER D ON D.MODL_IDXX=C.MODL_IDXX AND D.CODE_COMP=A.CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL E ON D.MODL_IDXX=E.MODL_IDXX" & vbLf
        SQL_C += "WHERE A.MCLR_IDXX =   " & txtMclrId.Text & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProduct_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read


                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("CODD_DESC")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("MOLH_CODE")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("MOLH_IDXX")
            End While
        End With





        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub btnPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPO.Click
        frmHelpPOSJ.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtID.Text = .Help_str1
            txtNoSj.Text = .Help_str2
            txtDateSJ.Text = .Help_str3
            TXTNOPO.Text = .Help_str4
            txtCustomer.Text = .Help_str5
            txtIdModel.Text = .Help_str6
            txtModel.Text = .Help_str7
            txtColor.Text = .Help_str8
            txtMclrId.Text = .Help_str9


        End With


        FP_COMPONENT()

errHandle:
    End Sub

    Private Sub spdProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellClick

        vMolhId = spdProduct_Sheet1.Cells.Item(e.Row, 3).Text
        FP_SIZE_COMPONENT()
        FP_SIZE_SHEET()
        FP_SIZE_DETAIL()
    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick
        lblSize.Text = spdSize_Sheet1.Cells.Item(0, e.Column).Text
    End Sub

    Private Sub frmReturPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_COMBO_UNIT()
        FP_HEAD()
    End Sub

    Private Sub btnRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetur.Click

        If lblSize.Text = "-" Then
            MsgBox("Pilih Size dahulu")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.retur where retr_idxx='" & txtIdRetur.Text & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            If txtID.Text = "" Then
                MsgBox("Masukan PO, tidak boleh kosong")
                Exit Sub
            End If

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.retur (ordh_idxx,retr_date,retr_desc) VALUES (" & Val(txtID.Text) & ",'" & dtRetur.Text & "','" & txtRemark.Text & "')" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.retur_detail (retr_idxx,retd_size,retd_qtyx,CODE_LRXX,molh_idxx) VALUES (" & Val(txtIdRetur.Text) & ",'" & lblSize.Text & "'," & txtQty.Text & "," & Strings.Right(cboUnit.Text, 1) & "," & vMolhId & ")" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)

        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.retur_detail (retr_idxx,retd_size,retd_qtyx,CODE_LRXX,molh_idxx) VALUES (" & Val(txtIdRetur.Text) & ",'" & lblSize.Text & "'," & txtQty.Text & "," & Strings.Right(cboUnit.Text, 1) & "," & vMolhId & ")" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)

        End If
        FP_SIZE_DETAIL()

    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

        txtIdRetur.Text = spdHead_Sheet1.Cells.Item(e.Row, 0).Text
        dtRetur.Text = spdHead_Sheet1.Cells.Item(e.Row, 1).Text
        txtID.Text = spdHead_Sheet1.Cells.Item(e.Row, 10).Text
        TXTNOPO.Text = spdHead_Sheet1.Cells.Item(e.Row, 2).Text
        txtCustomer.Text = spdHead_Sheet1.Cells.Item(e.Row, 8).Text
        txtIdModel.Text = spdHead_Sheet1.Cells.Item(e.Row, 5).Text
        txtModel.Text = spdHead_Sheet1.Cells.Item(e.Row, 6).Text
        txtColor.Text = spdHead_Sheet1.Cells.Item(e.Row, 7).Text
        txtNoSj.Text = spdHead_Sheet1.Cells.Item(e.Row, 3).Text
        txtRemark.Text = spdHead_Sheet1.Cells.Item(e.Row, 9).Text
        txtMclrId.Text = spdHead_Sheet1.Cells.Item(e.Row, 14).Text

        FP_COMPONENT()
        FP_SIZE_DETAIL()
        FP_SIZE_SUMMARY()

        
    End Sub
End Class