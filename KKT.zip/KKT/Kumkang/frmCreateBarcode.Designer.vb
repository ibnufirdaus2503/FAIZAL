﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCreateBarcode
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer19 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer19 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer22 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer22 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer23 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer23 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer21 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer21 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer24 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer24 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer25 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer25 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer29 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer29 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer26 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer26 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer27 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer27 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim CheckBoxCellType1 As FarPoint.Win.Spread.CellType.CheckBoxCellType = New FarPoint.Win.Spread.CellType.CheckBoxCellType
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim NumberCellType1 As FarPoint.Win.Spread.CellType.NumberCellType = New FarPoint.Win.Spread.CellType.NumberCellType
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType5 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim EnhancedScrollBarRenderer11 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle21 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle22 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle23 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer6 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle24 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType6 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer12 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer13 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle25 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle26 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle27 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer7 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle28 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType7 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer14 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType6 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim EnhancedScrollBarRenderer15 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle29 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle30 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle31 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer8 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle32 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType8 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer16 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Dim TextCellType7 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType8 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType9 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.spdSize = New FarPoint.Win.Spread.FpSpread
        Me.spdSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdBarcode = New FarPoint.Win.Spread.FpSpread
        Me.spdBarcode_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnCreate = New System.Windows.Forms.Button
        Me.btnPrint = New System.Windows.Forms.Button
        Me.spdProduct = New FarPoint.Win.Spread.FpSpread
        Me.spdProduct_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnCheck = New System.Windows.Forms.Button
        Me.btnUncheck = New System.Windows.Forms.Button
        Me.spdOrderSize = New FarPoint.Win.Spread.FpSpread
        Me.spdOrderSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdLOT = New FarPoint.Win.Spread.FpSpread
        Me.spdLOT_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnAddLOT = New System.Windows.Forms.Button
        Me.pnlLot = New System.Windows.Forms.Panel
        Me.btnCloseLot = New System.Windows.Forms.Button
        Me.dtETD = New System.Windows.Forms.DateTimePicker
        Me.btnDelLot = New System.Windows.Forms.Button
        Me.btnSaveLot = New System.Windows.Forms.Button
        Me.txtLOT = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnLotSize = New System.Windows.Forms.Button
        Me.pnlHelpSizeUpdate = New System.Windows.Forms.Panel
        Me.btnCloseSize = New System.Windows.Forms.Button
        Me.btnSaveSize = New System.Windows.Forms.Button
        Me.spdUpdateSize = New FarPoint.Win.Spread.FpSpread
        Me.spdUpdateSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.lblShift = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.spdSizeComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdSizeComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdBarcode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdBarcode_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProduct_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdOrderSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdOrderSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdLOT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdLOT_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLot.SuspendLayout()
        Me.pnlHelpSizeUpdate.SuspendLayout()
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.spdSizeComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSizeComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer10.Name = "EnhancedColumnHeaderRenderer10"
        EnhancedColumnHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer10.TextRotationAngle = 0
        EnhancedRowHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer10.Name = "EnhancedRowHeaderRenderer10"
        EnhancedRowHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer10.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = "EnhancedColumnHeaderRenderer8"
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = "EnhancedRowHeaderRenderer8"
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer11.Name = "EnhancedColumnHeaderRenderer11"
        EnhancedColumnHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer11.TextRotationAngle = 0
        EnhancedRowHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer11.Name = "EnhancedRowHeaderRenderer11"
        EnhancedRowHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer11.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer12.Name = "EnhancedColumnHeaderRenderer12"
        EnhancedColumnHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer12.TextRotationAngle = 0
        EnhancedRowHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer12.Name = "EnhancedRowHeaderRenderer12"
        EnhancedRowHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer12.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer13.Name = "EnhancedColumnHeaderRenderer13"
        EnhancedColumnHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer13.TextRotationAngle = 0
        EnhancedRowHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer13.Name = "EnhancedRowHeaderRenderer13"
        EnhancedRowHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer13.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer14.Name = "EnhancedColumnHeaderRenderer14"
        EnhancedColumnHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer14.TextRotationAngle = 0
        EnhancedRowHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer14.Name = "EnhancedRowHeaderRenderer14"
        EnhancedRowHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer14.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer15.Name = "EnhancedColumnHeaderRenderer15"
        EnhancedColumnHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer15.TextRotationAngle = 0
        EnhancedRowHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer15.Name = "EnhancedRowHeaderRenderer15"
        EnhancedRowHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer15.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer16.Name = "EnhancedColumnHeaderRenderer16"
        EnhancedColumnHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer16.TextRotationAngle = 0
        EnhancedRowHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer16.Name = "EnhancedRowHeaderRenderer16"
        EnhancedRowHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer16.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer17.Name = "EnhancedColumnHeaderRenderer17"
        EnhancedColumnHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer17.TextRotationAngle = 0
        EnhancedRowHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer17.Name = "EnhancedRowHeaderRenderer17"
        EnhancedRowHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer17.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer18.Name = "EnhancedColumnHeaderRenderer18"
        EnhancedColumnHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer18.TextRotationAngle = 0
        EnhancedRowHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer18.Name = "EnhancedRowHeaderRenderer18"
        EnhancedRowHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer18.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer19.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer19.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer19.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer19.Name = "EnhancedColumnHeaderRenderer19"
        EnhancedColumnHeaderRenderer19.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer19.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer19.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer19.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer19.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer19.TextRotationAngle = 0
        EnhancedRowHeaderRenderer19.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer19.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer19.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer19.Name = "EnhancedRowHeaderRenderer19"
        EnhancedRowHeaderRenderer19.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer19.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer19.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer19.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer19.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer19.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer20.Name = "EnhancedColumnHeaderRenderer20"
        EnhancedColumnHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer20.TextRotationAngle = 0
        EnhancedRowHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer20.Name = "EnhancedRowHeaderRenderer20"
        EnhancedRowHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer20.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer22.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer22.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer22.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer22.Name = "EnhancedColumnHeaderRenderer22"
        EnhancedColumnHeaderRenderer22.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer22.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer22.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer22.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer22.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer22.TextRotationAngle = 0
        EnhancedRowHeaderRenderer22.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer22.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer22.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer22.Name = "EnhancedRowHeaderRenderer22"
        EnhancedRowHeaderRenderer22.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer22.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer22.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer22.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer22.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer22.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer23.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer23.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer23.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer23.Name = "EnhancedColumnHeaderRenderer23"
        EnhancedColumnHeaderRenderer23.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer23.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer23.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer23.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer23.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer23.TextRotationAngle = 0
        EnhancedRowHeaderRenderer23.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer23.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer23.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer23.Name = "EnhancedRowHeaderRenderer23"
        EnhancedRowHeaderRenderer23.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer23.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer23.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer23.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer23.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer23.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer21.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer21.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer21.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer21.Name = "EnhancedColumnHeaderRenderer21"
        EnhancedColumnHeaderRenderer21.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer21.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer21.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer21.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer21.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer21.TextRotationAngle = 0
        EnhancedRowHeaderRenderer21.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer21.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer21.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer21.Name = "EnhancedRowHeaderRenderer21"
        EnhancedRowHeaderRenderer21.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer21.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer21.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer21.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer21.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer21.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer24.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer24.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer24.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer24.Name = "EnhancedColumnHeaderRenderer24"
        EnhancedColumnHeaderRenderer24.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer24.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer24.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer24.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer24.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer24.TextRotationAngle = 0
        EnhancedRowHeaderRenderer24.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer24.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer24.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer24.Name = "EnhancedRowHeaderRenderer24"
        EnhancedRowHeaderRenderer24.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer24.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer24.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer24.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer24.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer24.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer25.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer25.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer25.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer25.Name = "EnhancedColumnHeaderRenderer25"
        EnhancedColumnHeaderRenderer25.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer25.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer25.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer25.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer25.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer25.TextRotationAngle = 0
        EnhancedRowHeaderRenderer25.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer25.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer25.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer25.Name = "EnhancedRowHeaderRenderer25"
        EnhancedRowHeaderRenderer25.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer25.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer25.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer25.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer25.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer25.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer29.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer29.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer29.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer29.Name = "EnhancedColumnHeaderRenderer29"
        EnhancedColumnHeaderRenderer29.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer29.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer29.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer29.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer29.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer29.TextRotationAngle = 0
        EnhancedRowHeaderRenderer29.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer29.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer29.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer29.Name = "EnhancedRowHeaderRenderer29"
        EnhancedRowHeaderRenderer29.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer29.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer29.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer29.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer29.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer29.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer26.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer26.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer26.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer26.Name = "EnhancedColumnHeaderRenderer26"
        EnhancedColumnHeaderRenderer26.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer26.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer26.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer26.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer26.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer26.TextRotationAngle = 0
        EnhancedRowHeaderRenderer26.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer26.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer26.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer26.Name = "EnhancedRowHeaderRenderer26"
        EnhancedRowHeaderRenderer26.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer26.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer26.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer26.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer26.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer26.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer27.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer27.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer27.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer27.Name = "EnhancedColumnHeaderRenderer27"
        EnhancedColumnHeaderRenderer27.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer27.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer27.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer27.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer27.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer27.TextRotationAngle = 0
        EnhancedRowHeaderRenderer27.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer27.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer27.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer27.Name = "EnhancedRowHeaderRenderer27"
        EnhancedRowHeaderRenderer27.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer27.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer27.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer27.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer27.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer27.TextRotationAngle = 0
        '
        'spdSize
        '
        Me.spdSize.AccessibleDescription = "spdSize, Sheet1, Row 0, Column 0, "
        Me.spdSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdSize.HorizontalScrollBar.TabIndex = 26
        Me.spdSize.Location = New System.Drawing.Point(609, 206)
        Me.spdSize.Name = "spdSize"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer10
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer10
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSize_Sheet1})
        Me.spdSize.Size = New System.Drawing.Size(196, 237)
        Me.spdSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSize.TabIndex = 31
        Me.spdSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdSize.VerticalScrollBar.TabIndex = 27
        Me.spdSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSize_Sheet1
        '
        Me.spdSize_Sheet1.Reset()
        Me.spdSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSize_Sheet1.ColumnCount = 2
        Me.spdSize_Sheet1.RowCount = 1
        Me.spdSize_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Size"
        Me.spdSize_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "QTTY"
        Me.spdSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSize_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdSize_Sheet1.Columns.Get(0).Label = "Size"
        Me.spdSize_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdSize_Sheet1.Columns.Get(0).Width = 76.0!
        Me.spdSize_Sheet1.Columns.Get(1).Label = "QTTY"
        Me.spdSize_Sheet1.Columns.Get(1).Width = 61.0!
        Me.spdSize_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdBarcode
        '
        Me.spdBarcode.AccessibleDescription = "spdBarcode, Sheet1, Row 0, Column 0, "
        Me.spdBarcode.BackColor = System.Drawing.SystemColors.Control
        Me.spdBarcode.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdBarcode.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdBarcode.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdBarcode.HorizontalScrollBar.TabIndex = 36
        Me.spdBarcode.Location = New System.Drawing.Point(1165, 43)
        Me.spdBarcode.Name = "spdBarcode"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer29
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer29
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdBarcode.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdBarcode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdBarcode.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdBarcode_Sheet1})
        Me.spdBarcode.Size = New System.Drawing.Size(217, 449)
        Me.spdBarcode.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdBarcode.TabIndex = 32
        Me.spdBarcode.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdBarcode.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdBarcode.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdBarcode.VerticalScrollBar.TabIndex = 37
        Me.spdBarcode.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdBarcode_Sheet1
        '
        Me.spdBarcode_Sheet1.Reset()
        Me.spdBarcode_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdBarcode_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdBarcode_Sheet1.ColumnCount = 3
        Me.spdBarcode_Sheet1.RowCount = 1
        Me.spdBarcode_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Print"
        Me.spdBarcode_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "B a r c o d e"
        Me.spdBarcode_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Q T Y"
        Me.spdBarcode_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdBarcode_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdBarcode_Sheet1.Columns.Get(0).CellType = CheckBoxCellType1
        Me.spdBarcode_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdBarcode_Sheet1.Columns.Get(0).Label = "Print"
        Me.spdBarcode_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdBarcode_Sheet1.Columns.Get(0).Width = 34.0!
        Me.spdBarcode_Sheet1.Columns.Get(1).CellType = TextCellType1
        Me.spdBarcode_Sheet1.Columns.Get(1).Label = "B a r c o d e"
        Me.spdBarcode_Sheet1.Columns.Get(1).Width = 88.0!
        Me.spdBarcode_Sheet1.Columns.Get(2).CellType = TextCellType2
        Me.spdBarcode_Sheet1.Columns.Get(2).Label = "Q T Y"
        Me.spdBarcode_Sheet1.Columns.Get(2).Width = 40.0!
        Me.spdBarcode_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdBarcode_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdBarcode_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdBarcode_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(819, 498)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(337, 56)
        Me.btnCreate.TabIndex = 33
        Me.btnCreate.Text = "Create Barcode"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(1165, 498)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(221, 54)
        Me.btnPrint.TabIndex = 34
        Me.btnPrint.Text = "Print Barcode"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'spdProduct
        '
        Me.spdProduct.AccessibleDescription = "spdProduct, Sheet1, Row 0, Column 0, "
        Me.spdProduct.BackColor = System.Drawing.SystemColors.Control
        Me.spdProduct.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdProduct.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdProduct.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdProduct.HorizontalScrollBar.TabIndex = 10
        Me.spdProduct.Location = New System.Drawing.Point(823, 42)
        Me.spdProduct.Name = "spdProduct"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.Renderer = EnhancedColumnHeaderRenderer26
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.Renderer = EnhancedRowHeaderRenderer26
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdProduct.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdProduct.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdProduct.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdProduct_Sheet1})
        Me.spdProduct.Size = New System.Drawing.Size(336, 127)
        Me.spdProduct.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdProduct.TabIndex = 35
        Me.spdProduct.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdProduct.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdProduct.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdProduct.VerticalScrollBar.TabIndex = 11
        Me.spdProduct.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdProduct_Sheet1
        '
        Me.spdProduct_Sheet1.Reset()
        Me.spdProduct_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdProduct_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdProduct_Sheet1.ColumnCount = 7
        Me.spdProduct_Sheet1.RowCount = 1
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Component"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "PACK"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "QTY BRC"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "PRT BRC"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Molh_idxx"
        Me.spdProduct_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Mold ID"
        Me.spdProduct_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdProduct_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdProduct_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdProduct_Sheet1.Columns.Get(0).Visible = False
        Me.spdProduct_Sheet1.Columns.Get(0).Width = 37.0!
        Me.spdProduct_Sheet1.Columns.Get(1).CellType = TextCellType3
        Me.spdProduct_Sheet1.Columns.Get(1).Label = "Component"
        Me.spdProduct_Sheet1.Columns.Get(1).Width = 150.0!
        Me.spdProduct_Sheet1.Columns.Get(2).Label = "PACK"
        Me.spdProduct_Sheet1.Columns.Get(2).Width = 37.0!
        Me.spdProduct_Sheet1.Columns.Get(3).Label = "QTY BRC"
        Me.spdProduct_Sheet1.Columns.Get(3).Width = 47.0!
        Me.spdProduct_Sheet1.Columns.Get(4).Label = "PRT BRC"
        Me.spdProduct_Sheet1.Columns.Get(4).Width = 43.0!
        Me.spdProduct_Sheet1.Columns.Get(5).CellType = NumberCellType1
        Me.spdProduct_Sheet1.Columns.Get(5).Label = "Molh_idxx"
        Me.spdProduct_Sheet1.Columns.Get(5).Visible = False
        Me.spdProduct_Sheet1.Columns.Get(6).Label = "Mold ID"
        Me.spdProduct_Sheet1.Columns.Get(6).Visible = False
        Me.spdProduct_Sheet1.Columns.Get(6).Width = 90.0!
        Me.spdProduct_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdProduct_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdProduct_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdProduct_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 24)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Order"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(823, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 24)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Component"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(1161, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 24)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Barcode"
        '
        'btnCheck
        '
        Me.btnCheck.Location = New System.Drawing.Point(1248, 6)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(66, 35)
        Me.btnCheck.TabIndex = 40
        Me.btnCheck.Text = "Check All"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'btnUncheck
        '
        Me.btnUncheck.Location = New System.Drawing.Point(1320, 6)
        Me.btnUncheck.Name = "btnUncheck"
        Me.btnUncheck.Size = New System.Drawing.Size(66, 35)
        Me.btnUncheck.TabIndex = 41
        Me.btnUncheck.Text = "Uncheck All"
        Me.btnUncheck.UseVisualStyleBackColor = True
        '
        'spdOrderSize
        '
        Me.spdOrderSize.AccessibleDescription = "spdOrderSize, Sheet1, Row 0, Column 0, "
        Me.spdOrderSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdOrderSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdOrderSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdOrderSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdOrderSize.HorizontalScrollBar.TabIndex = 4
        Me.spdOrderSize.Location = New System.Drawing.Point(12, 449)
        Me.spdOrderSize.Name = "spdOrderSize"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer13
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer13
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdOrderSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdOrderSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdOrderSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdOrderSize_Sheet1})
        Me.spdOrderSize.Size = New System.Drawing.Size(793, 109)
        Me.spdOrderSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdOrderSize.TabIndex = 42
        Me.spdOrderSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdOrderSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdOrderSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdOrderSize.VerticalScrollBar.TabIndex = 5
        Me.spdOrderSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdOrderSize_Sheet1
        '
        Me.spdOrderSize_Sheet1.Reset()
        Me.spdOrderSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdOrderSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdOrderSize_Sheet1.ColumnCount = 2
        Me.spdOrderSize_Sheet1.RowCount = 3
        Me.spdOrderSize_Sheet1.Cells.Get(0, 0).Value = "ORDER"
        Me.spdOrderSize_Sheet1.Cells.Get(1, 0).Value = "LOT"
        Me.spdOrderSize_Sheet1.Cells.Get(2, 0).Value = "BALANCE"
        Me.spdOrderSize_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "_"
        Me.spdOrderSize_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "TOTAL"
        Me.spdOrderSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdOrderSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdOrderSize_Sheet1.Columns.Get(0).Label = "_"
        Me.spdOrderSize_Sheet1.Columns.Get(0).Width = 81.0!
        Me.spdOrderSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdOrderSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdOrderSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdOrderSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdLOT
        '
        Me.spdLOT.AccessibleDescription = "spdLOT, Sheet1, Row 0, Column 0, "
        Me.spdLOT.BackColor = System.Drawing.SystemColors.Control
        Me.spdLOT.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdLOT.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdLOT.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdLOT.HorizontalScrollBar.TabIndex = 24
        Me.spdLOT.Location = New System.Drawing.Point(609, 42)
        Me.spdLOT.Name = "spdLOT"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer8
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer8
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdLOT.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdLOT.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdLOT.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdLOT_Sheet1})
        Me.spdLOT.Size = New System.Drawing.Size(196, 127)
        Me.spdLOT.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdLOT.TabIndex = 43
        Me.spdLOT.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdLOT.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdLOT.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdLOT.VerticalScrollBar.TabIndex = 25
        Me.spdLOT.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdLOT_Sheet1
        '
        Me.spdLOT_Sheet1.Reset()
        Me.spdLOT_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdLOT_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdLOT_Sheet1.ColumnCount = 2
        Me.spdLOT_Sheet1.RowCount = 1
        Me.spdLOT_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "LOT"
        Me.spdLOT_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "ETD Planning"
        Me.spdLOT_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdLOT_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdLOT_Sheet1.Columns.Get(0).CellType = TextCellType4
        Me.spdLOT_Sheet1.Columns.Get(0).Label = "LOT"
        Me.spdLOT_Sheet1.Columns.Get(0).Width = 71.0!
        Me.spdLOT_Sheet1.Columns.Get(1).CellType = TextCellType5
        Me.spdLOT_Sheet1.Columns.Get(1).Label = "ETD Planning"
        Me.spdLOT_Sheet1.Columns.Get(1).Width = 68.0!
        Me.spdLOT_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdLOT_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdLOT_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdLOT_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnAddLOT
        '
        Me.btnAddLOT.Location = New System.Drawing.Point(609, 42)
        Me.btnAddLOT.Name = "btnAddLOT"
        Me.btnAddLOT.Size = New System.Drawing.Size(38, 37)
        Me.btnAddLOT.TabIndex = 44
        Me.btnAddLOT.Text = "Add"
        Me.btnAddLOT.UseVisualStyleBackColor = True
        '
        'pnlLot
        '
        Me.pnlLot.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlLot.Controls.Add(Me.btnCloseLot)
        Me.pnlLot.Controls.Add(Me.dtETD)
        Me.pnlLot.Controls.Add(Me.btnDelLot)
        Me.pnlLot.Controls.Add(Me.btnSaveLot)
        Me.pnlLot.Controls.Add(Me.txtLOT)
        Me.pnlLot.Controls.Add(Me.Label5)
        Me.pnlLot.Controls.Add(Me.Label6)
        Me.pnlLot.Location = New System.Drawing.Point(231, 142)
        Me.pnlLot.Name = "pnlLot"
        Me.pnlLot.Size = New System.Drawing.Size(256, 113)
        Me.pnlLot.TabIndex = 45
        Me.pnlLot.Visible = False
        '
        'btnCloseLot
        '
        Me.btnCloseLot.Location = New System.Drawing.Point(174, 78)
        Me.btnCloseLot.Name = "btnCloseLot"
        Me.btnCloseLot.Size = New System.Drawing.Size(72, 27)
        Me.btnCloseLot.TabIndex = 60
        Me.btnCloseLot.Text = "Close"
        Me.btnCloseLot.UseVisualStyleBackColor = True
        '
        'dtETD
        '
        Me.dtETD.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtETD.Location = New System.Drawing.Point(62, 46)
        Me.dtETD.Name = "dtETD"
        Me.dtETD.Size = New System.Drawing.Size(121, 20)
        Me.dtETD.TabIndex = 59
        '
        'btnDelLot
        '
        Me.btnDelLot.Location = New System.Drawing.Point(96, 78)
        Me.btnDelLot.Name = "btnDelLot"
        Me.btnDelLot.Size = New System.Drawing.Size(72, 27)
        Me.btnDelLot.TabIndex = 5
        Me.btnDelLot.Text = "Delete"
        Me.btnDelLot.UseVisualStyleBackColor = True
        '
        'btnSaveLot
        '
        Me.btnSaveLot.Location = New System.Drawing.Point(20, 80)
        Me.btnSaveLot.Name = "btnSaveLot"
        Me.btnSaveLot.Size = New System.Drawing.Size(72, 27)
        Me.btnSaveLot.TabIndex = 4
        Me.btnSaveLot.Text = "Save"
        Me.btnSaveLot.UseVisualStyleBackColor = True
        '
        'txtLOT
        '
        Me.txtLOT.BackColor = System.Drawing.SystemColors.Info
        Me.txtLOT.Location = New System.Drawing.Point(62, 17)
        Me.txtLOT.Name = "txtLOT"
        Me.txtLOT.Size = New System.Drawing.Size(121, 20)
        Me.txtLOT.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "ETD"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "LOT"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(607, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 24)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "L O T"
        '
        'btnLotSize
        '
        Me.btnLotSize.Location = New System.Drawing.Point(609, 206)
        Me.btnLotSize.Name = "btnLotSize"
        Me.btnLotSize.Size = New System.Drawing.Size(38, 37)
        Me.btnLotSize.TabIndex = 47
        Me.btnLotSize.Text = "Add"
        Me.btnLotSize.UseVisualStyleBackColor = True
        '
        'pnlHelpSizeUpdate
        '
        Me.pnlHelpSizeUpdate.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnCloseSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.btnSaveSize)
        Me.pnlHelpSizeUpdate.Controls.Add(Me.spdUpdateSize)
        Me.pnlHelpSizeUpdate.Location = New System.Drawing.Point(642, 267)
        Me.pnlHelpSizeUpdate.Name = "pnlHelpSizeUpdate"
        Me.pnlHelpSizeUpdate.Size = New System.Drawing.Size(517, 144)
        Me.pnlHelpSizeUpdate.TabIndex = 71
        Me.pnlHelpSizeUpdate.Visible = False
        '
        'btnCloseSize
        '
        Me.btnCloseSize.Location = New System.Drawing.Point(3, 105)
        Me.btnCloseSize.Name = "btnCloseSize"
        Me.btnCloseSize.Size = New System.Drawing.Size(511, 32)
        Me.btnCloseSize.TabIndex = 15
        Me.btnCloseSize.Text = "Close"
        Me.btnCloseSize.UseVisualStyleBackColor = True
        '
        'btnSaveSize
        '
        Me.btnSaveSize.Location = New System.Drawing.Point(3, 71)
        Me.btnSaveSize.Name = "btnSaveSize"
        Me.btnSaveSize.Size = New System.Drawing.Size(511, 32)
        Me.btnSaveSize.TabIndex = 14
        Me.btnSaveSize.Text = "Save"
        Me.btnSaveSize.UseVisualStyleBackColor = True
        '
        'spdUpdateSize
        '
        Me.spdUpdateSize.AccessibleDescription = "spdUpdateSize, Sheet1, Row 0, Column 0, "
        Me.spdUpdateSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdUpdateSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer11.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer11
        Me.spdUpdateSize.HorizontalScrollBar.TabIndex = 2
        Me.spdUpdateSize.Location = New System.Drawing.Point(3, 3)
        Me.spdUpdateSize.Name = "spdUpdateSize"
        NamedStyle21.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle21.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle21.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle21.Renderer = EnhancedColumnHeaderRenderer11
        NamedStyle21.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle22.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle22.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle22.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle22.Renderer = EnhancedRowHeaderRenderer11
        NamedStyle22.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle23.BackColor = System.Drawing.Color.DimGray
        NamedStyle23.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle23.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer6.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer6.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer6.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle23.Renderer = EnhancedCornerRenderer6
        NamedStyle23.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle24.BackColor = System.Drawing.SystemColors.Window
        NamedStyle24.CellType = GeneralCellType6
        NamedStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle24.Renderer = GeneralCellType6
        Me.spdUpdateSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle21, NamedStyle22, NamedStyle23, NamedStyle24})
        Me.spdUpdateSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdUpdateSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdUpdateSize_Sheet1})
        Me.spdUpdateSize.Size = New System.Drawing.Size(511, 65)
        Me.spdUpdateSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdUpdateSize.TabIndex = 13
        Me.spdUpdateSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdUpdateSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer12.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdUpdateSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer12
        Me.spdUpdateSize.VerticalScrollBar.TabIndex = 3
        Me.spdUpdateSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdUpdateSize_Sheet1
        '
        Me.spdUpdateSize_Sheet1.Reset()
        Me.spdUpdateSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdUpdateSize_Sheet1.ColumnCount = 30
        Me.spdUpdateSize_Sheet1.ColumnHeader.RowCount = 0
        Me.spdUpdateSize_Sheet1.RowCount = 2
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 0).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 1).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 2).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 3).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 4).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 5).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 6).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 7).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 8).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 9).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 10).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 11).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 12).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 13).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 13).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 13).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 14).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 14).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 14).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 15).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 15).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 15).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 16).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 16).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 16).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 17).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 17).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 17).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 18).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 18).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 18).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 19).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 19).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 19).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 20).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 20).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 20).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 21).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 21).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 21).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 22).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 22).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 22).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 23).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 23).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 23).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 24).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 24).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 24).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 25).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 25).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 25).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 26).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 26).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 26).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 27).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 27).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 27).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 28).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 28).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 28).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 29).ForeColor = System.Drawing.Color.Red
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 29).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(0, 29).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 13).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 13).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 14).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 14).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 15).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 15).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 16).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 16).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 17).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 17).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 18).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 18).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 19).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 19).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 20).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 20).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 21).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 21).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 22).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 22).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 23).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 23).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 24).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 24).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 25).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 25).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 26).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 26).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 27).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 27).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 28).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 28).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 29).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdUpdateSize_Sheet1.Cells.Get(1, 29).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdUpdateSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdUpdateSize_Sheet1.Columns.Get(0).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(1).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(2).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(3).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(4).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(5).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(6).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(7).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(8).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(9).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(10).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(11).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(12).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(13).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(14).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(15).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(16).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(17).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(18).Width = 55.0!
        Me.spdUpdateSize_Sheet1.Columns.Get(19).Width = 55.0!
        Me.spdUpdateSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdUpdateSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdUpdateSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdUpdateSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel3.Controls.Add(Me.lblShift)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Location = New System.Drawing.Point(806, 42)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(11, 516)
        Me.Panel3.TabIndex = 123
        '
        'lblShift
        '
        Me.lblShift.AutoSize = True
        Me.lblShift.BackColor = System.Drawing.Color.CadetBlue
        Me.lblShift.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShift.Location = New System.Drawing.Point(995, 1)
        Me.lblShift.Name = "lblShift"
        Me.lblShift.Size = New System.Drawing.Size(160, 31)
        Me.lblShift.TabIndex = 96
        Me.lblShift.Text = "S H I F T - 2"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 72)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(10, 13)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = " "
        '
        'spdSizeComponent
        '
        Me.spdSizeComponent.AccessibleDescription = "spdSizeComponent, Sheet1, Row 0, Column 0, "
        Me.spdSizeComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdSizeComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSizeComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer13.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer13.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer13.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer13.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer13.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer13.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer13.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSizeComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer13
        Me.spdSizeComponent.HorizontalScrollBar.TabIndex = 24
        Me.spdSizeComponent.Location = New System.Drawing.Point(823, 206)
        Me.spdSizeComponent.Name = "spdSizeComponent"
        NamedStyle25.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle25.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle25.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle25.Renderer = EnhancedColumnHeaderRenderer27
        NamedStyle25.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle26.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle26.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle26.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle26.Renderer = EnhancedRowHeaderRenderer27
        NamedStyle26.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle27.BackColor = System.Drawing.Color.DimGray
        NamedStyle27.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle27.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer7.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer7.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer7.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle27.Renderer = EnhancedCornerRenderer7
        NamedStyle27.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle28.BackColor = System.Drawing.SystemColors.Window
        NamedStyle28.CellType = GeneralCellType7
        NamedStyle28.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle28.Renderer = GeneralCellType7
        Me.spdSizeComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle25, NamedStyle26, NamedStyle27, NamedStyle28})
        Me.spdSizeComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSizeComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSizeComponent_Sheet1})
        Me.spdSizeComponent.Size = New System.Drawing.Size(333, 286)
        Me.spdSizeComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSizeComponent.TabIndex = 124
        Me.spdSizeComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSizeComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer14.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer14.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer14.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer14.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer14.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer14.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer14.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSizeComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer14
        Me.spdSizeComponent.VerticalScrollBar.TabIndex = 25
        Me.spdSizeComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSizeComponent_Sheet1
        '
        Me.spdSizeComponent_Sheet1.Reset()
        Me.spdSizeComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSizeComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSizeComponent_Sheet1.ColumnCount = 5
        Me.spdSizeComponent_Sheet1.RowCount = 1
        Me.spdSizeComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Size Lot"
        Me.spdSizeComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Size Mold"
        Me.spdSizeComponent_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "QTY"
        Me.spdSizeComponent_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "QTY BRC"
        Me.spdSizeComponent_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "PRT BRC"
        Me.spdSizeComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSizeComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSizeComponent_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdSizeComponent_Sheet1.Columns.Get(0).Label = "Size Lot"
        Me.spdSizeComponent_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdSizeComponent_Sheet1.Columns.Get(0).Width = 59.0!
        Me.spdSizeComponent_Sheet1.Columns.Get(1).CellType = TextCellType6
        Me.spdSizeComponent_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdSizeComponent_Sheet1.Columns.Get(1).Label = "Size Mold"
        Me.spdSizeComponent_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdSizeComponent_Sheet1.Columns.Get(1).Width = 108.0!
        Me.spdSizeComponent_Sheet1.Columns.Get(2).Label = "QTY"
        Me.spdSizeComponent_Sheet1.Columns.Get(2).Width = 39.0!
        Me.spdSizeComponent_Sheet1.Columns.Get(3).Label = "QTY BRC"
        Me.spdSizeComponent_Sheet1.Columns.Get(3).Width = 33.0!
        Me.spdSizeComponent_Sheet1.Columns.Get(4).Label = "PRT BRC"
        Me.spdSizeComponent_Sheet1.Columns.Get(4).Width = 37.0!
        Me.spdSizeComponent_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdSizeComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSizeComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSizeComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(607, 179)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(103, 24)
        Me.Label10.TabIndex = 126
        Me.Label10.Text = "L O T  Size"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(823, 179)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(150, 24)
        Me.Label2.TabIndex = 127
        Me.Label2.Text = "Component Size"
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, 0"
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer15.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer15
        Me.spdHead.HorizontalScrollBar.TabIndex = 0
        Me.spdHead.Location = New System.Drawing.Point(12, 42)
        Me.spdHead.Name = "spdHead"
        NamedStyle29.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle29.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle29.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle29.Renderer = EnhancedColumnHeaderRenderer25
        NamedStyle29.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle30.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle30.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle30.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle30.Renderer = EnhancedRowHeaderRenderer25
        NamedStyle30.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle31.BackColor = System.Drawing.Color.DimGray
        NamedStyle31.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle31.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer8.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer8.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer8.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle31.Renderer = EnhancedCornerRenderer8
        NamedStyle31.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle32.BackColor = System.Drawing.SystemColors.Window
        NamedStyle32.CellType = GeneralCellType8
        NamedStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle32.Renderer = GeneralCellType8
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle29, NamedStyle30, NamedStyle31, NamedStyle32})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(589, 401)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 128
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer16.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer16
        Me.spdHead.VerticalScrollBar.TabIndex = 1
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 11
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 0).Value = 0
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 2).Value = 2
        Me.spdHead_Sheet1.Cells.Get(0, 3).CellType = TextCellType7
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 3).Value = "3"
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 4).Value = 4
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 5).Value = 5
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 6).Value = 6
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 7).Value = 7
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 8).Value = 8
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 9).Value = 9
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "NO. PO"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "ETD"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Id Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "TYPE PO"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "REASON"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Mclr ID"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "Customer Name"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHead_Sheet1.Columns.Get(0).CellType = TextCellType8
        Me.spdHead_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHead_Sheet1.Columns.Get(1).Label = "NO. PO"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 129.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "ETD"
        Me.spdHead_Sheet1.Columns.Get(2).Width = 93.0!
        Me.spdHead_Sheet1.Columns.Get(3).CellType = TextCellType9
        Me.spdHead_Sheet1.Columns.Get(3).Label = "Id Model"
        Me.spdHead_Sheet1.Columns.Get(4).Label = "Model"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 118.0!
        Me.spdHead_Sheet1.Columns.Get(5).Label = "Color"
        Me.spdHead_Sheet1.Columns.Get(5).Width = 107.0!
        Me.spdHead_Sheet1.Columns.Get(6).Label = "TYPE PO"
        Me.spdHead_Sheet1.Columns.Get(6).Width = 134.0!
        Me.spdHead_Sheet1.Columns.Get(7).Label = "REASON"
        Me.spdHead_Sheet1.Columns.Get(7).Width = 145.0!
        Me.spdHead_Sheet1.Columns.Get(9).Label = "Customer Name"
        Me.spdHead_Sheet1.Columns.Get(9).Width = 191.0!
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmCreateBarcode
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1429, 561)
        Me.Controls.Add(Me.pnlHelpSizeUpdate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.spdSizeComponent)
        Me.Controls.Add(Me.btnLotSize)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.pnlLot)
        Me.Controls.Add(Me.btnAddLOT)
        Me.Controls.Add(Me.spdLOT)
        Me.Controls.Add(Me.spdOrderSize)
        Me.Controls.Add(Me.btnUncheck)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.spdProduct)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.spdBarcode)
        Me.Controls.Add(Me.spdSize)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.spdHead)
        Me.Name = "frmCreateBarcode"
        Me.Text = "Create Barcode"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdBarcode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdBarcode_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProduct, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProduct_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdOrderSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdOrderSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdLOT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdLOT_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLot.ResumeLayout(False)
        Me.pnlLot.PerformLayout()
        Me.pnlHelpSizeUpdate.ResumeLayout(False)
        CType(Me.spdUpdateSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdUpdateSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.spdSizeComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSizeComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents spdSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdBarcode As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdBarcode_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents spdProduct As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdProduct_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents btnUncheck As System.Windows.Forms.Button
    Friend WithEvents spdOrderSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdOrderSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdLOT As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdLOT_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnAddLOT As System.Windows.Forms.Button
    Friend WithEvents pnlLot As System.Windows.Forms.Panel
    Friend WithEvents btnDelLot As System.Windows.Forms.Button
    Friend WithEvents btnSaveLot As System.Windows.Forms.Button
    Friend WithEvents txtLOT As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnCloseLot As System.Windows.Forms.Button
    Friend WithEvents dtETD As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnLotSize As System.Windows.Forms.Button
    Friend WithEvents pnlHelpSizeUpdate As System.Windows.Forms.Panel
    Friend WithEvents btnCloseSize As System.Windows.Forms.Button
    Friend WithEvents btnSaveSize As System.Windows.Forms.Button
    Friend WithEvents spdUpdateSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdUpdateSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblShift As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents spdSizeComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSizeComponent_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
End Class
