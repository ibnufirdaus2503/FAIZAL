﻿Public Class frmMasterMaterial
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_FILL_MATERIAL()
        With spdMaterial_Sheet1.Cells
            txtIdMaterial.Text = .Item(spdMaterial_Sheet1.ActiveRowIndex, 0).Text
            txtMaterial.Text = .Item(spdMaterial_Sheet1.ActiveRowIndex, 1).Text
            chkEva.Checked = IIf(.Item(spdMaterial_Sheet1.ActiveRowIndex, 2).Value = 1, 1, 0)
            chkIP.Checked = IIf(.Item(spdMaterial_Sheet1.ActiveRowIndex, 3).Value = 1, 1, 0)
            chkRubber.Checked = IIf(.Item(spdMaterial_Sheet1.ActiveRowIndex, 4).Value = 1, 1, 0)
        End With
    End Sub
    Private Sub FP_FILL_CATEGORY()
        txtIdCategory.Text = spdKategori_Sheet1.Cells.Item(spdKategori_Sheet1.ActiveRowIndex, 0).Text
        txtCategory.Text = spdKategori_Sheet1.Cells.Item(spdKategori_Sheet1.ActiveRowIndex, 1).Text

    End Sub
    Private Sub FP_INSERT_MATERIAL()

        If txtIdMaterial.Text = "" Then
            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.material (mate_name,cate_idxx,mate_evax,mate_chip,mate_rubr) VALUES ('" & txtMaterial.Text & "'," & spdKategori_Sheet1.Cells.Item(spdKategori_Sheet1.ActiveRowIndex, 0).Text & "," & IIf(chkEva.Checked = True, 1, 0) & "," & IIf(chkIP.Checked = True, 1, 0) & "," & IIf(chkRubber.Checked = True, 1, 0) & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.material SET mate_name='" & txtMaterial.Text & "',mate_evax=" & IIf(chkEva.Checked = True, 1, 0) & ",mate_chip=" & IIf(chkIP.Checked = True, 1, 0) & ",mate_rubr=" & IIf(chkRubber.Checked = True, 1, 0) & " where mate_idxx=" & txtIdMaterial.Text

            clsCom.GP_ExeSql(SQL_C)
        End If
    End Sub
    Sub FP_LIST_MATERIAL()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT mate_idxx,mate_name,isnull(mate_evax,0) mate_evax,isnull(mate_chip,0) mate_chip,isnull(mate_rubr,0) mate_rubr" & vbLf
        SQL_C += "FROM KKTERP.dbo.material where cate_idxx=" & spdKategori_Sheet1.Cells.Item(spdKategori_Sheet1.ActiveRowIndex, 0).Text
        SQL_C += "order by mate_idxx asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMaterial_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mate_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mate_name")

                If clsCom.gv_DataRdr("mate_evax") = 1 Then .Cells.Item(.RowCount - 1, 2).Value = 1 Else .Cells.Item(.RowCount - 1, 2).Value = 0
                If clsCom.gv_DataRdr("mate_chip") = 1 Then .Cells.Item(.RowCount - 1, 3).Value = 1 Else .Cells.Item(.RowCount - 1, 3).Value = 0
                If clsCom.gv_DataRdr("mate_rubr") = 1 Then .Cells.Item(.RowCount - 1, 4).Value = 1 Else .Cells.Item(.RowCount - 1, 4).Value = 0
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Sub FP_LIST_CATEGORY()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT cate_idxx,cate_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_category where CODE_TMAT=" & spdType_Sheet1.Cells.Item(spdType_Sheet1.ActiveRowIndex, 0).Text
        SQL_C += "order by cate_name asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdKategori_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cate_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cate_name")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Sub FP_LIST_TYPE()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common where codh_flnm='CODE_TMAT'" & vbLf
        SQL_C += "order by codd_desc asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdType_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    'Sub FP_LIST_PRODUKSI()
    '    Dim SQL_C As String
    '    SQL_C = ""
    '    SQL_C += "SELECT codd_valu,codd_desc" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.code_common where codh_flnm='CODE_PMAT' AND COD1_VALU=" & spdType_Sheet1.Cells.Item(spdType_Sheet1.ActiveRowIndex, 0).Text
    '    SQL_C += "order by codd_desc asc" & vbLf


    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdProduksi_Sheet1
    '        .RowCount = 0
    '        While clsCom.gv_DataRdr.Read
    '            .RowCount = .RowCount + 1
    '            .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
    '            .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
    '        End While

    '        .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()

    'End Sub
    Private Sub frmMasterMaterial_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_TYPE()
    End Sub
 
    Private Sub FP_INSERT()

        If txtCategory.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If

        If txtIdCategory.Text = "" Then
            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.material_category (cate_name,CODE_TMAT) VALUES ('" & txtCategory.Text & "'," & spdType_Sheet1.Cells.Item(spdType_Sheet1.ActiveRowIndex, 0).Text & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.material_category  SET material_category where cate_idxx=" & txtIdCategory.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

    End Sub
    Private Sub btnSaveCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveCategory.Click
        FP_INSERT()
        FP_LIST_CATEGORY()
        pnlKategori.Visible = False
    End Sub

    Private Sub btnCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCategory.Click
        txtIdCategory.Text = ""
        txtCategory.Text = ""

        txtCategory.Focus()

        pnlKategori.Visible = True
    End Sub

    Private Sub spdProduksi_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs)
        FP_LIST_CATEGORY()
    End Sub

    Private Sub btnMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMaterial.Click
        pnlMaterial.Visible = True
        txtIdMaterial.Text = ""
        txtMaterial.Text = ""
        chkEva.Checked = 0
        chkIP.Checked = 0
        chkRubber.Checked = 0

    End Sub
 
    Private Sub btnSaveMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMaterial.Click
        If txtMaterial.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If


        FP_INSERT_MATERIAL()
      


        FP_LIST_MATERIAL()
        pnlMaterial.Visible = False
    End Sub

    Private Sub spdType_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdType.CellClick
        FP_LIST_CATEGORY()
    End Sub

    Private Sub spdKategori_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdKategori.CellClick
        FP_LIST_MATERIAL()
    End Sub

    Private Sub btnCloseCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCategory.Click
        pnlKategori.Visible = False
    End Sub

    Private Sub spdKategori_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdKategori.CellDoubleClick
        FP_FILL_CATEGORY()
        pnlKategori.Visible = True
    End Sub

    Private Sub btnDeleteCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteCategory.Click
        If txtIdCategory.Text <> "" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.material    where  cate_idxx=" & txtIdCategory.Text

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.material_category   where  cate_idxx=" & txtIdCategory.Text

            clsCom.GP_ExeSql(SQL_C)
            FP_LIST_CATEGORY()
            pnlKategori.Visible = False
        End If
    End Sub

    Private Sub btnCloseMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseMaterial.Click
        pnlMaterial.Visible = False
    End Sub

    Private Sub spdMaterial_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaterial.CellClick

    End Sub

    Private Sub spdMaterial_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaterial.CellDoubleClick
        FP_FILL_MATERIAL()
        pnlMaterial.Visible = True
    End Sub

    Private Sub btnDeleteMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteMaterial.Click
        If txtIdMaterial.Text <> "" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.material    where  mate_idxx=" & txtIdMaterial.Text

            clsCom.GP_ExeSql(SQL_C)

            FP_LIST_MATERIAL()
        End If
        pnlMaterial.Visible = False
    End Sub
End Class