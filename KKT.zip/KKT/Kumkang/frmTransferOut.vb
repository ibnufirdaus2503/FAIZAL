﻿Public Class frmTransferOut
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold As Integer
    Dim ROW As Integer
    Public Sub cmdSheetDel()
        SQL_C = ""
        SQL_C += "UPDATE KKTERP.dbo.mold_stock SET CODE_BUIL='" & txtIdFrom.Text & "' WHERE molh_idxx=" & spdComponent_Sheet1.Cells.Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text & " AND mols_size='" & spdDetail_Sheet1.ColumnHeader.Cells.Item(0, spdDetail_Sheet1.ActiveColumnIndex).Text & "' and mold_idxx='" & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, spdDetail_Sheet1.ActiveColumnIndex).Text & "'"

        clsCom.GP_ExeSql(SQL_C)


        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.mold_detail_transfer WHERE trah_idxx=" & txtIDHeader.Text & " AND molh_idxx=" & spdComponent_Sheet1.Cells.Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text & " AND mols_size='" & spdDetail_Sheet1.ColumnHeader.Cells.Item(0, spdDetail_Sheet1.ActiveColumnIndex).Text & "' and mold_idxx='" & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, spdDetail_Sheet1.ActiveColumnIndex).Text & "'"

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_HEAD_SET_MOLD()
    End Sub
    Public Sub cmdInsert()
        'FP_INSERT()
    End Sub
    Public Sub cmdUpdate()
        'FP_MODIFY()
    End Sub
    Public Sub cmdInquery()
        FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()


        SQL_C = ""
        SQL_C += "UPDATE A SET CODE_BUIL='" & txtIdFrom.Text & "'" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.mold_detail_transfer B ON a.molh_idxx=B.molh_idxx and A.mols_size=B.mols_size" & vbLf
        SQL_C += "Where trah_idxx = " & txtIDHeader.Text & vbLf
       
        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.mold_header_transfer WHERE trah_idxx=" & txtIDHeader.Text

        clsCom.GP_ExeSql(SQL_C)


        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.mold_detail_transfer WHERE trah_idxx=" & txtIDHeader.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_HEAD()
        FP_CLEAR()

    End Sub
    Private Sub FP_CLEAR()
        txtIdFrom.Text = ""
        txtIdTo.Text = ""
        txtFrom.Text = ""
        txtTo.Text = ""
        txtSJ.Text = ""
        spdComponent_Sheet1.RowCount = 0
        spdDetail_Sheet1.RowCount = 0
    End Sub

    Private Sub FP_INIT()
        ' Call FP_LIST_HEAD()
        ' FP_COMBO_TYPE()
        ' FP_COMBO_ACTIVITY()
    End Sub
    Private Sub FP_LIST_HEAD_SET_MOLD()
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""


        SQL_C = ""
        SQL_C += "SELECT  mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_transfer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where trah_idxx = " & txtIDHeader.Text
        SQL_C += " group by mols_size,mold_idxx" & vbLf
        SQL_C += "order by vseqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_FILL()

      

        With spdHead_Sheet1.Cells
            txtFrom.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 3).Text
            txtTo.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 5).Text
            txtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text
            dtSJ.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
            txtIdFrom.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 7).Text
            txtIdTo.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 8).Text
            txtIDHeader.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 6).Text
        End With
    End Sub
    Private Sub FP_LIST_HEAD_COMPONENT()
 

        SQL_C = ""
        SQL_C += "SELECT A.*,QTY" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null AND molh_idxx in (SELECT molh_idxx FROM  KKTERP.dbo.mold_detail_transfer where trah_idxx=" & txtIDHeader.Text & ")" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,mols_size,count(mold_idxx) qty" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  molh_idxx,mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail_transfer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where trah_idxx = 5 " & vbLf
        SQL_C += "group by molh_idxx,mols_size,mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY molh_idxx,mols_size" & vbLf
        SQL_C += ")B ON A.molh_idxx=B.molh_idxx" & vbLf
        SQL_C += "ORDER BY codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")
                ' .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD()

        SQL_C = ""

        SQL_C += "SELECT trah_idxx,trah_sjxx,convert(varchar(10),trah_date,111) trah_date,trah_from,trah_toxx,B.codd_desc VFROM,C.codd_desc VTO,D.codd_desc VAREA_FROM,D.codd_desc VAREA_TO" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header_transfer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BUIL' AND B.codd_valu=trah_from" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_BUIL' AND C.codd_valu=trah_toxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_AREA' AND D.codd_valu=B.cod1_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_AREA' AND E.codd_valu=C.cod1_valu" & vbLf
        SQL_C += "WHERE trah_idxx is not null" & vbLf

        If txtFromCari.Text <> "" Then
            SQL_C += "AND B.codd_desc like '%" & txtFromCari.Text & "%'" & vbLf
        End If

        If txtTocari.Text <> "" Then
            SQL_C += "AND C.codd_desc like '%" & txtTocari.Text & "%'" & vbLf
        End If

        If txtSJCari.Text <> "" Then
            SQL_C += "AND  trah_sjxx like '%" & txtSJCari.Text & "%'" & vbLf
        End If

        SQL_C += " order by trah_date" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("trah_date")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("trah_sjxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("VAREA_FROM")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("VFROM")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("VAREA_TO")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("VTO")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("trah_idxx")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("trah_from")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("trah_toxx")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_LIST_SET_MOLD(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""

        SQL_C += "SELECT A.mols_size,mold_idxx" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT molh_idxx,mols_size,CODE_BUIL " & vbLf
        SQL_C += " FROM KKTERP.dbo.mold_building " & vbLf
        SQL_C += "WHERE molh_idxx=" & spdHelpComponent_Sheet1.Cells.Item(ID, 0).Text & " AND CODE_BUIL='" & txtIdTo.Text & "'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += "where  molh_idxx = " & spdHelpComponent_Sheet1.Cells.Item(ID, 0).Text & " AND CODE_BUIL='" & txtIdFrom.Text & "'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY mols_size,mold_idxx" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpSize_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    
    Private Sub FP_LIST_HELP_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null " & vbLf

        If txtModelHelpCari.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModelHelpCari.Text & "%'"
        End If
        SQL_C += " order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariModel.Click
        FP_LIST_HELP_COMPONENT()
    End Sub

    Private Sub btnHelpUpdateSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpUpdateSize.Click
        If txtFrom.Text = "" Or txtTo.Text = "" Or txtSJ.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        pnlUpdateMold.Visible = True
    End Sub

    Private Sub spdHelpComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpComponent.CellClick
        code_mold = e.Row
        FP_LIST_SET_MOLD(code_mold)
    End Sub

    Private Sub spdHelpSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpSize.CellClick

        If spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor <> Color.LimeGreen Then
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.LimeGreen
        Else
            spdHelpSize.ActiveSheet.Cells(e.Row, e.Column).BackColor = Color.White
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlUpdateMold.Visible = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFrom.Click
        frmHelpBuilding.ShowDialog()




        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdFrom.Text = .Help_str1
            txtFrom.Text = .Help_str2
          


        End With
errHandle:
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        frmHelpBuilding.ShowDialog()




        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdTo.Text = .Help_str1
            txtTo.Text = .Help_str2



        End With
errHandle:
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim i, j As Integer

        If txtIDHeader.Text = "" Then
            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.mold_header_transfer (trah_sjxx,trah_date,trah_from,trah_toxx,trah_inst) values ('" & txtSJ.Text & "','" & dtSJ.Text & "','" & txtIdFrom.Text & "','" & txtIdTo.Text & "',GETDATE())"

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "SELECT TOP 1 trah_idxx FROM KKTERP.dbo.mold_header_transfer ORDER BY trah_idxx desc"

            clsCom.GP_ExeSqlReader(SQL_C)

            clsCom.gv_DataRdr.Read
            txtIDHeader.Text = clsCom.gv_DataRdr("trah_idxx")
         
            clsCom.gv_ExeSqlReaderEnd()

            FP_LIST_HEAD_COMPONENT()
            FP_LIST_HEAD()


        End If

        With spdHelpSize_Sheet1

            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    If .Cells.Item(j, i).BackColor = Color.LimeGreen Then
                       
                        SQL_C = ""
                        SQL_C += "INSERT INTO  KKTERP.dbo.mold_detail_transfer (trah_idxx,mols_size,mold_idxx,molh_idxx) values (" & txtIDHeader.Text & ",'" & .ColumnHeader.Cells.Item(0, i).Text & "','" & .Cells.Item(j, i).Text & "'," & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & ")"
                        'SQL_C += "insert into KKTERP.dbo.mold_detail (molh_idxx,mols_size,mold_idxx,newh_idxx) values (" & code_mold & ",'" & .ColumnHeader.Cells.Item(0, i).Text & "','" & .Cells.Item(j, i).Text & "'," & txtIdHeader.Text & ") "

                        clsCom.GP_ExeSql(SQL_C)

                        SQL_C = ""
                        SQL_C += "UPDATE KKTERP.dbo.mold_stock SET CODE_BUIL='" & txtIdTo.Text & "' where mold_idxx='" & .Cells.Item(j, i).Text & "' AND molh_idxx=" & spdHelpComponent_Sheet1.Cells.Item(code_mold, 0).Text & " AND mols_size='" & .ColumnHeader.Cells.Item(0, i).Text & "'"

                        clsCom.GP_ExeSql(SQL_C)
                    End If
                Next
            Next

        End With

        pnlUpdateMold.Visible = False
    End Sub

    Private Sub frmTransferOut_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_HEAD()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        FP_LIST_FILL()
        FP_LIST_HEAD_COMPONENT()
    End Sub

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick

    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        If e.Column = 7 Then
            pnlUpdateMold.Visible = True

            With spdComponent_Sheet1.Cells
                spdHelpComponent_Sheet1.Cells.Item(0, 0).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 1).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 1).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 2).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 2).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 3).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 3).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 4).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 4).Text
                spdHelpComponent_Sheet1.Cells.Item(0, 5).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 5).Text
                '  spdHelpComponent_Sheet1.Cells.Item(0, 6).Text = .Item(spdComponent_Sheet1.ActiveRowIndex, 6).Text
            End With
        End If
        FP_LIST_HEAD_SET_MOLD()
    End Sub
End Class