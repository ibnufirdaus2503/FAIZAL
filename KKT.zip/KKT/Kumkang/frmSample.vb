﻿Imports System.Collections.Generic
Public Class frmSample
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    'Private Sub dictionay_pivot()
    '    Dim Building As New Dictionary(Of String, Dictionary(Of String, Integer))()
    '     salesData.Add("ProdukA", New Dictionary(Of String, Integer) From {{"Januari", 100}, {"Februari", 150}, {"Maret", 200}})


    '    SQL_C = ""
    '    SQL_C += "SELECT CODE_BUIL,B.codd_desc , mols_size " & vbLf
    '    SQL_C += "FROM KKTERP.dbo.mold_building A" & vbLf
    '    SQL_C += "INNER JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BUIL' AND B.codd_valu=CODE_BUIL" & vbLf
    '    SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_AREA' AND C.codd_valu=B.cod1_valu" & vbLf
    '    SQL_C += "INNER JOIN KKTERP.dbo.group_size D ON D.CODE_SIZE=mols_size AND D.grop_size=mols_size" & vbLf
    '    SQL_C += "WHERE  A.molh_idxx = 4 " & vbLf

    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    While clsCom.gv_DataRdr.Read
    '        Building.Add(clsCom.gv_DataRdr("cust_idxx"), New Dictionary(Of string,Integer) From {{clsCom.gv_DataRdr("cust_idxx"),clsCom.gv_DataRdr("cust_idxx")}})

    '         Building.Add(clsCom.gv_DataRdr("cust_idxx"),  New Dictionary(Of String, Integer) From {{clsCom.gv_DataRdr("cust_idxx"), clsCom.gv_DataRdr("cust_idxx")}})

    '    End While
    'End Sub
    Private Sub dictionary()
        Dim dataDictionary As New Dictionary(Of String, String)()
        dataDictionary.Add("Apel", 10)
        dataDictionary.Add("Jeruk", 15)
        dataDictionary.Add("Mangga", 20)

        SQL_C = ""
        SQL_C += "select cust_name,cust_idxx,isnull(cust_tlpx,'') cust_tlpx,cust_addr from  KKTERP.dbo.customer" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)
 
        While clsCom.gv_DataRdr.Read
            dataDictionary.Add(clsCom.gv_DataRdr("cust_idxx"), clsCom.gv_DataRdr("cust_name"))
          
        End While

          

        clsCom.gv_ExeSqlReaderEnd()


        spdHead_Sheet1.RowCount = 0
        spdHead_Sheet1.ColumnCount = 2

        ' Set header kolom
        'spdHead_Sheet1.Cells(0, 0).Value = "Buah"
        'spdHead_Sheet1.Cells(0, 1).Value = "Jumlah"

        ' Isi data dari Dictionary ke sheet
        Dim rowIndex As Integer = 0
        For Each kvp As KeyValuePair(Of String, String) In dataDictionary
            spdHead_Sheet1.RowCount += 1
            spdHead_Sheet1.Cells(rowIndex, 0).Value = kvp.Key ' Key (Nama Buah)
            spdHead_Sheet1.Cells(rowIndex, 1).Value = kvp.Value ' Value (Jumlah)
            rowIndex += 1
        Next

        ' Atur lebar kolom
        spdHead_Sheet1.Columns(0).Width = 100
        spdHead_Sheet1.Columns(1).Width = 100
    End Sub
    Private Sub FP_LIST_HEAD()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "select cust_name,cust_idxx,isnull(cust_tlpx,'') cust_tlpx,cust_addr from  KKTERP.dbo.customer" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("cust_tlpx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("cust_addr")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmSample_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' FP_LIST_HEAD()
        dictionary()
    End Sub
End Class