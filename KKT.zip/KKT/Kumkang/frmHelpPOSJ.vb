﻿Public Class frmHelpPOSJ
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_HEAD()
        Dim Id_Model, Id_PO As Integer


        SQL_C = ""
        SQL_C += "SELECT ordh_idxx,ordh_poxx,convert(varchar(10),ordh_date,111) ordh_date,isnull(ordh_desc,'') ordh_desc, A.mclr_idxx," & vbLf
        SQL_C += "convert(varchar(10),ordh_etdh,111) ordh_etdh,ordh_nctr,convert(varchar(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "customer_name, brand_name, modl_idxx,model_name, colr_name,CODE_GEND," & vbLf
        SQL_C += "CODE_POXX,ISNULL(CODE_REAS,'') CODE_REAS ,D.codd_desc vTYPE_PO,ISNULL(E.codd_desc,'') vReason,isnull(C.CODD_DESC,'') VGENDER," & vbLf
        SQL_C += "A.SJXH_IDXX,SJXH_NOXX,CONVERT(VARCHAR(10),SJXH_dATE,111) TGL" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GEND' AND C.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_POXX' AND D.codd_valu=A.CODE_POXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_REAS' AND E.codd_valu=A.CODE_REAS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.SURAT_JALANH F ON F.SJXH_IDXX=A.SJXH_IDXX" & vbLf
        SQL_C += "WHERE A.SJXH_IDXX Is Not NULL " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                Id_Model = clsCom.gv_DataRdr("modl_idxx")
                Id_PO = clsCom.gv_DataRdr("ordh_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = Id_PO.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("TGL")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 5).Text = Id_Model.ToString("D4")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("sjxh_idxx")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("mclr_idxx")







            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHead_Sheet1.Cells.Item(e.Row, 0).Text 'ID PO
            .Help_str2 = spdHead_Sheet1.Cells.Item(e.Row, 1).Text 'NO SJ
            .Help_str3 = spdHead_Sheet1.Cells.Item(e.Row, 2).Text 'DATE SJ
            .Help_str4 = spdHead_Sheet1.Cells.Item(e.Row, 3).Text 'NO PO  
            .Help_str5 = spdHead_Sheet1.Cells.Item(e.Row, 4).Text 'ID CUSTOMER NAME
            .Help_str6 = spdHead_Sheet1.Cells.Item(e.Row, 5).Text ' ID MODEL
            .Help_str7 = spdHead_Sheet1.Cells.Item(e.Row, 6).Text 'MODEL NAME
            .Help_str8 = spdHead_Sheet1.Cells.Item(e.Row, 7).Text 'COLOR NAME
            .Help_str9 = spdHead_Sheet1.Cells.Item(e.Row, 9).Text 'MCLR ID 





        End With

        Me.Close()
    End Sub

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
     
    End Sub

    Private Sub frmHelpPOSJ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_HEAD()
    End Sub

    Private Sub btnClosePOSJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClosePOSJ.Click
        Me.Close()
    End Sub
End Class