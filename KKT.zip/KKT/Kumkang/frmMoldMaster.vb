﻿Public Class frmMoldMaster

    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vRowProduct, VIDBuilding, vRowSize As String
    Dim vRowMaster As Integer
    Sub FP_GROUP_SIZE_MOLD()

        Dim vRow, RowIndex As Integer

        SQL_C = ""
        SQL_C += "Select count(*) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_mold_size B ON mols_size=grop_size" & vbLf
        SQL_C += "WHERE A.molh_idxx=" & vRowProduct & " AND mols_size='" & vRowSize & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdSubSIze_Sheet1.RowCount = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "Select ISNULL(CODD_VALU,'')CODD_VALU ,ISNULL(CODE_SIZE,'') CODE_SIZE" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_mold_size B ON mols_size=grop_size" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_SIZE' AND CODD_DESC=CODE_SIZE" & vbLf
        SQL_C += "WHERE A.molh_idxx=" & vRowProduct & " AND mols_size='" & vRowSize & "'" & vbLf
        SQL_C += "ORDER BY CODD_VALU" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSubSIze_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1

                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("CODE_SIZE")



            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Public Sub cmdInquery()
        FP_LIST_Master()
    End Sub
    Private Sub FP_COMBO_PRESS()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu ,codd_desc   FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_PRES'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboPress
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_MOLDSHOP()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT vend_idxx,vend_name FROM KKTERP.dbo.vendor where vend_mshp=1 order by vend_name" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With cboMoldshop
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("vend_name") & Space(100) & clsCom.gv_DataRdr("vend_idxx"))
            End While

            .SelectedIndex = 0
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_GROUP()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu ,codd_desc   " & vbLf
        SQL_C += "FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_GCUS'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboGroup
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_BRAND()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu ,codd_desc   " & vbLf
        SQL_C += "FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_BRAN'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboBrand
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_Master()
        Dim SQL_C As String
        Dim RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.mold_master "

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdMaster_Sheet1.RowCount = clsCom.gv_DataRdr("QTY")
        clsCom.gv_ExeSqlReaderEnd()



        SQL_C = ""
        SQL_C += "SELECT mast_idxx,mast_name,CODE_BRAN,B.codd_desc VbRAND,CODE_GCUS ,C.codd_desc vGroup,vend_name,A.vend_idxx FROM KKTERP.dbo.mold_master A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BRAN' AND B.CODD_VALU=CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GCUS' AND C.CODD_VALU=CODE_GCUS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vendor D ON D.vend_idxx=A.vend_idxx" & vbLf
        SQL_C += "WHERE mast_idxx is not null" & vbLf

        If txtMoldCari.Text <> "" Then
            SQL_C += "AND mast_name like'%" & txtMoldCari.Text & "%'"
        End If
         

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMaster_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1

                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("mast_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("CODE_BRAN")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("CODE_GCUS")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("vend_idxx")
                .Cells.Item(RowIndex - 1, 4).Text = clsCom.gv_DataRdr("VbRAND")
                .Cells.Item(RowIndex - 1, 5).Text = clsCom.gv_DataRdr("mast_name")
                .Cells.Item(RowIndex - 1, 6).Text = clsCom.gv_DataRdr("vGroup")
                .Cells.Item(RowIndex - 1, 7).Text = clsCom.gv_DataRdr("vend_name")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
   
   
    
    Private Sub FP_LIST_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,B.codd_desc,CODE_COMP "
        SQL_C += "FROM KKTERP.dbo.mold_header A"
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP"
        SQL_C += "where A.modl_idxx = "

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SIZE()
        Dim RowIndex As Integer

        On Error GoTo errHandle


        SQL_C = ""
        SQL_C += "SELECT count(*) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size" & vbLf
        SQL_C += "WHERE molh_idxx=" & vRowProduct

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdSize_Sheet1.RowCount = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()



        SQL_C = ""
        SQL_C += "SELECT molh_idxx,mols_size,mols_cavi " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size" & vbLf
        SQL_C += "WHERE molh_idxx=" & vRowProduct
        SQL_C += "order by mols_seqn" & vbLf





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1

                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
errHandle:
    End Sub
 
    Private Sub FP_COMBO_PRODUCT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT component_id,component_name FROM KKTERP.dbo.vProduct order by component_name" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboProduct
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("component_name") & Space(100) & clsCom.gv_DataRdr("component_id"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

   
    Private Sub btnMoldCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoldCode.Click
        txtMoldCode.Text = ""
        txtQty.Text = ""

        pnlMoldCode.Visible = True
        FP_COMBO_PRODUCT()

    End Sub

   

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer
        pnlHelpSizeUpdate.Visible = False
        With spdSizeUpdate_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text = "" Then
                    Exit For
                End If

                SQL_C = ""
                SQL_C = SQL_C + " select count(*) qty from KKTERP.dbo.mold_size where  molh_idxx=" & vRowProduct & " and mols_size='" & .Cells.Item(0, i).Text & "'"

                clsCom.GP_ExeSqlReader(SQL_C)

                clsCom.gv_DataRdr.Read()
                If clsCom.gv_DataRdr("qty") <> 0 Then
                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C = SQL_C + " UPDATE KKTERP.dbo.mold_size SET mols_cavi=" & .Cells.Item(1, i).Text & "  where  molh_idxx=" & vRowProduct & " and mols_size='" & .Cells.Item(0, i).Text & "'"

                    clsCom.GP_ExeSqlReader(SQL_C)
                Else
                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C = SQL_C + "insert into KKTERP.dbo.mold_size (molh_idxx,mols_size,mols_cavi,mols_seqn) VALUES (" & vRowProduct & ", '" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & "," & i & ")"

                    clsCom.GP_ExeSql(SQL_C)

                    SQL_C = ""
                    SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.group_mold_size (grop_size,CODE_SIZE,molh_idxx) values ('" & .Cells.Item(0, i).Text & "','" & .Cells.Item(0, i).Text & "'," & vRowProduct & ")"

                    clsCom.GP_ExeSql(SQL_C)
                End If




            Next

        End With

        FP_LIST_SIZE()
      

    End Sub

    Private Sub spdProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellClick
        vRowProduct = spdProduct_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_SIZE()
       

    End Sub

    Private Sub btnSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
        Dim i, j As Integer


      
        With spdSizeUpdate_Sheet1
            For i = 0 To .RowCount - 1
                For j = 0 To .ColumnCount - 1
                    .Cells.Item(i, j).Text = ""
                Next
            Next

        End With
        pnlHelpSizeUpdate.Visible = True
    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    Private Sub spdProduct_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellDoubleClick



        pnlMoldCode.Visible = True
        With spdProduct_Sheet1.Cells
            txtMoldCode.Text = .Item(e.Row, 2).Text
            txtIdMold.Text = .Item(e.Row, 0).Text
            txtQty.Text = .Item(e.Row, 4).Text
            cboPress.Text = .Item(e.Row, 3).Text & Space(100) & .Item(e.Row, 5).Text
            cboProduct.Text = .Item(e.Row, 1).Text & Space(100) & .Item(e.Row, 6).Text

        End With
    End Sub

  

    Private Sub btnCloseHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseHead.Click
        pnlMoldCode.Visible = False
    End Sub

      

     
  
    Private Sub FP_LIST_PRODUCT()
        Dim rowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT count(*) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header  " & vbLf
        SQL_C += "where  mast_idxx=" & vRowMaster

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()
        spdProduct_Sheet1.RowCount = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,ISNULL(B.codd_desc,'') vComp,ISNULL(CODE_COMP,'') CODE_COMP,ISNULL(CODE_PRES,'') CODE_PRES,ISNULL(C.CODD_DESC,'') vPress,ISNULL(molh_paCK,0) vPack" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C on C.codh_flnm='CODE_PRES' and C.codd_valu=CODE_PRES" & vbLf

        SQL_C += "where A.mast_idxx=" & vRowMaster





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProduct_Sheet1
            rowIndex = 0
            While clsCom.gv_DataRdr.Read
                rowIndex = rowIndex + 1

                .Cells.Item(rowIndex - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(rowIndex - 1, 1).Text = clsCom.gv_DataRdr("vComp")
                .Cells.Item(rowIndex - 1, 2).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(rowIndex - 1, 3).Text = clsCom.gv_DataRdr("vPress")
                .Cells.Item(rowIndex - 1, 4).Text = clsCom.gv_DataRdr("VPACK")
                .Cells.Item(rowIndex - 1, 5).Text = clsCom.gv_DataRdr("CODE_PRES")
                .Cells.Item(rowIndex - 1, 6).Text = clsCom.gv_DataRdr("CODE_COMP")
             
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub



    Private Sub spdSize_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellDoubleClick
        If MsgBox("Apakah data akan di hapus ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            SQL_C = ""
            SQL_C = SQL_C + " delete KKTERP.dbo.mold_size    where  molh_idxx=" & vRowProduct & " and mols_size='" & spdSize_Sheet1.Cells.Item(e.Row, 0).Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)

            SQL_C = ""
            SQL_C = SQL_C + " delete KKTERP.dbo.group_mold_size    where  molh_idxx=" & vRowProduct & " and grop_size='" & spdSize_Sheet1.Cells.Item(e.Row, 0).Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)

            FP_LIST_SIZE()

        End If
    End Sub

    Private Sub btnAddMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMaster.Click
        txtIdMaster.Text = ""
        txtMaster.Text = ""

        pnlMasterMold.Visible = True
        FP_COMBO_BRAND()
        FP_COMBO_MOLDSHOP()
    End Sub

    Private Sub btnSaveMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMaster.Click

        If txtIdMaster.Text = "" Then
            SQL_C = ""
            SQL_C = SQL_C + "insert into KKTERP.dbo.mold_master (mast_name,CODE_BRAN,CODE_GCUS,vend_idxx) VALUES ('" & txtMaster.Text & "'," & Strings.Trim(Strings.Right(cboBrand.Text, 3)) & "," & Strings.Trim(Strings.Right(cboGroup.Text, 3)) & "," & Strings.Trim(Strings.Right(cboMoldshop.Text, 3)) & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.mold_master SET mast_name='" & txtMaster.Text & "',CODE_BRAN=" & Strings.Trim(Strings.Right(cboBrand.Text, 3)) & ",CODE_GCUS=" & Strings.Trim(Strings.Right(cboGroup.Text, 3)) & ",vend_idxx=" & Strings.Trim(Strings.Right(cboMoldshop.Text, 3)) & " WHERE mast_idxx=" & txtIdMaster.Text & ""

            clsCom.GP_ExeSql(SQL_C)
        End If

        FP_LIST_Master()
        pnlMasterMold.Visible = False
    End Sub

    Private Sub frmMoldMaster_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_Master()
        FP_COMBO_BRAND()
        FP_COMBO_GROUP()
        FP_COMBO_MOLDSHOP()
        FP_COMBO_PRESS()
    End Sub

   

    Private Sub spdMaster_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaster.CellDoubleClick
        pnlMasterMold.Visible = True
        With spdMaster_Sheet1
            txtIdMaster.Text = .Cells.Item(e.Row, 0).Text
            txtMaster.Text = .Cells.Item(e.Row, 5).Text


            cboBrand.Text = .Cells.Item(e.Row, 4).Text & Space(100) & .Cells.Item(e.Row, 1).Text
            cboGroup.Text = .Cells.Item(e.Row, 6).Text & Space(100) & .Cells.Item(e.Row, 2).Text


          

        End With
       
      
       
    End Sub

    Private Sub btnDeleteMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteMaster.Click
       
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_master SET mast_name='" & txtMaster.Text & "' WHERE mast_idxx=" & txtIdMaster.Text & ""

        clsCom.GP_ExeSql(SQL_C)


        FP_LIST_Master()
        pnlMasterMold.Visible = False
    End Sub

    Private Sub btnCloseMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseMaster.Click
        pnlMasterMold.Visible = False
    End Sub

    Private Sub spdMaster_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaster.CellClick
        vRowMaster = spdMaster_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_PRODUCT()
    End Sub

    Private Sub btnSaveHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveHead.Click
        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.mold_header where mast_idxx=" & vRowMaster & " AND CODE_COMP='" & Strings.Trim(Strings.Right(cboProduct.Text, 3)) & "'"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.mold_header (mast_idxx,CODE_COMP,molh_code,CODE_PRES,molh_pack) values (" & vRowMaster & ",'" & Strings.Trim(Strings.Right(cboProduct.Text, 3)) & "','" & txtMoldCode.Text & "'," & Strings.Right(cboPress.Text, 1) & "," & txtQty.Text & ")" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.mold_header  SET molh_pack=" & txtQty.Text & ",molh_code='" & txtMoldCode.Text & "', CODE_PRES=" & Strings.Right(cboPress.Text, 1) & " WHERE molh_idxx=" & txtIdMold.Text

            clsCom.GP_ExeSql(SQL_C)

        End If
        pnlMoldCode.Visible = False

        FP_LIST_PRODUCT()
    End Sub

    Private Sub btnDelHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelHead.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_header  WHERE molh_idxx=" & txtIdMold.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_size  WHERE molh_idxx=" & txtIdMold.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        'SQL_C = ""
        'SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_building WHERE molh_idxx=" & txtIdMold.Text & "  "

        'clsCom.GP_ExeSql(SQL_C)

        FP_LIST_PRODUCT()

        spdSize_Sheet1.RowCount = 0


    End Sub

    Private Sub btnSaveModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '  If txtIdModel.Text = "" Then

        ' Else

        '  End If
    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick
        vRowSize = spdSize_Sheet1.Cells.Item(e.Row, 0).Text
        FP_GROUP_SIZE_MOLD()
    End Sub

    Private Sub spdSubSIze_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSubSIze.CellClick

    End Sub

    Private Sub spdSubSIze_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSubSIze.CellDoubleClick
        If MsgBox("Apakah data akan di hapus ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            SQL_C = ""
            SQL_C = SQL_C + " delete KKTERP.dbo.group_mold_size    where  molh_idxx=" & vRowProduct & " and grop_size='" & vRowSize & "' and CODE_SIZE='" & spdSubSIze_Sheet1.Cells.Item(e.Row, 0).Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)



        End If

        FP_GROUP_SIZE_MOLD()
    End Sub

    Private Sub btnGroupSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGroupSave.Click
        Dim i As Integer
        pnlHelpSizeUpdate.Visible = False
        With spdGroupSize_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text = "" Then
                    Exit For
                End If

                SQL_C = ""
                SQL_C = SQL_C + " select count(*) qty from KKTERP.dbo.group_mold_size where  molh_idxx=" & vRowProduct & " and grop_size='" & vRowSize & "' AND code_size='" & .Cells.Item(0, i).Text & "'"

                clsCom.GP_ExeSqlReader(SQL_C)

                clsCom.gv_DataRdr.Read()
                If clsCom.gv_DataRdr("qty") = 0 Then

                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.group_mold_size (grop_size,CODE_SIZE,molh_idxx) values ('" & vRowSize & "','" & .Cells.Item(0, i).Text & "'," & vRowProduct & ")"

                    clsCom.GP_ExeSql(SQL_C)
                Else
                    clsCom.gv_ExeSqlReaderEnd()
                End If






            Next

        End With

        pnlGroupSize.Visible = False

        FP_GROUP_SIZE_MOLD()
    End Sub

    Private Sub btnCloseGroupSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseGroupSize.Click
        pnlGroupSize.Visible = False
    End Sub

    Private Sub btnAddGroupSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddGroupSize.Click
        Dim i, j As Integer



        With spdGroupSize_Sheet1
            For i = 0 To .RowCount - 1
                For j = 0 To .ColumnCount - 1
                    .Cells.Item(i, j).Text = ""
                Next
            Next

        End With
        pnlGroupSize.Visible = True
    End Sub
End Class