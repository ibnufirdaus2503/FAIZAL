﻿Public Class frmSettingModel

    Private Sub spdArea_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdArea.CellClick

    End Sub
End Class