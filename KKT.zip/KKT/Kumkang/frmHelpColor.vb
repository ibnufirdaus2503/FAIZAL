﻿Public Class frmHelpColor
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_COLOR()
        Dim vRow, RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT count(*) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.color A" & vbLf

        If txtColor.Text <> "" Then
            SQL_C += "WHERE colr_name like '%" & txtColor.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdHelpColor_Sheet1.RowCount = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()



        SQL_C = ""
        SQL_C += "SELECT A.* " & vbLf
        SQL_C += "FROM KKTERP.dbo.color A" & vbLf

        If txtColor.Text <> "" Then
            SQL_C += "WHERE colr_name like '%" & txtColor.Text & "%'"
        End If
        SQL_C += "ORDER BY A.colr_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpColor_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1
                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("colr_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("colr_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

  

    Private Sub spdHelpColor_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpColor.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHelpColor_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdHelpColor_Sheet1.Cells.Item(e.Row, 1).Text



        End With

        Me.Close()
    End Sub

    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        FP_LIST_COLOR()
    End Sub

    Private Sub btnCloseColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseColor.Click
        Me.Close()

    End Sub

   
End Class