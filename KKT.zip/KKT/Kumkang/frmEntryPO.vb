﻿Public Class frmEntryPO
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vPO As String
    Private Sub FP_COMBO_PRESS()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT   codd_valu ,codd_desc   FROM  KKTERP.dbo.code_common WHERE  codh_flnm='CODE_PRES'" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboPress
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex = 0

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SIZE_ORDER_COMPONENT()
        Dim mcom_old, vrow, vcol, i, j, vTotal As Integer

        Dim vFlag As Boolean

        vFlag = False

        SQL_C = ""
        SQL_C += "SELECT  MOLH_IDXX  ,MOLH_CODE,CODD_DESC,MOLS_SIZE,QTY,VSEQN" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT MOLH_IDXX ,MOLH_CODE,CODD_DESC,MOLS_SIZE,SUM(ORDD_QTYX) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select c.MOLH_IDXX, MOLH_CODE,CODD_DESC,mols_size,GROP_SIZE,CODE_SIZE,GROP_SEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx=" & txtID.Text & " AND COD1_VALU='CP'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT * FROM KKTERP.dbo.order_Detail where ordh_idxx=" & txtID.Text & vbLf
        SQL_C += ") B ON ORDD_SIZE=CODE_SIZE" & vbLf
        SQL_C += "WHERE ORDD_SIZE Is Not NULL " & vbLf
        SQL_C += "GROUP BY MOLH_IDXX,MOLH_CODE,CODD_DESC,MOLS_SIZE" & vbLf
        SQL_C += ") X" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select  GROP_SIZE,MIN(GROP_SEQN) VSEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx=" & txtID.Text & " AND COD1_VALU='CP'" & vbLf
        SQL_C += "GROUP BY c.MOLH_IDXX, MOLH_CODE,CODD_DESC,GROP_SIZE" & vbLf
        SQL_C += ")" & vbLf
        SQL_C += "Y ON mols_size=GROP_SIZE   " & vbLf
        SQL_C += "ORDER BY  molh_idxx,VSEQN" & vbLf




        clsCom.GP_ExeSqlReader(SQL_C)



        With spdSizeComponentPO_Sheet1
 
            For i = 0 To .RowCount - 1
                For j = 1 To .ColumnCount - 1
                    .Cells.Item(i, j).Text = ""
                Next
            Next


            mcom_old = 0
            While clsCom.gv_DataRdr.Read


                If mcom_old <> clsCom.gv_DataRdr("MOLH_IDXX") Then


                    vcol = 3
                    If vFlag = False Then
                        vrow = 0
                        vFlag = True
                    Else
                        vrow = 2

                    End If


                    .Cells.Item(vrow, 0).Text = clsCom.gv_DataRdr("MOLH_IDXX")
                    .Cells.Item(vrow, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, 1).Text = clsCom.gv_DataRdr("CODD_DESC")
                    .Cells.Item(vrow, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, vcol - 1).Text = "Total"
                    .Cells.Item(vrow, vcol - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                Else
                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                End If


                vcol = vcol + 1
                mcom_old = clsCom.gv_DataRdr("MOLH_IDXX")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With



        clsCom.gv_ExeSqlReaderEnd()


        With spdSizeComponentPO_Sheet1

            If .Cells.Item(0, 0).Text <> "" Then
                vTotal = 0
                For i = 2 To .ColumnCount - 1
                    If .Cells.Item(1, i).Text <> "" Then
                        vTotal = vTotal + Val(spdSizeComponentPO_Sheet1.Cells.Item(1, i).Text)
                    End If
                Next
                .Cells.Item(1, 2).Text = vTotal
                .Cells.Item(1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
            End If



            If .Cells.Item(2, 0).Text <> "" Then
                vTotal = 0
                For i = 2 To .ColumnCount - 1

                    If .Cells.Item(3, i).Text <> "" Then
                        vTotal = vTotal + Val(.Cells.Item(3, i).Text)
                    End If
                Next
                .Cells.Item(3, 2).Text = vTotal
                .Cells.Item(3, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(3, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
            End If

        End With
    End Sub
    Private Sub FP_LIST_SIZE_REFF()
        SQL_C = ""
        SQL_C += "SELECT ordd_size,ordd_qtyx " & vbLf
        SQL_C += "FROM KKTERP.dbo.order_detail A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.CODE_COMMON B ON B.CODH_FLNM='CODE_SIZE' AND CODD_DESC=ORDD_SIZE" & vbLf
        SQL_C += "WHERE ordh_poxx='" & txtReff.Text & "'" & vbLf
        SQL_C += "ORDER BY CODD_VALU"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            .RowCount = 1
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_REFF()

        SQL_C = ""
        SQL_C += "SELECT CODE_GEND,CODE_BRAN,ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111) ordh_date,CONVERT(VARCHAR(10),ordh_etdh,111) ordh_etdh,ordh_nctr ,D.CODE_GCUS,"
        SQL_C += "CONVERT(VARCHAR(10),ordh_dctr,111) ordh_dctr,A.cust_idxx,A.CODE_PROD,A.colr_idxx,A.modl_idxx,ordh_styl,ordh_desc,ordh_stat,cust_name,colr_name,modl_name,E.codd_desc vBran,F.codd_desc vProd,isnull(G.codd_desc,'') vGender" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color B ON B.colr_idxx=A.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model C ON C.modl_idxx=A.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer D ON D.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_BRAN' AND E.codd_valu=C.CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common F ON F.codh_flnm='CODE_PROD' AND F.codd_valu=A.CODE_PROD" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_GEND' AND G.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "where A.CUST_IDXX is not null AND ORDH_POXX='" & txtReff.Text & "'" & vbLf
 



        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        txtPO.Text = Now.ToString("yyyyMMddHHmmss")

        dtPO.Value = Now
        dtETD.Value = Now
        txtNoKontrak.Text = ""
        dtContract.Text = Now
        txtModel.Text = clsCom.gv_DataRdr("modl_name")
        txtColor.Text = clsCom.gv_DataRdr("colr_name")

        txtIDMclr.Text = clsCom.gv_DataRdr("modl_idxx")
        txtBrand.Text = clsCom.gv_DataRdr("vBran")
    

        clsCom.gv_ExeSqlReaderEnd()

        FP_LIST_SIZE_REFF()

       










    End Sub
    Private Sub FP_COMBO_REASON()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT CODD_DESC,CODD_valu FROM KKTERP.dbo.CODE_COMMON where codh_flnm='CODE_REAS'"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboReason
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_TYPEPO()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT CODD_DESC,CODD_valu FROM KKTERP.dbo.CODE_COMMON where codh_flnm='CODE_POXX'"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboType
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Public Sub cmdInquery()
        FP_LIST_HEAD()
    End Sub
    Public Sub cmdAdd()

    End Sub
    Public Sub cmdInsert()

        FP_CLEAR()
        FP_COMBO_GENDER()

        txtPO.Focus()

    End Sub
    Public Sub cmdUpdate()

        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.production where prod_prnt is not null and ordh_idxx=" & txtID.Text


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") > 0 Then
            clsCom.gv_ExeSqlReaderEnd()
            MsgBox("Tidak bisa di update,Barcode sudah di print")
            Exit Sub
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.order_header SET ordh_poxx='" & txtPO.Text & "',ordh_date='" & dtPO.Value & "',ordh_etdh='" & dtETD.Value & "',ordh_nctr='" & txtNoKontrak.Text & "',ordh_dctr='" & dtContract.Value & "', ordh_desc='" & txtDesc.Text & "',CODE_GEND='" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',mclr_idxx=" & txtIDMclr.Text & ",cust_idxx=" & txtIdCustomer.Text & ",CODE_PRES=" & Strings.Trim(Strings.Right(cboPress.Text, 3)) & " WHERE ordh_idxx=" & Val(txtID.Text)

            clsCom.GP_ExeSqlReader(SQL_C)

            MsgBox("Sukses Update")


        End If

        FP_LIST_SIZE(Val(txtID.Text))
        FP_LIST_HEAD()
        FP_SIZE_ORDER_COMPONENT()

    End Sub
    Public Sub cmdDelete()


        SQL_C = ""
        SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.production where prod_prnt is not null and ordh_idxx=" & Val(txtID.Text)
         

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()
            MsgBox("Tidak bisa di hapus,Barcode sudah di print")
            Exit Sub
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "delete KKTERP.dbo.order_detail where ordh_idxx=" & txtID.Text & ""

            clsCom.GP_ExeSqlReader(SQL_C)

            SQL_C = ""
            SQL_C = SQL_C + "delete KKTERP.dbo.order_header where ordh_idxx=" & txtID.Text & ""

            clsCom.GP_ExeSqlReader(SQL_C)

            FP_CLEAR()
            FP_LIST_HEAD()

        End If


       





    End Sub

    Private Sub FP_COMBO_GENDER()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc  FROM KKTERP.dbo.code_common where codh_flnm='CODE_GEND'"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboGender
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_CLEAR()
        Dim i, j As Integer

        txtPO.Text = ""
        dtPO.Value = Now
        dtETD.Value = Now
        txtNoKontrak.Text = ""
        dtContract.Text = Now
        txtModel.Text = ""
        txtBrand.Text = ""
        txtColor.Text = ""

        txtIDMclr.Text = ""
        txtBrand.Text = ""

        txtDesc.Text = ""
        txtID.Text = ""
        txtIDModel.Text = ""


        cboGender.Items.Clear()
        cboGender.Text = ""
        spdSize_Sheet1.RowCount = 0
        spdSize_Sheet1.ColumnCount = 0

        With spdSizeComponentPO_Sheet1
            For i = 0 To .RowCount - 1
                For j = 0 To .ColumnCount - 1
                    .Cells.Item(i, j).Text = ""
                Next
            Next

        End With

        FP_COMBO_GENDER()
    End Sub

    
    Private Sub FP_LIST_HEAD()
        Dim vId As Integer
        Dim vIdModel As Integer

      
        SQL_C = ""
        SQL_C += "SELECT ordh_idxx,ordh_poxx,convert(varchar(10),ordh_date,111) ordh_date,isnull(ordh_desc,'') ordh_desc," & vbLf
        SQL_C += "convert(varchar(10),ordh_etdh,111) ordh_etdh,ordh_nctr,convert(varchar(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "isnull(cust_name,'')  customer_name, brand_name, modl_idxx,model_name, isnull(colr_name,'') colr_name,CODE_GEND,A.mclr_idxx,ISNULL(A.cust_idxx,'') cust_idxx," & vbLf
        SQL_C += "CODE_POXX,ISNULL(CODE_REAS,'') CODE_REAS ,D.codd_desc vTYPE_PO,ISNULL(E.codd_desc,'') vReason,isnull(C.CODD_DESC,'') VGENDER,ISNULL(CODE_PRES,'') CODE_PRES, ISNULL(G.CODD_DESC,'') vProduct" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GEND' AND C.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_POXX' AND D.codd_valu=A.CODE_POXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_REAS' AND E.codd_valu=A.CODE_REAS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer F ON F.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_PRES' AND G.codd_valu=A.CODE_PRES" & vbLf
        SQL_C += "WHERE ordh_idxx is not null" & vbLf

        If txtCustomerCari.Text <> "" Then
            SQL_C += "AND cust_name like '%" & txtCustomerCari.Text & "%'" & vbLf
        End If

        If txtModelCari.Text <> "" Then
            SQL_C += "AND modl_name like '%" & txtModelCari.Text & "%'" & vbLf
        End If

        If txtColorCari.Text <> "" Then
            SQL_C += "AND colr_name like '%" & txtColorCari.Text & "%'" & vbLf
        End If



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                vId = clsCom.gv_DataRdr("ordh_idxx")
                vIdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = vId.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_date")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_etdh")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("ordh_nctr")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("ordh_dctr")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 8).Text = vIdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("vGender")
                .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("ordh_desc")
                .Cells.Item(.RowCount - 1, 13).Text = clsCom.gv_DataRdr("vTYPE_PO")
                .Cells.Item(.RowCount - 1, 14).Text = clsCom.gv_DataRdr("vReason")
                .Cells.Item(.RowCount - 1, 15).Text = clsCom.gv_DataRdr("CODE_GEND")
                .Cells.Item(.RowCount - 1, 16).Text = clsCom.gv_DataRdr("CODE_POXX")
                .Cells.Item(.RowCount - 1, 17).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(.RowCount - 1, 18).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 19).Text = clsCom.gv_DataRdr("CODE_PRES")
                .Cells.Item(.RowCount - 1, 20).Text = clsCom.gv_DataRdr("vproduct")







                Dim i As Integer

                If clsCom.gv_DataRdr("CODE_POXX") = 2 Then
                    For i = 0 To .ColumnCount - 1
                        .Cells.Item(.RowCount - 1, i).BackColor = Color.Aquamarine
                    Next
                End If

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SIZE(ByVal vPO As Integer)
        Dim i As Integer
        Dim vTotal As Integer

      

        SQL_C = ""
        SQL_C += "SELECT ordd_size,ordd_qtyx " & vbLf
        SQL_C += "FROM KKTERP.dbo.order_detail A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.CODE_COMMON B ON B.CODH_FLNM='CODE_SIZE' AND CODD_DESC=ORDD_SIZE" & vbLf
        SQL_C += "WHERE ordh_idxx=" & vPO & "" & vbLf
        SQL_C += "ORDER BY CODD_VALU" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 1
            .RowCount = 1
            vTotal = 0

            Dim j As Integer


            For j = 1 To .ColumnCount - 1
                .Cells.Item(0, j).Text = ""
            Next

            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1

                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, 0).Text = "Total"
                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


                vTotal = vTotal + clsCom.gv_DataRdr("ordd_qtyx")

            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect

            .Cells.Item(0, 0).Text = vTotal
            .Cells.Item(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
            .Cells.Item(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        Dim vidModel As Integer


        frmHelpModelColorComplete.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtCustomer.Text = .Help_str1
            txtBrand.Text = .Help_str2
            vidModel = .Help_str3
            txtIDModel.Text = vidModel.ToString("D4")
            txtModel.Text = .Help_str4
            txtColor.Text = .Help_str5
            txtIDMclr.Text = .Help_str6
            txtIdCustomer.Text = .Help_str7

           

        End With

     



errHandle:
    End Sub
   
   

    Private Sub frmEntryPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_COMBO_PRESS()
        FP_COMBO_GENDER()
        FP_LIST_HEAD()
        FP_COMBO_TYPEPO()
        FP_COMBO_REASON()
    End Sub

     
    Private Sub btnSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
  

        pnlDetailUpdate.Visible = True





    End Sub

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer

        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.order_header where ordh_poxx='" & txtPO.Text & "'"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.order_lot WHERE ordh_poxx='" & txtPO.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr("qty") = 0 Then
                SQL_C = ""
                SQL_C = SQL_C + "delete KKTERP.dbo.order_detail where ordh_poxx='" & txtPO.Text & "'"

                clsCom.GP_ExeSqlReader(SQL_C)

                With spdUpdateSize_Sheet1
                    For i = 0 To .ColumnCount - 1
                        If .Cells.Item(0, i).Text <> "" Then
                            SQL_C = ""
                            SQL_C = SQL_C + "insert into KKTERP.dbo.order_detail (ordh_poxx,ordd_size,ordd_qtyx) values ('" & txtPO.Text & "','" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & ")"

                            clsCom.GP_ExeSqlReader(SQL_C)
                        End If
                    Next
                End With

            Else
                MsgBox("Sudah di buat LOT Planning !!!")
                Exit Sub

            End If

        Else
            clsCom.gv_ExeSqlReaderEnd()

            If Strings.Right(cboType.Text, 1) = 1 Then
                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx,CODE_PRES) values ('" & txtPO.Text & "','" & dtPO.Value & "','" & dtETD.Value & "','" & txtNoKontrak.Text & "','" & dtContract.Value & "','" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',1," & txtIDMclr.Text & "," & txtIdCustomer.Text & "," & Strings.Trim(Strings.Right(cboPress.Text, 3)) & ")"

            ElseIf Strings.Right(cboType.Text, 1) = 2 Then
                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx,CODE_PRES) values ('" & txtPO.Text & "','" & dtPO.Value & "','" & dtETD.Value & "','" & txtNoKontrak.Text & "','" & dtContract.Value & "','" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',2," & txtIDMclr.Text & "," & txtIdCustomer.Text & "," & Strings.Trim(Strings.Right(cboPress.Text, 3)) & ")"

            Else

                If txtReff.Text = "" Then
                    MsgBox("HARUS DI ISI PO REFF")
                    Exit Sub
                End If

                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx,CODE_PRES) values ('" & txtPO.Text & "','" & dtPO.Value & "','" & dtETD.Value & "','" & txtNoKontrak.Text & "','" & dtContract.Value & "','" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',3," & txtIDMclr.Text & "," & txtIdCustomer.Text & "," & Strings.Trim(Strings.Right(cboPress.Text, 3)) & ")"

            End If


            clsCom.GP_ExeSqlReader(SQL_C)

            SQL_C = ""
            SQL_C = SQL_C + "SELECT top 1 ordh_idxx FROM KKTERP.dbo.order_header order by ordh_idxx desc"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            txtID.Text = clsCom.gv_DataRdr("ordh_idxx")
            clsCom.gv_ExeSqlReaderEnd()



            With spdUpdateSize_Sheet1
                For i = 0 To .ColumnCount - 1
                    If .Cells.Item(0, i).Text <> "" Then
                        SQL_C = ""
                        SQL_C = SQL_C + "insert into KKTERP.dbo.order_detail (ordh_idxx,ordd_size,ordd_qtyx) values (" & txtID.Text & ",'" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & ")"

                        clsCom.GP_ExeSqlReader(SQL_C)
                    End If
                Next


            End With

        End If







        pnlHelpSizeUpdate.Visible = False
        FP_LIST_HEAD()
        FP_LIST_SIZE(vPO)
    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

        Dim i As Integer

        FP_CLEAR()

        With spdHead_Sheet1.Cells
            txtID.Text = .Item(e.Row, 0).Text
            txtPO.Text = .Item(e.Row, 1).Text
            dtPO.Value = .Item(e.Row, 2).Text
            dtETD.Value = .Item(e.Row, 3).Text
            txtNoKontrak.Text = .Item(e.Row, 4).Text
            dtContract.Text = .Item(e.Row, 5).Text

            txtCustomer.Text = .Item(e.Row, 6).Text
            txtBrand.Text = .Item(e.Row, 7).Text
            txtIDModel.Text = .Item(e.Row, 8).Text
            txtModel.Text = .Item(e.Row, 9).Text
            txtColor.Text = .Item(e.Row, 10).Text
            txtDesc.Text = .Item(e.Row, 12).Text
            txtIdCustomer.Text = .Item(e.Row, 18).Text

         
           
            cboType.Text = .Item(e.Row, 13).Text & Space(100) & .Item(e.Row, 16).Text
            cboGender.Text = .Item(e.Row, 11).Text & Space(100) & .Item(e.Row, 15).Text
            cboPress.Text = .Item(e.Row, 20).Text & Space(100) & .Item(e.Row, 19).Text
            txtIDMclr.Text = .Item(e.Row, 17).Text

            'If .Item(e.Row, 23).Text <> "" Then
            '    cboReason.Text = .Item(e.Row, 23).Text & Space(100) & .Item(e.Row, 20).Text
            'End If




            FP_LIST_SIZE(Val(txtID.Text))

        End With

        FP_SIZE_ORDER_COMPONENT()


    End Sub

    
    Private Sub cboType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboType.SelectedIndexChanged

        FP_CLEAR()
        If Trim(Strings.Right(cboType.Text, 2)) = 2 Then
            cboReason.Visible = False
            txtReff.Visible = True
            lblReason.Visible = False
            lblReff.Visible = True
            btnPO.Visible = True
        ElseIf Trim(Strings.Right(cboType.Text, 2)) = 3 Then
            cboReason.Visible = True
            txtReff.Visible = True
            lblReason.Visible = True
            lblReff.Visible = True
            btnPO.Visible = True
        Else
            cboReason.Visible = False
            txtReff.Visible = False
            lblReason.Visible = False
            lblReff.Visible = False
            btnPO.Visible = False
        End If
    End Sub

    Private Sub btnPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPO.Click
        frmHelpPO.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            'txtIdModel.Text = .Help_str4
            'txtModel.Text = .Help_str2
            'txtIdCustomer.Text = .Help_str5
            'txtBrand.Text = .Help_str3
            txtReff.Text = .Help_str1


        End With


        FP_REFF()


        '  FP_COMBO_CUSTOMER()

errHandle:
    End Sub

    Private Sub btnSaveSizeuPDATE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSizeuPDATE.Click
        Dim i As Integer


        If txtID.Text = "" Then
            If Strings.Right(cboType.Text, 1) = 1 Then
                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx) values ('" & txtPO.Text & "',convert(varchar(10),'" & dtPO.Value & "',111),convert(varchar(10),'" & dtETD.Value & "',111),'" & txtNoKontrak.Text & "',convert(varchar(10),'" & dtContract.Value & "',111),'" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',1," & txtIDMclr.Text & "," & txtIdCustomer.Text & ")"

            ElseIf Strings.Right(cboType.Text, 1) = 2 Then
                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx) values ('" & txtPO.Text & "',convert(varchar(10),'" & dtPO.Value & "',111),convert(varchar(10),'" & dtETD.Value & "',111),'" & txtNoKontrak.Text & "',convert(varchar(10),'" & dtContract.Value & "',111),'" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',2," & txtIDMclr.Text & "," & txtIdCustomer.Text & ")"

            Else

                If txtReff.Text = "" Then
                    MsgBox("HARUS DI ISI PO REFF")
                    Exit Sub
                End If

                SQL_C = ""
                SQL_C = SQL_C + "insert into KKTERP.dbo.order_header(ordh_poxx,ordh_date,ordh_etdh,ordh_nctr,ordh_dctr, ordh_desc,ordh_stat,CODE_GEND,CODE_POXX,mclr_idxx,cust_idxx) values ('" & txtPO.Text & "',convert(varchar(10),'" & dtPO.Value & "',111),convert(varchar(10),'" & dtETD.Value & "',111),'" & txtNoKontrak.Text & "',convert(varchar(10),'" & dtContract.Value & "',111),'" & txtDesc.Text & "',0,'" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "',3," & txtIDMclr.Text & "," & txtIdCustomer.Text & ")"

            End If


            clsCom.GP_ExeSqlReader(SQL_C)

            SQL_C = ""
            SQL_C = SQL_C + "SELECT top 1 ordh_idxx FROM KKTERP.dbo.order_header order by ordh_idxx desc"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            txtID.Text = clsCom.gv_DataRdr("ordh_idxx")
            clsCom.gv_ExeSqlReaderEnd()



            With spdSizeUpdate_Sheet1
                For i = 0 To .RowCount - 1
                    If .Cells.Item(i, 0).Text <> "" Then
                        SQL_C = ""
                        SQL_C = SQL_C + "insert into KKTERP.dbo.order_detail (ordh_idxx,ordd_size,ordd_qtyx) values (" & txtID.Text & ",'" & .Cells.Item(i, 0).Text & "'," & .Cells.Item(i, 1).Text & ")"

                        clsCom.GP_ExeSqlReader(SQL_C)
                    End If
                Next


            End With
        Else
            SQL_C = ""
            SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.order_lot WHERE ordh_idxx='" & txtID.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr("qty") = 0 Then
                clsCom.gv_ExeSqlReaderEnd()
                SQL_C = ""
                SQL_C = SQL_C + "delete KKTERP.dbo.order_detail where ordh_idxx='" & txtID.Text & "'"

                clsCom.GP_ExeSqlReader(SQL_C)

                With spdSizeUpdate_Sheet1
                    For i = 0 To .RowCount - 1
                        If .Cells.Item(i, 0).Text <> "" Then
                            SQL_C = ""
                            SQL_C = SQL_C + "insert into KKTERP.dbo.order_detail (ordh_idxx,ordd_size,ordd_qtyx) values (" & txtID.Text & ",'" & .Cells.Item(i, 0).Text & "'," & .Cells.Item(i, 1).Text & ")"

                            clsCom.GP_ExeSqlReader(SQL_C)
                        End If
                    Next


                End With

            Else
                clsCom.gv_ExeSqlReaderEnd()
                MsgBox("Sudah di buat LOT Planning !!!")
                Exit Sub

            End If
        End If

        


        pnlDetailUpdate.Visible = False

        FP_LIST_SIZE(Val(txtID.Text))
        FP_LIST_HEAD()
        FP_SIZE_ORDER_COMPONENT()

    End Sub

    Private Sub btnCloseSizeUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSizeUpdate.Click
        Dim i, j As Integer

        pnlDetailUpdate.Visible = False
    End Sub

    

    Private Sub spdSize_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellDoubleClick
        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.production where prod_prnt is not null and ordh_idxx=" & txtID.Text

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            
            

            MsgBox("Tidak bisa di rubah karena sudah di print barcode")
            Exit Sub


        Else
            clsCom.gv_ExeSqlReaderEnd()

            pnlUpdateSize.Visible = True
            With spdSize_Sheet1
                txtSizeRevisi.Text = .ColumnHeader.Cells.Item(0, e.Column).Text
                txtQtyRevisi.Text = .Cells.Item(e.Row, e.Column).Text
            End With
        End If


       
    End Sub

    Private Sub btnDeleteRevisi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRevisi.Click
        SQL_C = ""
        SQL_C = SQL_C + "delete KKTERP.dbo.order_detail  where ordh_idxx= " & txtID.Text & "AND ordd_size='" & txtSizeRevisi.Text & "'"

        clsCom.GP_ExeSqlReader(SQL_C)

        FP_LIST_SIZE(Val(txtID.Text))

        FP_SIZE_ORDER_COMPONENT()

        pnlUpdateSize.Visible = False
    End Sub

    Private Sub btnSaveRevisi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveRevisi.Click
        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.dbo.order_detail where ordd_size='" & txtSizeRevisi.Text & "' and ordh_idxx=" & txtID.Text

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "update KKTERP.dbo.order_detail set ordd_qtyx=" & txtQtyRevisi.Text & "  where ordh_idxx= " & txtID.Text & "AND ordd_size='" & txtSizeRevisi.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.order_detail (ordh_idxx,ordd_size,ordd_qtyx) VALUES(" & txtID.Text & ",'" & txtSizeRevisi.Text & "'," & txtQtyRevisi.Text & " )  "

            clsCom.GP_ExeSqlReader(SQL_C)


        End If


       


        FP_LIST_SIZE(Val(txtID.Text))

        FP_SIZE_ORDER_COMPONENT()

        pnlUpdateSize.Visible = False
    End Sub

    Private Sub btnCloseRevisi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseRevisi.Click
        pnlUpdateSize.Visible = False
    End Sub

    Private Sub btnAddRevisi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRevisi.Click
        txtSizeRevisi.Enabled = True
        txtSizeRevisi.Text = ""
        txtQtyRevisi.Text = ""
        txtSizeRevisi.Focus()
    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick

    End Sub
End Class