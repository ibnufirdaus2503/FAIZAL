﻿Public Class frmHelpModelColorComplete
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_DETAIL(byval Id As Integer)
        SQL_C = ""
        SQL_C += "SELECT CUST_IDXX,CUST_NAME FROM KKTERP.DBO.CUSTOMER WHERE CODE_GCUS=" & Id

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdCustomer_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CUST_IDXX")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("CUST_NAME")

            End While


            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_HEAD()
        Dim vModel As Integer


        SQL_C = ""
        SQL_C += "SELECT mclr_idxx,modl_idxx,brand_id,customer_id,A.colr_idxx,vend_idxx," & vbLf
        SQL_C += "customer_name, brand_name, model_name, vend_name, pack_cp, isnull(colr_name,'') colr_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.model_color A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel B ON B.model_id =A.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color C ON C.colr_idxx=A.colr_idxx" & vbLf
        SQL_C += "WHERE mclr_idxx is not null and model_id is not null" & vbLf

        If txtModel.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModel.Text & "%'"
        End If

        If txtColor.Text <> "" Then
            SQL_C += "AND colr_name like '%" & txtColor.Text & "%'"
        End If

        SQL_C += "order by  model_name,colr_name asc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("brand_name")

                vModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 2).Text = vModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("customer_id")


            End While


            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()




    End Sub

    Private Sub frmHelpModelColorComplete_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_HEAD()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            '  .Help_str1 = spdHead_Sheet1.Cells.Item(e.Row, 0).Text 'Customer
            .Help_str2 = spdHead_Sheet1.Cells.Item(e.Row, 1).Text 'Brand
            .Help_str3 = spdHead_Sheet1.Cells.Item(e.Row, 2).Text 'Id Model
            .Help_str4 = spdHead_Sheet1.Cells.Item(e.Row, 3).Text 'Model
            .Help_str5 = spdHead_Sheet1.Cells.Item(e.Row, 4).Text 'Color
            .Help_str6 = spdHead_Sheet1.Cells.Item(e.Row, 5).Text 'Id Mclr

        End With

        FP_DETAIL(spdHead_Sheet1.Cells.Item(e.Row, 6).Text)
    End Sub

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
      


    End Sub

    Private Sub btnCLose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCLose.Click
        Me.Close()
    End Sub

    Private Sub spdCustomer_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdCustomer.CellClick
        With clsVAR.gv_Help(0)
            .Help_str7 = spdCustomer_Sheet1.Cells.Item(e.Row, 0).Text 'ID CUSTOMER
            .Help_str1 = spdCustomer_Sheet1.Cells.Item(e.Row, 1).Text '  CUSTOMER


        End With
        Me.Close()
    End Sub

    
End Class