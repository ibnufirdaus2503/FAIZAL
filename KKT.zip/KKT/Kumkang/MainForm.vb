﻿Imports System.Data.SqlClient
Imports Microsoft.Win32


Public Class MainForm

    Private Const REG_KEY_PATH As String = "Software\KKTERP"
    Dim sConString As String
    Dim vUser As String
    'sConString += "Provider=MSOLEDBSQL;Server=192.168.2.1;;UID=KKTI;PWD=KKTI0707;DATABASE=KKTERP"
    Dim ConnString As String = "Data Source=" & clsVAR.gv_ip_address & ";Initial Catalog=KKTERP;Persist Security Info=True;User ID=KKTI; password=KKTI0707"
    ' Dim con As New SqlConnection(ConnString)
    Private Sub cmd_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_ADD.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdInsert()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_MODIFY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_MODIFY.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdUpdate()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_DELETE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_DELETE.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdDelete()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_PRINT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_PRINT.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdPrint()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_QUERY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_QUERY.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdInquery()
        Catch ex As Exception

        End Try
    End Sub
    Public Sub HapusDariRegistry(ByVal keyPath As String, ByVal valueName As String)
        Try
            Using key As RegistryKey = Registry.CurrentUser.OpenSubKey(keyPath, True)
                If key IsNot Nothing Then
                    key.DeleteValue(valueName, False)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error menghapus registry: " & ex.Message)
        End Try
    End Sub
    Private Function GetMenuItems() As DataTable
        Dim sql As String
        '  sql = "select * from KKTERP.dbo.menuitems order by parentid,vid"
        ' sql = "select * from KKTERP.dbo.menuAkses order by parentid,vid"

        sql = "SELECT * "
        sql += "FROM "
        sql += "("
        sql += "SELECT B.* " & vbLf
        sql += "FROM KKTERP.dbo.user_akses A" & vbLf
        sql += "LEFT JOIN KKTERP.dbo.menuAkses B ON A.VID=B.VID" & vbLf
        sql += "WHERE VUSER='" & Val(clsVAR.gv_User) & "'" & vbLf
        'sql += "WHERE VUSER='1'" & vbLf
        sql += "        UNION ALL " & vbLf
        sql += "SELECT * " & vbLf
        sql += "FROM KKTERP.dbo.menuAkses A" & vbLf
        sql += "WHERE VID in " & vbLf
        sql += "			(SELECT DISTINCT ParentId" & vbLf
        sql += "			FROM KKTERP.dbo.user_akses A" & vbLf
        sql += "			LEFT JOIN KKTERP.dbo.menuAkses B ON A.VID=B.VID" & vbLf
        sql += "			WHERE VUSER='" & Val(clsVAR.gv_User) & "')" & vbLf
        '  sql += "			WHERE VUSER='1')" & vbLf


        sql += ")A"
        sql += " WHERE VID Is Not NULL "
        sql += "order by vid"


        Dim dataTable As New DataTable()

        Using con As New SqlConnection(ConnString)
            Using Command As New SqlCommand(sql, con)
                con.Open()
                Dim Adapter As New SqlDataAdapter(Command)
                Adapter.Fill(dataTable)
            End Using
        End Using

        Return dataTable
    End Function


    Private Sub CreateDynamicMenu()
        Dim MenuItems As DataTable = GetMenuItems()
        Dim menuDict As New Dictionary(Of Integer, ToolStripMenuItem)

        For Each row As DataRow In MenuItems.Rows
            Dim id As Integer = CInt(row("vid"))
            Dim parendId As Integer = CInt(row("parentid"))
            Dim MenuText As String = row("MenuText").ToString()
            Dim FormName As String = row("FormName").ToString()

            Dim menuitem As New ToolStripMenuItem(MenuText)
            menuitem.Tag = FormName
            If parendId = 0 Then
                MenuStrip1.Items.Add(menuitem)
            Else
                If menuDict.ContainsKey(parendId) Then
                    menuDict(parendId).DropDownItems.Add(menuitem)
                    AddHandler menuitem.Click, AddressOf MenuItem_CLick
                End If
            End If
            menuDict(id) = menuitem
        Next
    End Sub
    Private Sub MenuItem_CLick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim menuItems As ToolStripMenuItem = CType(sender, ToolStripMenuItem)
        Dim formName As String = CType(menuItems.Tag, String)


        If Not String.IsNullOrEmpty(formName) Then
            Dim form As Form = CType(Activator.CreateInstance(Type.GetType("Kumkang." & formName)), Form)
            form.MdiParent = Me
            form.Show()

        End If
    End Sub
    Private Function BacaDariRegistry(Of T)(ByVal keyPath As String, ByVal valueName As String, ByVal defaultValue As T) As T
        Try
            Using key As RegistryKey = Registry.CurrentUser.OpenSubKey(keyPath)
                If key IsNot Nothing Then
                    Dim value As Object = key.GetValue(valueName)
                    If value IsNot Nothing Then
                        Return CType(value, T)
                    End If
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error membaca registry: " & ex.Message)
        End Try
        Return defaultValue
    End Function

    Private Sub MainForm_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        ' HapusDariRegistry(REG_KEY_PATH, "sUserId")
    End Sub
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        ' Tambahkan label status
        Dim toolStripStatusLabel1 As New ToolStripStatusLabel()
        toolStripStatusLabel1.Text = ""
        toolStripStatusLabel1.Spring = True ' Mengisi ruang tersisa
        StatusStrip.Items.Add(toolStripStatusLabel1)


        clsVAR.gv_User = BacaDariRegistry(REG_KEY_PATH, "sUserId", "")
        Dim IDUser As New ToolStripStatusLabel()
        IDUser.Text = "User : " & clsVAR.gv_User & "    "
        StatusStrip.Items.Add(IDUser)


        ' Tambahkan label waktu
        Dim timeLabel As New ToolStripStatusLabel()
        timeLabel.Text = DateTime.Now.ToShortTimeString()
        StatusStrip.Items.Add(timeLabel)


        CreateDynamicMenu()


    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub cmd_EXIT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_EXIT.Click
        Me.Close()
    End Sub
End Class