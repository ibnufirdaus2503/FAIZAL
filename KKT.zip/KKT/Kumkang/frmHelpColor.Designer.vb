﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHelpColor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.spdHelpColor = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpColor_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnCloseColor = New System.Windows.Forms.Button
        Me.pnlHelpCustomer = New System.Windows.Forms.Panel
        Me.btnColor = New System.Windows.Forms.Button
        Me.txtColor = New System.Windows.Forms.TextBox
        CType(Me.spdHelpColor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpColor_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpCustomer.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        '
        'spdHelpColor
        '
        Me.spdHelpColor.AccessibleDescription = "spdHelpCustomer, Sheet1, Row 0, Column 0, "
        Me.spdHelpColor.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpColor.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpColor.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpColor.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdHelpColor.HorizontalScrollBar.TabIndex = 14
        Me.spdHelpColor.Location = New System.Drawing.Point(4, 48)
        Me.spdHelpColor.Name = "spdHelpColor"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer1
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer1
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdHelpColor.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdHelpColor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpColor.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpColor_Sheet1})
        Me.spdHelpColor.Size = New System.Drawing.Size(229, 363)
        Me.spdHelpColor.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpColor.TabIndex = 27
        Me.spdHelpColor.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpColor.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpColor.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdHelpColor.VerticalScrollBar.TabIndex = 15
        Me.spdHelpColor.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpColor_Sheet1
        '
        Me.spdHelpColor_Sheet1.Reset()
        Me.spdHelpColor_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpColor_Sheet1.ColumnCount = 2
        Me.spdHelpColor_Sheet1.RowCount = 1
        Me.spdHelpColor_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Id Customer"
        Me.spdHelpColor_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Color"
        Me.spdHelpColor_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpColor_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpColor_Sheet1.Columns.Get(0).Label = "Id Customer"
        Me.spdHelpColor_Sheet1.Columns.Get(0).Locked = False
        Me.spdHelpColor_Sheet1.Columns.Get(0).Visible = False
        Me.spdHelpColor_Sheet1.Columns.Get(0).Width = 56.0!
        Me.spdHelpColor_Sheet1.Columns.Get(1).Label = "Color"
        Me.spdHelpColor_Sheet1.Columns.Get(1).Width = 176.0!
        Me.spdHelpColor_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHelpColor_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpColor_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnCloseColor
        '
        Me.btnCloseColor.Location = New System.Drawing.Point(4, 413)
        Me.btnCloseColor.Name = "btnCloseColor"
        Me.btnCloseColor.Size = New System.Drawing.Size(229, 33)
        Me.btnCloseColor.TabIndex = 26
        Me.btnCloseColor.Text = "Close"
        Me.btnCloseColor.UseVisualStyleBackColor = True
        '
        'pnlHelpCustomer
        '
        Me.pnlHelpCustomer.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpCustomer.Controls.Add(Me.btnColor)
        Me.pnlHelpCustomer.Controls.Add(Me.txtColor)
        Me.pnlHelpCustomer.Location = New System.Drawing.Point(4, 2)
        Me.pnlHelpCustomer.Name = "pnlHelpCustomer"
        Me.pnlHelpCustomer.Size = New System.Drawing.Size(229, 44)
        Me.pnlHelpCustomer.TabIndex = 25
        '
        'btnColor
        '
        Me.btnColor.Location = New System.Drawing.Point(176, 13)
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(46, 24)
        Me.btnColor.TabIndex = 25
        Me.btnColor.Text = ">>"
        Me.btnColor.UseVisualStyleBackColor = True
        '
        'txtColor
        '
        Me.txtColor.Location = New System.Drawing.Point(5, 14)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(165, 20)
        Me.txtColor.TabIndex = 12
        '
        'frmHelpColor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(234, 447)
        Me.Controls.Add(Me.spdHelpColor)
        Me.Controls.Add(Me.btnCloseColor)
        Me.Controls.Add(Me.pnlHelpCustomer)
        Me.Name = "frmHelpColor"
        Me.Text = "Help Color"
        CType(Me.spdHelpColor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpColor_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpCustomer.ResumeLayout(False)
        Me.pnlHelpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdHelpColor As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpColor_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnCloseColor As System.Windows.Forms.Button
    Friend WithEvents pnlHelpCustomer As System.Windows.Forms.Panel
    Friend WithEvents btnColor As System.Windows.Forms.Button
    Friend WithEvents txtColor As System.Windows.Forms.TextBox
End Class
