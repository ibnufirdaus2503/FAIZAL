﻿Public Class frmSuratJalanWaste
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInquery()
        FP_HEAD()
    End Sub
    Public Sub cmdDelete()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.surat_jalan_wasteh  WHERE sjws_idxx=" & Val(Strings.Right(txtSJ.Text, 7)) & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "update KKTERP.dbo.waste set sjws_idxx=null  WHERE sjws_idxx=" & Val(Strings.Right(txtSJ.Text, 7)) & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_HEAD()
        FP_CLEAR()
    End Sub
    Private Sub FP_DETAIL()
        Dim vBarcode As Integer
        Dim vTotal As Double

        SQL_C = ""
        SQL_C += "SELECT  wast_idxx,A.mcom_idxx,G.codd_desc vcomp,model_name,colr_name,H.CODD_DESC vwaste,I.CODD_DESC vproc,model_id,wast_weig " & vbLf
        SQL_C += "FROM KKTERP.dbo.waste A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=G.codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_WAST' AND CODE_WAST=H.codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common I ON I.codh_flnm='CODE_PRWS' AND CODE_PRWS=I.codd_valu" & vbLf
        SQL_C += "WHERE  sjws_idxx=" & Val(Strings.Right(txtSJ.Text, 7)) & vbLf




        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            .RowCount = 0
            vTotal = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                vBarcode = clsCom.gv_DataRdr("wast_idxx")

                .Cells.Item(.RowCount - 1, 0).Text = vBarcode.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_id")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vproc")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vwaste")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("wast_weig")

            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Private Sub FP_HEAD()


        SQL_C = ""
      
        SQL_C += "select SJWS_IDXX,sjws_noxx,convert(varchar(10),sjws_date,111) tgl ,CODE_MOBL,isnull(CODD_DESC,'') CODD_DESC,A.VEND_IDXX,VEND_ADDR,VEND_NAME" & vbLf
        SQL_C += "from surat_jalan_wasteh a" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_MOBL' AND CODE_MOBL=B.codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vendor C ON C.vend_idxx=A.vend_idxx" & vbLf
        SQL_C += "WHERE SJWS_IDXX IS  NOT NULL" & vbLf

        If txtSJCari.Text <> "" Then
            SQL_C += "AND sjws_noxx like '%" & txtSJCari.Text & "%'"
        End If

    

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1


                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("sjws_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("sjws_noxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("tgl")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vend_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vend_idxx")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("CODE_MOBL")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vend_addr")
                 

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_SEND_DATA()
        Dim vBarcode As Integer
        Dim vTotal As Double

        SQL_C = ""
        SQL_C += "SELECT  wast_idxx,A.mcom_idxx,G.codd_desc vcomp,model_name,colr_name,H.CODD_DESC vwaste,I.CODD_DESC vproc,model_id,wast_weig " & vbLf
        SQL_C += "FROM KKTERP.dbo.waste A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=G.codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_WAST' AND CODE_WAST=H.codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common I ON I.codh_flnm='CODE_PRWS' AND CODE_PRWS=I.codd_valu" & vbLf
        SQL_C += "WHERE WAST_OTDT is not null AND sjws_idxx is null" & vbLf




        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            .RowCount = 0
            vTotal = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                vBarcode = clsCom.gv_DataRdr("wast_idxx")

                .Cells.Item(.RowCount - 1, 1).Text = vBarcode.ToString("D7")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_id")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vproc")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vwaste")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("wast_weig")
              
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Public Sub cmdInsert()
        FP_CLEAR()
        FP_NOSJ()
    End Sub
    Private Sub FP_NOSJ()
        Dim IdSj, vBulan, vTahun As Integer

        Dim VROMAWI As String

        vBulan = Month(Now)
        vTahun = Year(Now)

        If vBulan = 1 Then
            vRomawi = "I"
        ElseIf vBulan = 2 Then
            vRomawi = "II"
        ElseIf vBulan = 3 Then
            vRomawi = "III"
        ElseIf vBulan = 4 Then
            vRomawi = "IV"
        ElseIf vBulan = 5 Then
            vRomawi = "V"
        ElseIf vBulan = 6 Then
            vRomawi = "VI"
        ElseIf vBulan = 7 Then
            vRomawi = "VII"
        ElseIf vBulan = 8 Then
            vRomawi = "VIII"
        ElseIf vBulan = 9 Then
            vRomawi = "IX"
        ElseIf vBulan = 10 Then
            vRomawi = "X"
        ElseIf vBulan = 11 Then
            vRomawi = "XI"
        ElseIf vBulan = 12 Then
            vRomawi = "XII"
        End If




        SQL_C = ""
        SQL_C += " SELECT IDENT_CURRENT('surat_jalan_wasteh') AS LastID" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        IdSj = clsCom.gv_DataRdr("LastID") + 1
        clsCom.gv_ExeSqlReaderEnd()



        txtSJ.Text = "KKTI/WASTE/" & VROMAWI & "/" & vTahun & "/" & IdSj.ToString("D7")


    End Sub
    Private Sub FP_CLEAR()
        txtSJ.Text = ""
        dtSJ.Text = ""
        txtCustomer.Text = ""
        txtIdCustomer.Text = ""
        txtNoPlat.Text = ""
        txtJenisKendaraan.Text = ""
        txtAlamat.Text = ""

        spdDetail_Sheet1.RowCount = 0
    End Sub
    Public Sub cmdPrint()

    End Sub

    Private Sub btnKendaraan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKendaraan.Click
        frmHelpKendaraan.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            txtNoPlat.Text = .Help_str1
            txtJenisKendaraan.Text = .Help_str2

        End With



errHandle:
    End Sub

    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        pnlModel.Visible = True
        FP_SEND_DATA()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlModel.Visible = False
    End Sub

    Private Sub btnHelpCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpCustomer.Click
        frmHelpVendor.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            txtIdCustomer.Text = .Help_str1
            txtCustomer.Text = .Help_str2
            txtAlamat.Text = .Help_str3

        End With



errHandle:
    End Sub

    Private Sub btnCheckAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckAll.Click
        Dim i As Integer

        With spdModel_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = True
            Next
        End With
    End Sub

    Private Sub btnUncheckAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUncheckAll.Click
        Dim i As Integer

        With spdModel_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = False
            Next
        End With
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim i As Integer

        If txtIdCustomer.Text = "" Then
            MsgBox("Pilih Vendor dahulu")
            Exit Sub
        End If

        If txtNoPlat.Text = "" Then
            MsgBox("Pilih kendaraan dahulu")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.SURAT_JALAN_wasteh where sjws_noxx='" & txtSJ.Text & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.SURAT_JALAN_wasteh (sjws_noxx,sjws_date,CODE_MOBL,vend_idxx) values ('" & txtSJ.Text & "','" & dtSJ.Value & "','" & txtNoPlat.Text & "'," & txtIdCustomer.Text & ")"

            clsCom.GP_ExeSql(SQL_C)

            With spdModel_Sheet1
                For i = 0 To .RowCount - 1

                  

                    SQL_C = ""
                    SQL_C += "update KKTERP.dbo.waste set sjws_idxx=" & Val(Strings.Right(txtSJ.Text, 6)) & "  where wast_idxx =" & spdModel_Sheet1.Cells.Item(i, 1).Text

                    clsCom.GP_ExeSql(SQL_C)

                Next

            End With
        Else
            clsCom.gv_ExeSqlReaderEnd()

            With spdModel_Sheet1
               


                SQL_C = ""
                SQL_C += "update KKTERP.dbo.SURAT_JALAN_wasteh set sjWA_date='" & dtSJ.Text & "',vemd_idxx=" & txtIdCustomer.Text & ",CODE_MOBL='" & txtNoPlat.Text & "' WHERE sjxh_idxx=" & Val(Strings.Right(txtSJ.Text, 6))

                clsCom.GP_ExeSql(SQL_C)

              
            End With

        End If
        FP_HEAD()
        FP_DETAIL()

        pnlModel.Visible = False
    End Sub

    Private Sub frmSuratJalanWaste_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_HEAD()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        With spdHead_Sheet1.Cells
            txtSJ.Text = .Item(e.Row, 1).Text
            dtSJ.Text = .Item(e.Row, 2).Text
            txtCustomer.Text = .Item(e.Row, 3).Text
            txtIdCustomer.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text
            txtNoPlat.Text = .Item(e.Row, 5).Text
            txtJenisKendaraan.Text = .Item(e.Row, 6).Text
            txtAlamat.Text = .Item(e.Row, 7).Text
        End With

        FP_DETAIL()
    End Sub
End Class