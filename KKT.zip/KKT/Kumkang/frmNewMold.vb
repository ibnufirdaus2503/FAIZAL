﻿Public Class frmNewMold
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold As Integer
    Dim ROW As Integer
    Dim ID As Integer
    Private Sub FP_LIST_HEAD_SET_MOLD()
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT  mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM  KKTERP.dbo.mold_detail A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.group_size B ON A.mols_size=B.grop_size" & vbLf
        SQL_C += "where newh_idxx = " & txtIdHeader.Text
        SQL_C += " group by mols_size,mold_idxx" & vbLf
        SQL_C += "order by vseqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD_COMPONENT()


        SQL_C = ""
        

        SQL_C += "SELECT A.molh_idxx,molh_code,codd_desc,CODE_COMP,model_name,brand_name,modl_idxx,COUNT(mols_size) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_detail A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.mold_header B ON A.molh_idxx=B.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' AND C.codd_valu=CODE_COMP" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.vmodel D ON D.model_id=modl_idxx" & vbLf
        SQL_C += "WHERE newh_idxx =   " & txtIdHeader.Text
        SQL_C += " GROUP BY A.molh_idxx,molh_code,codd_desc,CODE_COMP,model_name,brand_name,modl_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("QTY")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Public Sub cmdInsert()
        FP_INSERT()
    End Sub
    Public Sub cmdUpdate()
        FP_MODIFY()
    End Sub
    Public Sub cmdInquery()
        FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()
        FP_DELETE()

    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()
        FP_COMBO_TYPE()
        FP_COMBO_ACTIVITY()
    End Sub


    Private Sub FP_LIST_HELP_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp,model_name,brand_name,customer_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where molh_idxx is not null " & vbLf

        If txtModelHelpCari.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModelHelpCari.Text & "%'"
        End If
        SQL_C += " order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_code")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub FP_MODIFY()
        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.mold_new_header  SET  "
        SQL_C = SQL_C + "newh_sjxx='" & txtSJ.Text & "'"
        SQL_C = SQL_C + ",newh_kntr='" & txtKontrak.Text & "'"
        SQL_C = SQL_C + ",newh_sjdt='" & dtSJ.Value & "'"
        SQL_C = SQL_C + ", newh_kndt='" & dtKontrak.Value & "'"
        SQL_C = SQL_C + ",CODE_ACTV=" & Strings.Trim(Strings.Right(cboActivity.Text, 5))
        SQL_C = SQL_C + ",CODE_TMOL=" & Strings.Trim(Strings.Right(cboType.Text, 5))
        SQL_C = SQL_C + ",newh_dlvr=" & txtIdPengirim.Text
        SQL_C = SQL_C + "WHERE newh_idxx=" & txtIdHeader.Text & vbCrLf


        clsCom.GP_ExeSql(SQL_C)

    End Sub


    Private Sub FP_DELETE()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_new_header  WHERE newh_idxx=" & txtIdHeader.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_detail  WHERE newh_idxx=" & txtIdHeader.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)


        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.mold_stock  WHERE newh_idxx=" & txtIdHeader.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_CLEAR()
        FP_LIST_HEAD()
    End Sub
    Private Sub FP_INSERT()

        FP_CLEAR()

    End Sub
    Private Sub FP_CLEAR()


        txtIdHeader.Text = ""
        txtSJ.Text = ""
        txtKontrak.Text = ""
        txtPengirim.Text = ""
        ' dtSJ.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
        ' dtKontrak.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 2).Text

        txtIdPengirim.Text = ""
        spdComponent_Sheet1.RowCount = 0
        spdDetail_Sheet1.RowCount = 0
        spdDetail_Sheet1.ColumnCount = 0

        FP_COMBO_ACTIVITY()
        FP_COMBO_TYPE()
    End Sub
    Private Sub FP_LIST_SET_MOLD()
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT mols_size,mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_detail A" & vbLf
        SQL_C += "where newh_idxx = " & txtIdHeader.Text & " And molh_idxx = " & code_mold & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY mols_size,mold_idxx" & vbLf
        SQL_C += "ORDER BY vseqn,mold_idxx"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_FILL()




        With spdHead_Sheet1.Cells


            txtIdHeader.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 10).Text
            txtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text
            txtKontrak.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 2).Text
            txtPengirim.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text
            dtSJ.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
            dtKontrak.Value = .Item(spdHead_Sheet1.ActiveRowIndex, 2).Text
            cboType.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & Space(100) & .Item(spdHead_Sheet1.ActiveRowIndex, 8).Text
            cboActivity.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 7).Text & Space(100) & .Item(spdHead_Sheet1.ActiveRowIndex, 10).Text
            txtIdPengirim.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 8).Text




        End With


    End Sub

    Private Sub FP_LIST_DETAIL()
        Dim Old_Var As String
        Dim i As Integer

        SQL_C = ""
        SQL_C += "SELECT A.mols_size,mols_seqn,mold_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_detail B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "WHERE newh_idxx=" & txtIdHeader.Text & "" & vbLf
        SQL_C += " ORDER BY mols_seqn"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            Old_Var = ""
            i = 0
            While clsCom.gv_DataRdr.Read

                If Old_Var <> clsCom.gv_DataRdr("mols_seqn") Then
                    '  .Cells.Item(i,  clsCom.gv_DataRdr("mols_seqn")).Value ) = clsCom.gv_DataRdr("TGL_SJ"))
                Else

                End If

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("TGL_SJ")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("newh_sjxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("TGL_KONTRAK")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("newh_kntr")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vProduct")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("molh_code")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEADER_SIZE()
        SQL_C = ""
        SQL_C += "SELECT mols_size,mols_cavi FROM KKTERP.dbo.mold_size where molh_idxx=" & code_mold & " order by mols_seqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpSize_Sheet1
            .ColumnCount = 0

            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1
                .RowCount = 20
                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_SIZE()
        SQL_C = ""
        SQL_C += "SELECT mols_size,mols_cavi FROM KKTERP.dbo.mold_size where molh_idxx=" & code_mold & " order by mols_seqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpSize_Sheet1
            .ColumnCount = 0

            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1
                .RowCount = 20
                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD()




        SQL_C = ""
        SQL_C += "select newh_idxx,CODE_ACTV,CODE_TMOL,convert(varchar(10),A.newh_sjdt,111) newh_sjdt ,convert(varchar(10),A.newh_kndt,111) newh_kndt,newh_sjxx,newh_kntr,A.newh_dlvr,B.codd_desc ACTV,C.codd_desc VTYPE,E.vend_name  " & vbLf
        SQL_C += "from KKTERP.dbo.mold_new_header A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_ACTV' AND CODE_ACTV=B.codd_valu" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_TMOL' AND CODE_TMOL=C.codd_valu" & vbLf

        SQL_C += "INNER JOIN (" & vbLf
        SQL_C += "				SELECT cust_idxx newh_dlvr,cust_name vend_name,'CUST' newh_sdlv" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer " & vbLf
        SQL_C += "        UNION ALL " & vbLf
        SQL_C += "				SELECT vend_idxx,vend_name,'VEND'" & vbLf
        SQL_C += "FROM KKTERP.dbo.vendor " & vbLf
        SQL_C += "		) E ON  E.newh_dlvr=a.newh_dlvr and A.newh_sdlv=E.newh_sdlv" & vbLf
        SQL_C += "WHERE newh_idxx is not null" & vbLf

        If txtCustomerCari.Text <> "" Then
            SQL_C += "AND customer_name like '%" & txtCustomerCari.Text & "%'" & vbLf
        End If

        If txtMoldShopCari.Text <> "" Then
            SQL_C += "AND D.vend_name like '%" & txtMoldShopCari.Text & "%'" & vbLf
        End If

        If txtSJCari.Text <> "" Then
            SQL_C += "AND newh_sjxx like '%" & txtSJCari.Text & "%'" & vbLf
        End If

        If txtKontrakCari.Text <> "" Then
            SQL_C += "AND newh_kntr like '%" & txtKontrakCari.Text & "%'" & vbLf
        End If

        If txtModelCari.Text <> "" Then
            SQL_C += "AND model_name like '%" & txtModelCari.Text & "%'" & vbLf
        End If




        SQL_C += "order by newh_sjdt desc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("newh_sjdt")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("newh_sjxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("newh_kndt")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("newh_kntr")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vend_name")

                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("VTYPE")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("ACTV")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("newh_dlvr")

                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("CODE_TMOL")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("CODE_ACTV")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("newh_idxx")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_TYPE()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_TMOL'" & vbLf
        SQL_C += "ORDER BY codd_desc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboType
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_ACTIVITY()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_ACTV'" & vbLf
        SQL_C += "ORDER BY codd_desc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboActivity
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_INSERT_HEADER()


        SQL_C = ""
        SQL_C += "INSERT INTO KKTERP.dbo.mold_new_header(newh_sjxx,newh_sjdt,newh_kntr,newh_kndt,CODE_ACTV,CODE_TMOL,newh_dlvr,newh_sdlv) VALUES ('" & txtSJ.Text & "','" & dtSJ.Value & "','" & txtKontrak.Text & "','" & dtKontrak.Value & "'," & Strings.Trim(Strings.Right(cboActivity.Text, 3)) & "," & Strings.Trim(Strings.Right(cboType.Text, 3)) & "," & txtIdPengirim.Text & ",'" & txtCodeVendorCustomer.Text & "')"

        clsCom.GP_ExeSql(SQL_C)


        SQL_C = ""
        SQL_C += "SELECT top 1 newh_idxx FROM KKTERP.dbo.mold_new_header  order by newh_idxx desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        txtIdHeader.Text = clsCom.gv_DataRdr("newh_idxx")

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    'Private Sub FP_COMBO_SIZE()

    '    SQL_C = ""
    '    SQL_C += "SELECT mols_size,mols_cavi FROM KKTERP.dbo.mold_size where molh_idxx=" & txtIdMold.Text & " order by mols_size" & vbLf

    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With cboSize
    '        .Items.Clear()
    '        While clsCom.gv_DataRdr.Read
    '            .Items.Add(clsCom.gv_DataRdr("mols_size"))
    '        End While


    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()
    'End Sub
    Private Sub frmNewMold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        FP_INIT()
    End Sub



    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPengirim.Click
        frmHelpDelivery.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtPengirim.Text = .Help_str2
            txtIdPengirim.Text = .Help_str1
            txtCodeVendorCustomer.Text = .Help_str3



        End With

errHandle:
    End Sub




    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        FP_FILL()
        FP_LIST_HEAD_COMPONENT()
    End Sub

    Private Sub spdDetail_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellClick

    End Sub

    Private Sub spdDetail_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellDoubleClick
        If spdDetail_Sheet1.Cells.Item(e.Row, e.Column).Text = "" Then
            Exit Sub
        Else
            pnlUpdateSize.Visible = True
            txtAlias.Text = spdDetail_Sheet1.Cells.Item(e.Row, e.Column).Text
            txtSetMold.Text = spdDetail_Sheet1.Cells.Item(e.Row, e.Column).Text
            lblSize.Text = spdDetail_Sheet1.ColumnHeader.Cells.Item(0, e.Column).Text
        End If
    End Sub

    Private Sub btnSaveSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSet.Click

        If txtAlias.Text = "" Or txtSetMold.Text = "" Or lblSize.Text = "" Then
            MsgBox("Check data yang mau di update")
            Exit Sub

        End If
        SQL_C = ""
        SQL_C += "UPDATE KKTERP.dbo.mold_detail set mold_idxx='" & txtSetMold.Text & "' WHERE mold_idxx='" & txtAlias.Text & "' AND molh_idxx='" & code_mold & "' and mols_size='" & lblSize.Text & "' and newh_idxx=" & txtIdHeader.Text

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "UPDATE KKTERP.dbo.mold_stock set mold_idxx='" & txtSetMold.Text & "' WHERE mold_idxx='" & txtAlias.Text & "' AND molh_idxx='" & code_mold & "' and mols_size='" & lblSize.Text & "' and newh_idxx=" & txtIdHeader.Text

        clsCom.GP_ExeSql(SQL_C)

        pnlUpdateSize.Visible = False
        FP_LIST_SET_MOLD()
    End Sub

    Private Sub btnDeleteSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteSet.Click
        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.mold_detail  WHERE mold_idxx='" & txtAlias.Text & "' AND molh_idxx='" & code_mold & "' and mols_size='" & lblSize.Text & "' and newh_idxx=" & txtIdHeader.Text

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.mold_stock  WHERE mold_idxx='" & txtAlias.Text & "' AND molh_idxx='" & code_mold & "' and mols_size='" & lblSize.Text & "' and newh_idxx=" & txtIdHeader.Text

        clsCom.GP_ExeSql(SQL_C)

        pnlUpdateSize.Visible = False
        FP_LIST_SET_MOLD()
    End Sub

    Private Sub btnCloseSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSet.Click
        pnlUpdateSize.Visible = False
    End Sub

    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariModel.Click
        FP_LIST_HELP_COMPONENT()
    End Sub

    Private Sub btnHelpUpdateSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpUpdateSize.Click
        If txtSJ.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        pnlUpdateMold.Visible = True
    End Sub

    Private Sub spdHelpComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpComponent.CellClick

        code_mold = spdHelpComponent_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_HEADER_SIZE()
    End Sub

    Private Sub btnSave_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click


        If txtIdHeader.Text = "" Then
            FP_INSERT_HEADER()
        End If


        Dim i, j As Integer
        With spdHelpSize_Sheet1
            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    If .Cells.Item(j, i).Text = "" Then
                        Exit For
                    Else
                        SQL_C = ""

                        SQL_C += "insert into KKTERP.dbo.mold_detail (molh_idxx,mols_size,mold_idxx,newh_idxx) values (" & code_mold & ",'" & .ColumnHeader.Cells.Item(0, i).Text & "','" & .Cells.Item(j, i).Text & "'," & txtIdHeader.Text & ") "

                        clsCom.GP_ExeSql(SQL_C)

                        SQL_C = ""

                        SQL_C += "INSERT INTO KKTERP.dbo.mold_stock (molh_idxx,mold_idxx,mols_size,CODE_INOT,CODE_MSTS,CODE_BUIL,newh_idxx,stck_inst,CODE_MOTR) VALUES (" & code_mold & ",'" & .Cells.Item(j, i).Text & "','" & .ColumnHeader.Cells.Item(0, i).Text & "',1,1,'8A'," & txtIdHeader.Text & ",GETDATE()," & Strings.Trim(Strings.Right(cboType.Text, 3)) & ")"

                        clsCom.GP_ExeSql(SQL_C)
                    End If
                Next
            Next

        End With


        FP_LIST_HEAD()
        FP_LIST_SET_MOLD()
    End Sub


    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick


    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlUpdateMold.Visible = False
    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        FP_LIST_HEAD_SET_MOLD()
    End Sub
End Class