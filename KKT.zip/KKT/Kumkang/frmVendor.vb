﻿Public Class frmVendor
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInsert()
     
        FP_CLEAR()

    End Sub
    Public Sub cmdInquery()
        FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.vendor  WHERE vend_idxx=" & txtIdVendor.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_HEAD()
        FP_CLEAR()
    End Sub
    Public Sub cmdUpdate()
        If txtIdVendor.Text = "" Then
            Call FP_INSERT()
        Else
            FP_MODIFY()
        End If

        FP_LIST_HEAD()
        FP_CLEAR()
    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()
        Call FP_COMBO_PROPINSI()
    End Sub
    Private Sub FP_CLEAR()
        txtFull.Text = ""
        txtShort.Text = ""
        txtContactPerson.Text = ""
        txtTLP.Text = ""
        txtHP.Text = ""
        txtAddress.Text = ""
        txtIdVendor.Text = ""
        txtKodePos.Text = ""
        chkBerikat.Checked = False
        chkMoldshop.Checked = False
        txtBCNo.Text = ""

    End Sub
    Private Sub FP_MODIFY()
      

        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.vendor SET" & vbLf
        SQL_C = SQL_C + "vend_name='" & txtFull.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_shrt='" & txtShort.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_zipc='" & txtKodePos.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_cont='" & txtContactPerson.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_tlpx='" & txtTLP.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_hpxx='" & txtHP.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_addr='" & txtAddress.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_bcno='" & txtBCNo.Text & "'" & vbLf
        SQL_C = SQL_C + ",vend_bcxx=" & IIf(chkBerikat.Checked = True, 1, 0) & "" & vbLf
        SQL_C = SQL_C + ",vend_mshp=" & IIf(chkMoldshop.Checked = True, 1, 0) & "" & vbLf
        SQL_C = SQL_C + ",vend_impr=" & IIf(optImpor.Checked = True, 1, 0) & "" & vbLf
        SQL_C = SQL_C + ",vend_corp=" & IIf(optCorporation.Checked = True, 1, 0) & "" & vbLf
        SQL_C = SQL_C + ",CODE_PROP='" & Strings.Trim(Strings.Right(cboCity.Text, 3)) & "'" & vbLf
        SQL_C = SQL_C + "WHERE vend_idxx=" & txtIdVendor.Text

        clsCom.GP_ExeSql(SQL_C)



    End Sub
    Private Sub FP_INSERT()


    
        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.vendor (vend_name,vend_shrt,vend_cont,vend_tlpx,vend_hpxx,vend_addr,CODE_PROP,vend_zipc,vend_impr,vend_corp) VALUES ('" & txtFull.Text & "','" & txtShort.Text & "','" & txtContactPerson.Text & "','" & txtTLP.Text & "','" & txtHP.Text & "','" & txtAddress.Text & "','" & Strings.Trim(Strings.Right(cboCity.Text, 3)) & "','" & txtKodePos.Text & "'," & IIf(optImpor.Checked = True, 1, 0) & "," & IIf(optCorporation.Checked = True, 1, 0) & ")"

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_DELETE()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.vendor WHERE vend_idxx=" & txtIdVendor.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_LIST_HEAD()

        

        SQL_C = ""
        SQL_C += "SELECT vend_idxx,vend_name,vend_shrt,vend_cont,vend_tlpx,vend_hpxx,vend_addr,CODE_PROP,codd_desc,isnull(vend_zipc,'') vend_zipc,isnull(vend_bcxx,0) vend_bcxx,isnull(vend_bcno,'') vend_bcno,isnull(vend_mshp,0) vend_mshp,isnull(vend_impr,0) vend_impr,isnull(vend_corp,0) vend_corp" & vbLf
        SQL_C += "FROM KKTERP.dbo.VENDOR A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_PROP' AND A.CODE_PROP=B.codd_Valu" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("vend_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("vend_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vend_shrt")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vend_cont")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vend_tlpx")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vend_hpxx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vend_zipc")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("vend_addr")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("CODE_PROP")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("vend_bcxx")
                .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("vend_bcno")
                .Cells.Item(.RowCount - 1, 13).Text = clsCom.gv_DataRdr("vend_mshp")
                .Cells.Item(.RowCount - 1, 14).Text = clsCom.gv_DataRdr("vend_impr")
                .Cells.Item(.RowCount - 1, 15).Text = clsCom.gv_DataRdr("vend_corp")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_FILL(ByVal vRow As Integer)
        With spdHead_Sheet1.Cells
            txtIdVendor.Text = spdHead.ActiveSheet.Cells(vRow, 0).Value
            txtFull.Text = spdHead.ActiveSheet.Cells(vRow, 1).Value
            txtShort.Text = spdHead.ActiveSheet.Cells(vRow, 2).Value
            txtContactPerson.Text = spdHead.ActiveSheet.Cells(vRow, 3).Value
            txtTLP.Text = spdHead.ActiveSheet.Cells(vRow, 4).Value
            txtHP.Text = spdHead.ActiveSheet.Cells(vRow, 5).Value
            txtKodePos.Text = spdHead.ActiveSheet.Cells(vRow, 7).Value
            txtAddress.Text = spdHead.ActiveSheet.Cells(vRow, 8).Value
            '.Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("CODD_VALU"))
            cboCity.Text = spdHead.ActiveSheet.Cells(vRow, 6).Value & Space(100) & spdHead.ActiveSheet.Cells(vRow, 9).Value
            chkMoldshop.Checked = IIf(spdHead.ActiveSheet.Cells(vRow, 13).Value = 1, True, False)

            If spdHead.ActiveSheet.Cells(vRow, 14).Value = 1 Then
                optImpor.Checked = True
                optLocal.Checked = False
            Else
                optImpor.Checked = False
                optLocal.Checked = True
            End If

            If spdHead.ActiveSheet.Cells(vRow, 15).Value = 1 Then
                optCorporation.Checked = True
                optIndividual.Checked = False
            Else
                optCorporation.Checked = False
                optIndividual.Checked = True
            End If

         

        End With


    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        Call FP_FILL(e.Row)
    End Sub
    Private Sub FP_COMBO_PROPINSI()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common" & vbLf
        SQL_C += "WHERE codh_flnm='CODE_PROP'"
        SQL_C += "order by codd_desc asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)


        With cboCity
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("CODD_VALU"))
            End While


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmVendor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_INIT()
    End Sub
End Class