﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenu))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip
        Me.mnuMaster = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuCommonCode = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterVendorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SetLineProductionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSetModel = New System.Windows.Forms.ToolStripMenuItem
        Me.SetColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SetCalenderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupSizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterMaterialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BuildOfMaterialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SampleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UserAccessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterMoldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuTransaksi = New System.Windows.Forms.ToolStripMenuItem
        Me.OrderCostingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PurchasingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryMaterialByModelAndColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryPOVendorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreateBarcodeMaterialINToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BalanceMaterialByPOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MaterialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MaterialInToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FormulaMaterialByModelAndColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntrySPKToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryProductionMaterialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryReturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClosingPOBySuratJalanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MoldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SettingMoldSizeByModelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewMoldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MoldTransferByBuildingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MoldOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MoldStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MoldStockToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SettingMoldProductionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.SimulasiProduksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryPOAdditionalReturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntrySPKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreateBarcodeCMPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntrySuratJalanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClosingPOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EntryReturPOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PeniliaianKinerjaKaryawanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClosingPOBySuratJalanToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportProductionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.InsertToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.WasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportWasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SuratJalanWasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip = New System.Windows.Forms.ToolStrip
        Me.cmd_ADD = New System.Windows.Forms.ToolStripButton
        Me.cmd_MODIFY = New System.Windows.Forms.ToolStripButton
        Me.cmd_DELETE = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_QUERY = New System.Windows.Forms.ToolStripButton
        Me.cmd_PRINT = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_SHEETADD = New System.Windows.Forms.ToolStripButton
        Me.cmd_SHEETDEL = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_EXIT = New System.Windows.Forms.ToolStripButton
        Me.StatusStrip = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MenuStrip.SuspendLayout()
        Me.ToolStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaster, Me.mnuTransaksi, Me.PurchasingToolStripMenuItem, Me.MaterialToolStripMenuItem, Me.MoldToolStripMenuItem, Me.ToolStripMenuItem3, Me.ReportToolStripMenuItem, Me.ControlToolStripMenuItem, Me.WasteToolStripMenuItem, Me.ReportToolStripMenuItem1})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(1027, 24)
        Me.MenuStrip.TabIndex = 6
        Me.MenuStrip.Text = "MenuStrip1"
        '
        'mnuMaster
        '
        Me.mnuMaster.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCommonCode, Me.CustomerToolStripMenuItem, Me.MasterVendorToolStripMenuItem, Me.SetLineProductionToolStripMenuItem, Me.mnuSetModel, Me.SetColorToolStripMenuItem, Me.SetCalenderToolStripMenuItem, Me.GroupSizeToolStripMenuItem, Me.MasterMaterialToolStripMenuItem, Me.BuildOfMaterialToolStripMenuItem, Me.SampleToolStripMenuItem, Me.UserAccessToolStripMenuItem, Me.MasterMoldToolStripMenuItem})
        Me.mnuMaster.Name = "mnuMaster"
        Me.mnuMaster.Size = New System.Drawing.Size(55, 20)
        Me.mnuMaster.Text = "&Master"
        '
        'mnuCommonCode
        '
        Me.mnuCommonCode.Name = "mnuCommonCode"
        Me.mnuCommonCode.Size = New System.Drawing.Size(172, 22)
        Me.mnuCommonCode.Text = "Common Code"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.CustomerToolStripMenuItem.Text = "Master Customer"
        '
        'MasterVendorToolStripMenuItem
        '
        Me.MasterVendorToolStripMenuItem.Name = "MasterVendorToolStripMenuItem"
        Me.MasterVendorToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.MasterVendorToolStripMenuItem.Text = "Master Vendor"
        '
        'SetLineProductionToolStripMenuItem
        '
        Me.SetLineProductionToolStripMenuItem.Name = "SetLineProductionToolStripMenuItem"
        Me.SetLineProductionToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.SetLineProductionToolStripMenuItem.Text = "Master Room/Line"
        '
        'mnuSetModel
        '
        Me.mnuSetModel.Name = "mnuSetModel"
        Me.mnuSetModel.Size = New System.Drawing.Size(172, 22)
        Me.mnuSetModel.Text = "Master Model"
        '
        'SetColorToolStripMenuItem
        '
        Me.SetColorToolStripMenuItem.Name = "SetColorToolStripMenuItem"
        Me.SetColorToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.SetColorToolStripMenuItem.Text = "Master Color"
        '
        'SetCalenderToolStripMenuItem
        '
        Me.SetCalenderToolStripMenuItem.Name = "SetCalenderToolStripMenuItem"
        Me.SetCalenderToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.SetCalenderToolStripMenuItem.Text = "Master Calender"
        '
        'GroupSizeToolStripMenuItem
        '
        Me.GroupSizeToolStripMenuItem.Name = "GroupSizeToolStripMenuItem"
        Me.GroupSizeToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.GroupSizeToolStripMenuItem.Text = "Group Size"
        '
        'MasterMaterialToolStripMenuItem
        '
        Me.MasterMaterialToolStripMenuItem.Name = "MasterMaterialToolStripMenuItem"
        Me.MasterMaterialToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.MasterMaterialToolStripMenuItem.Text = "Master Material"
        '
        'BuildOfMaterialToolStripMenuItem
        '
        Me.BuildOfMaterialToolStripMenuItem.Name = "BuildOfMaterialToolStripMenuItem"
        Me.BuildOfMaterialToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.BuildOfMaterialToolStripMenuItem.Text = "Build Of Material"
        '
        'SampleToolStripMenuItem
        '
        Me.SampleToolStripMenuItem.Name = "SampleToolStripMenuItem"
        Me.SampleToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.SampleToolStripMenuItem.Text = "sample"
        '
        'UserAccessToolStripMenuItem
        '
        Me.UserAccessToolStripMenuItem.Name = "UserAccessToolStripMenuItem"
        Me.UserAccessToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.UserAccessToolStripMenuItem.Text = "User Access"
        '
        'MasterMoldToolStripMenuItem
        '
        Me.MasterMoldToolStripMenuItem.Name = "MasterMoldToolStripMenuItem"
        Me.MasterMoldToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.MasterMoldToolStripMenuItem.Text = "Master Mold"
        '
        'mnuTransaksi
        '
        Me.mnuTransaksi.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderCostingToolStripMenuItem, Me.ToolStripMenuItem1, Me.PToolStripMenuItem})
        Me.mnuTransaksi.Name = "mnuTransaksi"
        Me.mnuTransaksi.Size = New System.Drawing.Size(73, 20)
        Me.mnuTransaksi.Text = "Marketing"
        '
        'OrderCostingToolStripMenuItem
        '
        Me.OrderCostingToolStripMenuItem.Name = "OrderCostingToolStripMenuItem"
        Me.OrderCostingToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.OrderCostingToolStripMenuItem.Text = "Order Costing"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(175, 22)
        Me.ToolStripMenuItem1.Text = "Entry PO Customer"
        '
        'PToolStripMenuItem
        '
        Me.PToolStripMenuItem.Name = "PToolStripMenuItem"
        Me.PToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.PToolStripMenuItem.Text = "Priority PO"
        '
        'PurchasingToolStripMenuItem
        '
        Me.PurchasingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EntryMaterialByModelAndColorToolStripMenuItem, Me.EntryPOVendorToolStripMenuItem, Me.CreateBarcodeMaterialINToolStripMenuItem, Me.BalanceMaterialByPOToolStripMenuItem})
        Me.PurchasingToolStripMenuItem.Name = "PurchasingToolStripMenuItem"
        Me.PurchasingToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.PurchasingToolStripMenuItem.Text = "Purchasing"
        '
        'EntryMaterialByModelAndColorToolStripMenuItem
        '
        Me.EntryMaterialByModelAndColorToolStripMenuItem.Name = "EntryMaterialByModelAndColorToolStripMenuItem"
        Me.EntryMaterialByModelAndColorToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.EntryMaterialByModelAndColorToolStripMenuItem.Text = "Formula Material By Model And Color"
        '
        'EntryPOVendorToolStripMenuItem
        '
        Me.EntryPOVendorToolStripMenuItem.Name = "EntryPOVendorToolStripMenuItem"
        Me.EntryPOVendorToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.EntryPOVendorToolStripMenuItem.Text = "Entry PO Vendor"
        '
        'CreateBarcodeMaterialINToolStripMenuItem
        '
        Me.CreateBarcodeMaterialINToolStripMenuItem.Name = "CreateBarcodeMaterialINToolStripMenuItem"
        Me.CreateBarcodeMaterialINToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.CreateBarcodeMaterialINToolStripMenuItem.Text = "Create Barcode Material IN"
        '
        'BalanceMaterialByPOToolStripMenuItem
        '
        Me.BalanceMaterialByPOToolStripMenuItem.Name = "BalanceMaterialByPOToolStripMenuItem"
        Me.BalanceMaterialByPOToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.BalanceMaterialByPOToolStripMenuItem.Text = "Balance Material By PO"
        '
        'MaterialToolStripMenuItem
        '
        Me.MaterialToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MaterialInToolStripMenuItem, Me.FormulaMaterialByModelAndColorToolStripMenuItem, Me.EntrySPKToolStripMenuItem1, Me.EntryProductionMaterialToolStripMenuItem, Me.EntryReturToolStripMenuItem, Me.ClosingPOBySuratJalanToolStripMenuItem})
        Me.MaterialToolStripMenuItem.Name = "MaterialToolStripMenuItem"
        Me.MaterialToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.MaterialToolStripMenuItem.Text = "Material"
        '
        'MaterialInToolStripMenuItem
        '
        Me.MaterialInToolStripMenuItem.Name = "MaterialInToolStripMenuItem"
        Me.MaterialInToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.MaterialInToolStripMenuItem.Text = "Material In"
        '
        'FormulaMaterialByModelAndColorToolStripMenuItem
        '
        Me.FormulaMaterialByModelAndColorToolStripMenuItem.Name = "FormulaMaterialByModelAndColorToolStripMenuItem"
        Me.FormulaMaterialByModelAndColorToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.FormulaMaterialByModelAndColorToolStripMenuItem.Text = "Formula Material By Model And Color"
        '
        'EntrySPKToolStripMenuItem1
        '
        Me.EntrySPKToolStripMenuItem1.Name = "EntrySPKToolStripMenuItem1"
        Me.EntrySPKToolStripMenuItem1.Size = New System.Drawing.Size(274, 22)
        Me.EntrySPKToolStripMenuItem1.Text = "Entry SPK"
        '
        'EntryProductionMaterialToolStripMenuItem
        '
        Me.EntryProductionMaterialToolStripMenuItem.Name = "EntryProductionMaterialToolStripMenuItem"
        Me.EntryProductionMaterialToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.EntryProductionMaterialToolStripMenuItem.Text = "Entry Production Material"
        '
        'EntryReturToolStripMenuItem
        '
        Me.EntryReturToolStripMenuItem.Name = "EntryReturToolStripMenuItem"
        Me.EntryReturToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.EntryReturToolStripMenuItem.Text = "Entry Surat Jalan Material Out"
        '
        'ClosingPOBySuratJalanToolStripMenuItem
        '
        Me.ClosingPOBySuratJalanToolStripMenuItem.Name = "ClosingPOBySuratJalanToolStripMenuItem"
        Me.ClosingPOBySuratJalanToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.ClosingPOBySuratJalanToolStripMenuItem.Text = "Closing PO by Surat Jalan"
        '
        'MoldToolStripMenuItem
        '
        Me.MoldToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingMoldSizeByModelToolStripMenuItem, Me.NewMoldToolStripMenuItem, Me.MoldTransferByBuildingToolStripMenuItem, Me.MoldOutToolStripMenuItem, Me.MoldStockToolStripMenuItem, Me.MoldStockToolStripMenuItem1, Me.SettingMoldProductionToolStripMenuItem})
        Me.MoldToolStripMenuItem.Name = "MoldToolStripMenuItem"
        Me.MoldToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.MoldToolStripMenuItem.Text = "Mold"
        '
        'SettingMoldSizeByModelToolStripMenuItem
        '
        Me.SettingMoldSizeByModelToolStripMenuItem.Name = "SettingMoldSizeByModelToolStripMenuItem"
        Me.SettingMoldSizeByModelToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.SettingMoldSizeByModelToolStripMenuItem.Text = "Setting Mold Size By Model"
        '
        'NewMoldToolStripMenuItem
        '
        Me.NewMoldToolStripMenuItem.Name = "NewMoldToolStripMenuItem"
        Me.NewMoldToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.NewMoldToolStripMenuItem.Text = "New Mold"
        '
        'MoldTransferByBuildingToolStripMenuItem
        '
        Me.MoldTransferByBuildingToolStripMenuItem.Name = "MoldTransferByBuildingToolStripMenuItem"
        Me.MoldTransferByBuildingToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.MoldTransferByBuildingToolStripMenuItem.Text = "Mold Transfer By Building"
        '
        'MoldOutToolStripMenuItem
        '
        Me.MoldOutToolStripMenuItem.Name = "MoldOutToolStripMenuItem"
        Me.MoldOutToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.MoldOutToolStripMenuItem.Text = "Mold Out"
        '
        'MoldStockToolStripMenuItem
        '
        Me.MoldStockToolStripMenuItem.Name = "MoldStockToolStripMenuItem"
        Me.MoldStockToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.MoldStockToolStripMenuItem.Text = "Mold In"
        '
        'MoldStockToolStripMenuItem1
        '
        Me.MoldStockToolStripMenuItem1.Name = "MoldStockToolStripMenuItem1"
        Me.MoldStockToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.MoldStockToolStripMenuItem1.Text = "Mold Stock"
        '
        'SettingMoldProductionToolStripMenuItem
        '
        Me.SettingMoldProductionToolStripMenuItem.Name = "SettingMoldProductionToolStripMenuItem"
        Me.SettingMoldProductionToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.SettingMoldProductionToolStripMenuItem.Text = "Setting Mold Production"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SimulasiProduksiToolStripMenuItem, Me.ToolStripMenuItem4, Me.EntryPOAdditionalReturToolStripMenuItem, Me.EntrySPKToolStripMenuItem, Me.CreateBarcodeCMPToolStripMenuItem, Me.EntrySuratJalanToolStripMenuItem, Me.ClosingPOToolStripMenuItem, Me.EntryReturPOToolStripMenuItem})
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(66, 20)
        Me.ToolStripMenuItem3.Text = "Planning"
        '
        'SimulasiProduksiToolStripMenuItem
        '
        Me.SimulasiProduksiToolStripMenuItem.Name = "SimulasiProduksiToolStripMenuItem"
        Me.SimulasiProduksiToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.SimulasiProduksiToolStripMenuItem.Text = "Simulasi Produksi"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(209, 22)
        Me.ToolStripMenuItem4.Text = "Mapping Order"
        '
        'EntryPOAdditionalReturToolStripMenuItem
        '
        Me.EntryPOAdditionalReturToolStripMenuItem.Name = "EntryPOAdditionalReturToolStripMenuItem"
        Me.EntryPOAdditionalReturToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.EntryPOAdditionalReturToolStripMenuItem.Text = "Entry PO Additional Retur"
        '
        'EntrySPKToolStripMenuItem
        '
        Me.EntrySPKToolStripMenuItem.Name = "EntrySPKToolStripMenuItem"
        Me.EntrySPKToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.EntrySPKToolStripMenuItem.Text = "Entry SPK"
        '
        'CreateBarcodeCMPToolStripMenuItem
        '
        Me.CreateBarcodeCMPToolStripMenuItem.Name = "CreateBarcodeCMPToolStripMenuItem"
        Me.CreateBarcodeCMPToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.CreateBarcodeCMPToolStripMenuItem.Text = "Create Barcode CMP"
        '
        'EntrySuratJalanToolStripMenuItem
        '
        Me.EntrySuratJalanToolStripMenuItem.Name = "EntrySuratJalanToolStripMenuItem"
        Me.EntrySuratJalanToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.EntrySuratJalanToolStripMenuItem.Text = "Entry Surat Jalan"
        '
        'ClosingPOToolStripMenuItem
        '
        Me.ClosingPOToolStripMenuItem.Name = "ClosingPOToolStripMenuItem"
        Me.ClosingPOToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.ClosingPOToolStripMenuItem.Text = "Closing PO"
        '
        'EntryReturPOToolStripMenuItem
        '
        Me.EntryReturPOToolStripMenuItem.Name = "EntryReturPOToolStripMenuItem"
        Me.EntryReturPOToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.EntryReturPOToolStripMenuItem.Text = "Entry Retur PO"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PeniliaianKinerjaKaryawanToolStripMenuItem, Me.ClosingPOBySuratJalanToolStripMenuItem1, Me.ReportProductionToolStripMenuItem})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.ReportToolStripMenuItem.Text = "Production"
        '
        'PeniliaianKinerjaKaryawanToolStripMenuItem
        '
        Me.PeniliaianKinerjaKaryawanToolStripMenuItem.Name = "PeniliaianKinerjaKaryawanToolStripMenuItem"
        Me.PeniliaianKinerjaKaryawanToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.PeniliaianKinerjaKaryawanToolStripMenuItem.Text = "Entry Production CP"
        '
        'ClosingPOBySuratJalanToolStripMenuItem1
        '
        Me.ClosingPOBySuratJalanToolStripMenuItem1.Name = "ClosingPOBySuratJalanToolStripMenuItem1"
        Me.ClosingPOBySuratJalanToolStripMenuItem1.Size = New System.Drawing.Size(210, 22)
        Me.ClosingPOBySuratJalanToolStripMenuItem1.Text = "Closing PO By Surat Jalan"
        '
        'ReportProductionToolStripMenuItem
        '
        Me.ReportProductionToolStripMenuItem.Name = "ReportProductionToolStripMenuItem"
        Me.ReportProductionToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.ReportProductionToolStripMenuItem.Text = "Report Production By Day"
        '
        'ControlToolStripMenuItem
        '
        Me.ControlToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveToolStripMenuItem1, Me.InsertToolStripMenuItem1})
        Me.ControlToolStripMenuItem.Name = "ControlToolStripMenuItem"
        Me.ControlToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.ControlToolStripMenuItem.Text = "Warehouse"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.SaveToolStripMenuItem1.Text = "Save"
        '
        'InsertToolStripMenuItem1
        '
        Me.InsertToolStripMenuItem1.Name = "InsertToolStripMenuItem1"
        Me.InsertToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.InsertToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.InsertToolStripMenuItem1.Text = "Insert"
        '
        'WasteToolStripMenuItem
        '
        Me.WasteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReportWasteToolStripMenuItem, Me.SuratJalanWasteToolStripMenuItem})
        Me.WasteToolStripMenuItem.Name = "WasteToolStripMenuItem"
        Me.WasteToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.WasteToolStripMenuItem.Text = "Waste"
        '
        'ReportWasteToolStripMenuItem
        '
        Me.ReportWasteToolStripMenuItem.Name = "ReportWasteToolStripMenuItem"
        Me.ReportWasteToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.ReportWasteToolStripMenuItem.Text = "Report Waste"
        '
        'SuratJalanWasteToolStripMenuItem
        '
        Me.SuratJalanWasteToolStripMenuItem.Name = "SuratJalanWasteToolStripMenuItem"
        Me.SuratJalanWasteToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.SuratJalanWasteToolStripMenuItem.Text = "Surat Jalan Waste"
        '
        'ReportToolStripMenuItem1
        '
        Me.ReportToolStripMenuItem1.Name = "ReportToolStripMenuItem1"
        Me.ReportToolStripMenuItem1.Size = New System.Drawing.Size(54, 20)
        Me.ReportToolStripMenuItem1.Text = "Report"
        '
        'ToolStrip
        '
        Me.ToolStrip.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ToolStrip.GripMargin = New System.Windows.Forms.Padding(2, 2, 500, 2)
        Me.ToolStrip.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmd_ADD, Me.cmd_MODIFY, Me.cmd_DELETE, Me.ToolStripSeparator1, Me.cmd_QUERY, Me.cmd_PRINT, Me.ToolStripSeparator2, Me.cmd_SHEETADD, Me.cmd_SHEETDEL, Me.ToolStripSeparator3, Me.cmd_EXIT})
        Me.ToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Size = New System.Drawing.Size(1027, 39)
        Me.ToolStrip.TabIndex = 7
        Me.ToolStrip.Text = "ToolStrip"
        '
        'cmd_ADD
        '
        Me.cmd_ADD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_ADD.Image = CType(resources.GetObject("cmd_ADD.Image"), System.Drawing.Image)
        Me.cmd_ADD.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_ADD.Name = "cmd_ADD"
        Me.cmd_ADD.Size = New System.Drawing.Size(36, 36)
        Me.cmd_ADD.Text = "ToolStripButton1"
        '
        'cmd_MODIFY
        '
        Me.cmd_MODIFY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_MODIFY.Image = CType(resources.GetObject("cmd_MODIFY.Image"), System.Drawing.Image)
        Me.cmd_MODIFY.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_MODIFY.Name = "cmd_MODIFY"
        Me.cmd_MODIFY.Size = New System.Drawing.Size(36, 36)
        Me.cmd_MODIFY.Text = "ToolStripButton2"
        '
        'cmd_DELETE
        '
        Me.cmd_DELETE.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_DELETE.Image = CType(resources.GetObject("cmd_DELETE.Image"), System.Drawing.Image)
        Me.cmd_DELETE.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_DELETE.Name = "cmd_DELETE"
        Me.cmd_DELETE.Size = New System.Drawing.Size(36, 36)
        Me.cmd_DELETE.Text = "ToolStripButton3"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_QUERY
        '
        Me.cmd_QUERY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_QUERY.Image = CType(resources.GetObject("cmd_QUERY.Image"), System.Drawing.Image)
        Me.cmd_QUERY.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_QUERY.Name = "cmd_QUERY"
        Me.cmd_QUERY.Size = New System.Drawing.Size(36, 36)
        Me.cmd_QUERY.Text = "ToolStripButton4"
        '
        'cmd_PRINT
        '
        Me.cmd_PRINT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_PRINT.Image = CType(resources.GetObject("cmd_PRINT.Image"), System.Drawing.Image)
        Me.cmd_PRINT.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_PRINT.Name = "cmd_PRINT"
        Me.cmd_PRINT.Size = New System.Drawing.Size(36, 36)
        Me.cmd_PRINT.Text = "ToolStripButton5"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_SHEETADD
        '
        Me.cmd_SHEETADD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_SHEETADD.Image = CType(resources.GetObject("cmd_SHEETADD.Image"), System.Drawing.Image)
        Me.cmd_SHEETADD.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_SHEETADD.Name = "cmd_SHEETADD"
        Me.cmd_SHEETADD.Size = New System.Drawing.Size(36, 36)
        Me.cmd_SHEETADD.Text = "ToolStripButton1"
        '
        'cmd_SHEETDEL
        '
        Me.cmd_SHEETDEL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_SHEETDEL.Image = CType(resources.GetObject("cmd_SHEETDEL.Image"), System.Drawing.Image)
        Me.cmd_SHEETDEL.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_SHEETDEL.Name = "cmd_SHEETDEL"
        Me.cmd_SHEETDEL.Size = New System.Drawing.Size(36, 36)
        Me.cmd_SHEETDEL.Text = "ToolStripButton2"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_EXIT
        '
        Me.cmd_EXIT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_EXIT.Image = CType(resources.GetObject("cmd_EXIT.Image"), System.Drawing.Image)
        Me.cmd_EXIT.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_EXIT.Name = "cmd_EXIT"
        Me.cmd_EXIT.Size = New System.Drawing.Size(36, 36)
        Me.cmd_EXIT.Text = "ToolStripButton3"
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 414)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1027, 22)
        Me.StatusStrip.TabIndex = 8
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1027, 436)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.ToolStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.IsMdiContainer = True
        Me.Name = "MainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "  "
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuTransaksi As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PeniliaianKinerjaKaryawanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ControlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InsertToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents cmd_ADD As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_MODIFY As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_DELETE As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_QUERY As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_PRINT As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_SHEETADD As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_SHEETDEL As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_EXIT As System.Windows.Forms.ToolStripButton
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ReportToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderCostingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MoldToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MoldOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingMoldProductionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MoldStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewMoldToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingMoldSizeByModelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MoldTransferByBuildingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryPOAdditionalReturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchasingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryMaterialByModelAndColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BalanceMaterialByPOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateBarcodeMaterialINToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryPOVendorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntrySPKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateBarcodeCMPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MaterialToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MaterialInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormulaMaterialByModelAndColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntrySPKToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryProductionMaterialToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryReturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClosingPOBySuratJalanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClosingPOBySuratJalanToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SimulasiProduksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents MoldStockToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportProductionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntrySuratJalanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCommonCode As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterVendorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetLineProductionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSetModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetCalenderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupSizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterMaterialToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuildOfMaterialToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SampleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserAccessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntryReturPOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClosingPOToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportWasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SuratJalanWasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterMoldToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
