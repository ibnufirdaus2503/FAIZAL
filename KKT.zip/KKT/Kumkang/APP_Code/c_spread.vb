﻿Public Class c_spread
    Private Shared m_view_spread As FarPoint.Win.Spread.FpSpread
    Private Shared m_spread As FarPoint.Win.Spread.SheetView

    Shared Property p_spread() As FarPoint.Win.Spread.SheetView
        Set(ByVal value As FarPoint.Win.Spread.SheetView)
            m_spread = value
        End Set
        Get
            Return m_spread
        End Get
    End Property

    Shared Property view_spread() As FarPoint.Win.Spread.FpSpread
        Get
            Return m_view_spread
        End Get
        Set(ByVal value As FarPoint.Win.Spread.FpSpread)
            m_view_spread = value
        End Set
    End Property

    Public Shared Sub empty_row(ByRef m_view As FarPoint.Win.Spread.FpSpread, ByRef m_sp As FarPoint.Win.Spread.SheetView)
        p_spread = m_view.ActiveSheet
        view_spread = m_view
        m_view.ShowCell(0, 0, 0, 0, FarPoint.Win.Spread.VerticalPosition.Top, FarPoint.Win.Spread.HorizontalPosition.Left)
        m_sp.RowCount = 0
    End Sub
    'Public Shared Sub empty_row(ByRef m_view As FarPoint.Win.Spread.FpSpread, ByRef m_sp As FarPoint.Win.Spread.SheetView)
    'Public Shared Sub empty_row(ByRef m_view As FarPoint.Win.Spread.FpSpread)
    '    p_spread = m_view.ActiveSheet
    '    view_spread = m_view
    '    m_view_spread.ShowCell(0, 0, 0, 0, FarPoint.Win.Spread.VerticalPosition.Top, FarPoint.Win.Spread.HorizontalPosition.Left)
    '    m_spread.RowCount = 0
    'End Sub
End Class
