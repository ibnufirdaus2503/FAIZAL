﻿Public Class frmLineProduction
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim Vbuilding As String
    Dim vFunction As Integer
    Dim vRoom As Integer
    Dim vSubline As Integer
    Dim vMachine As Integer
    Private Sub FP_LIST_CELL()


      
        SQL_C = ""
        SQL_C += "SELECT  cell_idxx,cell_desc " & vbLf
        SQL_C += "FROM KKTERP.dbo.room_cell " & vbLf
        SQL_C += "WHERE mach_idxx=" & vMachine

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdCell_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cell_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cell_desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_MACHINE()

       
        SQL_C = ""
        SQL_C += "select mach_idxx,mach_desc" & vbLf
        SQL_C += "from KKTERP.dbo.room_machine" & vbLf
        SQL_C += "where subs_idxx=" & vSubline

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMachine_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mach_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mach_desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SUBLINE()

        SQL_C = ""
        SQL_C += "SELECT subs_idxx,subs_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.room_subline" & vbLf
        SQL_C += "WHERE room_idxx=" & vRoom

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSubline_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("subs_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("subs_desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_ROOM()

        SQL_C = ""
        SQL_C += "SELECT room_idxx,room_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.room_room" & vbLf
        SQL_C += "WHERE func_idxx=" & vFunction

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdRoom_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("room_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("room_desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub FP_LIST_FUNCTION()
        Dim SQL_C As String


        SQL_C = ""
        SQL_C += "SELECT B.codd_desc,A.func_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.room_function A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.code_common B ON B.codh_flnm='CODE_FUNC' and B.codd_valu=CODE_FUNC" & vbLf
        SQL_C += "WHERE A.code_buil='" & Vbuilding & "'"



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdFunction_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("func_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_FUNCTION()
        Dim SQL_C As String


        SQL_C = ""

        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_FUNC'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpFunction_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_Desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_BUILDING(ByVal ID As String)
        Dim SQL_C As String


        SQL_C = ""

        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_BUIL' AND cod1_valu='" & ID & "'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBuilding_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_Desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_AREA()
        Dim SQL_C As String


        SQL_C = ""

        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_AREA'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdArea_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_Desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    
    
    
    Private Sub frmLineProduction_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        FP_LIST_AREA()
    End Sub

    Private Sub cboArea_Click(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
 

    Private Sub spdArea_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdArea.CellClick

        FP_LIST_BUILDING(spdArea_Sheet1.Cells.Item(e.Row, 0).Text)
    End Sub

    Private Sub btnAddFunction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddFunction.Click
        FP_LIST_HELP_FUNCTION()
        pnlHelpFunction.Visible = True
    End Sub

    Private Sub btnCloseFunction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseFunction.Click
        pnlHelpFunction.Visible = False
    End Sub

    Private Sub spdHelpFunction_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpFunction.CellClick

    End Sub

    Private Sub spdHelpFunction_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpFunction.CellDoubleClick
        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.room_function (code_buil,code_func) VALUES ('" & Vbuilding & "'," & spdHelpFunction_Sheet1.Cells.Item(e.Row, 0).Text & ")" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        pnlHelpFunction.Visible = False

        FP_LIST_FUNCTION()

    End Sub

    Private Sub spdBuilding_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBuilding.CellClick
        Vbuilding = spdBuilding_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_FUNCTION()
    End Sub

    Private Sub btnAddRoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRoom.Click
        txtIdRoom.Text = ""
        pnlRoom.Visible = True
    End Sub

    Private Sub btnSaveRoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveRoom.Click

        If txtIdRoom.Text = "" Then
            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.room_room (func_idxx,room_desc) VALUES (" & vFunction & ",'" & txtRoom.Text & "')" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.room_room SET room_desc='" & txtRoom.Text & "' WHERE room_idxx=" & txtIdRoom.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

        FP_LIST_ROOM()

        pnlRoom.Visible = False
    End Sub

    Private Sub spdFunction_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdFunction.CellClick
        vFunction = spdFunction_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_ROOM()
    End Sub

    Private Sub btnAddSubline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddSubline.Click
        txtIdSubline.Text = ""

        pnlSubline.Visible = True
    End Sub

    Private Sub btnSaveSubline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSubline.Click

        If txtIdSubline.Text = "" Then
            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.room_subline(room_idxx,subs_desc) VALUES (" & vRoom & ",'" & txtSubline.Text & "')" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else

            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.room_subline SET subs_desc='" & txtSubline.Text & "' WHERE subs_idxx=" & txtIdSubline.Text

            clsCom.GP_ExeSql(SQL_C)
        End If



        FP_LIST_SUBLINE()

        pnlSubline.Visible = False
    End Sub

    Private Sub spdRoom_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdRoom.CellClick
        vRoom = spdRoom_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_SUBLINE()
    End Sub

    Private Sub btnCloseSubline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSubline.Click
        pnlSubline.Visible = False
    End Sub

    Private Sub btnAddMachine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMachine.Click
        txtIdMachine.Text = ""
        pnlMachine.Visible = True
    End Sub

    Private Sub btnCloseMachine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseMachine.Click
        pnlMachine.Visible = False
    End Sub

    Private Sub btnSaveMachine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMachine.Click

        If txtIdMachine.Text = "" Then
            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.room_machine(subs_idxx,mach_desc) VALUES (" & vSubline & ",'" & txtMachine.Text & "')" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.room_machine SET mach_desc='" & txtMachine.Text & "' WHERE mach_idxx=" & txtIdMachine.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

        FP_LIST_MACHINE()

        pnlMachine.Visible = False

    End Sub

    Private Sub spdSubline_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSubline.CellClick
        vSubline = spdSubline_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_MACHINE()
    End Sub

    Private Sub btnCloseCell_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCell.Click
        pnlCell.Visible = False
    End Sub

    Private Sub btnSaveCell_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveCell.Click

        If txtIdCell.Text = "" Then
            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.room_cell(mach_idxx,cell_desc) VALUES (" & vMachine & ",'" & txtCell.Text & "')" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.dbo.room_cell SET cell_desc='" & txtCell.Text & "' WHERE cell_idxx=" & txtIdCell.Text

            clsCom.GP_ExeSql(SQL_C)

        End If

        FP_LIST_CELL()

        pnlCell.Visible = False
    End Sub

    Private Sub spdMachine_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMachine.CellClick
        vMachine = spdMachine_Sheet1.Cells.Item(e.Row, 0).Text()
        FP_LIST_CELL()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        pnlCell.Visible = True
    End Sub

    Private Sub spdMachine_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMachine.CellDoubleClick
        txtIdMachine.Text = spdMachine_Sheet1.Cells.Item(e.Row, 0).Text()
        txtMachine.Text = spdMachine_Sheet1.Cells.Item(e.Row, 1).Text()
        pnlMachine.Visible = True
    End Sub

    Private Sub btnDeleteMachine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteMachine.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.room_machine  WHERE mach_idxx=" & txtIdMachine.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_MACHINE()

        pnlMachine.Visible = False
    End Sub

    
    Private Sub spdSubline_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSubline.CellDoubleClick
        txtIdSubline.Text = spdSubline_Sheet1.Cells.Item(e.Row, 0).Text()
        txtSubline.Text = spdSubline_Sheet1.Cells.Item(e.Row, 1).Text()
        pnlSubline.Visible = True
    End Sub

    Private Sub btnDeleteSubline_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteSubline.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.room_subline  WHERE subs_idxx=" & txtIdSubline.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_SUBLINE()

        pnlSubline.Visible = False
    End Sub

    Private Sub spdRoom_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdRoom.CellDoubleClick
        txtIdRoom.Text = spdRoom_Sheet1.Cells.Item(e.Row, 0).Text()
        txtRoom.Text = spdRoom_Sheet1.Cells.Item(e.Row, 1).Text()
        pnlRoom.Visible = True
    End Sub

    Private Sub btnDeleteRoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRoom.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.room_room  WHERE room_idxx=" & txtIdRoom.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_ROOM()

        pnlRoom.Visible = False
    End Sub

    Private Sub btnDeleteCell_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteCell.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.room_cell   WHERE cell_idxx=" & txtIdCell.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_CELL()

        pnlCell.Visible = False

    End Sub
End Class