﻿Public Class frmMapOrder
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vRowProduct As String
    Dim vRowSize As String
    Dim vPO As String
    Dim vIdModel As Integer

    Private Sub FP_LIST_COMPONENT()

        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,B.codd_desc,CODE_COMP " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP" & vbLf
        SQL_C += "where A.modl_idxx = " & vIdModel


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1


                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("molh_idxx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With


    End Sub
    Private Sub FP_LIST_SIZE()
        SQL_C = ""
        SQL_C += "SELECT ordd_size,ordd_qtyx FROM KKTERP.dbo.order_detail WHERE ordh_poxx='" & txtPO.Text & "' order by  ordd_size" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_PO()
        SQL_C = ""
        SQL_C = SQL_C + "SELECT A.cntr_noxx,ordh_poxx,convert(varchar(10),ordh_etdh,111) ETD,convert(varchar(10),ordh_date,111) datepo,B.cust_idxx,B.modl_idxx," & vbLf
        SQL_C = SQL_C + "B.CODE_BRAN,CODE_PROD,A.colr_idxx,colr_name,cust_name,modl_name,F.codd_desc VBRAND,G.codd_desc VPROD" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.order_contract B ON A.cntr_noxx=B.cntr_noxx" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.color C ON C.colr_idxx=A.colr_idxx" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.customer D ON D.cust_idxx=B.cust_idxx" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.model E ON E.modl_idxx=B.modl_idxx" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.code_common F ON F.codh_flnm='CODE_BRAN' AND F.codd_valu=B.CODE_BRAN" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_PROD' AND G.codd_valu=B.CODE_PROD" & vbLf
        SQL_C = SQL_C + "WHERE ordh_stat = 0 " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cntr_noxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("datepo")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("VBRAND")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("VPROD")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("ETD")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("modl_name")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("modl_idxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmMapOrder_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_PO()
    End Sub


       


    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        With spdHead
            txtPO.Text = .ActiveSheet.Cells(e.Row, 0).Value
            txtKontrak.Text = .ActiveSheet.Cells(e.Row, 1).Value
            txtDatePO.Text = .ActiveSheet.Cells(e.Row, 2).Value
            txtETD.Text = .ActiveSheet.Cells(e.Row, 6).Value
            txtCustomer.Text = .ActiveSheet.Cells(e.Row, 3).Value
            txtBrand.Text = .ActiveSheet.Cells(e.Row, 4).Value
            txtProduct.Text = .ActiveSheet.Cells(e.Row, 5).Value
            txtModel.Text = .ActiveSheet.Cells(e.Row, 7).Value
            txtColor.Text = .ActiveSheet.Cells(e.Row, 8).Value

            vIdModel = .ActiveSheet.Cells(e.Row, 9).Value
        End With

        FP_LIST_SIZE()
        FP_LIST_COMPONENT()

    End Sub
End Class