﻿Public Class frmUserAccess
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vUser As Integer
    Private Sub FP_USER()
        Dim SQL_C As String
        Dim vid As Integer
        Dim vRow, RowIndex As Integer



        SQL_C = ""
        SQL_C += "select count(*) qty from KKTERP.dbo.user_security where secr_stat=1"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        vRow = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "select * from KKTERP.dbo.user_security where secr_stat=1 ORDER BY secr_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdUser_Sheet1
            .RowCount = vRow
            RowIndex = 1
            While clsCom.gv_DataRdr.Read

                vid = clsCom.gv_DataRdr("secr_idxx")
                .Cells.Item(RowIndex - 1, 0).Text = vid.ToString("D5")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("secr_user")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("secr_pass")

                RowIndex = RowIndex + 1


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub FP_COMBO_MENU()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT MenuText,VID FROM KKTERP.dbo.menuAkses where formname is null"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboParent
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("MenuText") & Space(100) & clsCom.gv_DataRdr("VID"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_DETAIL()


        Dim vrow, RowIndex As Integer




        SQL_C = ""
        SQL_C += "SELECT count(*) brs " & vbLf
        SQL_C += "FROM KKTERP.dbo.user_akses A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.menuAkses B ON A.VID=B.VID" & vbLf
        SQL_C += "WHERE VUSER=" & vUser
        clsCom.GP_ExeSqlReader(SQL_C)


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        vrow = clsCom.gv_DataRdr("brs")

        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "SELECT B.* " & vbLf
        SQL_C += "FROM KKTERP.dbo.user_akses A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.menuAkses B ON A.VID=B.VID" & vbLf
        SQL_C += "WHERE VUSER=" & vUser


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMenuAdmin_Sheet1
            .RowCount = vrow
            RowIndex = 1
            While clsCom.gv_DataRdr.Read

                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("VID")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("MenuText")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("FormName")
                RowIndex = RowIndex + 1
            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_HEAD()
        Dim SQL_C As String
        Dim vrow, RowIndex As Integer


      

        SQL_C = ""
        SQL_C += "SELECT count(*) brs FROM KKTERP.dbo.menuAkses where formname is not null AND VID NOT IN (SELECT VID FROM KKTERP.dbo.user_akses where vuser=" & vUser & ") " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        vRow = clsCom.gv_DataRdr("brs")

        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "SELECT * FROM KKTERP.dbo.menuAkses where formname is not null AND VID NOT IN (SELECT VID FROM KKTERP.dbo.user_akses where vuser=" & vuser & ")order by MenuText" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)



        With spdMenuKumkang_Sheet1
            .RowCount = vrow
            RowIndex = 1
            While clsCom.gv_DataRdr.Read

                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("VID")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("MenuText")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("FormName")

                RowIndex = RowIndex + 1
            End While

            '.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub

    Private Sub frmUserAccess_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_USER()
        '  FP_HEAD()
        ' FP_DETAIL()
    End Sub

    Private Sub btnAddMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMenu.Click
        pnlHead.Visible = True
        FP_COMBO_MENU()
    End Sub

    Private Sub btnCloseHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseHead.Click
        pnlHead.Visible = False
    End Sub

    Private Sub btnCloserUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloserUser.Click
        pnlUser.Visible = False
    End Sub

    Private Sub btnAddUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddUser.Click
        Dim vid As Integer

        pnlUser.Visible = True
        txtUserID.Text = ""
        txtName.Text = ""
        txtPassword.Text = ""

        SQL_C = ""
        SQL_C += "SELECT count(*) vid FROM KKTERP.dbo.user_security" & vbLf
        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("VID") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            txtUserID.Text = "00001"

        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "SELECT top 1 secr_idxx+1 vid FROM KKTERP.dbo.user_security order by secr_idxx desc" & vbLf



            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()
            vid = clsCom.gv_DataRdr("VID")
            txtUserID.Text = vid.ToString("D5")


        End If


        





    End Sub

    Private Sub btnSaveUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveUser.Click

        SQL_C = ""
        SQL_C += "select count(*) qty from KKTERP.dbo.user_security where secr_idxx=" & Val(txtUserID.Text)

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.user_security (secr_user,secr_pass,secr_stat) values ('" & txtName.Text & "','" & txtPassword.Text & "',1)"

            clsCom.GP_ExeSql(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "update KKTERP.dbo.user_security set secr_pass='" & txtPassword.Text & "'  where secr_idxx=" & Val(txtUserID.Text)

            clsCom.GP_ExeSql(SQL_C)

        End If

        pnlUser.Visible = False

        FP_USER()
    End Sub

    Private Sub spdUser_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdUser.CellClick
        vUser = Val(spdUser_Sheet1.Cells.Item(e.Row, 0).Text)
        FP_HEAD()
        FP_DETAIL()
    End Sub

    Private Sub btnDeleteUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteUser.Click
        SQL_C = ""
        SQL_C += "update user_security set secr_stat=0  where secr_idxx=" & Val(txtUserID.Text)

        clsCom.GP_ExeSql(SQL_C)

        FP_USER()
        pnlUser.Visible = False
    End Sub

    Private Sub spdUser_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdUser.CellDoubleClick
        pnlUser.Visible = True
        With spdUser_Sheet1.Cells
            txtUserID.Text = .Item(spdUser_Sheet1.ActiveRowIndex, 0).Text
            txtName.Text = .Item(spdUser_Sheet1.ActiveRowIndex, 1).Text
            txtPassword.Text = .Item(spdUser_Sheet1.ActiveRowIndex, 2).Text

        End With
    End Sub

   
    Private Sub spdMenu_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs)

    End Sub
 
    Private Sub btnAddAccess_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddAccess.Click
        Dim i As Integer

        With spdMenuKumkang_Sheet1

            For i = 0 To .RowCount - 1
                If .Cells.Item(i, 0).Value = True Then

                    SQL_C = ""
                    SQL_C += "DELETE KKTERP.dbo.user_akses   WHERE VUSER=" & vUser & " AND VID=" & spdMenuKumkang_Sheet1.Cells.Item(i, 1).Text

                    clsCom.GP_ExeSql(SQL_C)

                    SQL_C = ""
                    SQL_C += "insert into KKTERP.dbo.user_akses (VUSER,VID) VALUES (" & vUser & "," & spdMenuKumkang_Sheet1.Cells.Item(i, 1).Text & ")"

                    clsCom.GP_ExeSql(SQL_C)
                End If
            Next

            '  spdMenu_Sheet1.RowCount = 0

        End With
       
        pnlUser.Visible = False


        FP_DETAIL()
        FP_HEAD()

    End Sub

    Private Sub btnRemoveAccess_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveAccess.Click
        Dim i As Integer

        With spdMenuAdmin_Sheet1

            For i = 0 To .RowCount - 1
                If .Cells.Item(i, 0).Value = True Then

                    SQL_C = ""
                    SQL_C += "DELETE KKTERP.dbo.user_akses   WHERE VUSER=" & vUser & " AND VID=" & spdMenuAdmin_Sheet1.Cells.Item(i, 1).Text

                    clsCom.GP_ExeSql(SQL_C)

                   
                End If
            Next



        End With

        pnlUser.Visible = False


        FP_DETAIL()
        FP_HEAD()
    End Sub
End Class