﻿Public Class frmCommonCode
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInsert()
        Dim NewRow As Boolean

        NewRow = True
        With spdDetail_Sheet1
            If .RowCount = 0 Then
                NewRow = True
            End If

            If NewRow = True Then
                .RowCount = .RowCount + 1
                .SetActiveCell(.RowCount - 1, 1)
            End If
        End With
    End Sub
    Public Sub cmdUpdate()
        Call FP_MODIFY_DETAIL()
    End Sub
    Public Sub cmdInquery()
        Cursor = Cursors.WaitCursor

        Cursor = Cursors.Default
    End Sub
    Public Sub cmdDelete()
        Cursor = Cursors.WaitCursor


        Cursor = Cursors.Default
    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_MODIFY()
        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.codh_common SET codh_desc='" & txtDescHead.Text & "' WHERE CODH_FLNM='" & txtCodeHead.Text & "'"

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Sub FP_MODIFY_DETAIL()
        Dim i As Integer

        SQL_C = ""
        SQL_C = SQL_C + "DELETE  KKTERP.dbo.code_common WHERE codh_flnm='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'"

        clsCom.GP_ExeSql(SQL_C)

        With spdDetail_Sheet1
            For i = 0 To .RowCount - 1

                SQL_C = ""
                SQL_C = SQL_C + " INSERT INTO KKTERP.dbo.code_common(codh_flnm,codd_valu,codd_desc,cod1_valu,cod2_valu,cod3_valu,cod1_desc,cod2_desc) VALUES ('" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "','" & .Cells.Item(i, 0).Text & "','" & .Cells.Item(i, 1).Text & "','" & .Cells.Item(i, 4).Text & "','" & .Cells.Item(i, 5).Text & "','" & .Cells.Item(i, 6).Text & "','" & .Cells.Item(i, 2).Text & "','" & .Cells.Item(i, 3).Text & "')" & vbCrLf

                clsCom.GP_ExeSql(SQL_C)

            Next
        End With
    End Sub
    Private Sub FP_DELETE()

       
    End Sub
  
    Private Sub FP_INSERT()
        If txtCodeHead.Text = "" Or txtDescHead.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.codh_common (codh_flnm,codh_desc,codh_uins,codh_tins) VALUES ('" & txtCodeHead.Text & "','" & txtDescHead.Text & "','ADMIN','" & Now & "')" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub
    
 
    Private Sub frmCommonCode_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        FP_INIT()

    End Sub


    Private Sub btnAddHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddHead.Click
        txtCodeHead.Text = ""
        txtDescHead.Text = ""
        txtCodeHead.Enabled = True
        txtCodeHead.Focus()



        pnlHead.Visible = True


    End Sub

    Private Sub btnSaveHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveHead.Click
        Cursor = Cursors.WaitCursor

        SQL_C = ""
        SQL_C = SQL_C + "SELECT COUNT(*) QTY FROM KKTERP.dbo.codh_common WHERE CODH_FLNM='" & txtCodeHead.Text & "'"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr.Item(0) = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            FP_INSERT()
        Else
            clsCom.gv_ExeSqlReaderEnd()
            FP_MODIFY()
        End If

        pnlHead.Visible = False
        Call FP_LIST_HEAD()

        Cursor = Cursors.Default

    End Sub

    Private Sub btnCloseHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseHead.Click
        pnlHead.Visible = False

    End Sub
    


    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        With spdHead_Sheet1.Cells
            txtCodeHead.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
            txtDescHead.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text

        End With
        txtCodeHead.Enabled = False

        pnlHead.Visible = True


    End Sub

    Sub FP_NewRow(ByVal ObjSpread As Object)
        'SpreadSheet New Row Create

        With ObjSpread

            .Row = .MaxRows
            .Col = 1
            '.Action= = SS_ACTION_ACTIVE_CELL
            .Lock = False
            .SetFocus()
        End With

    End Sub
    Sub FP_LIST_HEAD()
        Dim SQL_C As String
        Dim vRow As Integer


        SQL_C = ""
        SQL_C += "SELECT COUNT(*) brs" & vbLf
        SQL_C += "FROM KKTERP.dbo.codh_common" & vbLf
      

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        vRow = clsCom.gv_DataRdr("brs")

        clsCom.gv_ExeSqlReaderEnd()


 
        SQL_C = ""
        SQL_C += "SELECT codh_flnm,codh_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.codh_common" & vbLf
        SQL_C += "order by codh_flnm asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
          
            .RowCount = vRow
            Dim rowIndex As Integer
            rowIndex = 1
            While clsCom.gv_DataRdr.Read
                

                .Cells.Item(rowIndex - 1, 0).Text = clsCom.gv_DataRdr("codh_flnm")
                .Cells.Item(rowIndex - 1, 1).Text = clsCom.gv_DataRdr("codh_desc")

                rowIndex = rowIndex + 1
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Sub FP_LIST_DETAIL(ByVal codh_flnm As String)
        Dim vrow, RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT count(*) qty" & vbLf
        SQL_C += "FROM KKTERP.DBO.CODE_COMMON" & vbLf
        SQL_C += "WHERE codh_flnm='" & codh_flnm & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdDetail_Sheet1.RowCount = clsCom.gv_DataRdr("qty")

        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc,isnull(cod1_valu,'') cod1_valu,isnull(cod2_valu,'') cod2_valu,isnull(cod3_valu,'') cod3_valu,isnull(cod1_desc,'') cod1_desc,isnull(cod2_desc,'') cod2_desc,isnull(cod3_desc,'') cod3_desc" & vbLf
        SQL_C += "FROM KKTERP.DBO.CODE_COMMON" & vbLf
        SQL_C += "WHERE codh_flnm='" & codh_flnm & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1
                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("cod1_desc")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("cod2_desc")
                .Cells.Item(RowIndex - 1, 4).Text = clsCom.gv_DataRdr("cod1_valu")
                .Cells.Item(RowIndex - 1, 5).Text = clsCom.gv_DataRdr("cod2_valu")
                .Cells.Item(RowIndex - 1, 6).Text = clsCom.gv_DataRdr("cod3_valu")
            End While

            '   .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        Call FP_LIST_DETAIL(spdHead_Sheet1.Cells.Item(e.Row, 0).Text)
    End Sub

    Private Sub btnDelHead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelHead.Click
        SQL_C = ""
        SQL_C = SQL_C + "DELETE  KKTERP.dbo.codh_common WHERE codh_flnm='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'"

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "DELETE  KKTERP.dbo.code_common WHERE codh_flnm='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'"

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_HEAD()
        spdDetail_Sheet1.RowCount = 0

        pnlHead.Visible = False
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Get the active sheet
        Dim activeSheet As FarPoint.Win.Spread.SheetView = spdDetail.ActiveSheet

        ' Get the selected row index
        Dim selectedRowIndex As Integer = activeSheet.ActiveRowIndex

        ' Remove the selected row
        activeSheet.RemoveRows(selectedRowIndex, 1)
    End Sub

    Private Sub btnAddDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class

