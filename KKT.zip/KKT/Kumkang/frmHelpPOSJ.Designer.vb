﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHelpPOSJ
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnClosePOSJ = New System.Windows.Forms.Button
        Me.pnlHelpCustomer = New System.Windows.Forms.Panel
        Me.btnCariCustomer = New System.Windows.Forms.Button
        Me.txtCustomerHelpCari = New System.Windows.Forms.TextBox
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpCustomer.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, 0"
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdHead.HorizontalScrollBar.TabIndex = 2
        Me.spdHead.Location = New System.Drawing.Point(12, 49)
        Me.spdHead.Name = "spdHead"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = ""
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer1
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = ""
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer1
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(828, 318)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 155
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdHead.VerticalScrollBar.TabIndex = 3
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 10
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.Cells.Get(0, 0).Value = "0"
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 2).Value = 2
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 3).Value = 3
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 4).Value = 4
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 5).Value = 5
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 6).Value = 6
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 7).Value = 7
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 8).Value = 8
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 9).Value = 9
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "NO SJ"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "DATE SJ"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "NO. PO"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "CUSTOMER"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "ID MODEL"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "MODEL"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "COLOR"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "ID SJ"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "MCLR ID"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        Me.spdHead_Sheet1.Columns.Get(0).CellType = TextCellType1
        Me.spdHead_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHead_Sheet1.Columns.Get(0).Visible = False
        Me.spdHead_Sheet1.Columns.Get(0).Width = 72.0!
        Me.spdHead_Sheet1.Columns.Get(1).Label = "NO SJ"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 142.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "DATE SJ"
        Me.spdHead_Sheet1.Columns.Get(2).Width = 101.0!
        Me.spdHead_Sheet1.Columns.Get(3).Label = "NO. PO"
        Me.spdHead_Sheet1.Columns.Get(3).Width = 110.0!
        Me.spdHead_Sheet1.Columns.Get(4).Label = "CUSTOMER"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 87.0!
        Me.spdHead_Sheet1.Columns.Get(5).Label = "ID MODEL"
        Me.spdHead_Sheet1.Columns.Get(5).Locked = False
        Me.spdHead_Sheet1.Columns.Get(5).Width = 51.0!
        Me.spdHead_Sheet1.Columns.Get(6).Label = "MODEL"
        Me.spdHead_Sheet1.Columns.Get(6).Width = 134.0!
        Me.spdHead_Sheet1.Columns.Get(7).Label = "COLOR"
        Me.spdHead_Sheet1.Columns.Get(7).Width = 146.0!
        Me.spdHead_Sheet1.Columns.Get(8).Label = "ID SJ"
        Me.spdHead_Sheet1.Columns.Get(9).Label = "MCLR ID"
        Me.spdHead_Sheet1.Columns.Get(9).Visible = False
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.Rows.Get(0).Height = 21.0!
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnClosePOSJ
        '
        Me.btnClosePOSJ.Location = New System.Drawing.Point(611, 369)
        Me.btnClosePOSJ.Name = "btnClosePOSJ"
        Me.btnClosePOSJ.Size = New System.Drawing.Size(229, 33)
        Me.btnClosePOSJ.TabIndex = 156
        Me.btnClosePOSJ.Text = "Close"
        Me.btnClosePOSJ.UseVisualStyleBackColor = True
        '
        'pnlHelpCustomer
        '
        Me.pnlHelpCustomer.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpCustomer.Controls.Add(Me.btnCariCustomer)
        Me.pnlHelpCustomer.Controls.Add(Me.txtCustomerHelpCari)
        Me.pnlHelpCustomer.Location = New System.Drawing.Point(12, 3)
        Me.pnlHelpCustomer.Name = "pnlHelpCustomer"
        Me.pnlHelpCustomer.Size = New System.Drawing.Size(828, 44)
        Me.pnlHelpCustomer.TabIndex = 157
        '
        'btnCariCustomer
        '
        Me.btnCariCustomer.Location = New System.Drawing.Point(233, 8)
        Me.btnCariCustomer.Name = "btnCariCustomer"
        Me.btnCariCustomer.Size = New System.Drawing.Size(46, 24)
        Me.btnCariCustomer.TabIndex = 25
        Me.btnCariCustomer.Text = ">>"
        Me.btnCariCustomer.UseVisualStyleBackColor = True
        '
        'txtCustomerHelpCari
        '
        Me.txtCustomerHelpCari.Location = New System.Drawing.Point(62, 9)
        Me.txtCustomerHelpCari.Name = "txtCustomerHelpCari"
        Me.txtCustomerHelpCari.Size = New System.Drawing.Size(165, 20)
        Me.txtCustomerHelpCari.TabIndex = 12
        '
        'frmHelpPOSJ
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(844, 404)
        Me.Controls.Add(Me.pnlHelpCustomer)
        Me.Controls.Add(Me.btnClosePOSJ)
        Me.Controls.Add(Me.spdHead)
        Me.Name = "frmHelpPOSJ"
        Me.Text = "frmHelpPOSJ"
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpCustomer.ResumeLayout(False)
        Me.pnlHelpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnClosePOSJ As System.Windows.Forms.Button
    Friend WithEvents pnlHelpCustomer As System.Windows.Forms.Panel
    Friend WithEvents btnCariCustomer As System.Windows.Forms.Button
    Friend WithEvents txtCustomerHelpCari As System.Windows.Forms.TextBox
End Class
