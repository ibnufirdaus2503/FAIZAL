﻿Public Class frmHelpModelName
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_Master()

        Dim RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.mold_master "

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdMaster_Sheet1.RowCount = clsCom.gv_DataRdr("QTY")
        clsCom.gv_ExeSqlReaderEnd()



        SQL_C = ""
        SQL_C += "SELECT mast_idxx,mast_name,CODE_BRAN,B.codd_desc VbRAND,CODE_GCUS ,C.codd_desc vGroup,vend_name,A.vend_idxx FROM KKTERP.dbo.mold_master A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BRAN' AND B.CODD_VALU=CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GCUS' AND C.CODD_VALU=CODE_GCUS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vendor D ON D.vend_idxx=A.vend_idxx" & vbLf
        SQL_C += "WHERE mast_idxx is not null" & vbLf

        If txtMold.Text <> "" Then
            SQL_C += "AND mast_name LIKE '%" & txtMold.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMaster_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1

                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("mast_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("CODE_BRAN")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("CODE_GCUS")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("vend_idxx")
                .Cells.Item(RowIndex - 1, 4).Text = clsCom.gv_DataRdr("VbRAND")
                .Cells.Item(RowIndex - 1, 5).Text = clsCom.gv_DataRdr("mast_name")
                .Cells.Item(RowIndex - 1, 6).Text = clsCom.gv_DataRdr("vGroup")
                .Cells.Item(RowIndex - 1, 7).Text = clsCom.gv_DataRdr("vend_name")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub btnCariMold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariMold.Click
        FP_LIST_Master()
    End Sub

   

    Private Sub spdMaster_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaster.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdMaster_Sheet1.Cells.Item(e.Row, 0).Text ' mast_idxx
            .Help_str2 = spdMaster_Sheet1.Cells.Item(e.Row, 1).Text 'CODE_BRAN
            .Help_str3 = spdMaster_Sheet1.Cells.Item(e.Row, 2).Text 'CODE_GCUS
            .Help_str4 = spdMaster_Sheet1.Cells.Item(e.Row, 3).Text 'vend_idxx
            .Help_str5 = spdMaster_Sheet1.Cells.Item(e.Row, 4).Text 'VbRAND
            .Help_str6 = spdMaster_Sheet1.Cells.Item(e.Row, 5).Text 'mast_name
            .Help_str7 = spdMaster_Sheet1.Cells.Item(e.Row, 6).Text 'vGroup
            .Help_str8 = spdMaster_Sheet1.Cells.Item(e.Row, 7).Text 'vend_name







        End With

        Me.Close()
    End Sub

    Private Sub btnCloseMold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseMold.Click
        Me.Close()
    End Sub

    Private Sub frmHelpModelName_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_Master()
    End Sub
End Class