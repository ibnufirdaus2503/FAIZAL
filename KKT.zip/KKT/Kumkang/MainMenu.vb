﻿
'Imports System.Data.SqlClient

 
Public Class MainMenu

    Private Sub cmd_ADD_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_ADD.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdInsert()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_MODIFY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_MODIFY.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdUpdate()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_DELETE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_DELETE.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdDelete()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_PRINT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_PRINT.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdPrint()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmd_QUERY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_QUERY.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdInquery()
        Catch ex As Exception

        End Try
    End Sub


    Private Sub CommonCodeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCommonCode.Click

        Dim Frm As New frmCommonCode

        Frm.MdiParent = Me
        Frm.Show()

    End Sub

    Private Sub SetModelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSetModel.Click

        Dim Frm As New frmModel

        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SetColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetColorToolStripMenuItem.Click
        Dim Frm As New frmColor

        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SetMoldToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Frm As New frmMold

        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SetLineProductionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetLineProductionToolStripMenuItem.Click
        Dim Frm As New frmLineProduction

        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SetMaterialToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Frm As New frmSetMaterial


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportToolStripMenuItem.Click

    End Sub

    Private Sub ControlToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ControlToolStripMenuItem.Click

    End Sub

    Private Sub StatusStrip_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles StatusStrip.ItemClicked

    End Sub

    Private Sub CustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerToolStripMenuItem.Click
        Dim Frm As New frmCustomer


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ToolStrip_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip.ItemClicked

    End Sub

    Private Sub SetCalenderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetCalenderToolStripMenuItem.Click
        Dim Frm As New frmCalender



        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click
        Dim Frm As New frmEntryPO



        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MoldInToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Frm As New frmNewMold



        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SettingMoldProductionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingMoldProductionToolStripMenuItem.Click
        Dim Frm As New frmSettingMoldProduction



        Frm.MdiParent = Me
        Frm.Show()
    End Sub


    Private Sub SampleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Frm As New frmSample



        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub NewMoldToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewMoldToolStripMenuItem.Click
        Dim Frm As New frmNewMold


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SettingMoldSizeByModelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingMoldSizeByModelToolStripMenuItem.Click
        Dim Frm As New frmModelMold


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MoldOutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoldOutToolStripMenuItem.Click
        Dim Frm As New frmServiceOut


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MoldTransferToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub MoldTransferByBuildingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoldTransferByBuildingToolStripMenuItem.Click
        Dim Frm As New frmTransferOut


        Frm.MdiParent = Me
        Frm.Show()
    End Sub



    Private Sub MasterVendorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterVendorToolStripMenuItem.Click
        Dim Frm As New frmVendor


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click
        Dim Frm As New frmMapOrder


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub GroupSizeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupSizeToolStripMenuItem.Click
        Dim Frm As New frmGroupSize


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MasterMaterialToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterMaterialToolStripMenuItem.Click
        Dim Frm As New frmMasterMaterial


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntryMaterialByModelAndColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntryMaterialByModelAndColorToolStripMenuItem.Click
        Dim Frm As New frmFormula


        Frm.MdiParent = Me
        Frm.Show()
    End Sub



    Private Sub MaterialInToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MaterialInToolStripMenuItem.Click
        Dim Frm As New frmMaterialIn


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntryReturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntryReturToolStripMenuItem.Click
        Dim Frm As New frmMaterialSJOut


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntrySPKToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntrySPKToolStripMenuItem1.Click
        Dim Frm As New frmMaterialSPK


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntryProductionMaterialToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntryProductionMaterialToolStripMenuItem.Click
        Dim Frm As New frmMaterialProduksi


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub BuildOfMaterialToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuildOfMaterialToolStripMenuItem.Click

    End Sub

    Private Sub SampleToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SampleToolStripMenuItem.Click
        Dim Frm As New frmSample


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MoldStockToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoldStockToolStripMenuItem1.Click
        Dim Frm As New frmMoldStock


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub cmd_SHEETDEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_SHEETDEL.Click
        Dim Child As Object
        Try
            Child = CType(Me.ActiveMdiChild, Form)
            Child.cmdSheetDel()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub MoldStockToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoldStockToolStripMenuItem.Click
        Dim Frm As New frmMoldIn


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub FormulaMaterialByModelAndColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FormulaMaterialByModelAndColorToolStripMenuItem.Click
        Dim Frm As New frmFormula


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntrySPKToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntrySPKToolStripMenuItem.Click
        Dim Frm As New frmSPKCP


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub CreateBarcodeCMPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateBarcodeCMPToolStripMenuItem.Click
        Dim Frm As New frmCreateBarcode


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ReportProductionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportProductionToolStripMenuItem.Click
        Dim Frm As New frmRptProdBySize


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub PToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PToolStripMenuItem.Click

    End Sub

    Private Sub UserAccessToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserAccessToolStripMenuItem.Click
        Dim Frm As New frmUserAccess


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub EntryPOVendorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntryPOVendorToolStripMenuItem.Click

    End Sub

    Private Sub EntrySuratJalanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntrySuratJalanToolStripMenuItem.Click
        Dim Frm As New frmSuratJalan


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub OrderCostingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrderCostingToolStripMenuItem.Click

    End Sub

    Private Sub CreateBarcodeMaterialINToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateBarcodeMaterialINToolStripMenuItem.Click

    End Sub

    

    Private Sub EntryReturPOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntryReturPOToolStripMenuItem.Click
        Dim Frm As New frmReturPO


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ClosingPOToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClosingPOToolStripMenuItem.Click
        Dim Frm As New frmClosingPO


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub ReportWasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReportWasteToolStripMenuItem.Click
        Dim Frm As New frmWasteReport


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub SuratJalanWasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SuratJalanWasteToolStripMenuItem.Click
        Dim Frm As New frmSuratJalanWaste


        Frm.MdiParent = Me
        Frm.Show()
    End Sub

    Private Sub MasterMoldToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterMoldToolStripMenuItem.Click
        Dim Frm As New frmMoldMaster


        Frm.MdiParent = Me
        Frm.Show()
    End Sub
End Class
