﻿Public Class frmCustomer
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
     
    Public Sub cmdInsert()
       FP_CLEAR


    End Sub
   
    Public Sub cmdUpdate()
        If txtDesc.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If
        If txtCode.Text = "" Then
            Cursor = Cursors.WaitCursor

            SQL_C = ""
            SQL_C = SQL_C + "SELECT COUNT(*) QTY FROM KKTERP.dbo.customer WHERE cust_name='" & txtDesc.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr.Item(0) = 0 Then
                clsCom.gv_ExeSqlReaderEnd()

                FP_INSERT()
            Else
                clsCom.gv_ExeSqlReaderEnd()
                FP_MODIFY()
            End If

            txtCode.Text = ""
            txtDesc.Text = ""



            Cursor = Cursors.Default
        Else
            FP_MODIFY()
        End If

        FP_CLEAR()

        Call FP_LIST_HEAD()
    End Sub
    Public Sub cmdInquery()
        Call FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.customer  WHERE cust_idxx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_CLEAR()

        FP_LIST_HEAD()
    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()

        FP_COMBO_PROPINSI()
        FP_LIST_BRAND()

    End Sub
    Private Sub FP_MODIFY()
        Dim i As Integer

        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.customer  SET cust_name='" & txtDesc.Text & "', " & vbCrLf
        SQL_C = SQL_C + "cust_cont='" & txtContactPerson.Text & "'," & vbCrLf
        SQL_C = SQL_C + "cust_tlpx='" & txtTLP.Text & "'," & vbCrLf
        SQL_C = SQL_C + "cust_hpxx='" & txtHP.Text & "'," & vbCrLf
        SQL_C = SQL_C + "cust_post='" & txtKodePos.Text & "'," & vbCrLf
        SQL_C = SQL_C + "cust_addr='" & txtAddress.Text & "'," & vbCrLf
        SQL_C = SQL_C + "CODE_GCUS=" & txtIdGroupCustomer.Text & "," & vbCrLf
        SQL_C = SQL_C + "cust_shrt='" & txtShortName.Text & "'," & vbCrLf
        SQL_C = SQL_C + "cust_bcxx='" & IIf(chkBerikat.Checked = True, 1, 0) & "'," & vbCrLf
        SQL_C = SQL_C + "CODE_PROP='" & Strings.Trim(Strings.Right(cboCity.Text, 3)) & "'" & vbCrLf
        SQL_C = SQL_C + "WHERE cust_idxx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
 
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.customer_brand where cust_idxx=" & txtCode.Text

        clsCom.GP_ExeSql(SQL_C)


        With spdBrand_Sheet1
            i = 0
            For i = 0 To .RowCount - 1
                If .Cells.Item(i, 0).Value = True Then
                    SQL_C = ""
                    SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.customer_brand(cust_idxx,CODE_BRAN) VALUES (" & txtCode.Text & ",'" & .Cells.Item(i, 1).Text & "')" & vbCrLf

                    clsCom.GP_ExeSql(SQL_C)
                End If

            Next

        End With

        

    End Sub
    Private Sub FP_INSERT()


        SQL_C = ""
        SQL_C = SQL_C + "insert into KKTERP.dbo.customer (cust_name,cust_cont,cust_tlpx,cust_hpxx,cust_post,cust_addr,CODE_PROP,cust_bcxx,CODE_GCUS,cust_shrt) values ('" & txtDesc.Text & "','" & txtContactPerson.Text & "','" & txtTLP.Text & "','" & txtHP.Text & "','" & txtKodePos.Text & "','" & txtAddress.Text & "','" & Trim(Strings.Right(cboCity.Text, 3)) & "'," & IIf(chkBerikat.Checked = True, 1, 0) & "," & txtIdGroupCustomer.Text & ",'" & txtShortName.Text & "')" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_DELETE()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.customer  WHERE cust_idxx=" & txtCode.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_COMBO_PROPINSI()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common" & vbLf
        SQL_C += "WHERE codh_flnm='CODE_PROP'"
        SQL_C += "order by codd_desc asc" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)


        With cboCity
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("CODD_VALU"))
            End While


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT cust_idxx,cust_name,cust_cont,cust_hpxx,cust_post,cust_addr,CODE_PROP,ISNULL(cust_bcxx,0) cust_bcxx ,B.codd_desc VPROP,C.codd_desc VGROUP,CODE_GCUS,cust_shrt,cust_tlpx" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common B ON B.CODH_FLNM='CODE_PROP' and B.codd_valu=CODE_PROP" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.CODH_FLNM='CODE_GCUS' and C.codd_valu=CODE_GCUS" & vbLf
        SQL_C += "WHERE CUST_IDXX IS NOT NULL" & vbLf


        If txtCustomer.Text <> "" Then
            SQL_C += "AND cust_name like '%" & txtCustomer.Text & "%'" & vbLf
        End If
        SQL_C += "ORDER BY A.cust_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("VGROUP")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("cust_shrt")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("cust_cont")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("cust_tlpx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("cust_hpxx")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("VPROP")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("cust_post")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("cust_addr")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("CODE_PROP")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("cust_bcxx")
                .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("CODE_GCUS")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
 
     
    

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        
    End Sub

    Private Sub frmcustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_INIT()
    End Sub

   
 
    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        txtCode.Text = spdHead.ActiveSheet.Cells(e.Row, 0).Value
        txtGroupCustomer.Text = spdHead.ActiveSheet.Cells(e.Row, 1).Value
        txtIdGroupCustomer.Text = spdHead.ActiveSheet.Cells(e.Row, 12).Value
        txtDesc.Text = spdHead.ActiveSheet.Cells(e.Row, 2).Value
        txtContactPerson.Text = spdHead.ActiveSheet.Cells(e.Row, 4).Value
        txtTLP.Text = spdHead.ActiveSheet.Cells(e.Row, 5).Value
        txtHP.Text = spdHead.ActiveSheet.Cells(e.Row, 6).Value
        txtKodePos.Text = spdHead.ActiveSheet.Cells(e.Row, 8).Value
        txtAddress.Text = spdHead.ActiveSheet.Cells(e.Row, 9).Value
        txtShortName.Text = spdHead.ActiveSheet.Cells(e.Row, 3).Value


        cboCity.Text = spdHead.ActiveSheet.Cells(e.Row, 7).Value & Space(100) & spdHead.ActiveSheet.Cells(e.Row, 10).Value
        chkBerikat.Checked = IIf(spdHead.ActiveSheet.Cells(e.Row, 11).Value = 1, True, False)

      

        FP_LIST_BRAND()
    End Sub

    

    Private Sub FP_CLEAR()
        txtCode.Text = ""
        txtGroupCustomer.Text = ""
        txtIdGroupCustomer.Text = ""
        txtDesc.Text = ""
        txtContactPerson.Text = ""
        txtTLP.Text = ""
        txtHP.Text = ""
        txtKodePos.Text = ""
        txtAddress.Text = ""
        txtIdGroupCustomer.Text = ""
        txtShortName.Text = ""
        txtGroupCustomer.Text = ""
       

        
    End Sub


    Private Sub FP_LIST_BRAND()
        Dim SQL_C As String
 

        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc,ISNULL(CODE_BRAN,0) vcode" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_BRAN'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join" & vbLf
        SQL_C += "(		" & vbLf
        SQL_C += "SELECT cust_idxx,CODE_BRAN " & vbLf
        SQL_C += "FROM KKTERP.dbo.customer_brand A WHERE cust_idxx=" & IIf(txtCode.Text <> "", txtCode.Text, 0) & "" & vbLf
        SQL_C += ") B ON A.codd_valu=CODE_BRAN" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBrand_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                If clsCom.gv_DataRdr("vcode") <> 0 Then
                    .Cells.Item(.RowCount - 1, 0).Value = True
                End If
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("codd_Desc")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpGroupCustomer.Click
        frmHelpGroupCustomer.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            txtIdGroupCustomer.Text = .Help_str1
            txtGroupCustomer.Text = .Help_str2

        End With



errHandle:
    End Sub
End Class