﻿Public Class frmSuratJalan
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_CLEAR()
        txtSJ.Text = ""
        dtSJ.Text = ""
        txtCustomer.Text = ""
        txtIdCustomer.Text = ""
        txtNoPlat.Text = ""
        txtJenisKendaraan.Text = ""
        txtAlamat.Text = ""
    End Sub
    Public Sub cmdPrint()
        FP_PRINT()
    End Sub
    Private Sub FP_HEAD_MODEL(ByVal id_sj As Integer)
        Dim IdModel As Integer

        SQL_C = ""
        SQL_C += "SELECT sjxh_idxx,cust_name,sjxh_noxx,D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,QTY,moldset" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.sjxh_idxx,A.mcom_idxx,sjxh_noxx,molh_idxx,cust_name,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select A.sjxh_idxx,mcom_idxx,A.sjxh_noxx,cust_name" & vbLf
        SQL_C += "from KKTERP.dbo.surat_jalanh A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.surat_jaland B ON A.sjxh_idxx=B.sjxh_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer C ON C.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "where  A.sjxh_idxx =" & id_sj & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.production_good B ON A.sjxh_idxx=B.sjxh_idxx AND A.mcom_idxx=B.mcom_idxx" & vbLf
        SQL_C += "GROUP BY A.sjxh_idxx,A.mcom_idxx,sjxh_noxx,molh_idxx,cust_name" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "LEFT JOIN (" & vbLf
        SQL_C += "SELECT " & vbLf
        SQL_C += "mcom_idxx," & vbLf
        SQL_C += "STUFF((" & vbLf
        SQL_C += "SELECT ',' + mols_size+'('+ cast(qty as varchar)+')'" & vbLf
        SQL_C += "FROM (" & vbLf
        SQL_C += "SELECT mcom_idxx,mols_size,sum(prod_qtty) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good WHERE SJXH_IDXX=" & id_sj & vbLf
        SQL_C += "group by mcom_idxx,mols_size" & vbLf
        SQL_C += ") t1" & vbLf
        SQL_C += "WHERE(t1.mcom_idxx = t2.mcom_idxx)" & vbLf
        SQL_C += "FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'), 1, 1, '') AS MoldSet " & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += " SELECT mcom_idxx,mols_size,sum(prod_qtty) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good WHERE SJXH_IDXX=" & id_sj & vbLf
        SQL_C += "group by mcom_idxx,mols_size" & vbLf
        SQL_C += ") t2 " & vbLf
        SQL_C += "      GROUP BY " & vbLf
        SQL_C += "     mcom_idxx " & vbLf
        SQL_C += ") H ON A.mcom_idxx=H.mcom_idxx" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")


                .Cells.Item(.RowCount - 1, 1).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")
                .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("moldset")
                .Cells.Item(.RowCount - 1, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center








            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Sub FP_PRINT()
        Dim SQL_C As String
        Dim k As Int16



        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.TEMP_PRINT WHERE TEMP_USER='SJKIRIM'"

        '/* Execute
        clsCom.GP_ExeSql(SQL_C)

        With spdDetail_Sheet1
            For k = 0 To .RowCount - 1
                SQL_C = ""
                SQL_C = SQL_C + " INSERT INTO KKTERP.dbo.TEMP_PRINT (TEMP_USER,TEMP_VA01,TEMP_VA02,TEMP_VA03,TEMP_VA04,TEMP_VA05,TEMP_TX01,TEMP_IN01,TEMP_IN02,TEMP_VA06) VALUES ('SJKIRIM','" & txtSJ.Text & "','" & dtSJ.Value & "','" & txtCustomer.Text & "','" & txtJenisKendaraan.Text & "','" & txtNoPlat.Text & "','" & .Cells.Item(k, 1).Text + "  " + .Cells.Item(k, 2).Text + "  " + .Cells.Item(k, 4).Text + " " + .Cells.Item(k, 3).Text + " :" + .Cells.Item(k, 7).Text + "'," & k + 1 & "," & .Cells.Item(k, 6).Text & ",'TES')" & vbLf

                clsCom.GP_ExeSql(SQL_C)
            Next


            '/* Execute

        End With

        frmReport.ShowDialog()


        ' clsVAR.gv_Help(0).Help_str1 = "SJ"




    End Sub
   
    Private Sub FP_DETAIL()
        Dim IdModel As Integer

        SQL_C = ""
        SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "where SJXH_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
        SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")


                .Cells.Item(.RowCount - 1, 1).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")
                .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                '  .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("molh_idxx")







            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Sub FP_FILL()

        With spdHead_Sheet1.Cells
            txtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text
            dtSJ.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 2).Text
            txtCustomer.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 3).Text
            txtIdCustomer.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text
            txtNoPlat.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 5).Text
            txtJenisKendaraan.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 6).Text
            txtAlamat.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 7).Text
        End With

    End Sub
    Private Sub FP_HEAD()
        

        SQL_C = ""
        SQL_C += "SELECT sjxh_idxx,sjxh_noxx,convert(varchar(10),sjxh_date,111) tgl,cust_name,cust_addr,codd_valu,codd_desc,a.cust_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.SURAT_JALANH A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer B ON A.cust_idxx=B.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.CODE_COMMON C ON c.CODH_FLNM='CODE_MOBL' AND CODE_MOBL=codd_valu" & vbLf
        SQL_C += "where sjxh_idxx is not null" & vbLf

        If txtCustomerCari.Text <> "" Then
            SQL_C += "AND cust_name like '%" & txtCustomerCari.Text & "%'" & vbLf
        End If

        If txtModelCari.Text <> "" Then
            SQL_C += "AND sjxh_noxx like '%" & txtModelCari.Text & "%'" & vbLf
        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1


                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("sjxh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("tgl")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("cust_addr")







            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_DATA_MODEL()
        Dim IdModel As Integer

        SQL_C = ""
        SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "where prod_deli Is Not null And sjxh_idxx Is null " & vbLf
        SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModelUpdate_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mcom_idxx")


                .Cells.Item(.RowCount - 1, 2).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")
                .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                '  .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("molh_idxx")







            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Public Sub cmdInquery()

    End Sub
    Public Sub cmdDelete()
        'SQL_C = ""
        'SQL_C = SQL_C + "DELETE KKTERP.dbo.color  WHERE colr_idxx=" & txtCode.Text & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)
    End Sub
    Private Sub FP_INIT()
        'Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_MODIFY()
        'SQL_C = ""
        'SQL_C = SQL_C + "UPDATE KKTERP.dbo.color  SET colr_name='" & txtDesc.Text & "' WHERE colr_idxx=" & txtCode.Text & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)

    End Sub
    Public Sub cmdInsert()
        FP_CLEAR()
        FP_NOSJ()
    End Sub
    Private Sub FP_NOSJ()
        Dim IdSj, vBulan, vTahun As Integer

        Dim VROMAWI As String

        vBulan = Month(Now)
        vTahun = Year(Now)

        If vBulan = 1 Then
            vRomawi = "I"
        ElseIf vBulan = 2 Then
            vRomawi = "II"
        ElseIf vBulan = 3 Then
            vRomawi = "III"
        ElseIf vBulan = 4 Then
            vRomawi = "IV"
        ElseIf vBulan = 5 Then
            vRomawi = "V"
        ElseIf vBulan = 6 Then
            vRomawi = "VI"
        ElseIf vBulan = 7 Then
            vRomawi = "VII"
        ElseIf vBulan = 8 Then
            vRomawi = "VIII"
        ElseIf vBulan = 9 Then
            vRomawi = "IX"
        ElseIf vBulan = 10 Then
            vRomawi = "X"
        ElseIf vBulan = 11 Then
            vRomawi = "XI"
        ElseIf vBulan = 12 Then
            vRomawi = "XII"
        End If



       
        SQL_C = ""
        SQL_C += " SELECT IDENT_CURRENT('surat_jalanh') AS LastID" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        IdSj = clsCom.gv_DataRdr("LastID") + 1
        clsCom.gv_ExeSqlReaderEnd()

 

        txtSJ.Text = "KKTI/" & VROMAWI & "/" & vTahun & "/" & IdSj.ToString("D7")


    End Sub

    Private Sub frmSuratJalan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        FP_HEAD()
    End Sub

    Private Sub btnHelpCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpCustomer.Click
        frmHelpCustomer.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            txtIdCustomer.Text = .Help_str1
            txtCustomer.Text = .Help_str2
            txtAlamat.Text = .Help_str3

        End With



errHandle:
    End Sub

  
    Private Sub btnKendaraan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKendaraan.Click
        frmHelpKendaraan.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            txtNoPlat.Text = .Help_str1
            txtJenisKendaraan.Text = .Help_str2

        End With



errHandle:
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlModel.Visible = False
    End Sub

    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        pnlModel.Visible = True

        FP_DATA_MODEL()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim i As Integer

        SQL_C = ""
        SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.SURAT_JALANH where sjxh_noxx='" & txtSJ.Text & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.SURAT_JALANH (sjxh_noxx,sjxh_date,CODE_MOBL,cust_idxx) values ('" & txtSJ.Text & "','" & dtSJ.Value & "','" & txtNoPlat.Text & "'," & txtIdCustomer.Text & ")"

            clsCom.GP_ExeSql(SQL_C)

            With spdModelUpdate_Sheet1
                For i = 0 To .RowCount - 1

                    SQL_C = ""
                    SQL_C += "INSERT INTO KKTERP.dbo.SURAT_JALAND (sjxh_idxx,mcom_idxx) values (" & Val(Strings.Right(txtSJ.Text, 6)) & "," & spdModelUpdate_Sheet1.Cells.Item(i, 1).Text & ")"

                    clsCom.GP_ExeSql(SQL_C)

                    SQL_C = ""
                    SQL_C += "update KKTERP.dbo.production_good set sjxh_idxx=" & Val(Strings.Right(txtSJ.Text, 6)) & "  where prod_deli is not null and sjxh_idxx is null and mcom_idxx=" & spdModelUpdate_Sheet1.Cells.Item(i, 1).Text

                    clsCom.GP_ExeSql(SQL_C)

                Next

            End With
        Else
            clsCom.gv_ExeSqlReaderEnd()

            With spdModelUpdate_Sheet1
                For i = 0 To .RowCount - 1

                    SQL_C = ""
                    SQL_C += "SELECT count(*) qty FROM KKTERP.dbo.SURAT_JALAND where sjxh_idxx='" & txtSJ.Text & "' AND   mcom_idxx=" & spdModelUpdate_Sheet1.Cells.Item(i, 1).Text


                    clsCom.GP_ExeSqlReader(SQL_C)

                    clsCom.gv_DataRdr.Read()

                    If clsCom.gv_DataRdr("qty") = 0 Then
                        clsCom.gv_ExeSqlReaderEnd()

                        SQL_C = ""
                        SQL_C += "INSERT INTO KKTERP.dbo.SURAT_JALAND (sjxh_idxx,mcom_idxx) values (" & Val(Strings.Right(txtSJ.Text, 6)) & "," & spdModelUpdate_Sheet1.Cells.Item(i, 1).Text & ")"

                        clsCom.GP_ExeSql(SQL_C)

                    Else
                        clsCom.gv_ExeSqlReaderEnd()

                    End If

                   

                    SQL_C = ""
                    SQL_C += "update KKTERP.dbo.production_good set sjxh_idxx=" & Val(Strings.Right(txtSJ.Text, 6)) & "  where prod_deli is not null and sjxh_idxx is null and mcom_idxx=" & spdModelUpdate_Sheet1.Cells.Item(i, 1).Text

                    clsCom.GP_ExeSql(SQL_C)

                Next

            End With

        End If

        FP_HEAD()

        FP_HEAD_MODEL(Val(Strings.Right(txtSJ.Text, 6)))

        pnlModel.Visible = False
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

        With spdHead_Sheet1.Cells
            txtSJ.Text = .Item(e.Row, 1).Text
            dtSJ.Text = .Item(e.Row, 2).Text
            txtCustomer.Text = .Item(e.Row, 3).Text
            txtIdCustomer.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 4).Text
            txtNoPlat.Text = .Item(e.Row, 5).Text
            txtJenisKendaraan.Text = .Item(e.Row, 6).Text
            txtAlamat.Text = .Item(e.Row, 7).Text
        End With

        FP_HEAD_MODEL(Val(spdHead_Sheet1.Cells.Item(e.Row, 0).Text))
    End Sub

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        '  FP_FILL()
        FP_DETAIL()
    End Sub

    Private Sub spdDetail_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellClick

    End Sub

    Private Sub spdDetail_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellDoubleClick

    End Sub
End Class