﻿Public Class frmMaterialSPK
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_ALLKILO_HEADER()
        SQL_C = ""
        SQL_C += "SELECT distinct B.mate_idxx,mate_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_spkd A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_gramasi B ON A.mcom_idxx=B.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material C ON C.mate_idxx=B.mate_idxx" & vbLf
        SQL_C += "WHERE A.spkh_idxx = 1 " & vbLf
        SQL_C += "ORDER BY B.mate_idxx" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdAllKiloMaterial_Sheet1
            .ColumnCount = 5
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mate_name")
                ' .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_ALL_KILO()
        Dim i, j As Integer
        Dim TotalModel, TotalMaterial As Double

        SQL_C = ""
        SQL_C += "EXEC MATERIAL_KILO 6"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdAllKiloMaterial_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("colr_name")

                TotalModel = 0
                For i = 5 To .ColumnCount - 1

                    If clsCom.gv_DataRdr(i + 1) Is DBNull.Value Then

                    Else
                        .Cells.Item(.RowCount - 1, i).Text = clsCom.gv_DataRdr(i + 1)
                        TotalModel = TotalModel + clsCom.gv_DataRdr(i + 1)
                    End If

                Next
                .Cells.Item(.RowCount - 1, 4).Text = TotalModel


            End While

            For i = 4 To .ColumnCount - 1
                TotalMaterial = 0
                For j = 0 To .RowCount - 1

                    If .Cells.Item(j, i).Text <> "" Then
                        TotalMaterial = TotalMaterial + .Cells.Item(j, i).Text
                    End If
                Next
                .ColumnHeader.Cells.Item(1, i).Text = TotalMaterial
            Next

        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_KILO_DETAIL()
        Dim vTotal As Double

        vTotal = 0
        SQL_C = ""
        SQL_C += "SELECT B.mate_idxx,mate_name,gram_valu,spkd_batc,(gram_valu*spkd_batc)/1000 vkg" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_spkd A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_gramasi B ON A.mcom_idxx=B.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material C ON C.mate_idxx=B.mate_idxx" & vbLf
        SQL_C += "WHERE SPKD_IDXX =  " & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 0).Text

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdKilo_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mate_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mate_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vkg")
                vTotal = vTotal + clsCom.gv_DataRdr("vkg")


            End While
            .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = vTotal
            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_FILL_DETAIL()
        txtIdDetail.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 0).Text
        txtModel.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 5).Text
        txtBuyer.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 4).Text
        txtColor.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 6).Text
        txtComponent.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 3).Text
        txtBatch.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 8).Text
        txtIDMcom.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 9).Text
        cboMachine.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 1).Text & Space(100) & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 12).Text
        cboType.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 2).Text & Space(100) & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 10).Text
        cboSize.Text = spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 7).Text & Space(100) & spdDetail_Sheet1.Cells.Item(spdDetail_Sheet1.ActiveRowIndex, 11).Text
    End Sub
    Private Sub FP_LIST_DETAIL()

        SQL_C = ""
        SQL_C += "SELECT A.* ,model_name,brand_name,customer_name,vcomp,colr_name,C.codd_desc vtype,D.codd_desc vsize,mach_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_spkd A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "	SELECT mcom_idxx,model_name,brand_name,customer_name,codd_desc vcomp,colr_name" & vbLf
        SQL_C += "	FROM KKTERP.dbo.material_component A" & vbLf
        SQL_C += "	INNER JOIN KKTERP.dbo.model_color B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "	INNER JOIN KKTERP.dbo.vmodel C ON C.model_id =B.modl_idxx" & vbLf
        SQL_C += "	INNER JOIN  KKTERP.dbo.code_common D ON D.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "	INNER JOIN KKTERP.dbo.color E ON E.colr_idxx=B.colr_idxx" & vbLf
        SQL_C += ") B ON B.mcom_idxx=A.mcom_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_TSPK' AND A.CODE_TSPK=C.codd_valu" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_MSIZ' AND A.CODE_MSIZ=D.codd_valu" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.room_machine E ON E.mach_idxx=A.mach_idxx" & vbLf
        SQL_C += "WHERE spkh_idxx=" & spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 0).Text


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("spkd_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mach_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vtype")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vsize")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("spkd_batc")

                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("CODE_TSPK")
                .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("CODE_MSIZ")
                .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("mach_idxx")



            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()




    End Sub
    Private Sub FP_INSERT_DETAIL()

        'If txtIDSpk.Text = "" Then
        '    MsgBox("Lengkapi data anda")
        '    Exit Sub
        'End If

        If txtIdDetail.Text = "" Then
            SQL_C = ""
            SQL_C += "insert into KKTERP.dbo.material_spkd (spkh_idxx,mcom_idxx,spkd_batc,CODE_MSIZ,CODE_TSPK,mach_idxx) VALUES (" & spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 0).Text & "," & txtIDMcom.Text & "," & txtBatch.Text & ",'" & Strings.Trim(Strings.Right(cboSize.Text, 4)) & "'," & Strings.Trim(Strings.Right(cboType.Text, 4)) & "," & Strings.Trim(Strings.Right(cboMachine.Text, 4)) & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.material_spkd  SET spkd_batc=" & txtBatch.Text & ",CODE_MSIZ='" & Strings.Trim(Strings.Right(cboSize.Text, 4)) & "',CODE_TSPK=" & Strings.Trim(Strings.Right(cboType.Text, 4)) & ",mach_idxx=" & Strings.Trim(Strings.Right(cboMachine.Text, 4)) & ",mcom_idxx=" & txtIDMcom.Text & " where spkd_idxx=" & txtIdDetail.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

        pnlDetail.Visible = False
        FP_LIST_DETAIL()



    End Sub
    Private Sub FP_CBO_SIZE()


        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common where codh_flnm='CODE_MSIZ'" & vbLf




        clsCom.GP_ExeSqlReader(SQL_C)

        With cboSize
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_CBO_MACHINE()


        SQL_C = ""
        SQL_C += "select mach_idxx,mach_desc" & vbLf
        SQL_C += "from KKTERP.dbo.room_machine" & vbLf
        SQL_C += "where mach_idxx in (80,84,85)"



        clsCom.GP_ExeSqlReader(SQL_C)

        With cboMachine
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("mach_desc") & Space(100) & clsCom.gv_DataRdr("mach_idxx"))
            End While


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_FILL()
        txtIDSpk.Text = spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 0).Text
        dtSPK.Value = spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 1).Text
        cboPIC.Text = spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 3).Text & Space(100) & spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 5).Text
        cboShift.Text = spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 2).Text & Space(100) & spdHeader_Sheet1.Cells.Item(spdHeader_Sheet1.ActiveRowIndex, 4).Text
    End Sub
    Private Sub FP_LIST_HEADER()
        SQL_C = ""
        SQL_C += "SELECT A.spkh_idxx,CONVERT(VARCHAR(10),spkh_date,111) spkh_date,CODE_SHIF,CODE_PICX,B.codd_desc vShift,C.codd_desc vPIC" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_spkh A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_SHIF' AND B.codd_valu=CODE_SHIF" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_PICX' AND C.codd_valu=CODE_PICX" & vbLf
        SQL_C += "ORDER BY spkh_idxx DESC" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHeader_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("spkh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("spkh_date")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("vshift")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vPIC")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("CODE_SHIF")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("CODE_PICX")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_INSERT()

        'If txtIDSpk.Text = "" Then
        '    MsgBox("Lengkapi data anda")
        '    Exit Sub
        'End If

        If txtIDSpk.Text = "" Then
            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.material_spkh(spkh_date,CODE_SHIF,CODE_PICX) VALUES ('" & dtSPK.Value & "'," & Strings.Trim(Strings.Right(cboShift.Text, 4)) & "," & Strings.Trim(Strings.Right(cboPIC.Text, 4)) & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.material_spkh  SET spkh_date='" & dtSPK.Value & "',CODE_SHIF='" & Strings.Trim(Strings.Right(cboShift.Text, 4)) & "' where spkh_idxx=" & txtIDSpk.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

    End Sub
    Private Sub FP_COMBO_SHIFT()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common where codh_flnm='CODE_SHIF'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With cboShift
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_PIC()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common where codh_flnm='CODE_PICX'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With cboPIC
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_TYPE()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common where codh_flnm='CODE_TSPK'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With cboType
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
   

    Private Sub frmMaterialSPK_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_COMBO_SHIFT()
        FP_COMBO_PIC()
        FP_LIST_HEADER()
        FP_CBO_MACHINE()
        FP_COMBO_TYPE()
        FP_CBO_SIZE()
    End Sub

    Private Sub btnAddHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddHeader.Click
        pnlHeader.Visible = True
        pnlDetail.Visible = True
        pnlHeader.Visible = True
    End Sub

    Private Sub btnSaveSPK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSPK.Click
        FP_INSERT()
        pnlHeader.Visible = False
        FP_LIST_HEADER()

    End Sub

   

    Private Sub spdHeader_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHeader.CellDoubleClick
        FP_FILL()
        pnlHeader.Visible = True
    End Sub

    Private Sub spdHeader_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHeader.CellClick
        FP_LIST_DETAIL()
        FP_LIST_ALLKILO_HEADER()
        FP_ALL_KILO()
    End Sub

    Private Sub btnCLoseSPK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCLoseSPK.Click
        pnlHeader.Visible = False
    End Sub

    Private Sub btnDeleteSPK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteSPK.Click
        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.material_spkh    where spkh_idxx=" & txtIDSpk.Text

        clsCom.GP_ExeSql(SQL_C)

        pnlHeader.Visible = False
        FP_LIST_HEADER()

    End Sub

    Private Sub btnAddDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddDetail.Click
        pnlDetail.Visible = True
    End Sub

    Private Sub btnHelpModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpModel.Click
        frmHelpModelColorComponent.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIDMcom.Text = .Help_str1
            txtModel.Text = .Help_str4
            txtColor.Text = .Help_str5
            txtComponent.Text = .Help_str3
            txtBuyer.Text = .Help_str2


        End With
 

errHandle:
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveDetail.Click
        FP_INSERT_DETAIL()
    End Sub

    Private Sub btnCloseDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseDetail.Click
        pnlDetail.Visible = False
    End Sub

    Private Sub spdDetail_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellClick
        FP_KILO_DETAIL()
    End Sub

    Private Sub spdDetail_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellDoubleClick
        FP_FILL_DETAIL()
        pnlDetail.Visible = True
    End Sub
End Class