﻿Public Class frmSPKCP

    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold, vMcom As Integer
    Dim VROW, VCOL As Integer
    Dim vStatus As String
    Dim Vsize As String
    Private Sub FP_LIST_MOLD_SET()
        Dim Total_Set, Total_cavity As Integer

        SQL_C = ""
        SQL_C += "SELECT cell_xxxx,count(A.mols_size) vset,sum(mols_cavi) vcavity" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_spk A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_cell B ON A.cell_idxx=B.cell_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size C ON C.molh_idxx=A.molh_idxx AND C.mols_size=A.mols_size" & vbLf
        SQL_C += "WHERE subs_idxx=1 AND CODE_SHIF=1  AND CONVERT(VARCHAR(10),spkh_date,111)='2025/03/18'" & vbLf
        SQL_C += "group by cell_xxxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            Total_Set = 0
            While clsCom.gv_DataRdr.Read

                .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), 13).Text = clsCom.gv_DataRdr("vset")
                .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), 14).Text = clsCom.gv_DataRdr("vcavity")


                Total_Set = Total_Set + clsCom.gv_DataRdr("vset")
                Total_cavity = Total_cavity + clsCom.gv_DataRdr("vcavity")

            End While

            .ColumnHeader.Cells.Item(7, 13).Text = Total_Set
            .ColumnHeader.Cells.Item(7, 14).Text = Total_cavity

            '   .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()




    End Sub
    Private Sub FP_LIST_DETAIL()
        Dim WARNASEL1 As Color = Color.Turquoise
        Dim WARNASEL2 As Color = Color.Yellow
        Dim WARNASEL3 As Color = Color.Violet
        Dim WARNASEL4 As Color = Color.Tomato
        Dim WARNASEL5 As Color = Color.SlateGray
        Dim WARNASEL6 As Color = Color.RosyBrown
        Dim WARNASEL7 As Color = Color.Silver
        Dim WARNASEL8 As Color = Color.SpringGreen
        Dim WARNASEL9 As Color = Color.YellowGreen
        Dim WARNASEL10 As Color = Color.Orange
        Dim VAR_COLOR As Integer



        SQL_C = ""
        SQL_C += "SELECT model_name,colr_name,mols_size,cell_xxxx,cell_yyyy,A.mcom_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_spk A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_cell B ON A.cell_idxx=B.cell_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "WHERE subs_idxx=1 AND CODE_SHIF=1  AND CONVERT(VARCHAR(10),spkh_date,111)='2025/03/18'" & vbLf
        SQL_C += "ORDER BY A.mcom_idxx,mols_size"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1

            While clsCom.gv_DataRdr.Read

                .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).Text = clsCom.gv_DataRdr("colr_name")

                .ColumnHeader.Cells.Item(2, clsCom.gv_DataRdr("cell_yyyy")).Text = clsCom.gv_DataRdr("model_name")


                If Vsize = "" Then
                    VAR_COLOR = 1
                Else
                    If vMcom <> clsCom.gv_DataRdr("mcom_idxx") Or Vsize <> clsCom.gv_DataRdr("mols_size") Then
                        VAR_COLOR = VAR_COLOR + 1
                    End If
                End If



                If VAR_COLOR = 1 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL1
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL1

                ElseIf VAR_COLOR = 2 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL2
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL2

                ElseIf VAR_COLOR = 3 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL3
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL3

                ElseIf VAR_COLOR = 4 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL4
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL4

                ElseIf VAR_COLOR = 5 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL5
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL5

                ElseIf VAR_COLOR = 6 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL6
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL6

                ElseIf VAR_COLOR = 7 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL7
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL7

                ElseIf VAR_COLOR = 8 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL8
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL8

                ElseIf VAR_COLOR = 9 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL9
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL9

                ElseIf VAR_COLOR = 10 Then
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx"), clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL10
                    .Cells.Item(clsCom.gv_DataRdr("cell_xxxx") + 1, clsCom.gv_DataRdr("cell_yyyy")).BackColor = WARNASEL10


                End If




                vMcom = clsCom.gv_DataRdr("mcom_idxx")
                Vsize = clsCom.gv_DataRdr("mols_size")

            End While

            '   .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Private Sub FP_LIST_SIZE()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT molh_idxx,mols_size,mols_cavi " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size" & vbLf
        SQL_C += "WHERE molh_idxx=" & txtIDMold.Text
        SQL_C += "order by mols_seqn" & vbLf





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_CARI_CELL()
 
        SQL_C = ""
        SQL_C += "SELECT cell_idxx,mach_desc,subs_desc,cell_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.room_cell A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_machine B ON A.MACH_IDXX=B.MACH_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_subline C ON B.subs_idxx=C.subs_idxx" & vbLf
        SQL_C += "WHERE cell_xxxx = " & VROW & " And cell_yyyy = " & VCOL & " And B.subs_idxx = " & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text

        clsCom.GP_ExeSqlReader(SQL_C)

      
        clsCom.gv_DataRdr.Read()

        txtLine.Text = clsCom.gv_DataRdr("subs_desc")
        txtStation.Text = clsCom.gv_DataRdr("mach_desc")
        txtCell.Text = clsCom.gv_DataRdr("cell_desc")
        txtIdCell.Text = clsCom.gv_DataRdr("cell_idxx")

       

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_LINE()

        SQL_C = ""
        SQL_C += "SELECT subs_idxx,subs_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.room_subline A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_room B ON A.room_idxx=B.room_idxx" & vbLf
        SQL_C += "WHERE A.room_idxx = 2 "
 
        clsCom.GP_ExeSqlReader(SQL_C)

        With spdLine_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("subs_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("subs_desc")



            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SHIFT()


        SQL_C = ""
 
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_SHIF'" & vbLf

 
        clsCom.GP_ExeSqlReader(SQL_C)

        With spdShift_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
             


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmSPKCP_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_SHIFT()
        FP_LIST_LINE()
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        pnlCell.Visible = True
        FP_CARI_CELL()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        VROW = e.Row
        VCOL = e.Column

        If vStatus = "Duplicate" Then
            FP_CARI_CELL()

            SQL_C = ""
            ' SQL_C += "DELETE KKTERP.dbo.production_spk WHERE CONVERT(VARCHAR(10),spkh_date,111)=CONVERT(VARCHAR(10),'" & dtSPK.Value & "',111) AND CODE_SHIF=" & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & " AND subs_idxx=" & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & " AND cell_idxx=" & txtIdCell.Text

            SQL_C += "DELETE KKTERP.dbo.production_spk WHERE CONVERT(VARCHAR(10),spkh_date,111)='2025/03/18' AND CODE_SHIF=" & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & " AND subs_idxx=" & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & " AND cell_idxx=" & txtIdCell.Text

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_spk (spkh_date,CODE_SHIF,subs_idxx,cell_idxx,molh_idxx,mols_size,mcom_idxx)"
            '  SQL_C += "VALUES('" & dtSPK.Value & "', " & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & ", " & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & ", " & txtIdCell.Text & ", " & txtIDMold.Text & ", '" & txtSize.Text & "', " & txtIdMCom.Text & ")"
            SQL_C += "VALUES('2025/03/18', " & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & ", " & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & ", " & txtIdCell.Text & ", " & txtIDMold.Text & ", '" & txtSize.Text & "', " & txtIdMCom.Text & ")"

            clsCom.GP_ExeSql(SQL_C)

            FP_LIST_DETAIL()
        End If
    End Sub

    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        frmHelpModelColorComponent.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtComponent.Text = .Help_str3
            txtModel.Text = .Help_str4
            txtColor.Text = .Help_str5
            txtIDMold.Text = .Help_str6
            txtIdMCom.Text = .Help_str1



        End With

errHandle:
    End Sub

    Private Sub btnSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
        pnlSize.Visible = True
        FP_LIST_SIZE()
    End Sub
     

    Private Sub spdSize_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellDoubleClick
        txtSize.Text = spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text
        pnlSize.Visible = False
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        SQL_C = ""
        SQL_C += "INSERT INTO KKTERP.dbo.production_spk (spkh_date,CODE_SHIF,subs_idxx,cell_idxx,molh_idxx,mols_size,mcom_idxx)"
        ' SQL_C += "VALUES('" & dtSPK.Value & "', " & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & ", " & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & ", " & txtIdCell.Text & ", " & txtIDMold.Text & ", '" & txtSize.Text & "', " & txtIdMCom.Text & ")"

        SQL_C += "VALUES('" & dtSPK.Value & "', " & spdShift_Sheet1.Cells.Item(spdShift_Sheet1.ActiveRowIndex, 0).Text & ", " & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & ", " & txtIdCell.Text & ", " & txtIDMold.Text & ", '" & txtSize.Text & "', " & txtIdMCom.Text & ")"

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub spdLine_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdLine.CellClick
        FP_LIST_DETAIL()
        FP_LIST_MOLD_SET()
    End Sub

    Private Sub btnDuplicate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDuplicate.Click

        If VROW <> 0 And VROW <> 2 Then
            Exit Sub
        End If

        pnlCell.Visible = True
        vStatus = "Duplicate"



        SQL_C = ""
        SQL_C += "SELECT model_name,colr_name,cell_xxxx,cell_yyyy,A.cell_idxx,A.mcom_idxx,A.molh_idxx,A.mols_size " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_spk A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.room_cell B ON A.cell_idxx=B.cell_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "WHERE subs_idxx=1 AND CODE_SHIF=1  AND CONVERT(VARCHAR(10),spkh_date,111)='2025/03/18'" & vbLf
        SQL_C += "AND cell_xxxx=" & VROW & " AND cell_yyyy=" & VCOL

        clsCom.GP_ExeSqlReader(SQL_C)


        clsCom.gv_DataRdr.Read()

        txtIdCell.Text = clsCom.gv_DataRdr("cell_idxx")
        txtIdMCom.Text = clsCom.gv_DataRdr("mcom_idxx")
        txtIDMold.Text = clsCom.gv_DataRdr("molh_idxx")
        txtIdCell.Text = clsCom.gv_DataRdr("cell_idxx")
        txtSize.Text = clsCom.gv_DataRdr("mols_size")



        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub btnStopDuplicate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStopDuplicate.Click
        pnlCell.Visible = False
        vStatus = ""
    End Sub
End Class