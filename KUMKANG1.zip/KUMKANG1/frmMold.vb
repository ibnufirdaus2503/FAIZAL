﻿Public Class frmMold
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vRowProduct As String
    Dim vRowSize As String
    Private Sub FP_LIST_HEAD_MODEL()
        Dim SQL_C As String

 

        SQL_C = ""
        SQL_C += "SELECT B.modl_idxx,B.modl_name " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_model A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model B ON A.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "WHERE A.molh_idxx=" & txtIdMoldCode.Text


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("modl_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_MODEL()
        Dim SQL_C As String



        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.model" & vbLf
        SQL_C += "ORDER BY modl_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModelHelp_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("modl_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD_MOLDETAIL()
        Dim SQL_C As String

         

        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_detail" & vbLf
        SQL_C += "where molh_idxx='" & txtIdMoldCode.Text & "' and CODE_PROD='" & vRowProduct & "' AND mols_size='" & vRowSize & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMold_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mold_idxx")
                '  .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD_MOLDCODE()
        Dim SQL_C As String
        

        SQL_C = ""
        SQL_C += "select mols_size,mols_cavi" & vbLf
        SQL_C += "from KKTERP.dbo.mold_size" & vbLf
        SQL_C += "where molh_idxx=" & txtIdMoldCode.Text & " and CODE_PROD='" & vRowProduct & "'" & vbLf
        SQL_C += "ORDER BY mols_size" & vbLf

       


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_cavi")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub FP_LIST_HELP_MOLDCODE()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += " SELECT molh_idxx,molh_code from KKTERP.dbo.mold_header where cust_idxx=" & txtIdCustomer.Text & vbLf

        If txtMoldCodeHelpCari.Text <> "" Then
            SQL_C += "and molh_code like '%" & txtMoldCodeHelpCari.Text & "%'"
        End If
        SQL_C += "ORDER BY molh_code" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpMoldCode_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("molh_code")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD_PRODUCT()
       

        SQL_C = ""
        SQL_C += "select molh_idxx,CODE_PROD,codd_desc " & vbLf
        SQL_C += "from KKTERP.dbo.mold_product A" & vbLf
        SQL_C += "left join KKTERP.dbo.code_common B ON B.codh_flnm='CODE_PROD' and B.codd_valu=CODE_PROD" & vbLf
        SQL_C += "WHERE molh_idxx=" & txtIdMoldCode.Text & vbLf
        SQL_C += "ORDER BY B.codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProduct_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CODE_PROD")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_PRODUCT()
        SQL_C = ""
        SQL_C += "SELECT CODE_PROD,codd_desc " & vbLf
        SQL_C += "FROM KKTERP.dbo.customer_product A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_PROD' AND B.codd_valu=CODE_PROD" & vbLf
        SQL_C += "WHERE A.cust_idxx=" & txtIdCustomer.Text & vbLf
        SQL_C += "ORDER BY codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpProduct_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CODE_PROD")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_CUSTOMER()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT A.* ,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.CODH_FLNM='CODE_PROP' and B.codd_valu=CODE_PROP" & vbLf

        If txtCustomerHelpCari.Text <> "" Then
            SQL_C += "WHERE cust_name like '%" & txtCustomerHelpCari.Text & "%'"
        End If
        SQL_C += "ORDER BY A.cust_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpCustomer_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cust_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub frmMold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustomer.Click
        pnlHelpCustomer.Visible = True
        txtCustomerHelpCari.Text = ""
        FP_LIST_HELP_CUSTOMER()
    End Sub

    Private Sub btnHelpMoldCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpMoldCode.Click
        pnlHelpMoldCode.Visible = True
        txtMoldCodeHelpCari.Text = ""
        FP_LIST_HELP_MOLDCODE()
    End Sub

   

    Private Sub spdHelpCustomer_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpCustomer.CellDoubleClick
        txtCustomer.Text = spdHelpCustomer.ActiveSheet.Cells(e.Row, 1).Value
        txtIdCustomer.Text = spdHelpCustomer.ActiveSheet.Cells(e.Row, 0).Value
        pnlHelpCustomer.Visible = False

    End Sub

    Private Sub btnProduct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProduct.Click
        pnlHelpProduct.Visible = True
        FP_LIST_HELP_PRODUCT()
    End Sub

   

    Private Sub btnCariMoldCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariMoldCode.Click
        FP_LIST_HELP_PRODUCT()
    End Sub

    Private Sub spdHelpCustomer_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpCustomer.CellClick

    End Sub

    Private Sub spdHelpMoldCode_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpMoldCode.CellClick

    End Sub

    Private Sub spdHelpMoldCode_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpMoldCode.CellDoubleClick
        txtMoldCode.Text = spdHelpMoldCode.ActiveSheet.Cells(e.Row, 1).Value
        txtIdMoldCode.Text = spdHelpMoldCode.ActiveSheet.Cells(e.Row, 0).Value
        pnlHelpMoldCode.Visible = False

        FP_LIST_HEAD_PRODUCT()
        FP_LIST_HEAD_MODEL()
    End Sub

    

    Private Sub spdHelpProduct_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpProduct.CellDoubleClick


        If txtMoldCode.Text = "" And txtIdCustomer.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If

        If txtIdMoldCode.Text = "" Then





            SQL_C = ""
            SQL_C = SQL_C + "SELECT COUNT(*) QTY FROM KKTERP.dbo.molh_header WHERE mold_code='" & txtMoldCode.Text & "'"

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr.Item(0) = 0 Then
                clsCom.gv_ExeSqlReaderEnd()

                FP_INSERT_HEADER()
            End If



        End If

        clsCom.gv_ExeSqlReaderEnd()


        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.mold_product (molh_idxx,CODE_PROD) VALUES (" & txtIdMoldCode.Text & ",'" & spdHelpProduct.ActiveSheet.Cells(e.Row, 0).Value & "')"

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_HEAD_PRODUCT()

        pnlHelpProduct.Visible = False


    End Sub
    Private Sub FP_INSERT_HEADER()
        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.mold_header (cust_idxx,mold_code) VALUES (" & txtIdCustomer.Text & ",'" & txtMoldCode.Text & "')"

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C = SQL_C + "SELECT TOP 1 mold_idxx FROM KKTERP.dbo.molh_header ORDER BY molh_idxx DESC"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        txtIdMoldCode.Text = clsCom.gv_DataRdr.Item(0)
        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    
    Private Sub spdHelpProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpProduct.CellClick

    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    

    Private Sub btnSize_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
        pnlHelpSizeUpdate.Visible = True
    End Sub

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer
        With spdSizeUpdate_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text = "" Then
                    Exit Sub
                End If

                SQL_C = ""
                SQL_C = SQL_C + "insert into mold_size (molh_idxx,CODE_PROD,mols_size,mols_cavi) VALUES (" & txtIdMoldCode.Text & ",'" & spdProduct.ActiveSheet.Cells(vRowProduct, 0).Value & "','" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & ")"

                clsCom.GP_ExeSql(SQL_C)
            Next

        End With
    End Sub

    Private Sub spdProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellClick
        vRowProduct = spdProduct.ActiveSheet.Cells(e.Row, 0).Value
        FP_LIST_HEAD_MOLDCODE()
    End Sub

    Private Sub spdProduct_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellDoubleClick
        vRowProduct = spdHelpProduct.ActiveSheet.Cells(e.Row, 0).Value
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        pnlMold.Visible = True
    End Sub

    Private Sub btnSaveMold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMold.Click
        SQL_C = ""
        SQL_C = SQL_C + "insert into KKTERP.dbo.mold_detail (molh_idxx,CODE_PROD,mols_size,mold_idxx) VALUES (" & txtIdMoldCode.Text & ",'" & vRowProduct & "','" & vRowSize & "','" & txtIndexMold.Text & "')"

        clsCom.GP_ExeSql(SQL_C)
        pnlMold.Visible = False

        FP_LIST_HEAD_MOLDETAIL()

    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick
        vRowSize = spdSize.ActiveSheet.Cells(e.Row, 0).Value
        FP_LIST_HEAD_MOLDETAIL()
    End Sub

 
    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        pnlHelpModel.Visible = True
        FP_LIST_MODEL()
    End Sub

    Private Sub spdModelHelp_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModelHelp.CellClick

    End Sub

    Private Sub spdModelHelp_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModelHelp.CellDoubleClick
        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.mold_model (molh_idxx,modl_idxx) VALUES (" & txtIdMoldCode.Text & ",'" & spdModelHelp.ActiveSheet.Cells(e.Row, 0).Value & "')"


        clsCom.GP_ExeSql(SQL_C)

        pnlHelpModel.Visible = False
    End Sub

    Private Sub txtIdCustomer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtIdCustomer.TextChanged

    End Sub
End Class