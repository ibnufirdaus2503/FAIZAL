﻿Imports System.IO
Public Class frmCreateBarcode
    Dim filePath As String = "C:\barcode\barcode.txt"
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vSize As Integer
    Dim vLot As Integer
    Dim vPO As String
    Dim vModel_id As Integer
    Dim vColor_id As String
    Dim vMolh_id As Integer
    Dim vMcom_id As Integer
    Dim vMclr_Id As Integer
    Dim vQtty As Integer
    Dim Pcomponent As String
    Dim PLotEtd As String
    Dim PidBarcode As String
    Dim PMoldCode As String
    Dim PModel_Id As String
    Dim PModel_Name As String
    Dim PSize As String
    Dim PCustomerName As String









    Dim vSize_component As String
    Dim vCodeProd As String
    Private Sub FP_SIZE_GROUP()


        

        SQL_C = ""
        SQL_C += "SELECT A.*,isnull(qty_barcode,0) qty_barcode,isnull(qty_print,0) qty_print,ISNULL(isnull(qty_barcode,0)-isnull(qty_print,0),0) QTY_SISA" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,ISNULL(SUM(lotd_qtty),0) lotd_qtty" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT    mols_size,grop_size,CODE_SIZE" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size B ON mols_size=grop_size" & vbLf
        SQL_C += "WHERE molh_idxx = " & vMolh_id & " " & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT lotd_size,lotd_qtty" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot_size " & vbLf
        SQL_C += "WHERE lotx_idxx = " & vLot & "" & vbLf
        SQL_C += "		) B ON B.lotd_size=A.CODE_SIZE   " & vbLf
        SQL_C += "WHERE LOTD_QTTY Is Not NULL " & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  mols_size,count(*) qty_barcode" & vbLf
        SQL_C += "FROM KKTERP.dbo.PRODUCTION " & vbLf
        SQL_C += "WHERE lotx_idxx = " & vLot & "" & vbLf
        SQL_C += "group by mols_size" & vbLf
        SQL_C += ") B ON  B.mols_size=a.mols_size" & vbLf
        SQL_C += "   Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  mols_size,count(*) qty_print" & vbLf
        SQL_C += "FROM KKTERP.dbo.PRODUCTION " & vbLf
        SQL_C += "WHERE lotx_idxx = " & vLot & " And prod_prnt Is Not null " & vbLf
        SQL_C += "group by  mols_size" & vbLf
        SQL_C += ")C ON   C.mols_size=A.mols_size" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("lotd_qtty")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("qty_barcode")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("qty_print")

                If clsCom.gv_DataRdr("QTY_SISA") <> 0 Then
                    .Cells.Item(.RowCount - 1, 3).ForeColor = Color.Red
                End If




            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
   
    Private Sub FP_LIST_HEAD()
        Dim vId As Integer
        Dim vIdModel As Integer


        SQL_C = ""
        SQL_C += "SELECT ordh_idxx,ordh_poxx,convert(varchar(10),ordh_date,111) ordh_date,isnull(ordh_desc,'') ordh_desc," & vbLf
        SQL_C += "convert(varchar(10),ordh_etdh,111) ordh_etdh,ordh_nctr,convert(varchar(10),ordh_dctr,111) ordh_dctr,A.mclr_idxx," & vbLf
        SQL_C += "isnull(cust_name,'') customer_name, brand_name, modl_idxx,model_name, isnull(colr_name,'') colr_name,CODE_GEND," & vbLf
        SQL_C += "CODE_POXX,ISNULL(CODE_REAS,'') CODE_REAS ,D.codd_desc vTYPE_PO,ISNULL(E.codd_desc,'') vReason,isnull(C.CODD_DESC,'') VGENDER" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GEND' AND C.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_POXX' AND D.codd_valu=A.CODE_POXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_REAS' AND E.codd_valu=A.CODE_REAS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer F ON F.cust_idxx=A.cust_idxx" & vbLf

        'If txtCustomerCari.Text <> "" Then
        '    SQL_C += "AND cust_name like '%" & txtCustomerCari.Text & "%'" & vbLf
        'End If

        'If txtModelCari.Text <> "" Then
        '    SQL_C += "AND modl_name like '%" & txtModelCari.Text & "%'" & vbLf
        'End If

        'If txtColorCari.Text <> "" Then
        '    SQL_C += "AND colr_name like '%" & txtColorCari.Text & "%'" & vbLf
        'End If



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                vId = clsCom.gv_DataRdr("ordh_idxx")
                vIdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = vId.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_date")

                
                .Cells.Item(.RowCount - 1, 3).Text = vIdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("colr_name")
             
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vTYPE_PO")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vReason")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("customer_name")
               







                Dim i As Integer

                If clsCom.gv_DataRdr("CODE_POXX") = 2 Then
                    For i = 0 To .ColumnCount - 1
                        .Cells.Item(.RowCount - 1, i).BackColor = Color.Aquamarine
                    Next
                End If

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub



    'Private Sub FP_SIZE_GROUP()


    '    SQL_C = ""
    '    SQL_C += "SELECT A.grop_size,qty,ISNULL(qty_barcode,0) qty_barcode,ISNULL(qty_print,0)  qty_print,ISNULL(qty_barcode,0)-ISNULL(qty_print,0) QTY_SISA" & vbLf
    '    SQL_C += "FROM (" & vbLf
    '    SQL_C += "SELECT grop_size,sum(lotd_qtty) qty" & vbLf
    '    SQL_C += "FROM " & vbLf
    '    SQL_C += "(" & vbLf
    '    SQL_C += "SELECT DISTINCT  mols_size,grop_size,CODE_SIZE" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.mold_size A" & vbLf
    '    SQL_C += "INNER JOIN KKTERP.dbo.data_size B ON mols_size=grop_size" & vbLf
    '    SQL_C += "WHERE molh_idxx = " & vMolh_id & ") A" & vbLf
    '    SQL_C += "Left Join " & vbLf
    '    SQL_C += "(" & vbLf
    '    SQL_C += "SELECT lotd_size,lotd_qtty" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.order_lot_size " & vbLf
    '    SQL_C += "WHERE lotx_idxx = " & vLot & " " & vbLf
    '    SQL_C += ") B ON B.lotd_size=A.CODE_SIZE" & vbLf
    '    SQL_C += "where lotd_size Is Not null " & vbLf
    '    SQL_C += "group by grop_size" & vbLf
    '    SQL_C += ") A" & vbLf
    '    SQL_C += "Left Join " & vbLf
    '    SQL_C += "(" & vbLf
    '    SQL_C += "SELECT  mols_size,count(*) qty_barcode" & vbLf
    '    SQL_C += "FROM PRODUCTION WHERE   lotx_idxx=" & vLot & vbLf
    '    SQL_C += "group by lotx_idxx,mols_size" & vbLf
    '    SQL_C += ") B ON  B.mols_size=grop_size" & vbLf
    '    SQL_C += "Left Join " & vbLf
    '    SQL_C += "(" & vbLf
    '    SQL_C += "SELECT  mols_size,count(*) qty_print" & vbLf
    '    SQL_C += "FROM PRODUCTION WHERE   lotx_idxx=" & vLot & " and prod_prnt is not null" & vbLf
    '    SQL_C += "group by lotx_idxx,mols_size" & vbLf
    '    SQL_C += ")C ON   C.mols_size=grop_size" & vbLf

    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdSizeComponent_Sheet1
    '        .RowCount = 0
    '        While clsCom.gv_DataRdr.Read
    '            .RowCount = .RowCount + 1

    '            .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("grop_size")
    '            .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("qty")
    '            .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("qty_barcode")
    '            .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("qty_print")

    '            If clsCom.gv_DataRdr("QTY_SISA") <> 0 Then
    '                .Cells.Item(.RowCount - 1, 3).ForeColor = Color.Red
    '            End If




    '        End While

    '        .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()


    'End Sub
    'Private Sub FP_SIZE_SINGLE(ByVal vMcom_id As Integer)
    '    SQL_C = ""
    '    SQL_C += "select grop_seqn,lotd_size,lotd_qtty ," & vbLf
    '    SQL_C += "ISNULL(qty_print,0) qty_print,ISNULL(qty_barcode,0) qty_barcode,ISNULL(qty_barcode,0)-ISNULL(qty_print,0) vSisa " & vbLf
    '    SQL_C += "from order_lot_size A" & vbLf
    '    SQL_C += "        Left Join " & vbLf
    '    SQL_C += "	(" & vbLf
    '    SQL_C += "		SELECT lotx_idxx,mols_size,count(*) qty_barcode" & vbLf
    '    SQL_C += "		FROM PRODUCTION WHERE   lotx_idxx=" & vLot & " AND mcom_idxx=" & vMcom_id & "" & vbLf
    '    SQL_C += "		group by lotx_idxx,mols_size" & vbLf
    '    SQL_C += "	) E ON E.lotx_idxx=A.lotx_idxx AND E.mols_size=lotd_size" & vbLf
    '    SQL_C += "        Left Join " & vbLf
    '    SQL_C += "	(" & vbLf
    '    SQL_C += "		SELECT lotx_idxx,mols_size,count(*) qty_print" & vbLf
    '    SQL_C += "		FROM PRODUCTION WHERE   lotx_idxx=" & vLot & " and prod_prnt is not null AND mcom_idxx=" & vMcom_id & "" & vbLf
    '    SQL_C += "		group by lotx_idxx,mols_size" & vbLf
    '    SQL_C += "	) F ON F.lotx_idxx=A.lotx_idxx AND F.mols_size=lotd_size" & vbLf
    '    SQL_C += "INNER JOIN KKTERP.dbo.data_size B ON lotd_size=grop_size" & vbLf
    '    SQL_C += "        WHERE A.LOTX_IDXX = " & vlot & "" & vbLf
    '    SQL_C += "ORDER BY grop_seqn" & vbLf

    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdSizeComponent_Sheet1
    '        .RowCount = 0
    '        While clsCom.gv_DataRdr.Read
    '            .RowCount = .RowCount + 1



    '            .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("lotd_size")
    '            .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("lotd_qtty")
    '            .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("qty_barcode")
    '            .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("qty_print")

    '            If clsCom.gv_DataRdr("vsisa") <> 0 Then
    '                .Cells.Item(.RowCount - 1, 3).ForeColor = Color.Red
    '            End If


    '        End While

    '        .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()
    'End Sub
    Private Sub FP_SIZE_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT min(len(mols_size)) type_size" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size " & vbLf
        SQL_C += "WHERE molh_idxx =" & spdProduct_Sheet1.Cells.Item(spdProduct_Sheet1.ActiveRowIndex, 5).Text

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("type_size") = 1 Then
            clsCom.gv_ExeSqlReaderEnd()

            ' FP_SIZE_SINGLE()

        Else
            clsCom.gv_ExeSqlReaderEnd()

            FP_SIZE_GROUP()
        End If
    End Sub
    Private Sub FP_BALANCE()



      
        SQL_C = ""
        SQL_C += "SELECT COUNT(* ) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot_size" & vbLf

        SQL_C += "WHERE lotx_idxx IN(" & vbLf
        SQL_C += "Select lotx_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot " & vbLf
        SQL_C += "where  ordh_idxx='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'" & vbLf
        SQL_C += ")"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "SELECT ordd_size,ordd_qtyx,isnull(lotd_qtty,0) lotd_qtty,isnull(ordd_qtyx-lotd_qtty,0) vsisa" & vbLf
            SQL_C += "FROM " & vbLf
            SQL_C += "(" & vbLf
            SQL_C += "select ordd_size,ordd_qtyx" & vbLf
            SQL_C += "from KKTERP.dbo.order_detail A" & vbLf

            SQL_C += "where A.ordh_idxx='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'" & vbLf
            SQL_C += ") A" & vbLf
            SQL_C += "Left Join " & vbLf
            SQL_C += "(	SELECT lotd_size,lotd_qtty" & vbLf
            SQL_C += "FROM KKTERP.dbo.order_lot B   " & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.order_lot_size C ON B.lotx_idxx=C.lotx_idxx  " & vbLf
            SQL_C += "where B.ordh_idxx='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'" & vbLf
            SQL_C += ") B ON A.ordd_size=B.lotd_size" & vbLf
            SQL_C += "INNER JOIN KKTERP.dbo.data_size C ON A.ordd_size=grop_size" & vbLf
            SQL_C += "WHERE isnull(ordd_qtyx-lotd_qtty,0)<>0"
            SQL_C += "order by grop_seqn"

        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "select grop_seqn,ordd_size,ordd_qtyx vsisa" & vbLf
            SQL_C += "from KKTERP.dbo.order_detail A" & vbLf
            SQL_C += "INNER JOIN KKTERP.dbo.data_size B ON ordd_size=grop_size" & vbLf
            SQL_C += "where A.ordh_idxx='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "'" & vbLf
            SQL_C += "order by grop_seqn"
        End If

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdUpdateSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                ' .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                ' .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).ForeColor = Color.Red
                .Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("vsisa")
                .Cells.Item(1, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(1, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With
        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SIZE(ByVal vPO As String)
        Dim i, j As Integer

        SQL_C = ""

        SQL_C += "SELECT grop_seqn,ordd_size,ordd_qtyx,isnull(lotd_qtty,0) lotd_qtty,isnull(ordd_qtyx-lotd_qtty,0) vsisa" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select ordd_size,ordd_qtyx" & vbLf
        SQL_C += "from KKTERP.dbo.order_detail A" & vbLf
        SQL_C += "where A.ordh_idxx='" & vPO & "'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(	SELECT lotd_size,sum(lotd_qtty) lotd_qtty" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot B   " & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot_size C ON B.lotx_idxx=C.lotx_idxx  " & vbLf
        SQL_C += "where B.ordh_idxx='" & vPO & "'" & vbLf
        SQL_C += "group by lotd_size"
        SQL_C += ") B ON A.ordd_size=B.lotd_size" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size C ON ordd_size=grop_size" & vbLf
        SQL_C += "ORDER BY grop_seqn"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdOrderSize_Sheet1
            .ColumnCount = 2
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                .Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("lotd_qtty")
                .Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("vsisa")

                If clsCom.gv_DataRdr("vsisa") <> 0 Then
                    .Cells.Item(2, .ColumnCount - 1).ForeColor = Color.Red
                End If


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect

            Dim vTotal As Integer

            For i = 0 To .RowCount - 1
                vTotal = 0
                For j = 2 To .ColumnCount - 1
                    vTotal = vTotal + Val(.Cells.Item(i, j).Text)
                Next
                .Cells.Item(i, 1).Text = vTotal
            Next
        End With
        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_LOT(ByVal vPO As String)
        Dim vLOt As Integer

        SQL_C = ""
        SQL_C += "SELECT lotx_idxx,convert(varchar(10),lotx_etdx,111) etd FROM KKTERP.dbo.order_lot WHERE ordh_idxx='" & vPO & "'" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdLOT_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1


                vLOt = clsCom.gv_DataRdr("lotx_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = vLOt.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("etd")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_Barcode()
        Dim i As Integer
        Try

            With spdBarcode_Sheet1
                Using writer As New StreamWriter(filePath)
                    For i = 0 To .RowCount - 1

                        If .Cells.Item(i, 0).Value = True Then

                            SQL_C = ""
                            SQL_C += "update KKTERP.dbo.production set prod_prnt=getdate() where prod_idxx=" & Val(spdBarcode_Sheet1.Cells.Item(i, 1).Text) & ""
                            
                            clsCom.GP_ExeSql(SQL_C)


                           

                           
                            writer.WriteLine("^XA")
                            writer.WriteLine("^LH150,5")
                            writer.WriteLine("^FO0,10 ^GB540,380,4^FS")
                            writer.WriteLine("^FO0,10 ^GB540,50,4^FS")
                            writer.WriteLine("^FO0,55 ^GB540,60,4^FS")
                            writer.WriteLine("^FO0,55 ^GB200,60,4^FS")
                            writer.WriteLine("^FO0,111 ^GB150,60,4^FS")
                            writer.WriteLine("^FO0,167 ^GB540,60,4^FS")
                            writer.WriteLine("^FO0,225 ^GB100,163,4^FS")
                            writer.WriteLine("^FO270,225 ^GB270,163,4^FS")
                            writer.WriteLine("^FO10,23^A0N,30,20^FD^FS")
                            writer.WriteLine("^FO250,25^A0N,25,25^FD" & Now & "^FS")
                            writer.WriteLine("^FO10,70^A0N,35,35^FD^FS")
                            writer.WriteLine("^FO9,75^A0N,30,30^FD" & Pcomponent & "^FS") 'COMPONENT
                            writer.WriteLine("^FO205,75^A0N,30,30^FDETD:" & PLotEtd & "^FS") 'ETD
                            writer.WriteLine("^FO105,70^A0N,50,50^FD^FS")
                            writer.WriteLine("^FO105,115^A0N,20,20^FD^FS")
                            writer.WriteLine("^FO20,250")
                            writer.WriteLine("^BQN,4,3")
                            writer.WriteLine("^FDMM,0" & spdBarcode_Sheet1.Cells.Item(i, 1).Text & "^FS") 'BARCODE
                            writer.WriteLine("^FO290,320^A0N,25,25^FD" & PMoldCode & "^FS") 'MOLD CODE
                            writer.WriteLine("^FO105,320^A0N,25,25^FD" & spdBarcode_Sheet1.Cells.Item(i, 1).Text & "^FS") 'BARCODE
                            writer.WriteLine("^FO9,126^A0N,40,40^FD" & PModel_Id & "^FS")  'ID MODEL
                            writer.WriteLine("^FO155,126^A0N,40,40^FD" & PModel_Name & "^FS") 'NAMA MODEL
                            writer.WriteLine("^FO9,180^A0N,40,40^FD" & vColor_id & "^FS") 'WARNA
                            writer.WriteLine("^FO120,260^A0N,40,40^FD" & spdBarcode_Sheet1.Cells.Item(i, 2).Text & " PRS^FS")
                            writer.WriteLine("^FO290,260^A0N,50,50^FD" & vSize_component & "^FS") 'SIZE
                            writer.WriteLine("^FO5,25^A0N,25,25^FD" & PCustomerName & "^FS") 'CUSTOMER NAME
                            writer.WriteLine("^XZ")

                        End If


                    Next
                End Using
            End With

        Catch ex As Exception
            Console.WriteLine("Error writing file: " & ex.Message)
        End Try

        Dim sCommand As String
        sCommand = " print C:\barcode\barcode.txt"
        Call Shell("cmd.exe /c " & sCommand, vbHide)
    End Sub
    Private Sub FP_LIST_BARCODE()
        Dim vBarcode As Integer

        SQL_C = ""
        SQL_C += "select isnull(convert(varchar(10),prod_prnt,111),'') prod_prnt,prod_idxx,prod_qtty "
        SQL_C += "from KKTERP.dbo.production "
        SQL_C += "where lotx_idxx=" & vLot & "" & vbLf
        SQL_C += "AND prod_opcd='cmp' and   mols_size='" & vSize_component & "'  " & vbLf
        SQL_C += "and mcom_idxx= " & vMcom_id & " " & vbLf
        SQL_C += "and ordh_idxx='" & Val(vPO) & "'" & vbLf
        SQL_C += "order by  prod_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBarcode_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                vBarcode = clsCom.gv_DataRdr("prod_idxx")

                If clsCom.gv_DataRdr("prod_prnt") <> "" Then
                    .Cells.Item(.RowCount - 1, 1).BackColor = Color.Tomato
                    .Cells.Item(.RowCount - 1, 2).BackColor = Color.Tomato
                End If
                .Cells.Item(.RowCount - 1, 1).Text = vBarcode.ToString("D9")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("prod_qtty")


            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With
        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_PRODUCT(ByVal vlot As Integer)
        Dim SQL_C As String


         

        SQL_C = ""
        SQL_C += "SELECT A.*,ISNULL(QTY_BARCODE,0) QTY_BARCODE,ISNULL(qty_print,0) qty_print,isnull(qty_barcode,0)-isnull(qty_print,0) blm_print" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf

        SQL_C += "SELECT mcom_idxx,A.code_comp,A.mclr_idxx,molh_idxx,E.mast_idxx,modl_name,molh_code,codd_desc,molh_pack" & vbLf
        SQL_C += "FROM KKTERP.DBO.MATERIAL_COMPONENT A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.CODE_COMMON B ON B.CODH_FLNM='CODE_COMP' AND B.CODD_VALU=A.CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL_COLOR C ON A.MCLR_IDXX=C.MCLR_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL E ON E.MODL_IDXX=C.MODL_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MOLD_MASTER F ON E.MAST_IDXX=F.MAST_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MOLD_HEADER G ON G.MAST_IDXX=F.MAST_IDXX   AND A.CODE_COMP=G.CODE_COMP" & vbLf
        SQL_C += "WHERE A.MCLR_IDXX = " & Val(vMclr_Id) & vbLf


      
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mcom_idxx,count(*) qty_barcode " & vbLf
        SQL_C += "FROM PRODUCTION WHERE ordh_idxx=" & Val(vPO) & " AND lotx_idxx= " & Val(vlot) & vbLf
        SQL_C += "group by mcom_idxx" & vbLf
        SQL_C += ") B ON B.mcom_idxx=A.mcom_idxx" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mcom_idxx,count(*) qty_print" & vbLf
        SQL_C += "FROM PRODUCTION WHERE ordh_idxx=" & Val(vPO) & " AND lotx_idxx=" & Val(vlot) & " and prod_prnt is not null" & vbLf
        SQL_C += "group by mcom_idxx" & vbLf
        SQL_C += ") C ON C.mcom_idxx=A.mcom_idxx" & vbLf





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProduct_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("molh_pack")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("qty_barcode")

                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("qty_print")


                If clsCom.gv_DataRdr("blm_print") <> 0 Then
                    .Cells.Item(.RowCount - 1, 4).ForeColor = Color.Red
                End If
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("molh_code")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    'Private Sub FP_LIST_HEAD()
    '    Dim vModel As Integer
    '    Dim i As Integer


    '    SQL_C = ""
    '    SQL_C += "SELECT CODE_BRAN,cust_shrt,ordh_poxx,CONVERT(VARCHAR(10),ordh_date,111) ordh_date,CONVERT(VARCHAR(10),ordh_etdh,111) ordh_etdh,ordh_nctr, CONVERT(VARCHAR(10),ordh_dctr,111) ordh_dctr,A.cust_idxx,A.CODE_PROD,A.colr_idxx,A.modl_idxx,ordh_styl,ordh_desc,ordh_stat,cust_name,colr_name,modl_name,E.codd_desc vBran,F.codd_desc vProd,CODE_POXX" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.color B ON B.colr_idxx=A.colr_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.model C ON C.modl_idxx=A.modl_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.customer D ON D.cust_idxx=A.cust_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_BRAN' AND E.codd_valu=C.CODE_BRAN" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.code_common F ON F.codh_flnm='CODE_PROD' AND F.codd_valu=A.CODE_PROD" & vbLf



    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdHead_Sheet1
    '        .RowCount = 0
    '        While clsCom.gv_DataRdr.Read
    '            .RowCount = .RowCount + 1
    '            .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("ordh_poxx")
    '            .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_date")
    '            .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_etdh")
    '            .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_nctr")
    '            .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("ordh_dctr")
    '            .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("cust_name")
    '            .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("vBran")
    '            .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("vProd")
    '            .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("modl_name")
    '            .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("colr_name")
    '            ' .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("ordh_styl")
    '            .Cells.Item(.RowCount - 1, 11).Text = clsCom.gv_DataRdr("ordh_desc")

    '            .Cells.Item(.RowCount - 1, 12).Text = clsCom.gv_DataRdr("CODE_BRAN")
    '            .Cells.Item(.RowCount - 1, 13).Text = clsCom.gv_DataRdr("cust_idxx")
    '            .Cells.Item(.RowCount - 1, 14).Text = clsCom.gv_DataRdr("CODE_PROD")
    '            .Cells.Item(.RowCount - 1, 15).Text = clsCom.gv_DataRdr("colr_idxx")
    '            .Cells.Item(.RowCount - 1, 16).Text = clsCom.gv_DataRdr("modl_idxx")
    '            .Cells.Item(.RowCount - 1, 17).Text = clsCom.gv_DataRdr("cust_shrt")

    '            vModel = clsCom.gv_DataRdr("modl_idxx")
    '            .Cells.Item(.RowCount - 1, 18).Text = vModel.ToString("D4")

    '            If clsCom.gv_DataRdr("CODE_POXX") = 2 Then
    '                For i = 0 To .ColumnCount - 1
    '                    .Cells.Item(.RowCount - 1, i).BackColor = Color.Aquamarine
    '                Next


    '            ElseIf clsCom.gv_DataRdr("CODE_POXX") = 3 Then
    '                For i = 0 To .ColumnCount - 1
    '                    .Cells.Item(.RowCount - 1, i).BackColor = Color.Bisque
    '                Next


    '            End If



    '        End While

    '        .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()

    'End Sub
    Private Sub FP_LIST_SIZE_LOT(ByVal vLot As Integer)
        SQL_C = ""
        SQL_C += "select *  " & vbLf
        SQL_C += "from KKTERP.dbo.order_lot_size A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size B ON lotd_size=grop_size" & vbLf
        SQL_C += "WHERE LOTX_IDXX=" & vLot & vbLf
        SQL_C += "ORDER BY grop_seqn"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1



                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("lotd_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("lotd_qtty")


            End While

        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub frmCreateBarcode_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_HEAD()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick, spdHead.Click
        vColor_id = spdHead_Sheet1.Cells.Item(e.Row, 5).Text
        'vModel_id = spdHead_Sheet1.Cells.Item(e.Row, 16).Text
        vPO = spdHead_Sheet1.Cells.Item(e.Row, 0).Text
        vMclr_Id = spdHead_Sheet1.Cells.Item(e.Row, 8).Text
        PModel_Id = spdHead_Sheet1.Cells.Item(e.Row, 3).Text
        PModel_Name = spdHead_Sheet1.Cells.Item(e.Row, 4).Text
        PCustomerName = spdHead_Sheet1.Cells.Item(e.Row, 9).Text

        'vCodeProd = spdHead_Sheet1.Cells.Item(e.Row, 14).Text

        spdSize_Sheet1.RowCount = 0
        spdProduct_Sheet1.RowCount = 0
        spdSizeComponent_Sheet1.RowCount = 0
        spdBarcode_Sheet1.RowCount = 0
        'Try
        '    ' Your event handling code here
        'Finally
        '    spdLOT_Sheet1.RowCount = 0


        FP_LIST_SIZE(vPO)

        FP_LIST_LOT(vPO)


        'End Try

    End Sub

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Dim i, j As Integer
        Dim Sisa As Integer
        Dim qty_barcode As Integer

        SQL_C = ""
        SQL_C += "SELECT SUM(VSISA) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT ordd_size,ordd_qtyx,isnull(lotd_qtty,0) lotd_qtty,isnull(ordd_qtyx-lotd_qtty,0) vsisa" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select ordd_size,ordd_qtyx" & vbLf
        SQL_C += "from KKTERP.dbo.order_detail A" & vbLf
        SQL_C += "where A.ordh_idxx=" & Val(vPO) & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(	SELECT lotd_size,sum(lotd_qtty) lotd_qtty" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot B   " & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.order_lot_size C ON B.lotx_idxx=C.lotx_idxx  " & vbLf
        SQL_C += "where B.ordh_idxx=" & Val(vPO) & "" & vbLf
        SQL_C += "group by lotd_size" & vbLf
        SQL_C += ") B ON A.ordd_size=B.lotd_size" & vbLf
        SQL_C += ") A" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") > 0 Then
            MsgBox("Sisa Order Lot belum balance")
            clsCom.gv_ExeSqlReaderEnd()
            Exit Sub
        End If

        clsCom.gv_ExeSqlReaderEnd()

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.production WHERE lotx_idxx=" & Val(vLot) & " and ORDH_idxx=" & Val(vPO) & " AND mcom_idxx=" & vMcom_id

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") > 0 Then
            MsgBox("Sudah di Buat Barcode")
            clsCom.gv_ExeSqlReaderEnd()
            Exit Sub
        End If

        clsCom.gv_ExeSqlReaderEnd()

        With spdSizeComponent_Sheet1
            For i = 0 To .RowCount - 1
                Sisa = .Cells.Item(i, 1).Text Mod spdProduct_Sheet1.Cells.Item(spdProduct_Sheet1.ActiveRowIndex, 2).Text

                qty_barcode = (.Cells.Item(i, 1).Text - Sisa) / spdProduct_Sheet1.Cells.Item(spdProduct_Sheet1.ActiveRowIndex, 2).Text

                For j = 1 To qty_barcode

                    'SQL_C = ""
                    'SQL_C += "insert into KKTERP.dbo.production (prod_date,prod_opcd,prod_qtty,prod_hour,CODE_SHIF,mcom_idxx,mols_size,prod_grad,ordh_poxx)"
                    'SQL_C += "values (convert(varchar(10),getdate(),111),'CMP'," & spdProduct_Sheet1.Cells.Item(i, 2).Text & ",12,1," & spdProduct_Sheet1.Cells.Item(i, 0).Text & ",'" & .Cells.Item(i, 0).Text & "','A','" & spdHead_Sheet1.Cells.Item(i, 0).Text & "')"


                    SQL_C = ""
                    SQL_C += "insert into KKTERP.dbo.production (prod_date,prod_opcd,prod_qtty,prod_hour,CODE_SHIF,mcom_idxx,mols_size,prod_grad,ordh_idxx,lotx_idxx,molh_idxx,prod_updt)"
                    SQL_C += "values (convert(varchar(10),getdate(),111),'CMP'," & vQtty & ",12,1," & vMcom_id & ",'" & .Cells.Item(i, 0).Text & "','A'," & Val(vPO) & "," & Val(vLot) & "," & vMolh_id & ",getdate())"

                    clsCom.GP_ExeSql(SQL_C)
                Next

                'SQL_C = ""
                'SQL_C += "insert into KKTERP.dbo.production (prod_date,prod_opcd,prod_qtty,prod_hour,CODE_SHIF,mcom_idxx,mols_size,prod_grad,ordh_poxx,ordh_poxx)"
                'SQL_C += "values (convert(varchar(10),getdate(),111),'CMP'," & Sisa & ",12,1," & spdProduct_Sheet1.Cells.Item(i, 0).Text & ",'" & .Cells.Item(i, 0).Text & "','A','" & spdHead_Sheet1.Cells.Item(i, 0).Text & "')"

                If Sisa <> 0 Then
                    SQL_C = ""
                    SQL_C += "insert into KKTERP.dbo.production (prod_date,prod_opcd,prod_qtty,prod_hour,CODE_SHIF,mcom_idxx,mols_size,prod_grad,ordh_idxx,molh_idxx,prod_updt)"
                    SQL_C += "values (convert(varchar(10),getdate(),111),'CMP'," & Sisa & ",12,1," & vMcom_id & ",'" & .Cells.Item(i, 0).Text & "','A'," & Val(vPO) & "," & vMolh_id & ",getdate())"


                    clsCom.GP_ExeSql(SQL_C)
                End If

                Sisa = 0


            Next
        End With


        spdSizeComponent_Sheet1.RowCount = 0
        spdBarcode_Sheet1.RowCount = 0

        FP_LIST_PRODUCT(vLot)
    End Sub

    Private Sub spdProduct_ActiveSpreadViewChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles spdProduct.ActiveSpreadViewChanged

    End Sub

    Private Sub spdProduct_ButtonClicked(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs) Handles spdProduct.ButtonClicked

        FP_SIZE_COMPONENT()
    End Sub
 

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim folderInfo As New DirectoryInfo("C:\barcode")

        If Not folderInfo.Exists Then
            Directory.CreateDirectory("C:\barcode")
        End If



        If Not File.Exists(filePath) Then

            Try
                ' Create an empty file
                File.Create(filePath).Dispose()
                FP_Barcode()

            Catch ex As Exception
                MessageBox.Show("Error creating file: " & ex.Message)
            End Try
        Else
            File.WriteAllText(filePath, String.Empty)
            FP_Barcode()
        End If

        spdSizeComponent_Sheet1.RowCount = 0
        spdBarcode_Sheet1.RowCount = 0

        FP_LIST_PRODUCT(vLot)

    End Sub

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        Dim i As Integer

        With spdBarcode_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = True
            Next
        End With
    End Sub

    Private Sub btnUncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUncheck.Click
        Dim i As Integer

        With spdBarcode_Sheet1
            For i = 0 To .RowCount - 1
                .Cells.Item(i, 0).Value = False
            Next
        End With
    End Sub

    Private Sub btnAddLOT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddLOT.Click
        pnlLot.Visible = True
        Dim VLOT As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()
            VLOT = 1

            txtLOT.Text = VLOT.ToString("D7")

        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "SELECT TOP 1 lotx_idxx" & vbLf
            SQL_C += "FROM KKTERP.dbo.order_lot " & vbLf
            SQL_C += "ORDER BY lotx_idxx desc" & vbLf

            clsCom.GP_ExeSqlReader(SQL_C)

            clsCom.gv_DataRdr.Read()

            VLOT = clsCom.gv_DataRdr("lotx_idxx") + 1

            txtLOT.Text = VLOT.ToString("D7")

            clsCom.gv_ExeSqlReaderEnd()
        End If

       
        



    End Sub

    Private Sub btnSaveLot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveLot.Click
        SQL_C = ""
        SQL_C += "SELECT count(lotx_idxx) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_lot " & vbLf
        SQL_C += "WHERE   lotx_idxx=" & Val(Strings.Right(txtLOT.Text, 5))

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "insert into KKTERP.dbo.order_lot (lotx_etdx,ordh_idxx) values (convert(varchar(10),'" & dtETD.Value & "',111)," & Val(spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text) & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "update KKTERP.dbo.order_lot set lotx_etdx=convert(varchar(10),'" & dtETD.Value & "',111) WHERE lotx_idxx=" & Val(Strings.Right(txtLOT.Text, 6))

            clsCom.GP_ExeSql(SQL_C)

        End If

        FP_LIST_LOT(vPO)
        FP_LIST_SIZE_LOT(vLot)
        pnlLot.Visible = False
        
    End Sub

    Private Sub spdLOT_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdLOT.CellClick, spdLOT.Click
        vLot = spdLOT_Sheet1.Cells.Item(e.Row, 0).Text
        PLotEtd = spdLOT_Sheet1.Cells.Item(e.Row, 1).Text

        spdSizeComponent_Sheet1.RowCount = 0
        spdBarcode_Sheet1.RowCount = 0
        FP_LIST_PRODUCT(vLot)
        FP_LIST_SIZE_LOT(vLot)





    End Sub

    Private Sub spdLOT_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdLOT.CellDoubleClick

        pnlLot.Visible = True

        With spdLOT_Sheet1.Cells
            txtLOT.Text = .Item(spdLOT_Sheet1.ActiveRowIndex, 0).Text
            dtETD.Text = .Item(spdLOT_Sheet1.ActiveRowIndex, 1).Text

        End With


       
    End Sub

    Private Sub btnDelLot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelLot.Click

        SQL_C = ""
        SQL_C += "SELECT count(*) qty" & vbLf
        SQL_C += "FROM KKTERP.dbo.production " & vbLf
        SQL_C += "WHERE ordh_poxx='" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "' AND lotx_idxx=" & Val(Strings.Right(txtLOT.Text, 6)) & " AND prod_prnt is null"

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.prodduction WHERE lotx_idxx=" & Val(Strings.Right(txtLOT.Text, 6))

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.order_lot WHERE lotx_idxx=" & Val(Strings.Right(txtLOT.Text, 6))

            clsCom.GP_ExeSql(SQL_C)

            FP_LIST_LOT(vPO)
            FP_LIST_SIZE(vPO)
            spdSize_Sheet1.RowCount = 0
            pnlLot.Visible = False

        Else
            clsCom.gv_ExeSqlReaderEnd()

            MsgBox("Tidak bisa di hapus sudah print barcode")
            Exit Sub
        End If

        
    End Sub

    Private Sub btnCloseLot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseLot.Click
        pnlLot.Visible = False
    End Sub

    Private Sub btnLotSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLotSize.Click
        pnlHelpSizeUpdate.Visible = True
        FP_BALANCE()
    End Sub

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer



        With spdUpdateSize_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text <> "" Then
                     

                    SQL_C = ""
                    SQL_C += "insert into KKTERP.dbo.order_lot_size(lotx_idxx,lotd_size,lotd_qtty) values (" & Val(Strings.Right(spdLOT_Sheet1.Cells.Item(spdLOT_Sheet1.ActiveRowIndex, 0).Text, 5)) & ",'" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & ")"

                    clsCom.GP_ExeSql(SQL_C)
                End If
            Next


        End With
        pnlHelpSizeUpdate.Visible = False
        FP_LIST_SIZE(vPO)
        FP_LIST_SIZE_LOT(vLot)

    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    Private Sub btnBalance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FP_BALANCE()
    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick

    End Sub

    Private Sub spdSizeComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSizeComponent.CellClick
        If spdBarcode_Sheet1.RowCount = 0 Then
            spdBarcode_Sheet1.RowCount = 4
        Else
            spdBarcode_Sheet1.RowCount = 0
        End If
        vSize_component = spdSizeComponent_Sheet1.Cells.Item(e.Row, 0).Text

        FP_LIST_BARCODE()
    End Sub

    Private Sub spdHead_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles spdHead.Click
      


    End Sub

    Private Sub spdProduct_Change(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.ChangeEventArgs) Handles spdProduct.Change

    End Sub

    Private Sub spdProduct_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProduct.CellClick
        vMolh_id = spdProduct_Sheet1.Cells.Item(e.Row, 5).Text
        vMcom_id = spdProduct_Sheet1.Cells.Item(e.Row, 0).Text
        vQtty = spdProduct_Sheet1.Cells.Item(e.Row, 2).Text

        Pcomponent = spdProduct_Sheet1.Cells.Item(e.Row, 1).Text
        PMoldCode = spdProduct_Sheet1.Cells.Item(e.Row, 6).Text

        spdBarcode_Sheet1.RowCount = 0

        FP_SIZE_GROUP()
       


    End Sub

    Private Sub spdBarcode_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBarcode.CellClick

    End Sub
End Class