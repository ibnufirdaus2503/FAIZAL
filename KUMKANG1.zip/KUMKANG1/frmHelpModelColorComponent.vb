﻿Public Class frmHelpModelColorComponent
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_MODEL_COLOR()






        SQL_C = ""
        
        SQL_C += "SELECT mcom_idxx,model_name,brand_name,customer_name,codd_desc,colr_name,isnull(molh_idxx,'')  molh_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_component A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel C ON C.model_id =B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.code_common D ON D.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color E ON E.colr_idxx=B.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header F ON F.modl_idxx=B.modl_idxx AND F.CODE_COMP=A.CODE_COMP" & vbLf

        SQL_C += "WHERE mcom_idxx is not null" & vbLf

        If txtModel.Text <> "" Then
            SQL_C += "AND model_name like'%" & txtModel.Text & "%'"
        End If

        If txtColor.Text <> "" Then
            SQL_C += "AND colr_name like'%" & txtColor.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

   

    Private Sub spdModel_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdModel_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdModel_Sheet1.Cells.Item(e.Row, 1).Text
            .Help_str3 = spdModel_Sheet1.Cells.Item(e.Row, 2).Text
            .Help_str4 = spdModel_Sheet1.Cells.Item(e.Row, 3).Text
            .Help_str5 = spdModel_Sheet1.Cells.Item(e.Row, 4).Text
            .Help_str6 = spdModel_Sheet1.Cells.Item(e.Row, 5).Text
           

        End With

        Me.Close()
    End Sub

    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        FP_MODEL_COLOR()
    End Sub

    Private Sub spdModel_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellClick

    End Sub
End Class