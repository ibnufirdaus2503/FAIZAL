﻿Public Class frmClosingPO
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInsert()
        FP_CLEAR()


    End Sub
    Sub FP_CLEAR()
        Dim i, j As Integer

        With spdHead_Sheet1.Cells


            txtID.Text = ""
            txtIdSJ.Text = ""
            txtNoSJ.Text = ""
            txtDate.Text = ""
            txtNOPO.Text = ""
            txtCustomer.Text = ""
            txtIdModel.Text = ""
            txtModel.Text = ""
            txtColor.Text = ""
        End With

        With spdSizeComponentPO_Sheet1
            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    .Cells.Item(j, i).Text = ""
                Next
            Next
        End With

        With spdSizeSJ_Sheet1
            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    .Cells.Item(j, i).Text = ""
                Next
            Next
        End With

        With spdBalance_Sheet1
            For i = 0 To .ColumnCount - 1
                For j = 0 To .RowCount - 1
                    .Cells.Item(j, i).Text = ""
                    .Cells.Item(j, i).BackColor = Color.White

                Next
            Next
        End With
    End Sub



    Private Sub FP_BALANCE()
        Dim mcom_old, vcol, vrow As Integer
        Dim vFlag, vClose As Boolean

        vFlag = False

        SQL_C = ""
        SQL_C += "SELECT A.MOLH_IDXX,MOLH_CODE,CODD_DESC,A.MOLS_SIZE,QTY_ORDER,QTY_SJ,QTY_ORDER-QTY_SJ VBALANCE" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT MOLH_IDXX ,MOLH_CODE,CODD_DESC,MOLS_SIZE,SUM(ORDD_QTYX) QTY_ORDER" & vbLf
        SQL_C += "FROM" & vbLf
        SQL_C += "	(" & vbLf
        SQL_C += "	select c.MOLH_IDXX, MOLH_CODE,CODD_DESC,mols_size,GROP_SIZE,CODE_SIZE,GROP_SEQN" & vbLf
        SQL_C += "	from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "	LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "	left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "	LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "	LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "	LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "	INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "	where ordh_idxx=3 AND COD1_VALU='CP'" & vbLf
        SQL_C += "	) A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "		(" & vbLf
        SQL_C += "		SELECT * FROM KKTERP.dbo.order_Detail where ordh_idxx=3" & vbLf
        SQL_C += "		) B ON ORDD_SIZE=CODE_SIZE" & vbLf
        SQL_C += "WHERE ORDD_SIZE Is Not NULL " & vbLf
        SQL_C += "GROUP BY MOLH_IDXX,MOLH_CODE,CODD_DESC,MOLS_SIZE" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  MOLH_IDXX,mols_size,SUM(prod_qtty) QTY_SJ" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component D ON A.mcom_idxx=D.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color E ON E.mclr_idxx=D.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel F ON F.model_id =E.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color G ON G.colr_idxx=E.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "where SJXH_idxx = 4 " & vbLf
        SQL_C += "GROUP BY  MOLH_IDXX,CODD_DESC,A.mcom_idxx,grop_seqn,mols_size" & vbLf
        SQL_C += ") B ON A.MOLH_IDXX=B.MOLH_IDXX AND A.MOLS_SIZE=B.MOLS_SIZE" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBalance_Sheet1
            vClose = True


            mcom_old = 0
            While clsCom.gv_DataRdr.Read


                If mcom_old <> clsCom.gv_DataRdr("MOLH_IDXX") Then


                    vcol = 2
                    If vFlag = False Then
                        vrow = 0
                        vFlag = True
                    Else
                        vrow = 2

                    End If


                    .Cells.Item(vrow, 0).Text = clsCom.gv_DataRdr("MOLH_IDXX")
                    .Cells.Item(vrow, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, 1).Text = clsCom.gv_DataRdr("CODD_DESC")
                    .Cells.Item(vrow, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("vbalance")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    If clsCom.gv_DataRdr("vbalance") <> 0 Then
                        vClose = False
                        .Cells.Item(vrow + 1, vcol).BackColor = Color.Red
                    End If
                Else
                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("vbalance")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    If clsCom.gv_DataRdr("vbalance") <> 0 Then
                        vClose = False
                        .Cells.Item(vrow + 1, vcol).BackColor = Color.Red
                    End If
                End If


                vcol = vcol + 1
                mcom_old = clsCom.gv_DataRdr("MOLH_IDXX")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

        If vClose = False Then
            btnClose.Enabled = False
        Else
            btnClose.Enabled = True
        End If



    End Sub
    Private Sub FP_SIZE_ORDER_COMPONENT()
        Dim mcom_old, vrow, vcol As Integer

        Dim vFlag As Boolean

        vFlag = False

        SQL_C = ""
        SQL_C += "SELECT  MOLH_IDXX  ,MOLH_CODE,CODD_DESC,MOLS_SIZE,QTY,VSEQN" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT MOLH_IDXX ,MOLH_CODE,CODD_DESC,MOLS_SIZE,SUM(ORDD_QTYX) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select c.MOLH_IDXX, MOLH_CODE,CODD_DESC,mols_size,GROP_SIZE,CODE_SIZE,GROP_SEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx=" & txtID.Text & " AND COD1_VALU='CP'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT * FROM KKTERP.dbo.order_Detail where ordh_idxx=" & txtID.Text & vbLf
        SQL_C += ") B ON ORDD_SIZE=CODE_SIZE" & vbLf
        SQL_C += "WHERE ORDD_SIZE Is Not NULL " & vbLf
        SQL_C += "GROUP BY MOLH_IDXX,MOLH_CODE,CODD_DESC,MOLS_SIZE" & vbLf
        SQL_C += ") X" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "select  GROP_SIZE,MIN(GROP_SEQN) VSEQN" & vbLf
        SQL_C += "from KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew X ON A.mclr_idxx=X.mclr_idxx" & vbLf
        SQL_C += "left join KKTERP.dbo.model B ON X.modl_idxx=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.mold_header C ON b.modl_idxx=c.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON codh_flnm='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_size E ON E.molh_idxx=c.molh_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.data_size F ON mols_size=grop_size" & vbLf
        SQL_C += "where ordh_idxx=" & txtID.Text & " AND COD1_VALU='CP'" & vbLf
        SQL_C += "GROUP BY c.MOLH_IDXX, MOLH_CODE,CODD_DESC,GROP_SIZE" & vbLf
        SQL_C += ")" & vbLf
        SQL_C += "Y ON mols_size=GROP_SIZE   " & vbLf
        SQL_C += "ORDER BY  molh_idxx,VSEQN" & vbLf




        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeComponentPO_Sheet1

            mcom_old = 0
            While clsCom.gv_DataRdr.Read


                If mcom_old <> clsCom.gv_DataRdr("MOLH_IDXX") Then


                    vcol = 2
                    If vFlag = False Then
                        vrow = 0
                        vFlag = True
                    Else
                        vrow = 2

                    End If


                    .Cells.Item(vrow, 0).Text = clsCom.gv_DataRdr("MOLH_IDXX")
                    .Cells.Item(vrow, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, 1).Text = clsCom.gv_DataRdr("CODD_DESC")
                    .Cells.Item(vrow, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                Else
                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                End If


                vcol = vcol + 1
                mcom_old = clsCom.gv_DataRdr("MOLH_IDXX")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SIZE()
        Dim mcom_old, vrow, vcol As Integer

        Dim vFlag As Boolean

        vFlag = False

        SQL_C = ""
        SQL_C += "SELECT  CODD_DESC,A.mcom_idxx,isnull(grop_seqn,0) grop_seqn,mols_size,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component D ON A.mcom_idxx=D.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color E ON E.mclr_idxx=D.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel F ON F.model_id =E.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color G ON G.colr_idxx=E.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

        SQL_C += "where SJXH_idxx=" & txtIdSJ.Text & vbLf

        SQL_C += "GROUP BY  CODD_DESC,A.mcom_idxx,grop_seqn,mols_size" & vbLf
        SQL_C += "order by A.mcom_idxx,grop_seqn"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeSJ_Sheet1

            mcom_old = 0
            While clsCom.gv_DataRdr.Read


                If mcom_old <> clsCom.gv_DataRdr("mcom_idxx") Then


                    vcol = 2
                    If vFlag = False Then
                        vrow = 0
                        vFlag = True
                    Else
                        vrow = 2

                    End If


                    .Cells.Item(vrow, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                    .Cells.Item(vrow, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, 1).Text = clsCom.gv_DataRdr("CODD_DESC")
                    .Cells.Item(vrow, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                Else
                    .Cells.Item(vrow, vcol).Text = clsCom.gv_DataRdr("mols_size")
                    .Cells.Item(vrow, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(vrow + 1, vcol).Text = clsCom.gv_DataRdr("QTY")
                    .Cells.Item(vrow + 1, vcol).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(vrow + 1, vcol).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                End If


                vcol = vcol + 1
                mcom_old = clsCom.gv_DataRdr("mcom_idxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SIZE(ByVal vPO As Integer)
        SQL_C = ""
        SQL_C += "SELECT ordd_size,ordd_qtyx " & vbLf
        SQL_C += "FROM KKTERP.dbo.order_detail A" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=ordd_size AND CODE_SIZE=ordd_size" & vbLf
        SQL_C += "WHERE ordh_idxx='" & vPO & "'" & vbLf
        SQL_C += "ORDER BY grop_seqn"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            .RowCount = 1
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_HEAD()
        Dim Id_Model, Id_PO As Integer


        SQL_C = ""
        SQL_C += "SELECT ordh_idxx,ordh_poxx,convert(varchar(10),ordh_date,111) ordh_date,isnull(ordh_desc,'') ordh_desc," & vbLf
        SQL_C += "convert(varchar(10),ordh_etdh,111) ordh_etdh,ordh_nctr,convert(varchar(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "customer_name, brand_name, modl_idxx,model_name, colr_name,CODE_GEND," & vbLf
        SQL_C += "CODE_POXX,ISNULL(CODE_REAS,'') CODE_REAS ,D.codd_desc vTYPE_PO,ISNULL(E.codd_desc,'') vReason,isnull(C.CODD_DESC,'') VGENDER," & vbLf
        SQL_C += "A.SJXH_IDXX,SJXH_NOXX,CONVERT(VARCHAR(10),SJXH_dATE,111) TGL" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GEND' AND C.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_POXX' AND D.codd_valu=A.CODE_POXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_REAS' AND E.codd_valu=A.CODE_REAS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.SURAT_JALANH F ON F.SJXH_IDXX=A.SJXH_IDXX" & vbLf
        SQL_C += "WHERE A.SJXH_IDXX Is Not NULL " & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                Id_Model = clsCom.gv_DataRdr("modl_idxx")
                Id_PO = clsCom.gv_DataRdr("ordh_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = Id_PO.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("TGL")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 5).Text = Id_Model.ToString("D4")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("sjxh_idxx")







            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub frmClosingPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_HEAD()
    End Sub
    'Private Sub FP_DETAIL()
    '    Dim IdModel As Integer

    '    SQL_C = ""
    '    SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
    '    SQL_C += "where SJXH_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
    '    SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdDetail_Sheet1
    '        .RowCount = 0
    '        While clsCom.gv_DataRdr.Read

    '            .RowCount = .RowCount + 1
    '            .RowHeader.Rows.Item(.RowCount - 1).Height = 40

    '            IdModel = clsCom.gv_DataRdr("modl_idxx")
    '            .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")


    '            .Cells.Item(.RowCount - 1, 1).Text = IdModel.ToString("D4")
    '            .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
    '            .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

    '            .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
    '            .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

    '            .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
    '            .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
    '            .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
    '            .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
    '            .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")
    '            .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
    '            .Cells.Item(.RowCount - 1, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
    '            '  .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("molh_idxx")







    '        End While

    '        ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()

    'End Sub
    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

        FP_CLEAR()

        With spdHead_Sheet1.Cells


            txtID.Text = .Item(e.Row, 0).Text
            txtIdSJ.Text = .Item(e.Row, 8).Text
            txtNoSJ.Text = .Item(e.Row, 1).Text
            txtDate.Text = .Item(e.Row, 2).Text
            txtNOPO.Text = .Item(e.Row, 3).Text
            txtCustomer.Text = .Item(e.Row, 4).Text
            txtIdModel.Text = .Item(e.Row, 5).Text
            txtModel.Text = .Item(e.Row, 6).Text
            txtColor.Text = .Item(e.Row, 7).Text
        End With

      

        FP_SIZE_ORDER_COMPONENT()
        FP_SIZE()

        FP_BALANCE()

        btnClose.Enabled = False
    End Sub

    Private Sub btnPO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPO.Click
        frmHelpPO.ShowDialog()

        On Error GoTo errHandle
        FP_CLEAR()

        With clsVAR.gv_Help(0)
            txtID.Text = .Help_str1
            txtNOPO.Text = .Help_str2
            txtModel.Text = .Help_str6
            txtIdModel.Text = .Help_str5
            txtColor.Text = .Help_str7
            txtCustomer.Text = .Help_str4




            FP_LIST_SIZE(.Help_str1)


        End With


        FP_SIZE_ORDER_COMPONENT()



errHandle:
    End Sub


    Private Sub btnSJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSJ.Click
        frmHelpSJ.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            ' txtIdModel.Text = .Help_str2
            txtNoSJ.Text = .Help_str1
            txtDate.Text = .Help_str2

            txtIdSJ.Text = .Help_str3

            '  FP_LIST_SIZE(.Help_str1)


        End With



        FP_SIZE()

        FP_BALANCE()


errHandle:
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        If txtID.Text = "" Then
            MsgBox("Pilih PO dahulu")
            Exit Sub
        End If

        If txtIdSJ.Text = "" Then
            MsgBox("Pilih SJ dahulu")
            Exit Sub
        End If

        If txtNOPO.Text = "" Then
            MsgBox("NO PO Tidak boleh kosong")
            Exit Sub
        End If


        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.DBO.order_header where ordh_idxx='" & txtID.Text & "' and sjxh_idxx is not null"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") <> 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            MsgBox("Sudah di Close")
            Exit Sub
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "UPDATE KKTERP.DBO.order_header SET sjxh_idxx=" & txtIdSJ.Text & ",ordh_poxx='" & txtNOPO.Text & "',ordh_date='" & txtDate.Text & "',ordh_dcls=getdate() where ordh_idxx=" & txtID.Text

            clsCom.GP_ExeSql(SQL_C)

        End If

        FP_HEAD()
    End Sub
End Class