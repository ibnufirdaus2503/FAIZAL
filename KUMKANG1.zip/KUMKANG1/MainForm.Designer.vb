﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.StatusStrip = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ToolStrip = New System.Windows.Forms.ToolStrip
        Me.cmd_ADD = New System.Windows.Forms.ToolStripButton
        Me.cmd_MODIFY = New System.Windows.Forms.ToolStripButton
        Me.cmd_DELETE = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_QUERY = New System.Windows.Forms.ToolStripButton
        Me.cmd_PRINT = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_SHEETADD = New System.Windows.Forms.ToolStripButton
        Me.cmd_SHEETDEL = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.cmd_EXIT = New System.Windows.Forms.ToolStripButton
        Me.lblUser = New System.Windows.Forms.Label
        Me.StatusStrip.SuspendLayout()
        Me.ToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 414)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1027, 22)
        Me.StatusStrip.TabIndex = 9
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1027, 24)
        Me.MenuStrip1.TabIndex = 10
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStrip
        '
        Me.ToolStrip.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ToolStrip.GripMargin = New System.Windows.Forms.Padding(2, 2, 500, 2)
        Me.ToolStrip.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmd_ADD, Me.cmd_MODIFY, Me.cmd_DELETE, Me.ToolStripSeparator1, Me.cmd_QUERY, Me.cmd_PRINT, Me.ToolStripSeparator2, Me.cmd_SHEETADD, Me.cmd_SHEETDEL, Me.ToolStripSeparator3, Me.cmd_EXIT})
        Me.ToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Size = New System.Drawing.Size(1027, 39)
        Me.ToolStrip.TabIndex = 11
        Me.ToolStrip.Text = "ToolStrip"
        '
        'cmd_ADD
        '
        Me.cmd_ADD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_ADD.Image = CType(resources.GetObject("cmd_ADD.Image"), System.Drawing.Image)
        Me.cmd_ADD.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_ADD.Name = "cmd_ADD"
        Me.cmd_ADD.Size = New System.Drawing.Size(36, 36)
        Me.cmd_ADD.Text = "INSERT"
        '
        'cmd_MODIFY
        '
        Me.cmd_MODIFY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_MODIFY.Image = CType(resources.GetObject("cmd_MODIFY.Image"), System.Drawing.Image)
        Me.cmd_MODIFY.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_MODIFY.Name = "cmd_MODIFY"
        Me.cmd_MODIFY.Size = New System.Drawing.Size(36, 36)
        Me.cmd_MODIFY.Text = "UPDATE"
        '
        'cmd_DELETE
        '
        Me.cmd_DELETE.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_DELETE.Image = CType(resources.GetObject("cmd_DELETE.Image"), System.Drawing.Image)
        Me.cmd_DELETE.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_DELETE.Name = "cmd_DELETE"
        Me.cmd_DELETE.Size = New System.Drawing.Size(36, 36)
        Me.cmd_DELETE.Text = "DELETE"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_QUERY
        '
        Me.cmd_QUERY.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_QUERY.Image = CType(resources.GetObject("cmd_QUERY.Image"), System.Drawing.Image)
        Me.cmd_QUERY.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_QUERY.Name = "cmd_QUERY"
        Me.cmd_QUERY.Size = New System.Drawing.Size(36, 36)
        Me.cmd_QUERY.Text = "INQUERY"
        '
        'cmd_PRINT
        '
        Me.cmd_PRINT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_PRINT.Image = CType(resources.GetObject("cmd_PRINT.Image"), System.Drawing.Image)
        Me.cmd_PRINT.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_PRINT.Name = "cmd_PRINT"
        Me.cmd_PRINT.Size = New System.Drawing.Size(36, 36)
        Me.cmd_PRINT.Text = "PRINT"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_SHEETADD
        '
        Me.cmd_SHEETADD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_SHEETADD.Image = CType(resources.GetObject("cmd_SHEETADD.Image"), System.Drawing.Image)
        Me.cmd_SHEETADD.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_SHEETADD.Name = "cmd_SHEETADD"
        Me.cmd_SHEETADD.Size = New System.Drawing.Size(36, 36)
        Me.cmd_SHEETADD.Text = "Insert  Cell"
        '
        'cmd_SHEETDEL
        '
        Me.cmd_SHEETDEL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_SHEETDEL.Image = CType(resources.GetObject("cmd_SHEETDEL.Image"), System.Drawing.Image)
        Me.cmd_SHEETDEL.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_SHEETDEL.Name = "cmd_SHEETDEL"
        Me.cmd_SHEETDEL.Size = New System.Drawing.Size(36, 36)
        Me.cmd_SHEETDEL.Text = "Delete Cell"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 39)
        '
        'cmd_EXIT
        '
        Me.cmd_EXIT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cmd_EXIT.Image = CType(resources.GetObject("cmd_EXIT.Image"), System.Drawing.Image)
        Me.cmd_EXIT.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmd_EXIT.Name = "cmd_EXIT"
        Me.cmd_EXIT.Size = New System.Drawing.Size(36, 36)
        Me.cmd_EXIT.Text = "Log out"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Location = New System.Drawing.Point(874, 40)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(0, 13)
        Me.lblUser.TabIndex = 12
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1027, 436)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.ToolStrip)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.StatusStrip)
        Me.IsMdiContainer = True
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MainForm"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents cmd_ADD As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_MODIFY As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_DELETE As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_QUERY As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_PRINT As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_SHEETADD As System.Windows.Forms.ToolStripButton
    Friend WithEvents cmd_SHEETDEL As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmd_EXIT As System.Windows.Forms.ToolStripButton
    Friend WithEvents lblUser As System.Windows.Forms.Label
End Class
