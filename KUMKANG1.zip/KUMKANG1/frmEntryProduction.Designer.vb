﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEntryProduction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.cboProductCari = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.dtContract = New System.Windows.Forms.DateTimePicker
        Me.spdRoom = New FarPoint.Win.Spread.FpSpread
        Me.spdRoom_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdCell = New FarPoint.Win.Spread.FpSpread
        Me.spdCell_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Panel2.SuspendLayout()
        CType(Me.spdRoom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdRoom_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCell, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCell_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.dtContract)
        Me.Panel2.Controls.Add(Me.cboProductCari)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Location = New System.Drawing.Point(12, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1341, 36)
        Me.Panel2.TabIndex = 11
        '
        'cboProductCari
        '
        Me.cboProductCari.BackColor = System.Drawing.SystemColors.Info
        Me.cboProductCari.FormattingEnabled = True
        Me.cboProductCari.Location = New System.Drawing.Point(283, 6)
        Me.cboProductCari.Name = "cboProductCari"
        Me.cboProductCari.Size = New System.Drawing.Size(48, 21)
        Me.cboProductCari.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(253, 11)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Shift"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Date SPK"
        '
        'dtContract
        '
        Me.dtContract.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtContract.Location = New System.Drawing.Point(70, 8)
        Me.dtContract.Name = "dtContract"
        Me.dtContract.Size = New System.Drawing.Size(166, 20)
        Me.dtContract.TabIndex = 52
        '
        'spdRoom
        '
        Me.spdRoom.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdRoom.BackColor = System.Drawing.SystemColors.Control
        Me.spdRoom.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdRoom.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdRoom.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdRoom.HorizontalScrollBar.TabIndex = 8
        Me.spdRoom.Location = New System.Drawing.Point(12, 46)
        Me.spdRoom.Name = "spdRoom"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdRoom.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdRoom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdRoom.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdRoom_Sheet1})
        Me.spdRoom.Size = New System.Drawing.Size(186, 490)
        Me.spdRoom.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdRoom.TabIndex = 35
        Me.spdRoom.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdRoom.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdRoom.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdRoom.VerticalScrollBar.TabIndex = 9
        Me.spdRoom.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdRoom_Sheet1
        '
        Me.spdRoom_Sheet1.Reset()
        Me.spdRoom_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdRoom_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdRoom_Sheet1.ColumnCount = 2
        Me.spdRoom_Sheet1.RowCount = 1
        Me.spdRoom_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdRoom_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "LINE/ROOM"
        Me.spdRoom_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdRoom_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdRoom_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdRoom_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdRoom_Sheet1.Columns.Get(1).Label = "LINE/ROOM"
        Me.spdRoom_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdRoom_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdRoom_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdRoom_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdRoom_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, "
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdHead.HorizontalScrollBar.TabIndex = 26
        Me.spdHead.Location = New System.Drawing.Point(200, 48)
        Me.spdHead.Name = "spdHead"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = ""
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer2
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = ""
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer2
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(474, 488)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 36
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdHead.VerticalScrollBar.TabIndex = 27
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 9
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Product"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Model"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Total"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Id Brand"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Id Product"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Id Color"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Id Model"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHead_Sheet1.Columns.Get(1).Label = "Product"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 75.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "Model"
        Me.spdHead_Sheet1.Columns.Get(2).Width = 118.0!
        Me.spdHead_Sheet1.Columns.Get(3).Label = "Color"
        Me.spdHead_Sheet1.Columns.Get(3).Width = 107.0!
        Me.spdHead_Sheet1.Columns.Get(4).Label = "Total"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 47.0!
        Me.spdHead_Sheet1.Columns.Get(6).Label = "Id Product"
        Me.spdHead_Sheet1.Columns.Get(6).Width = 83.0!
        Me.spdHead_Sheet1.Columns.Get(8).Label = "Id Model"
        Me.spdHead_Sheet1.Columns.Get(8).Width = 83.0!
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdCell
        '
        Me.spdCell.AccessibleDescription = "FpSpread3, Sheet1, Row 0, Column 0, "
        Me.spdCell.BackColor = System.Drawing.SystemColors.Control
        Me.spdCell.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdCell.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdCell.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdCell.HorizontalScrollBar.TabIndex = 12
        Me.spdCell.Location = New System.Drawing.Point(675, 48)
        Me.spdCell.Name = "spdCell"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdCell.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdCell.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdCell.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdCell_Sheet1})
        Me.spdCell.Size = New System.Drawing.Size(678, 75)
        Me.spdCell.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdCell.TabIndex = 42
        Me.spdCell.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdCell.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdCell.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdCell.VerticalScrollBar.TabIndex = 13
        Me.spdCell.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdCell_Sheet1
        '
        Me.spdCell_Sheet1.Reset()
        Me.spdCell_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdCell_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdCell_Sheet1.ColumnCount = 2
        Me.spdCell_Sheet1.RowCount = 1
        Me.spdCell_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdCell_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "CELL"
        Me.spdCell_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdCell_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdCell_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdCell_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdCell_Sheet1.Columns.Get(1).Label = "CELL"
        Me.spdCell_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdCell_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdCell_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdCell_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdCell_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmEntryProduction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.spdCell)
        Me.Controls.Add(Me.spdHead)
        Me.Controls.Add(Me.spdRoom)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "frmEntryProduction"
        Me.Text = "Entry Production"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.spdRoom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdRoom_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCell, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCell_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cboProductCari As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtContract As System.Windows.Forms.DateTimePicker
    Friend WithEvents spdRoom As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdRoom_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdCell As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdCell_Sheet1 As FarPoint.Win.Spread.SheetView
End Class
