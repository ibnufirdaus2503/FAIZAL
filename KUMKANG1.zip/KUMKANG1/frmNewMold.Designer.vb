﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewMold
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim ButtonCellType5 As FarPoint.Win.Spread.CellType.ButtonCellType = New FarPoint.Win.Spread.CellType.ButtonCellType
        Dim EnhancedScrollBarRenderer11 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle21 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle22 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle23 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer6 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle24 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType6 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer12 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtMoldShopCari = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtKontrakCari = New System.Windows.Forms.TextBox
        Me.txtSJCari = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtModelCari = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtCustomerCari = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.spdHead = New FarPoint.Win.Spread.FpSpread
        Me.spdHead_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.pnlUpdateSize = New System.Windows.Forms.Panel
        Me.txtAlias = New System.Windows.Forms.TextBox
        Me.btnCloseSet = New System.Windows.Forms.Button
        Me.btnDeleteSet = New System.Windows.Forms.Button
        Me.btnSaveSet = New System.Windows.Forms.Button
        Me.txtSetMold = New System.Windows.Forms.TextBox
        Me.lblSize = New System.Windows.Forms.Label
        Me.txtCodeVendorCustomer = New System.Windows.Forms.TextBox
        Me.txtIdPengirim = New System.Windows.Forms.TextBox
        Me.btnPengirim = New System.Windows.Forms.Button
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtPengirim = New System.Windows.Forms.TextBox
        Me.txtIdHeader = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.cboActivity = New System.Windows.Forms.ComboBox
        Me.dtKontrak = New System.Windows.Forms.DateTimePicker
        Me.txtKontrak = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.cboType = New System.Windows.Forms.ComboBox
        Me.dtSJ = New System.Windows.Forms.DateTimePicker
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtSJ = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.spdDetail = New FarPoint.Win.Spread.FpSpread
        Me.spdDetail_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlUpdateMold = New System.Windows.Forms.Panel
        Me.btnCariModel = New System.Windows.Forms.Button
        Me.txtModelHelpCari = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.spdHelpComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdHelpSize = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnHelpUpdateSize = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.pnlUpdateSize.SuspendLayout()
        CType(Me.spdDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdDetail_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlUpdateMold.SuspendLayout()
        CType(Me.spdHelpComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = "EnhancedColumnHeaderRenderer8"
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = "EnhancedRowHeaderRenderer8"
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer10.Name = "EnhancedColumnHeaderRenderer10"
        EnhancedColumnHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer10.TextRotationAngle = 0
        EnhancedRowHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer10.Name = "EnhancedRowHeaderRenderer10"
        EnhancedRowHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer10.TextRotationAngle = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.txtMoldShopCari)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.txtKontrakCari)
        Me.Panel1.Controls.Add(Me.txtSJCari)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.txtModelCari)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.txtCustomerCari)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1344, 56)
        Me.Panel1.TabIndex = 7
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(10, 29)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(53, 13)
        Me.Label21.TabIndex = 43
        Me.Label21.Text = "Moldshop"
        '
        'txtMoldShopCari
        '
        Me.txtMoldShopCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtMoldShopCari.Enabled = False
        Me.txtMoldShopCari.Location = New System.Drawing.Point(63, 27)
        Me.txtMoldShopCari.Name = "txtMoldShopCari"
        Me.txtMoldShopCari.Size = New System.Drawing.Size(174, 20)
        Me.txtMoldShopCari.TabIndex = 40
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(400, 29)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(64, 13)
        Me.Label20.TabIndex = 39
        Me.Label20.Text = "No. Kontrak"
        '
        'txtKontrakCari
        '
        Me.txtKontrakCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtKontrakCari.Enabled = False
        Me.txtKontrakCari.Location = New System.Drawing.Point(469, 26)
        Me.txtKontrakCari.Name = "txtKontrakCari"
        Me.txtKontrakCari.Size = New System.Drawing.Size(174, 20)
        Me.txtKontrakCari.TabIndex = 38
        '
        'txtSJCari
        '
        Me.txtSJCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtSJCari.Enabled = False
        Me.txtSJCari.Location = New System.Drawing.Point(470, 3)
        Me.txtSJCari.Name = "txtSJCari"
        Me.txtSJCari.Size = New System.Drawing.Size(174, 20)
        Me.txtSJCari.TabIndex = 37
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(384, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 36
        Me.Label13.Text = "No. Surat Jalan"
        '
        'txtModelCari
        '
        Me.txtModelCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtModelCari.Location = New System.Drawing.Point(714, 3)
        Me.txtModelCari.Name = "txtModelCari"
        Me.txtModelCari.Size = New System.Drawing.Size(174, 20)
        Me.txtModelCari.TabIndex = 26
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(676, 6)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Model"
        '
        'txtCustomerCari
        '
        Me.txtCustomerCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtCustomerCari.Enabled = False
        Me.txtCustomerCari.Location = New System.Drawing.Point(63, 4)
        Me.txtCustomerCari.Name = "txtCustomerCari"
        Me.txtCustomerCari.Size = New System.Drawing.Size(174, 20)
        Me.txtCustomerCari.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(10, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = " "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Customer"
        '
        'spdHead
        '
        Me.spdHead.AccessibleDescription = "spdHead, Sheet1, Row 0, Column 0, 0"
        Me.spdHead.BackColor = System.Drawing.SystemColors.Control
        Me.spdHead.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdHead.HorizontalScrollBar.TabIndex = 6
        Me.spdHead.Location = New System.Drawing.Point(12, 74)
        Me.spdHead.Name = "spdHead"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.Renderer = EnhancedColumnHeaderRenderer10
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.Renderer = EnhancedRowHeaderRenderer10
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdHead.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdHead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHead.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHead_Sheet1})
        Me.spdHead.Size = New System.Drawing.Size(617, 287)
        Me.spdHead.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHead.TabIndex = 25
        Me.spdHead.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHead.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHead.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdHead.VerticalScrollBar.TabIndex = 7
        Me.spdHead.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHead_Sheet1
        '
        Me.spdHead_Sheet1.Reset()
        Me.spdHead_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHead_Sheet1.ColumnCount = 11
        Me.spdHead_Sheet1.RowCount = 1
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 0).Value = 0
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 2).Value = 2
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 3).Value = 3
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 4).Value = 4
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 5).Value = 5
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 6).Value = 6
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 7).Value = 7
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 8).Value = 8
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 9).Value = 9
        Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHead_Sheet1.Cells.Get(0, 10).ParseFormatString = "n"
        Me.spdHead_Sheet1.Cells.Get(0, 10).Value = 10
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Tgl. Surat Jalan"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Surat Jalan"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Tgl. Kontrak"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "No. Kontrak"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "PT. Pengirim"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "TYPE"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Activity"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "id Pengirim"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "CODE TYPE"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "CODE ACTV"
        Me.spdHead_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "Id Header"
        Me.spdHead_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHead_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHead_Sheet1.Columns.Get(0).Label = "Tgl. Surat Jalan"
        Me.spdHead_Sheet1.Columns.Get(0).Width = 89.0!
        Me.spdHead_Sheet1.Columns.Get(1).Label = "Surat Jalan"
        Me.spdHead_Sheet1.Columns.Get(1).Width = 117.0!
        Me.spdHead_Sheet1.Columns.Get(2).Label = "Tgl. Kontrak"
        Me.spdHead_Sheet1.Columns.Get(2).Width = 69.0!
        Me.spdHead_Sheet1.Columns.Get(3).Label = "No. Kontrak"
        Me.spdHead_Sheet1.Columns.Get(3).Width = 152.0!
        Me.spdHead_Sheet1.Columns.Get(4).Label = "PT. Pengirim"
        Me.spdHead_Sheet1.Columns.Get(4).Width = 169.0!
        Me.spdHead_Sheet1.Columns.Get(5).Label = "TYPE"
        Me.spdHead_Sheet1.Columns.Get(5).Width = 95.0!
        Me.spdHead_Sheet1.Columns.Get(6).Label = "Activity"
        Me.spdHead_Sheet1.Columns.Get(6).Width = 89.0!
        Me.spdHead_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHead_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHead_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHead_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.txtCodeVendorCustomer)
        Me.Panel2.Controls.Add(Me.txtIdPengirim)
        Me.Panel2.Controls.Add(Me.btnPengirim)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.txtPengirim)
        Me.Panel2.Controls.Add(Me.txtIdHeader)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.cboActivity)
        Me.Panel2.Controls.Add(Me.dtKontrak)
        Me.Panel2.Controls.Add(Me.txtKontrak)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.cboType)
        Me.Panel2.Controls.Add(Me.dtSJ)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.txtSJ)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Location = New System.Drawing.Point(12, 364)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(617, 209)
        Me.Panel2.TabIndex = 27
        '
        'pnlUpdateSize
        '
        Me.pnlUpdateSize.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlUpdateSize.Controls.Add(Me.txtAlias)
        Me.pnlUpdateSize.Controls.Add(Me.btnCloseSet)
        Me.pnlUpdateSize.Controls.Add(Me.btnDeleteSet)
        Me.pnlUpdateSize.Controls.Add(Me.btnSaveSet)
        Me.pnlUpdateSize.Controls.Add(Me.txtSetMold)
        Me.pnlUpdateSize.Controls.Add(Me.lblSize)
        Me.pnlUpdateSize.Location = New System.Drawing.Point(83, 28)
        Me.pnlUpdateSize.Name = "pnlUpdateSize"
        Me.pnlUpdateSize.Size = New System.Drawing.Size(166, 84)
        Me.pnlUpdateSize.TabIndex = 36
        Me.pnlUpdateSize.Visible = False
        '
        'txtAlias
        '
        Me.txtAlias.Location = New System.Drawing.Point(75, 3)
        Me.txtAlias.Name = "txtAlias"
        Me.txtAlias.Size = New System.Drawing.Size(36, 20)
        Me.txtAlias.TabIndex = 54
        '
        'btnCloseSet
        '
        Me.btnCloseSet.Location = New System.Drawing.Point(112, 48)
        Me.btnCloseSet.Name = "btnCloseSet"
        Me.btnCloseSet.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseSet.TabIndex = 6
        Me.btnCloseSet.Text = "Close"
        Me.btnCloseSet.UseVisualStyleBackColor = True
        '
        'btnDeleteSet
        '
        Me.btnDeleteSet.Location = New System.Drawing.Point(58, 48)
        Me.btnDeleteSet.Name = "btnDeleteSet"
        Me.btnDeleteSet.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteSet.TabIndex = 5
        Me.btnDeleteSet.Text = "Delete"
        Me.btnDeleteSet.UseVisualStyleBackColor = True
        '
        'btnSaveSet
        '
        Me.btnSaveSet.Location = New System.Drawing.Point(3, 48)
        Me.btnSaveSet.Name = "btnSaveSet"
        Me.btnSaveSet.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveSet.TabIndex = 4
        Me.btnSaveSet.Text = "Save"
        Me.btnSaveSet.UseVisualStyleBackColor = True
        '
        'txtSetMold
        '
        Me.txtSetMold.BackColor = System.Drawing.SystemColors.Info
        Me.txtSetMold.Location = New System.Drawing.Point(5, 25)
        Me.txtSetMold.Name = "txtSetMold"
        Me.txtSetMold.Size = New System.Drawing.Size(158, 20)
        Me.txtSetMold.TabIndex = 2
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.Location = New System.Drawing.Point(2, 6)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(27, 13)
        Me.lblSize.TabIndex = 0
        Me.lblSize.Text = "Size"
        '
        'txtCodeVendorCustomer
        '
        Me.txtCodeVendorCustomer.Location = New System.Drawing.Point(289, 86)
        Me.txtCodeVendorCustomer.Name = "txtCodeVendorCustomer"
        Me.txtCodeVendorCustomer.Size = New System.Drawing.Size(36, 20)
        Me.txtCodeVendorCustomer.TabIndex = 60
        '
        'txtIdPengirim
        '
        Me.txtIdPengirim.Location = New System.Drawing.Point(289, 112)
        Me.txtIdPengirim.Name = "txtIdPengirim"
        Me.txtIdPengirim.Size = New System.Drawing.Size(36, 20)
        Me.txtIdPengirim.TabIndex = 57
        '
        'btnPengirim
        '
        Me.btnPengirim.Location = New System.Drawing.Point(284, 138)
        Me.btnPengirim.Name = "btnPengirim"
        Me.btnPengirim.Size = New System.Drawing.Size(41, 23)
        Me.btnPengirim.TabIndex = 56
        Me.btnPengirim.Text = ">>"
        Me.btnPengirim.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(38, 144)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(67, 13)
        Me.Label18.TabIndex = 55
        Me.Label18.Text = "PT. Pengirim"
        '
        'txtPengirim
        '
        Me.txtPengirim.BackColor = System.Drawing.SystemColors.Info
        Me.txtPengirim.Location = New System.Drawing.Point(108, 141)
        Me.txtPengirim.Name = "txtPengirim"
        Me.txtPengirim.Size = New System.Drawing.Size(174, 20)
        Me.txtPengirim.TabIndex = 54
        '
        'txtIdHeader
        '
        Me.txtIdHeader.Location = New System.Drawing.Point(289, 9)
        Me.txtIdHeader.Name = "txtIdHeader"
        Me.txtIdHeader.Size = New System.Drawing.Size(36, 20)
        Me.txtIdHeader.TabIndex = 53
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(64, 33)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 13)
        Me.Label17.TabIndex = 52
        Me.Label17.Text = "Activity"
        '
        'cboActivity
        '
        Me.cboActivity.BackColor = System.Drawing.SystemColors.Info
        Me.cboActivity.FormattingEnabled = True
        Me.cboActivity.Location = New System.Drawing.Point(109, 28)
        Me.cboActivity.Name = "cboActivity"
        Me.cboActivity.Size = New System.Drawing.Size(174, 21)
        Me.cboActivity.TabIndex = 51
        '
        'dtKontrak
        '
        Me.dtKontrak.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtKontrak.Location = New System.Drawing.Point(109, 119)
        Me.dtKontrak.Name = "dtKontrak"
        Me.dtKontrak.Size = New System.Drawing.Size(174, 20)
        Me.dtKontrak.TabIndex = 49
        '
        'txtKontrak
        '
        Me.txtKontrak.BackColor = System.Drawing.SystemColors.Info
        Me.txtKontrak.Location = New System.Drawing.Point(109, 97)
        Me.txtKontrak.Name = "txtKontrak"
        Me.txtKontrak.Size = New System.Drawing.Size(174, 20)
        Me.txtKontrak.TabIndex = 48
        Me.txtKontrak.Text = "KN/MSI/II/2025/01"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 122)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(95, 13)
        Me.Label16.TabIndex = 47
        Me.Label16.Text = "Tgl. Habis Kontrak"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(41, 100)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(64, 13)
        Me.Label15.TabIndex = 46
        Me.Label15.Text = "No. Kontrak"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 12)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 13)
        Me.Label9.TabIndex = 45
        Me.Label9.Text = "Type New Mold"
        '
        'cboType
        '
        Me.cboType.BackColor = System.Drawing.SystemColors.Info
        Me.cboType.FormattingEnabled = True
        Me.cboType.Location = New System.Drawing.Point(109, 5)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(174, 21)
        Me.cboType.TabIndex = 44
        '
        'dtSJ
        '
        Me.dtSJ.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtSJ.Location = New System.Drawing.Point(108, 74)
        Me.dtSJ.Name = "dtSJ"
        Me.dtSJ.Size = New System.Drawing.Size(174, 20)
        Me.dtSJ.TabIndex = 28
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 78)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 13)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "Tgl. Surat Jalan"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(45, 55)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Surat Jalan"
        '
        'txtSJ
        '
        Me.txtSJ.BackColor = System.Drawing.SystemColors.Info
        Me.txtSJ.Location = New System.Drawing.Point(109, 52)
        Me.txtSJ.Name = "txtSJ"
        Me.txtSJ.Size = New System.Drawing.Size(174, 20)
        Me.txtSJ.TabIndex = 8
        Me.txtSJ.Text = "SJ/MSI/II/2025/01"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(10, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = " "
        '
        'spdDetail
        '
        Me.spdDetail.AccessibleDescription = "spdDetail, Sheet1, Row 0, Column 0, "
        Me.spdDetail.BackColor = System.Drawing.SystemColors.Control
        Me.spdDetail.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdDetail.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdDetail.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdDetail.HorizontalScrollBar.TabIndex = 4
        Me.spdDetail.Location = New System.Drawing.Point(631, 216)
        Me.spdDetail.Name = "spdDetail"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer13.Name = ""
        EnhancedColumnHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer13.TextRotationAngle = 0
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer13
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer13.Name = ""
        EnhancedRowHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer13.TextRotationAngle = 0
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer13
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdDetail.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdDetail.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdDetail.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdDetail_Sheet1})
        Me.spdDetail.Size = New System.Drawing.Size(725, 360)
        Me.spdDetail.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdDetail.TabIndex = 28
        Me.spdDetail.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdDetail.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdDetail.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdDetail.VerticalScrollBar.TabIndex = 5
        Me.spdDetail.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdDetail_Sheet1
        '
        Me.spdDetail_Sheet1.Reset()
        Me.spdDetail_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdDetail_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdDetail_Sheet1.ColumnCount = 1
        Me.spdDetail_Sheet1.RowCount = 30
        Me.spdDetail_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdDetail_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "SIZE RUN"
        Me.spdDetail_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdDetail_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdDetail_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdDetail_Sheet1.Columns.Get(0).Label = "SIZE RUN"
        Me.spdDetail_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdDetail_Sheet1.Columns.Get(0).Width = 68.0!
        Me.spdDetail_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdDetail_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdDetail_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdDetail_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdComponent
        '
        Me.spdComponent.AccessibleDescription = "spdComponent, Sheet1, Row 0, Column 0, 0"
        Me.spdComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdComponent.HorizontalScrollBar.TabIndex = 26
        Me.spdComponent.Location = New System.Drawing.Point(635, 74)
        Me.spdComponent.Name = "spdComponent"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer11.Name = ""
        EnhancedColumnHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer11.TextRotationAngle = 0
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer11
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer11.Name = ""
        EnhancedRowHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer11.TextRotationAngle = 0
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer11
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdComponent_Sheet1})
        Me.spdComponent.Size = New System.Drawing.Size(721, 136)
        Me.spdComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdComponent.TabIndex = 35
        Me.spdComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdComponent.VerticalScrollBar.TabIndex = 27
        Me.spdComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdComponent_Sheet1
        '
        Me.spdComponent_Sheet1.Reset()
        Me.spdComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdComponent_Sheet1.ColumnCount = 7
        Me.spdComponent_Sheet1.RowCount = 1
        Me.spdComponent_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdComponent_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdComponent_Sheet1.Cells.Get(0, 0).Value = 0
        Me.spdComponent_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdComponent_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdComponent_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdComponent_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdComponent_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdComponent_Sheet1.Cells.Get(0, 3).Value = 2
        Me.spdComponent_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdComponent_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdComponent_Sheet1.Cells.Get(0, 4).Value = 3
        Me.spdComponent_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdComponent_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdComponent_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdComponent_Sheet1.Cells.Get(0, 5).Value = 4
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Model"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Brand"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Component"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Mold Code"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "QTY SET"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "ADD"
        Me.spdComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdComponent_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdComponent_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdComponent_Sheet1.Columns.Get(1).Label = "Model"
        Me.spdComponent_Sheet1.Columns.Get(1).Width = 111.0!
        Me.spdComponent_Sheet1.Columns.Get(3).Label = "Component"
        Me.spdComponent_Sheet1.Columns.Get(3).Width = 120.0!
        Me.spdComponent_Sheet1.Columns.Get(4).Label = "Mold Code"
        Me.spdComponent_Sheet1.Columns.Get(4).Width = 193.0!
        Me.spdComponent_Sheet1.Columns.Get(5).Label = "QTY SET"
        Me.spdComponent_Sheet1.Columns.Get(5).Width = 43.0!
        ButtonCellType5.ButtonColor2 = System.Drawing.SystemColors.ButtonFace
        ButtonCellType5.Text = ": : :"
        Me.spdComponent_Sheet1.Columns.Get(6).CellType = ButtonCellType5
        Me.spdComponent_Sheet1.Columns.Get(6).Label = "ADD"
        Me.spdComponent_Sheet1.Columns.Get(6).Width = 32.0!
        Me.spdComponent_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlUpdateMold
        '
        Me.pnlUpdateMold.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlUpdateMold.Controls.Add(Me.pnlUpdateSize)
        Me.pnlUpdateMold.Controls.Add(Me.btnCariModel)
        Me.pnlUpdateMold.Controls.Add(Me.txtModelHelpCari)
        Me.pnlUpdateMold.Controls.Add(Me.Label2)
        Me.pnlUpdateMold.Controls.Add(Me.spdHelpComponent)
        Me.pnlUpdateMold.Controls.Add(Me.spdHelpSize)
        Me.pnlUpdateMold.Controls.Add(Me.btnSave)
        Me.pnlUpdateMold.Controls.Add(Me.btnClose)
        Me.pnlUpdateMold.Location = New System.Drawing.Point(670, 79)
        Me.pnlUpdateMold.Name = "pnlUpdateMold"
        Me.pnlUpdateMold.Size = New System.Drawing.Size(675, 487)
        Me.pnlUpdateMold.TabIndex = 40
        Me.pnlUpdateMold.Visible = False
        '
        'btnCariModel
        '
        Me.btnCariModel.Location = New System.Drawing.Point(423, 7)
        Me.btnCariModel.Name = "btnCariModel"
        Me.btnCariModel.Size = New System.Drawing.Size(41, 23)
        Me.btnCariModel.TabIndex = 44
        Me.btnCariModel.Text = ">>"
        Me.btnCariModel.UseVisualStyleBackColor = True
        '
        'txtModelHelpCari
        '
        Me.txtModelHelpCari.BackColor = System.Drawing.SystemColors.Info
        Me.txtModelHelpCari.Location = New System.Drawing.Point(195, 9)
        Me.txtModelHelpCari.Name = "txtModelHelpCari"
        Me.txtModelHelpCari.Size = New System.Drawing.Size(222, 20)
        Me.txtModelHelpCari.TabIndex = 43
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(157, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Model"
        '
        'spdHelpComponent
        '
        Me.spdHelpComponent.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdHelpComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer11.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer11
        Me.spdHelpComponent.HorizontalScrollBar.TabIndex = 36
        Me.spdHelpComponent.Location = New System.Drawing.Point(6, 36)
        Me.spdHelpComponent.Name = "spdHelpComponent"
        NamedStyle21.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle21.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle21.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle21.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle22.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle22.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle22.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle22.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle23.BackColor = System.Drawing.Color.DimGray
        NamedStyle23.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle23.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer6.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer6.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer6.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle23.Renderer = EnhancedCornerRenderer6
        NamedStyle23.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle24.BackColor = System.Drawing.SystemColors.Window
        NamedStyle24.CellType = GeneralCellType6
        NamedStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle24.Renderer = GeneralCellType6
        Me.spdHelpComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle21, NamedStyle22, NamedStyle23, NamedStyle24})
        Me.spdHelpComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpComponent_Sheet1})
        Me.spdHelpComponent.Size = New System.Drawing.Size(665, 122)
        Me.spdHelpComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpComponent.TabIndex = 41
        Me.spdHelpComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer12.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer12
        Me.spdHelpComponent.VerticalScrollBar.TabIndex = 37
        Me.spdHelpComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpComponent_Sheet1
        '
        Me.spdHelpComponent_Sheet1.Reset()
        Me.spdHelpComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpComponent_Sheet1.ColumnCount = 6
        Me.spdHelpComponent_Sheet1.RowCount = 1
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Model"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Brand"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Code Comp"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Component"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Mold Code"
        Me.spdHelpComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpComponent_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHelpComponent_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdHelpComponent_Sheet1.Columns.Get(1).Label = "Model"
        Me.spdHelpComponent_Sheet1.Columns.Get(1).Width = 112.0!
        Me.spdHelpComponent_Sheet1.Columns.Get(4).Label = "Component"
        Me.spdHelpComponent_Sheet1.Columns.Get(4).Width = 168.0!
        Me.spdHelpComponent_Sheet1.Columns.Get(5).Label = "Mold Code"
        Me.spdHelpComponent_Sheet1.Columns.Get(5).Width = 164.0!
        Me.spdHelpComponent_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdHelpComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdHelpSize
        '
        Me.spdHelpSize.AccessibleDescription = "spdHelpColor, Sheet1, Row 0, Column 0, "
        Me.spdHelpSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdHelpSize.HorizontalScrollBar.TabIndex = 2
        Me.spdHelpSize.Location = New System.Drawing.Point(3, 160)
        Me.spdHelpSize.Name = "spdHelpSize"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer6
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer6
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdHelpSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdHelpSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpSize_Sheet1})
        Me.spdHelpSize.Size = New System.Drawing.Size(665, 242)
        Me.spdHelpSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpSize.TabIndex = 13
        Me.spdHelpSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdHelpSize.VerticalScrollBar.TabIndex = 3
        Me.spdHelpSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpSize_Sheet1
        '
        Me.spdHelpSize_Sheet1.Reset()
        Me.spdHelpSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpSize_Sheet1.ColumnCount = 1
        Me.spdHelpSize_Sheet1.RowCount = 20
        Me.spdHelpSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 32.0!
        Me.spdHelpSize_Sheet1.Columns.Get(0).Width = 84.0!
        Me.spdHelpSize_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdHelpSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(5, 412)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(665, 33)
        Me.btnSave.TabIndex = 40
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(6, 446)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(665, 34)
        Me.btnClose.TabIndex = 39
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnHelpUpdateSize
        '
        Me.btnHelpUpdateSize.Location = New System.Drawing.Point(635, 71)
        Me.btnHelpUpdateSize.Name = "btnHelpUpdateSize"
        Me.btnHelpUpdateSize.Size = New System.Drawing.Size(37, 39)
        Me.btnHelpUpdateSize.TabIndex = 47
        Me.btnHelpUpdateSize.Text = ">>"
        Me.btnHelpUpdateSize.UseVisualStyleBackColor = True
        '
        'frmNewMold
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 578)
        Me.Controls.Add(Me.pnlUpdateMold)
        Me.Controls.Add(Me.btnHelpUpdateSize)
        Me.Controls.Add(Me.spdComponent)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.spdHead)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.spdDetail)
        Me.Name = "frmNewMold"
        Me.Text = "frmNewMold"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.spdHead, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHead_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnlUpdateSize.ResumeLayout(False)
        Me.pnlUpdateSize.PerformLayout()
        CType(Me.spdDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdDetail_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlUpdateMold.ResumeLayout(False)
        Me.pnlUpdateMold.PerformLayout()
        CType(Me.spdHelpComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtCustomerCari As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents spdHead As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHead_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSJ As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtSJ As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtModelCari As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cboType As System.Windows.Forms.ComboBox
    Friend WithEvents dtKontrak As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtKontrak As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents spdDetail As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdDetail_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cboActivity As System.Windows.Forms.ComboBox
    Friend WithEvents txtIdHeader As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtPengirim As System.Windows.Forms.TextBox
    Friend WithEvents btnPengirim As System.Windows.Forms.Button
    Friend WithEvents txtIdPengirim As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtKontrakCari As System.Windows.Forms.TextBox
    Friend WithEvents txtSJCari As System.Windows.Forms.TextBox
    Friend WithEvents txtMoldShopCari As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtCodeVendorCustomer As System.Windows.Forms.TextBox
    Friend WithEvents spdComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdComponent_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlUpdateSize As System.Windows.Forms.Panel
    Friend WithEvents btnCloseSet As System.Windows.Forms.Button
    Friend WithEvents btnDeleteSet As System.Windows.Forms.Button
    Friend WithEvents btnSaveSet As System.Windows.Forms.Button
    Friend WithEvents txtSetMold As System.Windows.Forms.TextBox
    Friend WithEvents lblSize As System.Windows.Forms.Label
    Friend WithEvents txtAlias As System.Windows.Forms.TextBox
    Friend WithEvents pnlUpdateMold As System.Windows.Forms.Panel
    Friend WithEvents btnCariModel As System.Windows.Forms.Button
    Friend WithEvents txtModelHelpCari As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents spdHelpComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpComponent_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdHelpSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnHelpUpdateSize As System.Windows.Forms.Button
End Class
