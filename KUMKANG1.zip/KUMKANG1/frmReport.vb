﻿Imports System.Data.SqlClient

Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class frmReport
    Dim clsCom As clsCOMMAND = New clsCOMMAND()

   
    Private Sub frmReport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sql_vb As String

        With clsVAR.gv_Help(0)

            Dim xReport As SuratJalan

            xReport = New SuratJalan
            xReport.SetDatabaseLogon("sa", "kumkang")

            sql_vb = ""
            sql_vb = " SELECT * FROM KKTERP.dbo.TEMP_PRINT WHERE TEMP_USER = 'SJKIRIM'"

            clsCom.GP_ExeSqlReader_Dataset(sql_vb)

            xReport.SetDataSource(clsCom.gv_DataSet)
            CrystalReportViewer1.ReportSource = xReport
            xReport.RecordSelectionFormula = "{TEMP_PRINT.TEMP_USER} = 'SJKIRIM'"



        End With

        '   FP_PRINT()
    End Sub

    Sub FP_PRINT()
        Dim report As New ReportDocument
        report.Load("Path\SuratJalan.rpt")

        Dim connInfo As New ConnectionInfo
        With connInfo
            .ServerName = "LAPTOP-GVVF28ET"
            .DatabaseName = "KKTERP"
            .UserID = "sa"
            .Password = "kumkang"
        End With

        ' Terapkan koneksi ke semua tabel dalam report
        Dim crTables As Tables = report.Database.Tables
        For Each crTable As Table In crTables
            Dim crTableLogonInfo As TableLogOnInfo = crTable.LogOnInfo
            crTableLogonInfo.ConnectionInfo = connInfo
            crTable.ApplyLogOnInfo(crTableLogonInfo)
        Next

        ' Tampilkan di CrystalReportViewer
        CrystalReportViewer1.ReportSource = report
        CrystalReportViewer1.RefreshReport()
    End Sub
End Class