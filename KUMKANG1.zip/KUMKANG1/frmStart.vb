﻿Public Class frmStart
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInquery()

    End Sub
    Public Sub cmdDelete()
        'SQL_C = ""
        'SQL_C = SQL_C + "DELETE KKTERP.dbo.color  WHERE colr_idxx=" & txtCode.Text & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)
    End Sub
    Private Sub FP_INIT()
        'Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_MODIFY()
        'SQL_C = ""
        'SQL_C = SQL_C + "UPDATE KKTERP.dbo.color  SET colr_name='" & txtDesc.Text & "' WHERE colr_idxx=" & txtCode.Text & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)

    End Sub
    Private Sub FP_INSERT()


        'SQL_C = ""
        'SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.color (colr_name) VALUES ('" & txtDesc.Text & "')" & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_DELETE()
        'SQL_C = ""
        'SQL_C = SQL_C + "DELETE KKTERP.dbo.color  WHERE colr_iddx=" & txtCode.Text & vbCrLf

        'clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_LIST_HEAD()
        'Dim SQL_C As String
        'SQL_C = ""
        'SQL_C += "SELECT colr_idxx,colr_name" & vbLf
        'SQL_C += "FROM KKTERP.dbo.color" & vbLf
        'SQL_C += "order by colr_name asc" & vbLf


        'clsCom.GP_ExeSqlReader(SQL_C)

        'With spdHead_Sheet1
        '    .RowCount = 0
        '    While clsCom.gv_DataRdr.Read
        '        .RowCount = .RowCount + 1
        '        .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("colr_idxx")
        '        .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("colr_name")
        '    End While

        '    .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        'End With

        'clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_FILL()
        'With spdHead_Sheet1.Cells
        '    txtCode.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 0).Text
        '    txtDesc.Text = .Item(spdHead_Sheet1.ActiveRowIndex, 1).Text

        'End With
    End Sub

    Private Sub frmStart_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class