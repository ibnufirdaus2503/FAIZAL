﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFormula
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer21 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer21 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnModelColor = New System.Windows.Forms.Button
        Me.txtModel = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.spdComponent = New FarPoint.Win.Spread.FpSpread
        Me.spdComponent_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdMaterial = New FarPoint.Win.Spread.FpSpread
        Me.spdMaterial_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnHelpComponent = New System.Windows.Forms.Button
        Me.btnGramasi = New System.Windows.Forms.Button
        Me.pnlGramasi = New System.Windows.Forms.Panel
        Me.txtIdGram = New System.Windows.Forms.TextBox
        Me.txtIdMaterial = New System.Windows.Forms.TextBox
        Me.btnHelpMaterial = New System.Windows.Forms.Button
        Me.btnCloseMaterial = New System.Windows.Forms.Button
        Me.btnDeleteMaterial = New System.Windows.Forms.Button
        Me.btnSaveMaterial = New System.Windows.Forms.Button
        Me.txtGramasi = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMaterial = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnModel = New System.Windows.Forms.Button
        Me.spdModel = New FarPoint.Win.Spread.FpSpread
        Me.spdModel_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdColor = New FarPoint.Win.Spread.FpSpread
        Me.spdColor_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlModel = New System.Windows.Forms.Panel
        Me.txtIDModelMold = New System.Windows.Forms.TextBox
        Me.btnModelMOld = New System.Windows.Forms.Button
        Me.txtMold = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtIdModel = New System.Windows.Forms.TextBox
        Me.btnCloseModel = New System.Windows.Forms.Button
        Me.btnDeleteModel = New System.Windows.Forms.Button
        Me.btnSaveModel = New System.Windows.Forms.Button
        Me.txtModelName = New System.Windows.Forms.TextBox
        Me.lblSize = New System.Windows.Forms.Label
        Me.btnColor = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtPairs = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdMaterial, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdMaterial_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlGramasi.SuspendLayout()
        CType(Me.spdModel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdModel_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdColor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdColor_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlModel.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = "EnhancedColumnHeaderRenderer8"
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = "EnhancedRowHeaderRenderer8"
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer10.Name = "EnhancedColumnHeaderRenderer10"
        EnhancedColumnHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer10.TextRotationAngle = 0
        EnhancedRowHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer10.Name = "EnhancedRowHeaderRenderer10"
        EnhancedRowHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer10.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer11.Name = "EnhancedColumnHeaderRenderer11"
        EnhancedColumnHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer11.TextRotationAngle = 0
        EnhancedRowHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer11.Name = "EnhancedRowHeaderRenderer11"
        EnhancedRowHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer11.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer12.Name = "EnhancedColumnHeaderRenderer12"
        EnhancedColumnHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer12.TextRotationAngle = 0
        EnhancedRowHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer12.Name = "EnhancedRowHeaderRenderer12"
        EnhancedRowHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer12.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer14.Name = "EnhancedColumnHeaderRenderer14"
        EnhancedColumnHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer14.TextRotationAngle = 0
        EnhancedRowHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer14.Name = "EnhancedRowHeaderRenderer14"
        EnhancedRowHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer14.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer13.Name = "EnhancedColumnHeaderRenderer13"
        EnhancedColumnHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer13.TextRotationAngle = 0
        EnhancedRowHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer13.Name = "EnhancedRowHeaderRenderer13"
        EnhancedRowHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer13.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer15.Name = "EnhancedColumnHeaderRenderer15"
        EnhancedColumnHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer15.TextRotationAngle = 0
        EnhancedRowHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer15.Name = "EnhancedRowHeaderRenderer15"
        EnhancedRowHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer15.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer16.Name = "EnhancedColumnHeaderRenderer16"
        EnhancedColumnHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer16.TextRotationAngle = 0
        EnhancedRowHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer16.Name = "EnhancedRowHeaderRenderer16"
        EnhancedRowHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer16.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer17.Name = "EnhancedColumnHeaderRenderer17"
        EnhancedColumnHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer17.TextRotationAngle = 0
        EnhancedRowHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer17.Name = "EnhancedRowHeaderRenderer17"
        EnhancedRowHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer17.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer18.Name = "EnhancedColumnHeaderRenderer18"
        EnhancedColumnHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer18.TextRotationAngle = 0
        EnhancedRowHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer18.Name = "EnhancedRowHeaderRenderer18"
        EnhancedRowHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer18.TextRotationAngle = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel1.Controls.Add(Me.btnModelColor)
        Me.Panel1.Controls.Add(Me.txtModel)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Location = New System.Drawing.Point(4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1344, 60)
        Me.Panel1.TabIndex = 2
        '
        'btnModelColor
        '
        Me.btnModelColor.Location = New System.Drawing.Point(303, 21)
        Me.btnModelColor.Name = "btnModelColor"
        Me.btnModelColor.Size = New System.Drawing.Size(47, 22)
        Me.btnModelColor.TabIndex = 39
        Me.btnModelColor.Text = ">>"
        Me.btnModelColor.UseVisualStyleBackColor = True
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(52, 21)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(245, 20)
        Me.txtModel.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Model"
        '
        'spdComponent
        '
        Me.spdComponent.AccessibleDescription = "spdComponent, Sheet1, Row 0, Column 0, "
        Me.spdComponent.BackColor = System.Drawing.SystemColors.Control
        Me.spdComponent.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdComponent.HorizontalScrollBar.TabIndex = 10
        Me.spdComponent.Location = New System.Drawing.Point(723, 70)
        Me.spdComponent.Name = "spdComponent"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer17
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer17
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdComponent.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdComponent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdComponent.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdComponent_Sheet1})
        Me.spdComponent.Size = New System.Drawing.Size(177, 495)
        Me.spdComponent.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdComponent.TabIndex = 33
        Me.spdComponent.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdComponent.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdComponent.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdComponent.VerticalScrollBar.TabIndex = 11
        Me.spdComponent.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdComponent_Sheet1
        '
        Me.spdComponent_Sheet1.Reset()
        Me.spdComponent_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdComponent_Sheet1.ColumnCount = 2
        Me.spdComponent_Sheet1.RowCount = 1
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdComponent_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Component"
        Me.spdComponent_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdComponent_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdComponent_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdComponent_Sheet1.Columns.Get(0).Visible = False
        Me.spdComponent_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdComponent_Sheet1.Columns.Get(1).Label = "Component"
        Me.spdComponent_Sheet1.Columns.Get(1).Width = 122.0!
        Me.spdComponent_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdComponent_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdComponent_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdComponent_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdMaterial
        '
        Me.spdMaterial.AccessibleDescription = "spdMaterial, Sheet1, Row 0, Column 0, "
        Me.spdMaterial.BackColor = System.Drawing.SystemColors.Control
        Me.spdMaterial.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMaterial.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMaterial.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdMaterial.HorizontalScrollBar.TabIndex = 12
        Me.spdMaterial.Location = New System.Drawing.Point(906, 68)
        Me.spdMaterial.Name = "spdMaterial"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer20.Name = ""
        EnhancedColumnHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer20.TextRotationAngle = 0
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer20
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer20.Name = ""
        EnhancedRowHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer20.TextRotationAngle = 0
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer20
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdMaterial.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdMaterial.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdMaterial.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdMaterial_Sheet1})
        Me.spdMaterial.Size = New System.Drawing.Size(442, 495)
        Me.spdMaterial.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdMaterial.TabIndex = 34
        Me.spdMaterial.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMaterial.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMaterial.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdMaterial.VerticalScrollBar.TabIndex = 13
        Me.spdMaterial.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdMaterial_Sheet1
        '
        Me.spdMaterial_Sheet1.Reset()
        Me.spdMaterial_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdMaterial_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdMaterial_Sheet1.ColumnCount = 5
        Me.spdMaterial_Sheet1.RowCount = 1
        Me.spdMaterial_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdMaterial_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Category"
        Me.spdMaterial_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Material"
        Me.spdMaterial_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Gramasi"
        Me.spdMaterial_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Id Material"
        Me.spdMaterial_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdMaterial_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdMaterial_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdMaterial_Sheet1.Columns.Get(0).Visible = False
        Me.spdMaterial_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdMaterial_Sheet1.Columns.Get(1).Label = "Category"
        Me.spdMaterial_Sheet1.Columns.Get(1).Width = 154.0!
        Me.spdMaterial_Sheet1.Columns.Get(2).Label = "Material"
        Me.spdMaterial_Sheet1.Columns.Get(2).Width = 173.0!
        Me.spdMaterial_Sheet1.Columns.Get(4).Label = "Id Material"
        Me.spdMaterial_Sheet1.Columns.Get(4).Visible = False
        Me.spdMaterial_Sheet1.Columns.Get(4).Width = 97.0!
        Me.spdMaterial_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdMaterial_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdMaterial_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdMaterial_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnHelpComponent
        '
        Me.btnHelpComponent.Location = New System.Drawing.Point(723, 70)
        Me.btnHelpComponent.Name = "btnHelpComponent"
        Me.btnHelpComponent.Size = New System.Drawing.Size(37, 38)
        Me.btnHelpComponent.TabIndex = 38
        Me.btnHelpComponent.Text = ">>"
        Me.btnHelpComponent.UseVisualStyleBackColor = True
        '
        'btnGramasi
        '
        Me.btnGramasi.Location = New System.Drawing.Point(906, 66)
        Me.btnGramasi.Name = "btnGramasi"
        Me.btnGramasi.Size = New System.Drawing.Size(37, 38)
        Me.btnGramasi.TabIndex = 39
        Me.btnGramasi.Text = ">>"
        Me.btnGramasi.UseVisualStyleBackColor = True
        '
        'pnlGramasi
        '
        Me.pnlGramasi.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlGramasi.Controls.Add(Me.txtIdGram)
        Me.pnlGramasi.Controls.Add(Me.txtIdMaterial)
        Me.pnlGramasi.Controls.Add(Me.btnHelpMaterial)
        Me.pnlGramasi.Controls.Add(Me.btnCloseMaterial)
        Me.pnlGramasi.Controls.Add(Me.btnDeleteMaterial)
        Me.pnlGramasi.Controls.Add(Me.btnSaveMaterial)
        Me.pnlGramasi.Controls.Add(Me.txtGramasi)
        Me.pnlGramasi.Controls.Add(Me.Label4)
        Me.pnlGramasi.Controls.Add(Me.txtMaterial)
        Me.pnlGramasi.Controls.Add(Me.Label7)
        Me.pnlGramasi.Location = New System.Drawing.Point(1026, 202)
        Me.pnlGramasi.Name = "pnlGramasi"
        Me.pnlGramasi.Size = New System.Drawing.Size(244, 90)
        Me.pnlGramasi.TabIndex = 42
        Me.pnlGramasi.Visible = False
        '
        'txtIdGram
        '
        Me.txtIdGram.Location = New System.Drawing.Point(10, 55)
        Me.txtIdGram.Name = "txtIdGram"
        Me.txtIdGram.Size = New System.Drawing.Size(30, 20)
        Me.txtIdGram.TabIndex = 46
        Me.txtIdGram.Visible = False
        '
        'txtIdMaterial
        '
        Me.txtIdMaterial.Location = New System.Drawing.Point(190, 29)
        Me.txtIdMaterial.Name = "txtIdMaterial"
        Me.txtIdMaterial.Size = New System.Drawing.Size(30, 20)
        Me.txtIdMaterial.TabIndex = 45
        Me.txtIdMaterial.Visible = False
        '
        'btnHelpMaterial
        '
        Me.btnHelpMaterial.Location = New System.Drawing.Point(190, 6)
        Me.btnHelpMaterial.Name = "btnHelpMaterial"
        Me.btnHelpMaterial.Size = New System.Drawing.Size(30, 20)
        Me.btnHelpMaterial.TabIndex = 44
        Me.btnHelpMaterial.Text = ">>"
        Me.btnHelpMaterial.UseVisualStyleBackColor = True
        '
        'btnCloseMaterial
        '
        Me.btnCloseMaterial.Location = New System.Drawing.Point(169, 55)
        Me.btnCloseMaterial.Name = "btnCloseMaterial"
        Me.btnCloseMaterial.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseMaterial.TabIndex = 43
        Me.btnCloseMaterial.Text = "Close"
        Me.btnCloseMaterial.UseVisualStyleBackColor = True
        '
        'btnDeleteMaterial
        '
        Me.btnDeleteMaterial.Location = New System.Drawing.Point(115, 55)
        Me.btnDeleteMaterial.Name = "btnDeleteMaterial"
        Me.btnDeleteMaterial.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteMaterial.TabIndex = 42
        Me.btnDeleteMaterial.Text = "Delete"
        Me.btnDeleteMaterial.UseVisualStyleBackColor = True
        '
        'btnSaveMaterial
        '
        Me.btnSaveMaterial.Location = New System.Drawing.Point(60, 55)
        Me.btnSaveMaterial.Name = "btnSaveMaterial"
        Me.btnSaveMaterial.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveMaterial.TabIndex = 41
        Me.btnSaveMaterial.Text = "Save"
        Me.btnSaveMaterial.UseVisualStyleBackColor = True
        '
        'txtGramasi
        '
        Me.txtGramasi.Location = New System.Drawing.Point(65, 29)
        Me.txtGramasi.Name = "txtGramasi"
        Me.txtGramasi.Size = New System.Drawing.Size(120, 20)
        Me.txtGramasi.TabIndex = 40
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Gramasi"
        '
        'txtMaterial
        '
        Me.txtMaterial.Location = New System.Drawing.Point(65, 6)
        Me.txtMaterial.Name = "txtMaterial"
        Me.txtMaterial.Size = New System.Drawing.Size(120, 20)
        Me.txtMaterial.TabIndex = 38
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(7, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Material"
        '
        'btnModel
        '
        Me.btnModel.Location = New System.Drawing.Point(4, 72)
        Me.btnModel.Name = "btnModel"
        Me.btnModel.Size = New System.Drawing.Size(39, 34)
        Me.btnModel.TabIndex = 88
        Me.btnModel.Text = ">>"
        Me.btnModel.UseVisualStyleBackColor = True
        '
        'spdModel
        '
        Me.spdModel.AccessibleDescription = "spdModel, Sheet1, Row 0, Column 0, "
        Me.spdModel.BackColor = System.Drawing.SystemColors.Control
        Me.spdModel.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdModel.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdModel.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdModel.HorizontalScrollBar.TabIndex = 8
        Me.spdModel.Location = New System.Drawing.Point(4, 73)
        Me.spdModel.Name = "spdModel"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer21.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer21.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer21.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer21.Name = ""
        EnhancedColumnHeaderRenderer21.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer21.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer21.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer21.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer21.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer21.TextRotationAngle = 0
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer21
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer21.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer21.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer21.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer21.Name = ""
        EnhancedRowHeaderRenderer21.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer21.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer21.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer21.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer21.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer21.TextRotationAngle = 0
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer21
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdModel.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdModel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdModel.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdModel_Sheet1})
        Me.spdModel.Size = New System.Drawing.Size(483, 491)
        Me.spdModel.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdModel.TabIndex = 87
        Me.spdModel.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdModel.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdModel.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdModel.VerticalScrollBar.TabIndex = 9
        Me.spdModel.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdModel_Sheet1
        '
        Me.spdModel_Sheet1.Reset()
        Me.spdModel_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdModel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdModel_Sheet1.ColumnCount = 6
        Me.spdModel_Sheet1.RowCount = 1
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "Id Model"
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "ID MAST"
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Model Name"
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Model Mold"
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "Brand"
        Me.spdModel_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Pack"
        Me.spdModel_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdModel_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdModel_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdModel_Sheet1.Columns.Get(0).Label = "Id Model"
        Me.spdModel_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdModel_Sheet1.Columns.Get(0).Visible = False
        Me.spdModel_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdModel_Sheet1.Columns.Get(1).Label = "ID MAST"
        Me.spdModel_Sheet1.Columns.Get(1).Visible = False
        Me.spdModel_Sheet1.Columns.Get(2).Label = "Model Name"
        Me.spdModel_Sheet1.Columns.Get(2).Width = 127.0!
        Me.spdModel_Sheet1.Columns.Get(3).Label = "Model Mold"
        Me.spdModel_Sheet1.Columns.Get(3).Width = 172.0!
        Me.spdModel_Sheet1.Columns.Get(4).Label = "Brand"
        Me.spdModel_Sheet1.Columns.Get(4).Width = 87.0!
        Me.spdModel_Sheet1.Columns.Get(5).Label = "Pack"
        Me.spdModel_Sheet1.Columns.Get(5).Width = 40.0!
        Me.spdModel_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdModel_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdModel_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdModel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdColor
        '
        Me.spdColor.AccessibleDescription = "spColor, Sheet1, Row 0, Column 0, "
        Me.spdColor.BackColor = System.Drawing.SystemColors.Control
        Me.spdColor.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdColor.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdColor.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdColor.HorizontalScrollBar.TabIndex = 38
        Me.spdColor.Location = New System.Drawing.Point(493, 74)
        Me.spdColor.Name = "spdColor"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer16
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer16
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdColor.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdColor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdColor.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdColor_Sheet1})
        Me.spdColor.Size = New System.Drawing.Size(224, 491)
        Me.spdColor.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdColor.TabIndex = 89
        Me.spdColor.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdColor.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdColor.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdColor.VerticalScrollBar.TabIndex = 39
        Me.spdColor.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdColor_Sheet1
        '
        Me.spdColor_Sheet1.Reset()
        Me.spdColor_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdColor_Sheet1.ColumnCount = 2
        Me.spdColor_Sheet1.RowCount = 1
        Me.spdColor_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID Color"
        Me.spdColor_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Color"
        Me.spdColor_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdColor_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdColor_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdColor_Sheet1.Columns.Get(0).Label = "ID Color"
        Me.spdColor_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdColor_Sheet1.Columns.Get(0).Visible = False
        Me.spdColor_Sheet1.Columns.Get(0).Width = 42.0!
        Me.spdColor_Sheet1.Columns.Get(1).Label = "Color"
        Me.spdColor_Sheet1.Columns.Get(1).Width = 167.0!
        Me.spdColor_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdColor_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdColor_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdColor_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlModel
        '
        Me.pnlModel.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlModel.Controls.Add(Me.Label2)
        Me.pnlModel.Controls.Add(Me.txtPairs)
        Me.pnlModel.Controls.Add(Me.Label1)
        Me.pnlModel.Controls.Add(Me.txtIDModelMold)
        Me.pnlModel.Controls.Add(Me.btnModelMOld)
        Me.pnlModel.Controls.Add(Me.txtMold)
        Me.pnlModel.Controls.Add(Me.Label11)
        Me.pnlModel.Controls.Add(Me.txtIdModel)
        Me.pnlModel.Controls.Add(Me.btnCloseModel)
        Me.pnlModel.Controls.Add(Me.btnDeleteModel)
        Me.pnlModel.Controls.Add(Me.btnSaveModel)
        Me.pnlModel.Controls.Add(Me.txtModelName)
        Me.pnlModel.Controls.Add(Me.lblSize)
        Me.pnlModel.Location = New System.Drawing.Point(92, 183)
        Me.pnlModel.Name = "pnlModel"
        Me.pnlModel.Size = New System.Drawing.Size(262, 120)
        Me.pnlModel.TabIndex = 90
        Me.pnlModel.Visible = False
        '
        'txtIDModelMold
        '
        Me.txtIDModelMold.Enabled = False
        Me.txtIDModelMold.Location = New System.Drawing.Point(225, 59)
        Me.txtIDModelMold.Name = "txtIDModelMold"
        Me.txtIDModelMold.Size = New System.Drawing.Size(31, 20)
        Me.txtIDModelMold.TabIndex = 93
        Me.txtIDModelMold.Visible = False
        '
        'btnModelMOld
        '
        Me.btnModelMOld.Location = New System.Drawing.Point(217, 31)
        Me.btnModelMOld.Name = "btnModelMOld"
        Me.btnModelMOld.Size = New System.Drawing.Size(39, 22)
        Me.btnModelMOld.TabIndex = 92
        Me.btnModelMOld.Text = ">>"
        Me.btnModelMOld.UseVisualStyleBackColor = True
        '
        'txtMold
        '
        Me.txtMold.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtMold.Enabled = False
        Me.txtMold.Location = New System.Drawing.Point(64, 33)
        Me.txtMold.Name = "txtMold"
        Me.txtMold.Size = New System.Drawing.Size(146, 20)
        Me.txtMold.TabIndex = 56
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 39)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 13)
        Me.Label11.TabIndex = 55
        Me.Label11.Text = "Model Mold"
        '
        'txtIdModel
        '
        Me.txtIdModel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.txtIdModel.Enabled = False
        Me.txtIdModel.Location = New System.Drawing.Point(63, 7)
        Me.txtIdModel.Name = "txtIdModel"
        Me.txtIdModel.Size = New System.Drawing.Size(51, 20)
        Me.txtIdModel.TabIndex = 54
        '
        'btnCloseModel
        '
        Me.btnCloseModel.Location = New System.Drawing.Point(168, 82)
        Me.btnCloseModel.Name = "btnCloseModel"
        Me.btnCloseModel.Size = New System.Drawing.Size(63, 27)
        Me.btnCloseModel.TabIndex = 6
        Me.btnCloseModel.Text = "Close"
        Me.btnCloseModel.UseVisualStyleBackColor = True
        '
        'btnDeleteModel
        '
        Me.btnDeleteModel.Location = New System.Drawing.Point(93, 82)
        Me.btnDeleteModel.Name = "btnDeleteModel"
        Me.btnDeleteModel.Size = New System.Drawing.Size(69, 27)
        Me.btnDeleteModel.TabIndex = 5
        Me.btnDeleteModel.Text = "Delete"
        Me.btnDeleteModel.UseVisualStyleBackColor = True
        '
        'btnSaveModel
        '
        Me.btnSaveModel.Location = New System.Drawing.Point(8, 82)
        Me.btnSaveModel.Name = "btnSaveModel"
        Me.btnSaveModel.Size = New System.Drawing.Size(79, 27)
        Me.btnSaveModel.TabIndex = 4
        Me.btnSaveModel.Text = "Save"
        Me.btnSaveModel.UseVisualStyleBackColor = True
        '
        'txtModelName
        '
        Me.txtModelName.BackColor = System.Drawing.SystemColors.Info
        Me.txtModelName.Location = New System.Drawing.Point(120, 7)
        Me.txtModelName.Name = "txtModelName"
        Me.txtModelName.Size = New System.Drawing.Size(137, 20)
        Me.txtModelName.TabIndex = 2
        '
        'lblSize
        '
        Me.lblSize.AutoSize = True
        Me.lblSize.Location = New System.Drawing.Point(2, 10)
        Me.lblSize.Name = "lblSize"
        Me.lblSize.Size = New System.Drawing.Size(36, 13)
        Me.lblSize.TabIndex = 0
        Me.lblSize.Text = "Model"
        '
        'btnColor
        '
        Me.btnColor.Location = New System.Drawing.Point(493, 74)
        Me.btnColor.Name = "btnColor"
        Me.btnColor.Size = New System.Drawing.Size(39, 34)
        Me.btnColor.TabIndex = 91
        Me.btnColor.Text = ">>"
        Me.btnColor.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 13)
        Me.Label1.TabIndex = 94
        Me.Label1.Text = "Packing Finish Good"
        '
        'txtPairs
        '
        Me.txtPairs.BackColor = System.Drawing.SystemColors.Info
        Me.txtPairs.Location = New System.Drawing.Point(111, 56)
        Me.txtPairs.Name = "txtPairs"
        Me.txtPairs.Size = New System.Drawing.Size(51, 20)
        Me.txtPairs.TabIndex = 95
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(165, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 96
        Me.Label2.Text = "Pairs"
        '
        'frmFormula
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.btnColor)
        Me.Controls.Add(Me.pnlModel)
        Me.Controls.Add(Me.spdColor)
        Me.Controls.Add(Me.btnModel)
        Me.Controls.Add(Me.spdModel)
        Me.Controls.Add(Me.pnlGramasi)
        Me.Controls.Add(Me.btnGramasi)
        Me.Controls.Add(Me.btnHelpComponent)
        Me.Controls.Add(Me.spdMaterial)
        Me.Controls.Add(Me.spdComponent)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmFormula"
        Me.Text = "Gramasi"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.spdComponent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdComponent_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdMaterial, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdMaterial_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlGramasi.ResumeLayout(False)
        Me.pnlGramasi.PerformLayout()
        CType(Me.spdModel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdModel_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdColor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdColor_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlModel.ResumeLayout(False)
        Me.pnlModel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtModel As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents spdComponent As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdComponent_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdMaterial As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdMaterial_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnHelpComponent As System.Windows.Forms.Button
    Friend WithEvents btnGramasi As System.Windows.Forms.Button
    Friend WithEvents pnlGramasi As System.Windows.Forms.Panel
    Friend WithEvents btnHelpMaterial As System.Windows.Forms.Button
    Friend WithEvents btnCloseMaterial As System.Windows.Forms.Button
    Friend WithEvents btnDeleteMaterial As System.Windows.Forms.Button
    Friend WithEvents btnSaveMaterial As System.Windows.Forms.Button
    Friend WithEvents txtGramasi As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMaterial As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnModelColor As System.Windows.Forms.Button
    Friend WithEvents txtIdMaterial As System.Windows.Forms.TextBox
    Friend WithEvents txtIdGram As System.Windows.Forms.TextBox
    Friend WithEvents btnModel As System.Windows.Forms.Button
    Friend WithEvents spdModel As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdModel_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdColor As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdColor_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlModel As System.Windows.Forms.Panel
    Friend WithEvents txtMold As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtIdModel As System.Windows.Forms.TextBox
    Friend WithEvents btnCloseModel As System.Windows.Forms.Button
    Friend WithEvents btnDeleteModel As System.Windows.Forms.Button
    Friend WithEvents btnSaveModel As System.Windows.Forms.Button
    Friend WithEvents txtModelName As System.Windows.Forms.TextBox
    Friend WithEvents lblSize As System.Windows.Forms.Label
    Friend WithEvents btnColor As System.Windows.Forms.Button
    Friend WithEvents btnModelMOld As System.Windows.Forms.Button
    Friend WithEvents txtIDModelMold As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtPairs As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
