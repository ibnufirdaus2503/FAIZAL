﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHelpSJ
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.spdSJ = New FarPoint.Win.Spread.FpSpread
        Me.spdSJ_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnCloseSJ = New System.Windows.Forms.Button
        Me.pnlHelpCustomer = New System.Windows.Forms.Panel
        Me.btnCariSJ = New System.Windows.Forms.Button
        Me.txtSJ = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        CType(Me.spdSJ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSJ_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpCustomer.SuspendLayout()
        Me.SuspendLayout()
        '
        'spdSJ
        '
        Me.spdSJ.AccessibleDescription = "spdSJ, Sheet1, Row 0, Column 0, "
        Me.spdSJ.BackColor = System.Drawing.SystemColors.Control
        Me.spdSJ.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSJ.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSJ.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdSJ.HorizontalScrollBar.TabIndex = 2
        Me.spdSJ.Location = New System.Drawing.Point(6, 53)
        Me.spdSJ.Name = "spdSJ"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = ""
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer1
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = ""
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer1
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdSJ.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdSJ.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSJ.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSJ_Sheet1})
        Me.spdSJ.Size = New System.Drawing.Size(804, 373)
        Me.spdSJ.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSJ.TabIndex = 131
        Me.spdSJ.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSJ.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSJ.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdSJ.VerticalScrollBar.TabIndex = 3
        Me.spdSJ.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSJ_Sheet1
        '
        Me.spdSJ_Sheet1.Reset()
        Me.spdSJ_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSJ_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSJ_Sheet1.ColumnCount = 9
        Me.spdSJ_Sheet1.RowCount = 1
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "No. SJ"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Date SJ"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "ID Model"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "M o d e l"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Component"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "C o l o r"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "QTY"
        Me.spdSJ_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Id Sj"
        Me.spdSJ_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSJ_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        Me.spdSJ_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdSJ_Sheet1.Columns.Get(0).Visible = False
        Me.spdSJ_Sheet1.Columns.Get(1).Label = "No. SJ"
        Me.spdSJ_Sheet1.Columns.Get(1).Width = 111.0!
        Me.spdSJ_Sheet1.Columns.Get(2).Label = "Date SJ"
        Me.spdSJ_Sheet1.Columns.Get(2).Width = 82.0!
        Me.spdSJ_Sheet1.Columns.Get(3).CellType = TextCellType1
        Me.spdSJ_Sheet1.Columns.Get(3).Label = "ID Model"
        Me.spdSJ_Sheet1.Columns.Get(3).Width = 66.0!
        Me.spdSJ_Sheet1.Columns.Get(4).Label = "M o d e l"
        Me.spdSJ_Sheet1.Columns.Get(4).Width = 156.0!
        Me.spdSJ_Sheet1.Columns.Get(5).Label = "Component"
        Me.spdSJ_Sheet1.Columns.Get(5).Width = 108.0!
        Me.spdSJ_Sheet1.Columns.Get(6).Label = "C o l o r"
        Me.spdSJ_Sheet1.Columns.Get(6).Width = 169.0!
        Me.spdSJ_Sheet1.Columns.Get(7).Label = "QTY"
        Me.spdSJ_Sheet1.Columns.Get(7).Width = 55.0!
        Me.spdSJ_Sheet1.Columns.Get(8).Label = "Id Sj"
        Me.spdSJ_Sheet1.Columns.Get(8).Visible = False
        Me.spdSJ_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdSJ_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSJ_Sheet1.Rows.Get(0).Height = 45.0!
        Me.spdSJ_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSJ_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnCloseSJ
        '
        Me.btnCloseSJ.Location = New System.Drawing.Point(680, 427)
        Me.btnCloseSJ.Name = "btnCloseSJ"
        Me.btnCloseSJ.Size = New System.Drawing.Size(130, 33)
        Me.btnCloseSJ.TabIndex = 132
        Me.btnCloseSJ.Text = "Close"
        Me.btnCloseSJ.UseVisualStyleBackColor = True
        '
        'pnlHelpCustomer
        '
        Me.pnlHelpCustomer.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpCustomer.Controls.Add(Me.btnCariSJ)
        Me.pnlHelpCustomer.Controls.Add(Me.txtSJ)
        Me.pnlHelpCustomer.Controls.Add(Me.Label16)
        Me.pnlHelpCustomer.Location = New System.Drawing.Point(6, 3)
        Me.pnlHelpCustomer.Name = "pnlHelpCustomer"
        Me.pnlHelpCustomer.Size = New System.Drawing.Size(804, 44)
        Me.pnlHelpCustomer.TabIndex = 133
        '
        'btnCariSJ
        '
        Me.btnCariSJ.Location = New System.Drawing.Point(406, 14)
        Me.btnCariSJ.Name = "btnCariSJ"
        Me.btnCariSJ.Size = New System.Drawing.Size(46, 24)
        Me.btnCariSJ.TabIndex = 25
        Me.btnCariSJ.Text = ">>"
        Me.btnCariSJ.UseVisualStyleBackColor = True
        '
        'txtSJ
        '
        Me.txtSJ.Location = New System.Drawing.Point(56, 14)
        Me.txtSJ.Name = "txtSJ"
        Me.txtSJ.Size = New System.Drawing.Size(344, 20)
        Me.txtSJ.TabIndex = 12
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(15, 17)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(39, 13)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "No, SJ"
        '
        'frmHelpSJ
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(811, 463)
        Me.Controls.Add(Me.pnlHelpCustomer)
        Me.Controls.Add(Me.btnCloseSJ)
        Me.Controls.Add(Me.spdSJ)
        Me.Name = "frmHelpSJ"
        Me.Text = "Help SJ"
        CType(Me.spdSJ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSJ_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpCustomer.ResumeLayout(False)
        Me.pnlHelpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdSJ As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSJ_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnCloseSJ As System.Windows.Forms.Button
    Friend WithEvents pnlHelpCustomer As System.Windows.Forms.Panel
    Friend WithEvents btnCariSJ As System.Windows.Forms.Button
    Friend WithEvents txtSJ As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
End Class
