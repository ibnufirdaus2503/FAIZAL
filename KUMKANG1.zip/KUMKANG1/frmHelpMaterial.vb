﻿Public Class frmHelpMaterial
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_COMPONENT()

       

        SQL_C = ""
        SQL_C += "SELECT mate_idxx,mate_name,cate_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.material A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_category B ON A.cate_idxx=B.cate_idxx" & vbLf
        SQL_C += "WHERE mate_idxx is not null" & vbLf

        If txtMaterial.Text <> "" Then
            SQL_C += "AND  mate_name like '%" & txtMaterial.Text & "%'" & vbLf
        End If

        If txtMaterial.Text <> "" Then
            SQL_C += "AND  mate_name like '%" & txtMaterial.Text & "%'" & vbLf
        End If

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMaterial_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mate_idxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("mate_name")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cate_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub btnCariMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariMaterial.Click
        FP_LIST_COMPONENT()
    End Sub

    

    Private Sub spdMaterial_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaterial.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdMaterial_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdMaterial_Sheet1.Cells.Item(e.Row, 1).Text
          

        End With

        Me.Close()
    End Sub
End Class