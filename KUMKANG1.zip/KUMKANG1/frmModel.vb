﻿Public Class frmModel
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_HELP_COLOR()
        Dim SQL_C As String
        SQL_C = ""

        SQL_C += " SELECT colr_idxx,colr_name FROM KKTERP.dbo.color where colr_idxx is not null " & vbLf

        If txtCariColor.Text <> "" Then
            SQL_C += "AND colr_name like '%" & txtCariColor.Text & "%'"
        End If
        SQL_C += "ORDER BY colr_name"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpColor_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("colr_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("colr_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_COLOR()
        Dim SQL_C As String
        SQL_C = ""

        SQL_C += " SELECT A.mclr_idxx,B.colr_name FROM KKTERP.dbo.model_color A  " & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.color B ON A.colr_idxx=B.colr_idxx " & vbLf
        SQL_C += "where modl_idxx=" & txtIdModel.Text & "" & vbLf
        SQL_C += "ORDER BY colr_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdColor_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("colr_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_MOLDSHOP()
        Dim SQL_C As String

        SQL_C = ""
        SQL_C += "SELECT vend_idxx,vend_name FROM KKTERP.dbo.vendor where vend_mshp=1 order by vend_name" & vbLf
       


        clsCom.GP_ExeSqlReader(SQL_C)

        With cboMoldshop
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("vend_name") & Space(100) & clsCom.gv_DataRdr("vend_idxx"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_BRAND()
        Dim SQL_C As String
   
        SQL_C = ""
        SQL_C += "select distinct CODE_BRAN,codd_desc" & vbLf
        SQL_C += "from KKTERP.dbo.customer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer_brand B ON A.cust_idxx=B.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.CODH_FLNM='CODE_BRAN' AND C.codd_valu=CODE_BRAN" & vbLf
        SQL_C += "WHERE CODE_GCUS =   " & txtIdCustomer.Text

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboBrand
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("CODE_BRAN"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HELP_CUSTOMER()
        Dim SQL_C As String
        Dim vrow, RowIndex As Integer

        'SQL_C = ""

        'SQL_C += " SELECT count(*) qty FROM KKTERP.dbo.code_common WHERE CODH_FLNM='CODE_GCUS'" & vbLf


        'clsCom.GP_ExeSqlReader(SQL_C)
        'clsCom.gv_DataRdr.Read()
        'vrow = clsCom.gv_DataRdr("qty")
        'clsCom.gv_ExeSqlReaderEnd()


        'SQL_C = ""

        'SQL_C += " SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common WHERE CODH_FLNM='CODE_GCUS' ORDER BY codd_desc" & vbLf


        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_GCUS' AND CODE_GCUS=codd_valu" & vbLf
        SQL_C += "WHERE CUST_IDXX IS NOT NULL"

        If txtCustomerHelpCari.Text <> "" Then
            SQL_C += "AND CUST_NAME LIKE'%" & txtCustomerHelpCari.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        vrow = clsCom.gv_DataRdr("qty")
        clsCom.gv_ExeSqlReaderEnd()




        SQL_C = ""
        SQL_C += "SELECT cust_idxx,cust_name,codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.customer A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_GCUS' AND CODE_GCUS=codd_valu" & vbLf
        SQL_C += "WHERE CUST_IDXX IS NOT NULL"

        If txtCustomerHelpCari.Text <> "" Then
            SQL_C += "AND CUST_NAME LIKE'%" & txtCustomerHelpCari.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpCustomer_Sheet1
            .RowCount = vrow
            RowIndex = 1
            While clsCom.gv_DataRdr.Read

                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("codd_valu")
                RowIndex = RowIndex + 1

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Public Sub cmdInsert()
        FP_CLEAR()


    End Sub
    Public Sub cmdUpdate()
        If txtModelName.Text = "" Then
            MsgBox("Lengkapi data anda")
            Exit Sub
        End If

        If txtCustomer.Text = "" Then
            MsgBox("Lengkapi data customer")
            Exit Sub
        End If


        If txtGramasi.Text = "" Then
            MsgBox("Lengkapi data Gramasi")
            Exit Sub
        End If

        If txtChip.Text = "" Then
            MsgBox("Lengkapi data Chip")
            Exit Sub
        End If

        If txtFinishGood.Text = "" Then
            MsgBox("lenkapi data Finish Good")
            Exit Sub
        End If

        If txtIdModel.Text = "" Then


            FP_INSERT()


        Else
            FP_MODIFY()
        End If

        txtIdModel.Text = ""
        txtModelName.Text = ""

        Call FP_LIST_HEAD()


    End Sub
    Public Sub cmdInquery()
        Call FP_LIST_HEAD()
    End Sub
    Public Sub cmdDelete()
        Dim Id_Mold As Integer

        SQL_C = ""
        SQL_C = SQL_C + "SELECT count(*) qty FROM KKTERP.mold_header where modl_idxx=" & txtIdModel.Text

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "SELECT molh_idxx FROM KKTERP.mold_header where modl_idxx=" & txtIdModel.Text

            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            Id_Mold = clsCom.gv_DataRdr("qty")
            clsCom.gv_ExeSqlReaderEnd()


            SQL_C = ""
            SQL_C = SQL_C + "DELETE KKTERP.mold_size where molh_idxx=" & Id_Mold

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C = SQL_C + "DELETE KKTERP.mold_building where molh_idxx=" & Id_Mold

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C = SQL_C + "DELETE KKTERP.mold_header where modl_idxx=" & txtIdModel.Text

            clsCom.GP_ExeSql(SQL_C)


        End If


        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.material_component where mclr_idxx in  (select mclr_idxx from KKTERP.dbo.model_color  WHERE modl_idxx=" & txtIdModel.Text & ")"

        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.model_color  WHERE modl_idxx=" & txtIdModel.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)


        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.model_color  WHERE modl_idxx=" & txtIdModel.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_CLEAR()
        Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_INIT()
        Call FP_LIST_HEAD()
    End Sub
    Private Sub FP_MODIFY()
        If txtChip.Text = "" Or txtGramasi.Text = "" Or txtFinishGood.Text = "" Or txtIdCustomer.Text = "" Or txtModelName.Text = "" Then
            MsgBox("LENGKAPI DATA DAHULU")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C = SQL_C + "UPDATE KKTERP.dbo.model" & vbCrLf
        SQL_C = SQL_C + "SET modl_name='" & txtModelName.Text & "'," & vbCrLf
        SQL_C = SQL_C + "CODE_GCUS=" & txtIdCustomer.Text & "," & vbCrLf
        SQL_C = SQL_C + "CODE_BRAN=" & Strings.Trim(Strings.Right(cboBrand.Text, 5)) & "," & vbCrLf
        SQL_C = SQL_C + "vend_idxx=" & Strings.Trim(Strings.Right(cboMoldshop.Text, 5)) & "," & vbCrLf
        SQL_C = SQL_C + "modl_fgod=" & txtFinishGood.Text & "," & vbCrLf
        SQL_C = SQL_C + "modl_gram=" & txtGramasi.Text & "," & vbCrLf
        SQL_C = SQL_C + "modl_chip=" & txtChip.Text & "" & vbCrLf
        SQL_C = SQL_C + " WHERE modl_idxx=" & txtIdModel.Text


        clsCom.GP_ExeSql(SQL_C)

        FP_CLEAR()
        Call FP_LIST_HEAD()

    End Sub
    Private Sub FP_CLEAR()
        txtModelName.Text = ""
        txtCustomer.Text = ""
        txtIdCustomer.Text = ""
        txtFinishGood.Text = ""
        txtGramasi.Text = ""
        txtChip.Text = ""
        txtIdModel.Text = ""

    End Sub
    Private Sub FP_INSERT()

        If txtChip.Text = "" Or txtGramasi.Text = "" Or txtFinishGood.Text = "" Or txtIdCustomer.Text = "" Or txtModelName.Text = "" Then
            MsgBox("LENGKAPI DATA DAHULU")
            Exit Sub
        End If

        SQL_C = ""
        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.model (modl_name,CODE_GCUS,CODE_BRAN,vend_idxx,modl_fgod,modl_gram,modl_chip) VALUES ('" & txtModelName.Text & "'," & txtIdCustomer.Text & "," & Strings.Trim(Strings.Right(cboBrand.Text, 3)) & "," & Strings.Trim(Strings.Right(cboMoldshop.Text, 3)) & "," & txtFinishGood.Text & "," & txtGramasi.Text & "," & txtChip.Text & ")" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)

        FP_CLEAR()
        Call FP_LIST_HEAD()
    End Sub

    Private Sub FP_DELETE()
        SQL_C = ""
        SQL_C = SQL_C + "DELETE KKTERP.dbo.model  WHERE modl_idxx=" & txtIdModel.Text & vbCrLf

        clsCom.GP_ExeSql(SQL_C)


        

        FP_CLEAR()
    End Sub

    Private Sub FP_LIST_HEAD()
 
        SQL_C = ""
        SQL_C += "SELECT modl_idxx," & vbLf
        SQL_C += "modl_name," & vbLf
        SQL_C += "vend_name," & vbLf
        SQL_C += "isnull(A.cust_idxx,'') cust_idxx," & vbLf
        SQL_C += "CODE_BRAN," & vbLf
        SQL_C += "A.CODE_GCUS," & vbLf
        SQL_C += "A.vend_idxx," & vbLf
        SQL_C += "isnull(modl_fgod,0) modl_fgod," & vbLf
        SQL_C += "isnull(modl_gram,0) modl_gram," & vbLf
        SQL_C += "isnull(modl_chip,0)  modl_chip," & vbLf
        SQL_C += "B.codd_desc vBrand,isnull(c.CODD_DESC,'') vCustomer" & vbLf
        SQL_C += "FROM KKTERP.dbo.model A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BRAN' AND B.codd_valu=CODE_BRAN" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GCUS' AND C.codd_valu=CODE_GCUS" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vendor D ON D.vend_idxx=A.vend_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer E ON E.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "WHERE modl_name is not null" & vbLf

        If txtCustomerCari.Text <> "" Then
            SQL_C += "AND C.codd_desc LIKE '%" & txtCustomerCari.Text & "%'" & vbLf
        End If

        If txtModelCari.Text <> "" Then
            SQL_C += "AND model_name LIKE '%" & txtModelCari.Text & "%'" & vbLf
        End If

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("vCustomer")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("vBrand")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("modl_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vend_name")

                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("modl_fgod")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("modl_chip")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("modl_gram")

                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("CODE_GCUS")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("CODE_BRAN")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("vend_idxx")



            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub



    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        With spdHead_Sheet1.Cells
            txtCustomer.Text = .Item(e.Row, 0).Text
            cboBrand.Text = .Item(e.Row, 1).Text & Space(100) & .Item(e.Row, 9).Text
            txtModelName.Text = .Item(e.Row, 2).Text
            cboMoldshop.Text = .Item(e.Row, 3).Text & Space(100) & .Item(e.Row, 10).Text
            txtIdModel.Text = .Item(e.Row, 7).Text
            txtIdCustomer.Text = .Item(e.Row, 8).Text
            txtFinishGood.Text = .Item(e.Row, 4).Text
            txtChip.Text = .Item(e.Row, 5).Text
            txtGramasi.Text = .Item(e.Row, 6).Text
            txtGCUS.Text = .Item(e.Row, 11).Text

        End With

        FP_LIST_COLOR()
    End Sub

    Private Sub frmModel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_INIT()
    End Sub

    Private Sub btnCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustomer.Click
        frmHelpGroupCustomer.ShowDialog()
        Dim vidModel As Integer


        ' frmHelpModelColorComplete.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdCustomer.Text = .Help_str1
            txtCustomer.Text = .Help_str2
         


        End With





errHandle:
    End Sub

   

    Private Sub spdHelpCustomer_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpCustomer.CellDoubleClick
        txtCustomer.Text = spdHelpCustomer.ActiveSheet.Cells(e.Row, 1).Value
        txtIdCustomer.Text = spdHelpCustomer.ActiveSheet.Cells(e.Row, 0).Value
        txtGCUS.Text = spdHelpCustomer.ActiveSheet.Cells(e.Row, 2).Value
        pnlHelpCustomer.Visible = False
        FP_COMBO_BRAND()
        FP_COMBO_MOLDSHOP()
    End Sub

  
    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

    End Sub

    Private Sub btnCloseCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCustomer.Click
        pnlHelpCustomer.Visible = False
    End Sub

    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        If txtIdModel.Text = "" Then
            MsgBox("Pilih Model dahulu")
            Exit Sub
        End If
        pnlColor.Visible = True
        FP_LIST_HELP_COLOR()
    End Sub

    

    Private Sub spdHelpColor_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpColor.CellDoubleClick

        If txtIdModel.Text = "" Then
            MsgBox("Simpan Dahulu Modelnya baru pilih warna")
            Exit Sub
        End If


        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.model_color" & vbLf
        SQL_C += "WHERE modl_idxx=" & txtIdModel.Text & "AND colr_idxx=" & spdHelpColor.ActiveSheet.Cells(e.Row, 0).Value

       

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.model_color (modl_idxx,colr_idxx) VALUES (" & txtIdModel.Text & "," & spdHelpColor.ActiveSheet.Cells(e.Row, 0).Value & ")" & vbCrLf

            clsCom.GP_ExeSql(SQL_C)
        Else
            clsCom.gv_ExeSqlReaderEnd()
            MsgBox("sudah ada")

        End If

        pnlColor.Visible = False
        FP_LIST_COLOR()
    End Sub

    

     
    Private Sub btnCariWarna_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariWarna.Click
        FP_LIST_HELP_COLOR()
    End Sub

    Private Sub spdHelpColor_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpColor.CellClick

    End Sub

    Private Sub btnCloseWarna_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseWarna.Click
        pnlColor.Visible = False
    End Sub
End Class