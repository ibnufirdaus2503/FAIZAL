﻿Public Class frmFormula
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vIdModel, vIdMaster, vIdWarna As Integer
   
    Private Sub FP_LIST_MODEL_WARNA()
        Dim RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.model_color where modl_idxx=" & vIdModel

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdColor_Sheet1.RowCount = clsCom.gv_DataRdr("QTY")
        clsCom.gv_ExeSqlReaderEnd()

        SQL_C = ""
        SQL_C += "SELECT mclr_idxx,colr_name" & vbLf
        SQL_C += "FROM KKTERP.dbo.model_color A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color B ON A.colr_idxx=B.colr_idxx" & vbLf
        SQL_C += "where modl_idxx=" & vIdModel
        SQL_C += "order by colr_name"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdColor_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1
                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("colr_name")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_MODEL()

        Dim RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.model where modl_idxx is not null"

        If txtModel.Text <> "" Then
            SQL_C += "AND modl_name like '%" & txtModel.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdModel_Sheet1.RowCount = clsCom.gv_DataRdr("QTY")
        clsCom.gv_ExeSqlReaderEnd()

        SQL_C = ""
        SQL_C += "SELECT modl_idxx,modl_name,A.mast_idxx,mast_name,ISNULL(modl_fgod,0) modl_fgod,CODD_DESC " & vbLf
        SQL_C += "FROM KKTERP.dbo.model A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_master B ON A.mast_idxx=B.mast_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_BRAN' AND CODD_VALU=B.CODE_BRAN" & vbLf
        SQL_C += "WHERE modl_idxx is not null" & vbLf

        If txtModel.Text <> "" Then
            SQL_C += "AND modl_name like '%" & txtModel.Text & "%'"
        End If

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1
                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("mast_idxx")
                .Cells.Item(RowIndex - 1, 2).Text = clsCom.gv_DataRdr("modl_name")
                .Cells.Item(RowIndex - 1, 3).Text = clsCom.gv_DataRdr("mast_name")
                .Cells.Item(RowIndex - 1, 4).Text = clsCom.gv_DataRdr("CODD_DESC")
                .Cells.Item(RowIndex - 1, 5).Text = clsCom.gv_DataRdr("modl_fgod")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_FILL_CATEGORY()
        txtIdGram.Text = spdMaterial_Sheet1.Cells.Item(spdMaterial_Sheet1.ActiveRowIndex, 0).Text
        txtMaterial.Text = spdMaterial_Sheet1.Cells.Item(spdMaterial_Sheet1.ActiveRowIndex, 2).Text
        txtGramasi.Text = spdMaterial_Sheet1.Cells.Item(spdMaterial_Sheet1.ActiveRowIndex, 3).Text
        txtIdMaterial.Text = spdMaterial_Sheet1.Cells.Item(spdMaterial_Sheet1.ActiveRowIndex, 4).Text

    End Sub
    Private Sub FP_LIST_MATERIAL()
        SQL_C = ""
        SQL_C += "SELECT gram_idxx,mate_name,cate_name,gram_valu,A.mate_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.material_gramasi A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material B ON A.mate_idxx=B.mate_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_category C ON B.cate_idxx=C.cate_idxx" & vbLf
        SQL_C += "WHERE mcom_idxx=" & spdComponent_Sheet1.Cells.Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text & "" & vbLf
        SQL_C += "ORDER BY cate_name,mate_name "


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdMaterial_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("gram_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cate_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("mate_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("gram_valu")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("mate_idxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_COMPONENT()

        Dim RowIndex As Integer

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY FROM KKTERP.dbo.material_component where mclr_idxx=" & vIdWarna

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        spdComponent_Sheet1.RowCount = clsCom.gv_DataRdr("QTY")
        clsCom.gv_ExeSqlReaderEnd()

        SQL_C = ""
        SQL_C += "SELECT mcom_idxx,codd_desc,codd_valu " & vbLf
        SQL_C += "from KKTERP.dbo.material_component A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON codh_flnm='CODE_COMP' AND B.codd_valu=CODE_COMP" & vbLf
        SQL_C += "WHERE mclr_idxx = " & vIdWarna

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            RowIndex = 0
            While clsCom.gv_DataRdr.Read
                RowIndex = RowIndex + 1
                .Cells.Item(RowIndex - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(RowIndex - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

  

    End Sub
    
   
 

     

   
 

    Private Sub btnHelpMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpMaterial.Click
        frmHelpMaterial.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIdMaterial.Text = .Help_str1
            txtMaterial.Text = .Help_str2



        End With

        

errHandle:
    End Sub

    Private Sub btnGramasi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGramasi.Click
        pnlGramasi.Visible = True
        txtIdMaterial.Text = ""
        txtGramasi.Text = ""
        txtMaterial.Text = ""
        txtIdGram.Text = ""
    End Sub

    Private Sub btnSaveMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMaterial.Click

        If txtIdGram.Text = "" Then
            SQL_C = ""
            SQL_C += "insert into KKTERP.dbo.material_gramasi (mcom_idxx,mate_idxx,gram_valu) VALUES (" & spdComponent_Sheet1.Cells.Item(spdComponent_Sheet1.ActiveRowIndex, 0).Text & "," & txtIdMaterial.Text & "," & txtGramasi.Text & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.material_gramasi SET gram_valu=" & txtGramasi.Text & ",mate_idxx=" & txtIdMaterial.Text & " WHERE gram_idxx=" & txtIdGram.Text

            clsCom.GP_ExeSql(SQL_C)
        End If
        pnlGramasi.Visible = False

        FP_LIST_MATERIAL()
    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        FP_LIST_MATERIAL()
    End Sub

    Private Sub spdMaterial_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaterial.CellClick

    End Sub

    Private Sub spdMaterial_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdMaterial.CellDoubleClick
        FP_FILL_CATEGORY()
        pnlGramasi.Visible = True
    End Sub

    Private Sub btnCloseMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseMaterial.Click
        pnlGramasi.Visible = False
    End Sub

    Private Sub btnDeleteMaterial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteMaterial.Click
        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.material_gramasi WHERE mcom_idxx=" & txtIdGram.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_MATERIAL()
        pnlGramasi.Visible = False
    End Sub

    Private Sub spdComponent_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellDoubleClick
        If MsgBox("Apakah akan di hapus ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.material_component WHERE mcom_idxx= " & spdComponent_Sheet1.Cells.Item(e.Row, 0).Text & ""

            clsCom.GP_ExeSql(SQL_C)

            FP_LIST_COMPONENT()
        End If
    End Sub

    Private Sub spdHelpComponen_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs)

    End Sub

    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        pnlModel.Visible = True
    End Sub

    Private Sub btnModelMOld_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModelMOld.Click
        Dim vidModel As Integer


        frmHelpModelName.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtIDModelMold.Text = .Help_str1
            txtMold.Text = .Help_str6
        


        End With





errHandle:
    End Sub

    Private Sub btnSaveModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveModel.Click
        If txtModelName.Text = "" Then
            MsgBox("Model Name Harus di Isi")
            Exit Sub

        End If


        If txtIDModelMold.Text = "" Then
            MsgBox("Mold Model Harus di Isi")
            Exit Sub

        End If

        If txtPairs.Text = "" Then
            MsgBox("Qty Finish Good Harus di Isi")
            Exit Sub

        End If

        If txtIdModel.Text = "" Then
            SQL_C = ""
            SQL_C += " INSERT INTO KKTERP.dbo.model (modl_name,mast_idxx,modl_fgod) values  ('" & txtModelName.Text & "'," & txtIDModelMold.Text & "," & txtPairs.Text & ")"

            clsCom.GP_ExeSql(SQL_C)
        Else
            SQL_C = ""
            SQL_C += "UPDATE KKTERP.dbo.model SET modl_name='" & txtModelName.Text & "',mast_idxx=" & txtIDModelMold.Text & ",modl_fgod=" & txtPairs.Text & " WHERE modl_idxx=" & txtIdModel.Text

            clsCom.GP_ExeSql(SQL_C)
        End If

        pnlModel.Visible = False


        FP_LIST_MODEL()


    End Sub

    Private Sub frmFormula_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_MODEL()
    End Sub

    Private Sub spdModel_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellClick
        vIdModel = spdModel_Sheet1.Cells.Item(e.Row, 0).Text
        vIdMaster = spdModel_Sheet1.Cells.Item(e.Row, 1).Text

        FP_LIST_MODEL_WARNA()




    End Sub

    Private Sub spdModel_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellDoubleClick
        pnlModel.Visible = True

        txtIdModel.Text = spdModel_Sheet1.Cells.Item(e.Row, 0).Text
        txtModelName.Text = spdModel_Sheet1.Cells.Item(e.Row, 2).Text
        txtIDModelMold.Text = spdModel_Sheet1.Cells.Item(e.Row, 1).Text
        txtMold.Text = spdModel_Sheet1.Cells.Item(e.Row, 3).Text
        txtPairs.Text = spdModel_Sheet1.Cells.Item(e.Row, 5).Text
    End Sub

    Private Sub btnDeleteModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteModel.Click
        
        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.material_gramasi   WHERE mcom_idxx in ( SELECT mcom_idxx FROM KKTERP.DBO.MATERIAL_COMPONENT WHERE mclr_idxx in (SELECT mclr_idxx FROM KKTERP.dbo.model_color WHERE modl_idxx=" & txtIdModel.Text & "))"
        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "DELETE KKTERP.DBO.MATERIAL_COMPONENT WHERE mclr_idxx in (SELECT mclr_idxx FROM KKTERP.dbo.model_color WHERE modl_idxx=" & txtIdModel.Text & ")"

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.model_color WHERE modl_idxx=" & txtIdModel.Text

        clsCom.GP_ExeSql(SQL_C)

        SQL_C = ""
        SQL_C += "DELETE KKTERP.dbo.model WHERE modl_idxx=" & txtIdModel.Text

        clsCom.GP_ExeSql(SQL_C)

        FP_LIST_MODEL()

        spdColor_Sheet1.RowCount = 0
        spdMaterial_Sheet1.RowCount = 0
        spdComponent_Sheet1.RowCount = 0

    End Sub

    Private Sub btnCloseModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseModel.Click
        pnlModel.Visible = False
    End Sub

    
    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        Dim mclr_idxx As Integer


        frmHelpColor.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)

            If .Help_str1 <> "" Then

                SQL_C = ""
                SQL_C += "SELECT count(*) qty    FROM KKTERP.dbo.model_color where modl_idxx=" & vIdModel & " and colr_idxx=" & .Help_str1

                clsCom.GP_ExeSqlReader(SQL_C)
                clsCom.gv_DataRdr.Read()
                If clsCom.gv_DataRdr("qty") <> 0 Then
                    clsCom.gv_ExeSqlReaderEnd()
                    MsgBox("Warna Sudah Ada")
                    Exit Sub
                Else
                    clsCom.gv_ExeSqlReaderEnd()

                    SQL_C = ""
                    SQL_C += "  INSERT INTO  KKTERP.dbo.model_color (modl_idxx,colr_idxx) values(" & vIdModel & "," & .Help_str1 & ")"

                    clsCom.GP_ExeSql(SQL_C)


                    SQL_C = ""
                    SQL_C += "SELECT TOP 1  mclr_idxx FROM KKTERP.dbo.model_color order by mclr_idxx desc"

                    clsCom.GP_ExeSqlReader(SQL_C)
                    clsCom.gv_DataRdr.Read()
                    mclr_idxx = clsCom.gv_DataRdr("mclr_idxx")
                    clsCom.gv_ExeSqlReaderEnd()


                    SQL_C = ""
                    SQL_C += "insert into  KKTERP.DBO.MATERIAL_COMPONENT (CODE_COMP,mclr_idxx)" & vbLf
                    SQL_C += "Select CODE_COMP," & mclr_idxx & " mclr_idxx" & vbLf
                    SQL_C += "FROM KKTERP.dbo.MODEL A" & vbLf
                    SQL_C += "LEFT JOIN KKTERP.dbo.mold_master B ON A.mast_idxx=B.mast_idxx" & vbLf
                    SQL_C += "LEFT JOIN KKTERP.dbo.mold_header C ON B.mast_idxx=C.mast_idxx" & vbLf
                    SQL_C += "LEFT JOIN KKTERP.dbo.CODE_COMMON D ON D.CODH_FLNM='CODE_COMP' AND CODE_COMP=CODD_VALU" & vbLf
                    SQL_C += "WHERE COD1_VALU='CMP' and a.modl_idxx=" & vIdModel & vbLf

                    clsCom.GP_ExeSql(SQL_C)
                End If





               

            End If




        End With

        FP_LIST_MODEL_WARNA()


errHandle:
    End Sub

    Private Sub spdColor_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdColor.CellClick
        vIdWarna = spdColor_Sheet1.Cells.Item(e.Row, 0).Text
        FP_LIST_COMPONENT()
    End Sub

    Private Sub btnModelColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModelColor.Click
        FP_LIST_MODEL()
    End Sub

    Private Sub spdColor_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdColor.CellDoubleClick
        If MsgBox("Apakah akan di hapus", vbYesNo) = MsgBoxResult.Yes Then

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.material_gramasi   WHERE mcom_idxx in ( SELECT mcom_idxx FROM KKTERP.DBO.MATERIAL_COMPONENT WHERE mclr_idxx=" & spdColor_Sheet1.Cells.Item(e.Row, 0).Text & ")"
            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "DELETE KKTERP.DBO.MATERIAL_COMPONENT WHERE mclr_idxx=" & spdColor_Sheet1.Cells.Item(e.Row, 0).Text

            clsCom.GP_ExeSql(SQL_C)

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.model_color WHERE mclr_idxx=" & spdColor_Sheet1.Cells.Item(e.Row, 0).Text

            clsCom.GP_ExeSql(SQL_C)

           
        End If


        FP_LIST_MODEL_WARNA()

        spdMaterial_Sheet1.RowCount = 0
        spdComponent_Sheet1.RowCount = 0
    End Sub
End Class