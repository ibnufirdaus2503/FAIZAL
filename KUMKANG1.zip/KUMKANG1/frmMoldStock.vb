﻿Public Class frmMoldStock
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim code_mold As Integer
    Dim CODE_BUIL As Integer
    Dim ROW As Integer
    Private Sub FP_LIST_SET_MOLD_DESTROY(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT A.mols_size,A.mold_idxx,vseqn,QTY,mols_cavi,QTY*mols_cavi ttl" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.mols_size,A.mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=3 AND CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY A.mols_size,A.mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,count(mold_idxx) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=3 AND  CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "( " & vbLf
        SQL_C += "SELECT mols_size,molh_idxx,mols_cavi" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size C " & vbLf
        SQL_C += "WHERE molh_idxx= " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "  ) C ON A.mols_size=C.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn,A.mold_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDestroy_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                    .ColumnHeader.Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_cavi")
                    .ColumnHeader.Cells.Item(3, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ttl")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SET_MOLD_HABIS(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT A.mols_size,A.mold_idxx,vseqn,QTY,mols_cavi,QTY*mols_cavi ttl" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.mols_size,A.mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=2 AND CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY A.mols_size,A.mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,count(mold_idxx) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=2 AND  CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "( " & vbLf
        SQL_C += "SELECT mols_size,molh_idxx,mols_cavi" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size C " & vbLf
        SQL_C += "WHERE molh_idxx= " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "  ) C ON A.mols_size=C.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn,A.mold_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHabis_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                    .ColumnHeader.Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_cavi")
                    .ColumnHeader.Cells.Item(3, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ttl")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SET_MOLD_SERVICE(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT A.mols_size,A.mold_idxx,vseqn,QTY,mols_cavi,QTY*mols_cavi ttl" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.mols_size,A.mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=1 AND CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY A.mols_size,A.mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,count(mold_idxx) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_MOTR=1 AND  CODE_INOT=2 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "( " & vbLf
        SQL_C += "SELECT mols_size,molh_idxx,mols_cavi" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size C " & vbLf
        SQL_C += "WHERE molh_idxx= " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "  ) C ON A.mols_size=C.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn,A.mold_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdService_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                    .ColumnHeader.Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_cavi")
                    .ColumnHeader.Cells.Item(3, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ttl")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_BUILD()
        SQL_C = ""
        SQL_C += "SELECT CODE_BUIL,codd_desc,qty,cod2_valu" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT  CODE_BUIL,COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += "WHERE CODE_INOT=1 AND  molh_idxx =  " & spdComponent_Sheet1.Cells.Item(code_mold, 0).Text & "" & vbLf
        SQL_C += "GROUP BY CODE_BUIL" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_BUIL' AND B.codd_valu=CODE_BUIL" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdBuilding_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("CODE_BUIL")
                '  .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("qty")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SET_MOLD_BUILDING(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""

        SQL_C = ""
        SQL_C += "SELECT A.mols_size,A.mold_idxx,vseqn,QTY,mols_cavi,QTY*mols_cavi ttl" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.mols_size,A.mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_INOT=1 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(code_mold, 0).Text & " AND CODE_BUIL='" & spdBuilding_Sheet1.Cells.Item(CODE_BUIL, 0).Text & "'" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY A.mols_size,A.mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,count(mold_idxx) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_INOT=1 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(code_mold, 0).Text & "AND CODE_BUIL='" & spdBuilding_Sheet1.Cells.Item(CODE_BUIL, 0).Text & "'" & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "( " & vbLf
        SQL_C += "SELECT mols_size,molh_idxx,mols_cavi" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size C " & vbLf
        SQL_C += "WHERE molh_idxx= " & spdComponent_Sheet1.Cells.Item(code_mold, 0).Text & "  ) C ON A.mols_size=C.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn,A.mold_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                    .ColumnHeader.Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_cavi")
                    .ColumnHeader.Cells.Item(3, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ttl")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub FP_LIST_SET_MOLD(ByVal ID As Integer)
        Dim Old_Size As String
        Dim vRow As Integer
        vRow = 0
        Old_Size = ""
 
        SQL_C = ""
        SQL_C += "SELECT A.mols_size,A.mold_idxx,vseqn,QTY,mols_cavi,QTY*mols_cavi ttl" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.mols_size,A.mold_idxx,max(grop_seqn) vseqn" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,mold_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_INOT=1 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.group_size B on B.grop_size=mols_size" & vbLf
        SQL_C += "GROUP BY A.mols_size,A.mold_idxx" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mols_size,count(mold_idxx) qty " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_stock A" & vbLf
        SQL_C += " where CODE_INOT=1 AND  molh_idxx =   " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "" & vbLf
        SQL_C += "GROUP BY mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=B.mols_size" & vbLf
        SQL_C += "INNER Join " & vbLf
        SQL_C += "( " & vbLf
        SQL_C += "SELECT mols_size,molh_idxx,mols_cavi" & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_size C " & vbLf
        SQL_C += "WHERE molh_idxx= " & spdComponent_Sheet1.Cells.Item(ID, 0).Text & "  ) C ON A.mols_size=C.mols_size" & vbLf
        SQL_C += "ORDER BY vseqn,A.mold_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDetail_Sheet1

            .RowCount = 50
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read

                If Old_Size <> clsCom.gv_DataRdr("mols_size") Then
                    .ColumnCount = .ColumnCount + 1

                    vRow = 0
                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                    .ColumnHeader.Cells.Item(1, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                    .ColumnHeader.Cells.Item(2, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_cavi")
                    .ColumnHeader.Cells.Item(3, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ttl")
                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1
                Else

                    .Cells.Item(vRow, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mold_idxx")
                    vRow = vRow + 1


                End If

                Old_Size = clsCom.gv_DataRdr("mols_size")






            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub
    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        frmHelpModelMold.ShowDialog()




        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtCustomer.Text = .Help_str1
            txtBrand.Text = .Help_str3
            txtModel.Text = .Help_str2
            txtIdModel.Text = .Help_str6
            txtMoldshop.Text = .Help_str7


        End With

        FP_LIST_COMPONENT()

errHandle:
    End Sub

    Private Sub FP_LIST_COMPONENT()


        SQL_C = ""
        SQL_C += "SELECT molh_idxx,molh_code,codd_desc,code_comp" & vbLf
        SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf
        SQL_C += "where modl_idxx=  " & txtIdModel.Text
        SQL_C += " order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("code_comp")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("molh_code")


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub spdComponent_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdComponent.CellClick
        code_mold = e.Row
        FP_LIST_SET_MOLD(code_mold)
        FP_LIST_BUILD()
        FP_LIST_SET_MOLD_SERVICE(code_mold)
        FP_LIST_SET_MOLD_HABIS(code_mold)
        FP_LIST_SET_MOLD_DESTROY(code_mold)
    End Sub

    Private Sub spdDetail_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDetail.CellClick

    End Sub

    Private Sub spdBuilding_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdBuilding.CellClick
        CODE_BUIL = e.Row
        FP_LIST_SET_MOLD_BUILDING(CODE_BUIL)
        FP_LIST_SET_MOLD_HABIS(CODE_BUIL)
    End Sub
End Class