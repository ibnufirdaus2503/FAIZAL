﻿Public Class frmRptProdBySize
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String

    Public Sub cmdInquery()
        FP_HEAD()
    End Sub
    Private Sub FP_COMBO_PRODUCT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc  FROM KKTERP.dbo.code_common where codh_flnm='CODE_SCAN'"




        clsCom.GP_ExeSqlReader(SQL_C)


        With cboProc
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("codd_desc") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While
            .SelectedIndex() = 0


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_DETAIL()
        SQL_C = ""
        SQL_C += "SELECT mols_size,SUM(prod_qtty) qtty " & vbLf
        SQL_C += "FROM KKTERP.dbo.production " & vbLf
        SQL_C += "where cONVERT(VARCHAR(10),prod_date,111)=convert(varchar(10),'" & dtContract.Value & "',111)" & vbLf
        SQL_C += "AND prod_opcd='CMP' " & vbLf
        ' SQL_C += "AND modl_idxx= " & Val(Strings.Right(spdModel_Sheet1.Cells.Item(spdModel_Sheet1.ActiveRowIndex, 1).Text, 5)) & vbLf
        SQL_C += "AND mcom_idxx=" & spdModel_Sheet1.Cells.Item(spdModel_Sheet1.ActiveRowIndex, 0).Text & vbLf

        If Val(Strings.Right(cboProc.Text, 1)) = 1 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_scin is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 2 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_ingr is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 3 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_otgr is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 4 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_ingr is not null and prod_otgr is null" & vbLf
        End If

        SQL_C += "GROUP BY mols_size" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("qtty")
            
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_HEAD()
        SQL_C = ""
        SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "where cONVERT(VARCHAR(10),prod_date,111)=convert(varchar(10),'" & dtContract.Value & "',111)" & vbLf

        If Val(Strings.Right(cboProc.Text, 1)) = 1 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_scin is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 2 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_ingr is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 3 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_otgr is not null" & vbLf
        ElseIf Val(Strings.Right(cboProc.Text, 1)) = 4 Then
            SQL_C += "AND prod_opcd='CMP' " & vbLf
            SQL_C += "AND prod_ingr is not null and prod_otgr is null" & vbLf
        End If

        SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("QTY")



            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmRptProdBySize_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '   FP_HEAD()
        FP_COMBO_PRODUCT()
    End Sub

    Private Sub spdModel_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellClick
        FP_DETAIL()
    End Sub

    Private Sub spdModel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles spdModel.Click
        FP_DETAIL()
    End Sub
End Class