﻿Public Class frmOrderCustomer
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vKontrak, vPo As String
    Dim Vmodel As Integer
    Private Sub FP_LIST_COMPONENT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT A.modl_idxx,A.molh_idxx,A.molh_code,B.codd_desc,CODE_COMP " & vbLf
        SQL_C += "FROM KKTERP.dbo.mold_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_COMP' and B.codd_valu=CODE_COMP" & vbLf
        SQL_C += "where A.modl_idxx=" & Vmodel





        clsCom.GP_ExeSqlReader(SQL_C)

        With spdComponent_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("molh_code")
                ' .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("CODE_COMP")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SIZE()
        SQL_C = ""
        SQL_C += "SELECT ordd_size,ordd_qtyx FROM KKTERP.dbo.order_detail WHERE ordh_poxx='" & vPo & "' order by  ordd_size" & vbLf
       

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1
 

                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("ordd_qtyx")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_LIST_PO()
        SQL_C = ""
        SQL_C += "SELECT ordh_poxx,convert(varchar(10),ordh_Date,111) ordh_date,convert(varchar(10),ordh_etdh,111) ordh_etdh,A.colr_idxx,colr_name" & vbLf
        SQL_C += "FROM  KKTERP.dbo.order_header A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.color B ON A.colr_idxx=B.colr_idxx" & vbLf
        SQL_C += "where cntr_noxx='" & vKontrak & "'"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPO_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_date")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_etdh")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_idxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_LIST_CONTRACT()
        SQL_C = ""
        SQL_C += "SELECT A.cntr_noxx,convert(varchar(10),cntr_date,111) cntr_date,A.cust_idxx,A.CODE_BRAN,A.CODE_PROD,A.CODE_GEND,A.modl_idxx,A.cntr_desc," & vbLf
        SQL_C += "B.cust_name,modl_name,C.codd_desc brand,D.codd_desc item_prod,E.codd_desc gender" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_contract A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.customer B ON A.cust_idxx=B.cust_idxx" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_BRAN' AND C.codd_valu=CODE_BRAN" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_PROD' AND D.codd_valu=CODE_PROD" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_GEND' AND E.codd_valu=CODE_GEND" & vbLf
        SQL_C += "INNER JOIN  KKTERP.dbo.model F ON F.modl_idxx=A.modl_idxx" & vbLf
        SQL_C += "WHERE cntr_date is not null" & vbLf
        SQL_C += "order by cntr_dins" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdContract_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("cntr_noxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("cntr_Date")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("brand")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("item_prod")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("modl_name")

                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("CODE_BRAN")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("item_prod")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("modl_idxx")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

    End Sub
    Private Sub FP_LIST_PRODUCT()
        SQL_C = ""
        SQL_C += " SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_PROD' order by codd_valu" & vbLf
       
        clsCom.GP_ExeSqlReader(SQL_C)


        With cboProduct
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While

            .SelectedIndex = 0
        End With


    End Sub
    Private Sub FP_LIST_GENDER()
        SQL_C = ""
        SQL_C += " SELECT codd_valu,codd_desc FROM KKTERP.dbo.code_common WHERE codh_flnm='CODE_GEND' order by codd_desc" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)


        With cboGender
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("codd_valu"))
            End While

            .SelectedIndex = 0
        End With


    End Sub
    Private Sub FP_LIST_BRAND()
        SQL_C = ""
        SQL_C += "SELECT A.cust_idxx,B.cust_name,C.codd_desc,CODE_BRAN " & vbLf
        SQL_C += "FROM KKTERP.dbo.customer_brand A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer B ON A.cust_idxx=B.cust_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON c.codh_flnm='CODE_BRAN' AND C.codd_valu=CODE_BRAN" & vbLf
        SQL_C += "WHERE A.cust_idxx =" & txtIdCustomer.Text


        clsCom.GP_ExeSqlReader(SQL_C)


        With cboBrand
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("CODE_BRAN"))
            End While

            .SelectedIndex = 0
        End With


    End Sub


    Private Sub FP_LIST_MODEL()

        SQL_C = ""
        SQL_C += "SELECT A.* " & vbLf
        SQL_C += "FROM KKTERP.dbo.model A" & vbLf

        If txtHelpModelCari.Text <> "" Then
            SQL_C += "WHERE modl_name like '%" & txtHelpModelCari.Text & "%'"
        End If
        SQL_C += "ORDER BY A.modl_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpModel_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("modl_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_COLOR()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT A.* " & vbLf
        SQL_C += "FROM KKTERP.dbo.color A" & vbLf

        If txtHelpModelCari.Text <> "" Then
            SQL_C += "WHERE colr_name like '%" & txtHelpCariColor.Text & "%'"
        End If
        SQL_C += "ORDER BY A.colr_name" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpColor_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("colr_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("colr_name")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub frmOrderCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_INIT()
    End Sub


    Private Sub FP_COMBO_PRODUCT()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT * " & vbLf
        SQL_C += "FROM KKTERP.dbo.Vproduct" & vbLf
        SQL_C += "ORDER BY component_name"

        clsCom.GP_ExeSqlReader(SQL_C)

        With cboProductCari
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("component_name") & Space(100) & clsCom.gv_DataRdr("component_id"))
            End While


        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_COMBO_GENDER()
        Dim SQL_C As String


        SQL_C = ""
        SQL_C += "select A.CODE_GEND,B.codd_desc " & vbLf
        SQL_C += "from KKTERP.dbo.customer_gender A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B on B.codh_flnm='CODE_GEND' and B.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "where A.cust_idxx =" & txtIdCustomer.Text & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)


        With cboGender
            .Items.Clear()
            While clsCom.gv_DataRdr.Read
                .Items.Add(clsCom.gv_DataRdr("CODD_DESC") & Space(100) & clsCom.gv_DataRdr("CODE_GEND"))
            End While


        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_INIT()
        'FP_COMBO_PRODUCT()
        FP_LIST_CONTRACT()
        FP_LIST_PRODUCT()
        FP_LIST_GENDER()
    End Sub


    Private Sub btnModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModel.Click
        pnlModel.Visible = True
        FP_LIST_MODEL()
    End Sub

    Private Sub btnCloseModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        pnlModel.Visible = False
    End Sub
 
    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FP_LIST_MODEL()
    End Sub

    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        pnlHelpColor.Visible = True
        FP_LIST_COLOR()
    End Sub

    Private Sub btnCloseColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseColor.Click
        pnlHelpColor.Visible = False
    End Sub



    Private Sub spdHelpColor_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpColor.CellDoubleClick
        txtColor.Text = spdHelpColor.ActiveSheet.Cells(e.Row, 1).Value
        txtIdColor.Text = spdHelpColor.ActiveSheet.Cells(e.Row, 0).Value
        pnlHelpColor.Visible = False
    End Sub

    Private Sub btnCloseSizeUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        pnlUpdateSize.Visible = False
    End Sub


    Private Sub btnSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSize.Click
        pnlHelpSizeUpdate.Visible = True


       
    End Sub

    

    Private Sub btnHelpCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelpCustomer.Click
        frmHelpDelivery.ShowDialog()

        On Error GoTo errHandle
        With clsVAR.gv_Help(0)
            txtCustomer.Text = .Help_str2
            txtIdCustomer.Text = .Help_str1

        End With

        FP_LIST_BRAND()

errHandle:
    End Sub

    
    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click
        pnlKontrak.Visible = True
    End Sub
     

    Private Sub spdHelpModel_CellClick_1(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpModel.CellClick
        txtModel.Text = spdHelpModel.ActiveSheet.Cells(e.Row, 1).Value
        txtIdModel.Text = spdHelpModel.ActiveSheet.Cells(e.Row, 0).Value
        pnlModel.Visible = False
    End Sub
 
    Private Sub btnCloseContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseContract.Click
        pnlKontrak.Visible = False
    End Sub

    Private Sub btnSaveContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveContract.Click
        SQL_C = ""
        SQL_C += "select count(*) qty " & vbLf
        SQL_C += "from KKTERP.dbo.order_contract" & vbLf
        SQL_C += "where cntr_noxx='" & txtNoKontrak.Text & "'"


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()
 
            SQL_C = ""
            SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.order_contract(cntr_noxx,cust_idxx,CODE_BRAN,CODE_PROD,CODE_GEND,modl_idxx,cntr_desc,cntr_date,cntr_dins,cntr_uins) VALUES ('" & txtNoKontrak.Text & "','" & txtIdCustomer.Text & "','" & Strings.Trim(Strings.Right(cboBrand.Text, 3)) & "','" & Strings.Trim(Strings.Right(cboProduct.Text, 5)) & "','" & Strings.Trim(Strings.Right(cboGender.Text, 5)) & "'," & txtIdModel.Text & ",'" & txtDescContract.Text & "','" & dtContract.Text & "',GETDATE(),'ADMIN')"

            clsCom.GP_ExeSql(SQL_C)
  


        End If
        clsCom.gv_ExeSqlReaderEnd()

        pnlKontrak.Visible = False
        FP_LIST_CONTRACT()
    End Sub
 
    Private Sub btnSavePO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSavePO.Click
        SQL_C = ""
        SQL_C += "select count(*) qty " & vbLf
        SQL_C += "from KKTERP.dbo.order_header" & vbLf
        SQL_C += "where ordh_poxx='" & txtPO.Text & "'"


        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("qty") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            SQL_C = ""
            SQL_C = SQL_C + " insert into KKTERP.dbo.order_header (cntr_noxx,ordh_poxx,ordh_date,colr_idxx,ordh_etdh,ordh_styl,ordh_desc) values ('" & vKontrak & "','" & txtPO.Text & "','" & dtPO.Text & "'," & txtIdColor.Text & ",'" & dtPO.Text & "','" & txtStyle.Text & "','" & txtDesc.Text & "')"

            clsCom.GP_ExeSql(SQL_C)



        End If
        clsCom.gv_ExeSqlReaderEnd()

        FP_LIST_PO()

        pnlPO.Visible = False
    End Sub

    Private Sub spdContract_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdContract.CellClick
        vKontrak = spdContract.ActiveSheet.Cells(e.Row, 0).Value
        Vmodel = spdContract.ActiveSheet.Cells(e.Row, 9).Value
        FP_LIST_PO()
        FP_LIST_COMPONENT()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        pnlPO.Visible = True
    End Sub

    Private Sub spdPO_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdPO.CellClick
        vPo = spdPO.ActiveSheet.Cells(e.Row, 0).Value
        FP_LIST_SIZE()
    End Sub

    Private Sub btnSaveSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveSize.Click
        Dim i As Integer
         

        With spdUpdateSize_Sheet1
            For i = 0 To .ColumnCount - 1
                If .Cells.Item(0, i).Text <> "" Then
                    SQL_C = ""
                    SQL_C = SQL_C + "insert into KKTERP.dbo.order_detail (ordh_poxx,ordd_size,ordd_qtyx) values ('" & vPo & "','" & .Cells.Item(0, i).Text & "'," & .Cells.Item(1, i).Text & ")"

                    clsCom.GP_ExeSqlReader(SQL_C)
                End If
            Next


        End With
 

        clsCom.gv_ExeSqlReaderEnd()

        pnlHelpSizeUpdate.Visible = False
        FP_LIST_SIZE()
    End Sub

    Private Sub btnCloseSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSize.Click
        pnlHelpSizeUpdate.Visible = False
    End Sub

    Private Sub btnClosePO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClosePO.Click
        pnlPO.Visible = False
    End Sub

    Private Sub btnCloseModel_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseModel.Click
        pnlModel.Visible = False
    End Sub
End Class