﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLineProduction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer9 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer10 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer11 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer12 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer8 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer20 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer15 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer16 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer13 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer17 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer14 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer18 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer15 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle29 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle30 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle31 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer8 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle32 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType8 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer16 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer17 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle33 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle34 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle35 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer9 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle36 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType9 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer18 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer11 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle21 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle22 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle23 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer6 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle24 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType6 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer12 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Me.spdFunction = New FarPoint.Win.Spread.FpSpread
        Me.spdFunction_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdArea = New FarPoint.Win.Spread.FpSpread
        Me.spdArea_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdBuilding = New FarPoint.Win.Spread.FpSpread
        Me.spdBuilding_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnAddFunction = New System.Windows.Forms.Button
        Me.spdHelpFunction = New FarPoint.Win.Spread.FpSpread
        Me.spdHelpFunction_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlHelpFunction = New System.Windows.Forms.Panel
        Me.btnCloseFunction = New System.Windows.Forms.Button
        Me.spdRoom = New FarPoint.Win.Spread.FpSpread
        Me.spdRoom_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlRoom = New System.Windows.Forms.Panel
        Me.txtIdRoom = New System.Windows.Forms.TextBox
        Me.btnCloseRoom = New System.Windows.Forms.Button
        Me.btnDeleteRoom = New System.Windows.Forms.Button
        Me.btnSaveRoom = New System.Windows.Forms.Button
        Me.txtRoom = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.btnAddRoom = New System.Windows.Forms.Button
        Me.spdSubline = New FarPoint.Win.Spread.FpSpread
        Me.spdSubline_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlSubline = New System.Windows.Forms.Panel
        Me.txtIdSubline = New System.Windows.Forms.TextBox
        Me.btnCloseSubline = New System.Windows.Forms.Button
        Me.btnDeleteSubline = New System.Windows.Forms.Button
        Me.btnSaveSubline = New System.Windows.Forms.Button
        Me.txtSubline = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnAddSubline = New System.Windows.Forms.Button
        Me.spdMachine = New FarPoint.Win.Spread.FpSpread
        Me.spdMachine_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdCell = New FarPoint.Win.Spread.FpSpread
        Me.spdCell_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.pnlMachine = New System.Windows.Forms.Panel
        Me.txtIdMachine = New System.Windows.Forms.TextBox
        Me.btnCloseMachine = New System.Windows.Forms.Button
        Me.btnDeleteMachine = New System.Windows.Forms.Button
        Me.btnSaveMachine = New System.Windows.Forms.Button
        Me.txtMachine = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.btnAddMachine = New System.Windows.Forms.Button
        Me.pnlCell = New System.Windows.Forms.Panel
        Me.btnCloseCell = New System.Windows.Forms.Button
        Me.btnDeleteCell = New System.Windows.Forms.Button
        Me.btnSaveCell = New System.Windows.Forms.Button
        Me.txtCell = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.txtIdCell = New System.Windows.Forms.TextBox
        CType(Me.spdFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdFunction_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdArea, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdArea_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdBuilding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdBuilding_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHelpFunction_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHelpFunction.SuspendLayout()
        CType(Me.spdRoom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdRoom_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlRoom.SuspendLayout()
        CType(Me.spdSubline, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSubline_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSubline.SuspendLayout()
        CType(Me.spdMachine, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdMachine_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCell, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdCell_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlMachine.SuspendLayout()
        Me.pnlCell.SuspendLayout()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer9.Name = "EnhancedColumnHeaderRenderer9"
        EnhancedColumnHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer9.TextRotationAngle = 0
        EnhancedRowHeaderRenderer9.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer9.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer9.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer9.Name = "EnhancedRowHeaderRenderer9"
        EnhancedRowHeaderRenderer9.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer9.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer9.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer9.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer9.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer9.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer10.Name = "EnhancedColumnHeaderRenderer10"
        EnhancedColumnHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer10.TextRotationAngle = 0
        EnhancedRowHeaderRenderer10.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer10.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer10.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer10.Name = "EnhancedRowHeaderRenderer10"
        EnhancedRowHeaderRenderer10.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer10.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer10.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer10.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer10.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer10.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer11.Name = "EnhancedColumnHeaderRenderer11"
        EnhancedColumnHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer11.TextRotationAngle = 0
        EnhancedRowHeaderRenderer11.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer11.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer11.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer11.Name = "EnhancedRowHeaderRenderer11"
        EnhancedRowHeaderRenderer11.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer11.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer11.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer11.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer11.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer11.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer12.Name = "EnhancedColumnHeaderRenderer12"
        EnhancedColumnHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer12.TextRotationAngle = 0
        EnhancedRowHeaderRenderer12.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer12.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer12.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer12.Name = "EnhancedRowHeaderRenderer12"
        EnhancedRowHeaderRenderer12.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer12.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer12.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer12.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer12.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer12.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer8.Name = "EnhancedColumnHeaderRenderer8"
        EnhancedColumnHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer8.TextRotationAngle = 0
        EnhancedRowHeaderRenderer8.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer8.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer8.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer8.Name = "EnhancedRowHeaderRenderer8"
        EnhancedRowHeaderRenderer8.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer8.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer8.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer8.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer8.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer8.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer20.Name = "EnhancedColumnHeaderRenderer20"
        EnhancedColumnHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer20.TextRotationAngle = 0
        EnhancedRowHeaderRenderer20.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer20.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer20.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer20.Name = "EnhancedRowHeaderRenderer20"
        EnhancedRowHeaderRenderer20.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer20.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer20.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer20.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer20.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer20.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer15.Name = "EnhancedColumnHeaderRenderer15"
        EnhancedColumnHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer15.TextRotationAngle = 0
        EnhancedRowHeaderRenderer15.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer15.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer15.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer15.Name = "EnhancedRowHeaderRenderer15"
        EnhancedRowHeaderRenderer15.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer15.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer15.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer15.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer15.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer15.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer16.Name = "EnhancedColumnHeaderRenderer16"
        EnhancedColumnHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer16.TextRotationAngle = 0
        EnhancedRowHeaderRenderer16.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer16.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer16.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer16.Name = "EnhancedRowHeaderRenderer16"
        EnhancedRowHeaderRenderer16.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer16.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer16.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer16.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer16.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer16.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer13.Name = "EnhancedColumnHeaderRenderer13"
        EnhancedColumnHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer13.TextRotationAngle = 0
        EnhancedRowHeaderRenderer13.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer13.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer13.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer13.Name = "EnhancedRowHeaderRenderer13"
        EnhancedRowHeaderRenderer13.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer13.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer13.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer13.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer13.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer13.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer17.Name = "EnhancedColumnHeaderRenderer17"
        EnhancedColumnHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer17.TextRotationAngle = 0
        EnhancedRowHeaderRenderer17.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer17.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer17.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer17.Name = "EnhancedRowHeaderRenderer17"
        EnhancedRowHeaderRenderer17.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer17.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer17.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer17.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer17.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer17.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer14.Name = "EnhancedColumnHeaderRenderer14"
        EnhancedColumnHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer14.TextRotationAngle = 0
        EnhancedRowHeaderRenderer14.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer14.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer14.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer14.Name = "EnhancedRowHeaderRenderer14"
        EnhancedRowHeaderRenderer14.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer14.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer14.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer14.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer14.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer14.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer18.Name = "EnhancedColumnHeaderRenderer18"
        EnhancedColumnHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer18.TextRotationAngle = 0
        EnhancedRowHeaderRenderer18.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer18.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer18.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer18.Name = "EnhancedRowHeaderRenderer18"
        EnhancedRowHeaderRenderer18.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer18.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer18.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer18.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer18.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer18.TextRotationAngle = 0
        '
        'spdFunction
        '
        Me.spdFunction.AccessibleDescription = "spdFunction, Sheet1, Row 0, Column 0, "
        Me.spdFunction.BackColor = System.Drawing.SystemColors.Control
        Me.spdFunction.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdFunction.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer15.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer15.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer15.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer15.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer15.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdFunction.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer15
        Me.spdFunction.HorizontalScrollBar.TabIndex = 8
        Me.spdFunction.Location = New System.Drawing.Point(2, 314)
        Me.spdFunction.Name = "spdFunction"
        NamedStyle29.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle29.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle29.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle29.Renderer = EnhancedColumnHeaderRenderer20
        NamedStyle29.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle30.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle30.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle30.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle30.Renderer = EnhancedRowHeaderRenderer20
        NamedStyle30.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle31.BackColor = System.Drawing.Color.DimGray
        NamedStyle31.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle31.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer8.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer8.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer8.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle31.Renderer = EnhancedCornerRenderer8
        NamedStyle31.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle32.BackColor = System.Drawing.SystemColors.Window
        NamedStyle32.CellType = GeneralCellType8
        NamedStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle32.Renderer = GeneralCellType8
        Me.spdFunction.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle29, NamedStyle30, NamedStyle31, NamedStyle32})
        Me.spdFunction.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdFunction.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdFunction_Sheet1})
        Me.spdFunction.Size = New System.Drawing.Size(221, 178)
        Me.spdFunction.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdFunction.TabIndex = 21
        Me.spdFunction.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdFunction.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer16.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer16.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer16.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer16.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer16.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdFunction.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer16
        Me.spdFunction.VerticalScrollBar.TabIndex = 9
        Me.spdFunction.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdFunction_Sheet1
        '
        Me.spdFunction_Sheet1.Reset()
        Me.spdFunction_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdFunction_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdFunction_Sheet1.ColumnCount = 2
        Me.spdFunction_Sheet1.RowCount = 1
        Me.spdFunction_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdFunction_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "FUNCTION"
        Me.spdFunction_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdFunction_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdFunction_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdFunction_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdFunction_Sheet1.Columns.Get(1).Label = "FUNCTION"
        Me.spdFunction_Sheet1.Columns.Get(1).Width = 144.0!
        Me.spdFunction_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdFunction_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdFunction_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdFunction_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdArea
        '
        Me.spdArea.AccessibleDescription = "spdArea, Sheet1, Row 0, Column 0, "
        Me.spdArea.BackColor = System.Drawing.SystemColors.Control
        Me.spdArea.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdArea.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer17.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer17.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer17.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer17.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer17.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer17.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer17.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer17.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer17.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer17.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer17.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdArea.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer17
        Me.spdArea.HorizontalScrollBar.TabIndex = 6
        Me.spdArea.Location = New System.Drawing.Point(2, 2)
        Me.spdArea.Name = "spdArea"
        NamedStyle33.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle33.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle33.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle33.Renderer = EnhancedColumnHeaderRenderer10
        NamedStyle33.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle34.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle34.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle34.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle34.Renderer = EnhancedRowHeaderRenderer10
        NamedStyle34.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle35.BackColor = System.Drawing.Color.DimGray
        NamedStyle35.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle35.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer9.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer9.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer9.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle35.Renderer = EnhancedCornerRenderer9
        NamedStyle35.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle36.BackColor = System.Drawing.SystemColors.Window
        NamedStyle36.CellType = GeneralCellType9
        NamedStyle36.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle36.Renderer = GeneralCellType9
        Me.spdArea.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle33, NamedStyle34, NamedStyle35, NamedStyle36})
        Me.spdArea.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdArea.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdArea_Sheet1})
        Me.spdArea.Size = New System.Drawing.Size(221, 127)
        Me.spdArea.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdArea.TabIndex = 27
        Me.spdArea.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdArea.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer18.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer18.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer18.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer18.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer18.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer18.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer18.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer18.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer18.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer18.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer18.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdArea.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer18
        Me.spdArea.VerticalScrollBar.TabIndex = 7
        Me.spdArea.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdArea_Sheet1
        '
        Me.spdArea_Sheet1.Reset()
        Me.spdArea_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdArea_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdArea_Sheet1.ColumnCount = 2
        Me.spdArea_Sheet1.RowCount = 1
        Me.spdArea_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdArea_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "AREA"
        Me.spdArea_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdArea_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdArea_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdArea_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdArea_Sheet1.Columns.Get(1).Label = "AREA"
        Me.spdArea_Sheet1.Columns.Get(1).Width = 119.0!
        Me.spdArea_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdArea_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdArea_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdArea_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdBuilding
        '
        Me.spdBuilding.AccessibleDescription = "spdBuilding, Sheet1, Row 0, Column 0, "
        Me.spdBuilding.BackColor = System.Drawing.SystemColors.Control
        Me.spdBuilding.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdBuilding.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdBuilding.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdBuilding.HorizontalScrollBar.TabIndex = 8
        Me.spdBuilding.Location = New System.Drawing.Point(2, 131)
        Me.spdBuilding.Name = "spdBuilding"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer11
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer11
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdBuilding.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdBuilding.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdBuilding.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdBuilding_Sheet1})
        Me.spdBuilding.Size = New System.Drawing.Size(221, 181)
        Me.spdBuilding.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdBuilding.TabIndex = 28
        Me.spdBuilding.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdBuilding.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdBuilding.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdBuilding.VerticalScrollBar.TabIndex = 9
        Me.spdBuilding.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdBuilding_Sheet1
        '
        Me.spdBuilding_Sheet1.Reset()
        Me.spdBuilding_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdBuilding_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdBuilding_Sheet1.ColumnCount = 2
        Me.spdBuilding_Sheet1.RowCount = 1
        Me.spdBuilding_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdBuilding_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "Building"
        Me.spdBuilding_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdBuilding_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdBuilding_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdBuilding_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdBuilding_Sheet1.Columns.Get(1).Label = "Building"
        Me.spdBuilding_Sheet1.Columns.Get(1).Width = 119.0!
        Me.spdBuilding_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdBuilding_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdBuilding_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdBuilding_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnAddFunction
        '
        Me.btnAddFunction.Location = New System.Drawing.Point(2, 314)
        Me.btnAddFunction.Name = "btnAddFunction"
        Me.btnAddFunction.Size = New System.Drawing.Size(36, 35)
        Me.btnAddFunction.TabIndex = 29
        Me.btnAddFunction.Text = "Add"
        Me.btnAddFunction.UseVisualStyleBackColor = True
        '
        'spdHelpFunction
        '
        Me.spdHelpFunction.AccessibleDescription = "spdHelpFunction, Sheet1, Row 0, Column 0, "
        Me.spdHelpFunction.BackColor = System.Drawing.SystemColors.Control
        Me.spdHelpFunction.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpFunction.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpFunction.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdHelpFunction.HorizontalScrollBar.TabIndex = 8
        Me.spdHelpFunction.Location = New System.Drawing.Point(3, 3)
        Me.spdHelpFunction.Name = "spdHelpFunction"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.Renderer = EnhancedColumnHeaderRenderer12
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.Renderer = EnhancedRowHeaderRenderer12
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdHelpFunction.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdHelpFunction.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHelpFunction.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHelpFunction_Sheet1})
        Me.spdHelpFunction.Size = New System.Drawing.Size(141, 117)
        Me.spdHelpFunction.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHelpFunction.TabIndex = 30
        Me.spdHelpFunction.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHelpFunction.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHelpFunction.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdHelpFunction.VerticalScrollBar.TabIndex = 9
        Me.spdHelpFunction.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHelpFunction_Sheet1
        '
        Me.spdHelpFunction_Sheet1.Reset()
        Me.spdHelpFunction_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHelpFunction_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHelpFunction_Sheet1.ColumnCount = 2
        Me.spdHelpFunction_Sheet1.RowCount = 1
        Me.spdHelpFunction_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdHelpFunction_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "FUNCTION"
        Me.spdHelpFunction_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHelpFunction_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdHelpFunction_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdHelpFunction_Sheet1.Columns.Get(0).Visible = False
        Me.spdHelpFunction_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdHelpFunction_Sheet1.Columns.Get(1).Label = "FUNCTION"
        Me.spdHelpFunction_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdHelpFunction_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHelpFunction_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHelpFunction_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHelpFunction_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlHelpFunction
        '
        Me.pnlHelpFunction.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlHelpFunction.Controls.Add(Me.btnCloseFunction)
        Me.pnlHelpFunction.Controls.Add(Me.spdHelpFunction)
        Me.pnlHelpFunction.Location = New System.Drawing.Point(50, 321)
        Me.pnlHelpFunction.Name = "pnlHelpFunction"
        Me.pnlHelpFunction.Size = New System.Drawing.Size(149, 153)
        Me.pnlHelpFunction.TabIndex = 31
        Me.pnlHelpFunction.Visible = False
        '
        'btnCloseFunction
        '
        Me.btnCloseFunction.Location = New System.Drawing.Point(3, 122)
        Me.btnCloseFunction.Name = "btnCloseFunction"
        Me.btnCloseFunction.Size = New System.Drawing.Size(141, 28)
        Me.btnCloseFunction.TabIndex = 14
        Me.btnCloseFunction.Text = "Close"
        Me.btnCloseFunction.UseVisualStyleBackColor = True
        '
        'spdRoom
        '
        Me.spdRoom.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdRoom.BackColor = System.Drawing.SystemColors.Control
        Me.spdRoom.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdRoom.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdRoom.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdRoom.HorizontalScrollBar.TabIndex = 8
        Me.spdRoom.Location = New System.Drawing.Point(226, 3)
        Me.spdRoom.Name = "spdRoom"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.Renderer = EnhancedColumnHeaderRenderer15
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.Renderer = EnhancedRowHeaderRenderer15
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdRoom.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdRoom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdRoom.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdRoom_Sheet1})
        Me.spdRoom.Size = New System.Drawing.Size(186, 490)
        Me.spdRoom.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdRoom.TabIndex = 34
        Me.spdRoom.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdRoom.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdRoom.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdRoom.VerticalScrollBar.TabIndex = 9
        Me.spdRoom.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdRoom_Sheet1
        '
        Me.spdRoom_Sheet1.Reset()
        Me.spdRoom_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdRoom_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdRoom_Sheet1.ColumnCount = 2
        Me.spdRoom_Sheet1.RowCount = 1
        Me.spdRoom_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdRoom_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "LINE/ROOM"
        Me.spdRoom_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdRoom_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdRoom_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdRoom_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdRoom_Sheet1.Columns.Get(1).Label = "LINE/ROOM"
        Me.spdRoom_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdRoom_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdRoom_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdRoom_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdRoom_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlRoom
        '
        Me.pnlRoom.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlRoom.Controls.Add(Me.txtIdRoom)
        Me.pnlRoom.Controls.Add(Me.btnCloseRoom)
        Me.pnlRoom.Controls.Add(Me.btnDeleteRoom)
        Me.pnlRoom.Controls.Add(Me.btnSaveRoom)
        Me.pnlRoom.Controls.Add(Me.txtRoom)
        Me.pnlRoom.Controls.Add(Me.Label12)
        Me.pnlRoom.Location = New System.Drawing.Point(226, 98)
        Me.pnlRoom.Name = "pnlRoom"
        Me.pnlRoom.Size = New System.Drawing.Size(166, 84)
        Me.pnlRoom.TabIndex = 35
        Me.pnlRoom.Visible = False
        '
        'txtIdRoom
        '
        Me.txtIdRoom.Location = New System.Drawing.Point(68, 1)
        Me.txtIdRoom.Name = "txtIdRoom"
        Me.txtIdRoom.Size = New System.Drawing.Size(36, 20)
        Me.txtIdRoom.TabIndex = 60
        Me.txtIdRoom.Visible = False
        '
        'btnCloseRoom
        '
        Me.btnCloseRoom.Location = New System.Drawing.Point(112, 48)
        Me.btnCloseRoom.Name = "btnCloseRoom"
        Me.btnCloseRoom.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseRoom.TabIndex = 6
        Me.btnCloseRoom.Text = "Close"
        Me.btnCloseRoom.UseVisualStyleBackColor = True
        '
        'btnDeleteRoom
        '
        Me.btnDeleteRoom.Location = New System.Drawing.Point(58, 48)
        Me.btnDeleteRoom.Name = "btnDeleteRoom"
        Me.btnDeleteRoom.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteRoom.TabIndex = 5
        Me.btnDeleteRoom.Text = "Delete"
        Me.btnDeleteRoom.UseVisualStyleBackColor = True
        '
        'btnSaveRoom
        '
        Me.btnSaveRoom.Location = New System.Drawing.Point(3, 48)
        Me.btnSaveRoom.Name = "btnSaveRoom"
        Me.btnSaveRoom.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveRoom.TabIndex = 4
        Me.btnSaveRoom.Text = "Save"
        Me.btnSaveRoom.UseVisualStyleBackColor = True
        '
        'txtRoom
        '
        Me.txtRoom.BackColor = System.Drawing.SystemColors.Info
        Me.txtRoom.Location = New System.Drawing.Point(5, 22)
        Me.txtRoom.Name = "txtRoom"
        Me.txtRoom.Size = New System.Drawing.Size(158, 20)
        Me.txtRoom.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(0, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(66, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Line / Room"
        '
        'btnAddRoom
        '
        Me.btnAddRoom.Location = New System.Drawing.Point(226, 3)
        Me.btnAddRoom.Name = "btnAddRoom"
        Me.btnAddRoom.Size = New System.Drawing.Size(36, 35)
        Me.btnAddRoom.TabIndex = 36
        Me.btnAddRoom.Text = "Add"
        Me.btnAddRoom.UseVisualStyleBackColor = True
        '
        'spdSubline
        '
        Me.spdSubline.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdSubline.BackColor = System.Drawing.SystemColors.Control
        Me.spdSubline.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSubline.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSubline.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdSubline.HorizontalScrollBar.TabIndex = 10
        Me.spdSubline.Location = New System.Drawing.Point(411, 2)
        Me.spdSubline.Name = "spdSubline"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer16
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer16
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdSubline.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdSubline.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSubline.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSubline_Sheet1})
        Me.spdSubline.Size = New System.Drawing.Size(186, 490)
        Me.spdSubline.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSubline.TabIndex = 37
        Me.spdSubline.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSubline.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSubline.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdSubline.VerticalScrollBar.TabIndex = 11
        Me.spdSubline.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSubline_Sheet1
        '
        Me.spdSubline_Sheet1.Reset()
        Me.spdSubline_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSubline_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSubline_Sheet1.ColumnCount = 2
        Me.spdSubline_Sheet1.RowCount = 1
        Me.spdSubline_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdSubline_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "SUBLINE"
        Me.spdSubline_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSubline_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSubline_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdSubline_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdSubline_Sheet1.Columns.Get(1).Label = "SUBLINE"
        Me.spdSubline_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdSubline_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdSubline_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSubline_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSubline_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlSubline
        '
        Me.pnlSubline.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlSubline.Controls.Add(Me.txtIdSubline)
        Me.pnlSubline.Controls.Add(Me.btnCloseSubline)
        Me.pnlSubline.Controls.Add(Me.btnDeleteSubline)
        Me.pnlSubline.Controls.Add(Me.btnSaveSubline)
        Me.pnlSubline.Controls.Add(Me.txtSubline)
        Me.pnlSubline.Controls.Add(Me.Label2)
        Me.pnlSubline.Location = New System.Drawing.Point(413, 98)
        Me.pnlSubline.Name = "pnlSubline"
        Me.pnlSubline.Size = New System.Drawing.Size(166, 84)
        Me.pnlSubline.TabIndex = 38
        Me.pnlSubline.Visible = False
        '
        'txtIdSubline
        '
        Me.txtIdSubline.Location = New System.Drawing.Point(51, 0)
        Me.txtIdSubline.Name = "txtIdSubline"
        Me.txtIdSubline.Size = New System.Drawing.Size(36, 20)
        Me.txtIdSubline.TabIndex = 59
        Me.txtIdSubline.Visible = False
        '
        'btnCloseSubline
        '
        Me.btnCloseSubline.Location = New System.Drawing.Point(112, 48)
        Me.btnCloseSubline.Name = "btnCloseSubline"
        Me.btnCloseSubline.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseSubline.TabIndex = 6
        Me.btnCloseSubline.Text = "Close"
        Me.btnCloseSubline.UseVisualStyleBackColor = True
        '
        'btnDeleteSubline
        '
        Me.btnDeleteSubline.Location = New System.Drawing.Point(58, 48)
        Me.btnDeleteSubline.Name = "btnDeleteSubline"
        Me.btnDeleteSubline.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteSubline.TabIndex = 5
        Me.btnDeleteSubline.Text = "Delete"
        Me.btnDeleteSubline.UseVisualStyleBackColor = True
        '
        'btnSaveSubline
        '
        Me.btnSaveSubline.Location = New System.Drawing.Point(3, 48)
        Me.btnSaveSubline.Name = "btnSaveSubline"
        Me.btnSaveSubline.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveSubline.TabIndex = 4
        Me.btnSaveSubline.Text = "Save"
        Me.btnSaveSubline.UseVisualStyleBackColor = True
        '
        'txtSubline
        '
        Me.txtSubline.BackColor = System.Drawing.SystemColors.Info
        Me.txtSubline.Location = New System.Drawing.Point(5, 22)
        Me.txtSubline.Name = "txtSubline"
        Me.txtSubline.Size = New System.Drawing.Size(158, 20)
        Me.txtSubline.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Subline"
        '
        'btnAddSubline
        '
        Me.btnAddSubline.Location = New System.Drawing.Point(411, 2)
        Me.btnAddSubline.Name = "btnAddSubline"
        Me.btnAddSubline.Size = New System.Drawing.Size(36, 35)
        Me.btnAddSubline.TabIndex = 39
        Me.btnAddSubline.Text = "Add"
        Me.btnAddSubline.UseVisualStyleBackColor = True
        '
        'spdMachine
        '
        Me.spdMachine.AccessibleDescription = "FpSpread1, Sheet1, Row 0, Column 0, "
        Me.spdMachine.BackColor = System.Drawing.SystemColors.Control
        Me.spdMachine.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMachine.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMachine.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdMachine.HorizontalScrollBar.TabIndex = 12
        Me.spdMachine.Location = New System.Drawing.Point(598, 2)
        Me.spdMachine.Name = "spdMachine"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer17
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer17
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdMachine.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdMachine.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdMachine.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdMachine_Sheet1})
        Me.spdMachine.Size = New System.Drawing.Size(186, 490)
        Me.spdMachine.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdMachine.TabIndex = 40
        Me.spdMachine.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdMachine.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdMachine.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdMachine.VerticalScrollBar.TabIndex = 13
        Me.spdMachine.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdMachine_Sheet1
        '
        Me.spdMachine_Sheet1.Reset()
        Me.spdMachine_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdMachine_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdMachine_Sheet1.ColumnCount = 2
        Me.spdMachine_Sheet1.RowCount = 1
        Me.spdMachine_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdMachine_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "MACHINE"
        Me.spdMachine_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdMachine_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdMachine_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdMachine_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdMachine_Sheet1.Columns.Get(1).Label = "MACHINE"
        Me.spdMachine_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdMachine_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdMachine_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdMachine_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdMachine_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdCell
        '
        Me.spdCell.AccessibleDescription = "FpSpread3, Sheet1, Row 0, Column 0, "
        Me.spdCell.BackColor = System.Drawing.SystemColors.Control
        Me.spdCell.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdCell.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer11.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer11.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer11.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer11.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer11.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdCell.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer11
        Me.spdCell.HorizontalScrollBar.TabIndex = 12
        Me.spdCell.Location = New System.Drawing.Point(783, 2)
        Me.spdCell.Name = "spdCell"
        NamedStyle21.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle21.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle21.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle21.Renderer = EnhancedColumnHeaderRenderer18
        NamedStyle21.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle22.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle22.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle22.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle22.Renderer = EnhancedRowHeaderRenderer18
        NamedStyle22.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle23.BackColor = System.Drawing.Color.DimGray
        NamedStyle23.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle23.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer6.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer6.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer6.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle23.Renderer = EnhancedCornerRenderer6
        NamedStyle23.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle24.BackColor = System.Drawing.SystemColors.Window
        NamedStyle24.CellType = GeneralCellType6
        NamedStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle24.Renderer = GeneralCellType6
        Me.spdCell.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle21, NamedStyle22, NamedStyle23, NamedStyle24})
        Me.spdCell.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdCell.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdCell_Sheet1})
        Me.spdCell.Size = New System.Drawing.Size(186, 490)
        Me.spdCell.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdCell.TabIndex = 41
        Me.spdCell.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdCell.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer12.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer12.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer12.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer12.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer12.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdCell.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer12
        Me.spdCell.VerticalScrollBar.TabIndex = 13
        Me.spdCell.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdCell_Sheet1
        '
        Me.spdCell_Sheet1.Reset()
        Me.spdCell_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdCell_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdCell_Sheet1.ColumnCount = 2
        Me.spdCell_Sheet1.RowCount = 1
        Me.spdCell_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdCell_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "CELL"
        Me.spdCell_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdCell_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdCell_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdCell_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdCell_Sheet1.Columns.Get(1).Label = "CELL"
        Me.spdCell_Sheet1.Columns.Get(1).Width = 85.0!
        Me.spdCell_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.spdCell_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdCell_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdCell_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'pnlMachine
        '
        Me.pnlMachine.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlMachine.Controls.Add(Me.txtIdMachine)
        Me.pnlMachine.Controls.Add(Me.btnCloseMachine)
        Me.pnlMachine.Controls.Add(Me.btnDeleteMachine)
        Me.pnlMachine.Controls.Add(Me.btnSaveMachine)
        Me.pnlMachine.Controls.Add(Me.txtMachine)
        Me.pnlMachine.Controls.Add(Me.Label13)
        Me.pnlMachine.Location = New System.Drawing.Point(598, 101)
        Me.pnlMachine.Name = "pnlMachine"
        Me.pnlMachine.Size = New System.Drawing.Size(166, 84)
        Me.pnlMachine.TabIndex = 42
        Me.pnlMachine.Visible = False
        '
        'txtIdMachine
        '
        Me.txtIdMachine.Location = New System.Drawing.Point(58, 1)
        Me.txtIdMachine.Name = "txtIdMachine"
        Me.txtIdMachine.Size = New System.Drawing.Size(36, 20)
        Me.txtIdMachine.TabIndex = 58
        Me.txtIdMachine.Visible = False
        '
        'btnCloseMachine
        '
        Me.btnCloseMachine.Location = New System.Drawing.Point(112, 48)
        Me.btnCloseMachine.Name = "btnCloseMachine"
        Me.btnCloseMachine.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseMachine.TabIndex = 6
        Me.btnCloseMachine.Text = "Close"
        Me.btnCloseMachine.UseVisualStyleBackColor = True
        '
        'btnDeleteMachine
        '
        Me.btnDeleteMachine.Location = New System.Drawing.Point(58, 48)
        Me.btnDeleteMachine.Name = "btnDeleteMachine"
        Me.btnDeleteMachine.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteMachine.TabIndex = 5
        Me.btnDeleteMachine.Text = "Delete"
        Me.btnDeleteMachine.UseVisualStyleBackColor = True
        '
        'btnSaveMachine
        '
        Me.btnSaveMachine.Location = New System.Drawing.Point(3, 48)
        Me.btnSaveMachine.Name = "btnSaveMachine"
        Me.btnSaveMachine.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveMachine.TabIndex = 4
        Me.btnSaveMachine.Text = "Save"
        Me.btnSaveMachine.UseVisualStyleBackColor = True
        '
        'txtMachine
        '
        Me.txtMachine.BackColor = System.Drawing.SystemColors.Info
        Me.txtMachine.Location = New System.Drawing.Point(5, 22)
        Me.txtMachine.Name = "txtMachine"
        Me.txtMachine.Size = New System.Drawing.Size(158, 20)
        Me.txtMachine.TabIndex = 2
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 3)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Machine"
        '
        'btnAddMachine
        '
        Me.btnAddMachine.Location = New System.Drawing.Point(598, 2)
        Me.btnAddMachine.Name = "btnAddMachine"
        Me.btnAddMachine.Size = New System.Drawing.Size(36, 35)
        Me.btnAddMachine.TabIndex = 43
        Me.btnAddMachine.Text = "Add"
        Me.btnAddMachine.UseVisualStyleBackColor = True
        '
        'pnlCell
        '
        Me.pnlCell.BackColor = System.Drawing.Color.CadetBlue
        Me.pnlCell.Controls.Add(Me.txtIdCell)
        Me.pnlCell.Controls.Add(Me.btnCloseCell)
        Me.pnlCell.Controls.Add(Me.btnDeleteCell)
        Me.pnlCell.Controls.Add(Me.btnSaveCell)
        Me.pnlCell.Controls.Add(Me.txtCell)
        Me.pnlCell.Controls.Add(Me.Label14)
        Me.pnlCell.Location = New System.Drawing.Point(790, 102)
        Me.pnlCell.Name = "pnlCell"
        Me.pnlCell.Size = New System.Drawing.Size(166, 84)
        Me.pnlCell.TabIndex = 44
        Me.pnlCell.Visible = False
        '
        'btnCloseCell
        '
        Me.btnCloseCell.Location = New System.Drawing.Point(112, 48)
        Me.btnCloseCell.Name = "btnCloseCell"
        Me.btnCloseCell.Size = New System.Drawing.Size(51, 27)
        Me.btnCloseCell.TabIndex = 6
        Me.btnCloseCell.Text = "Close"
        Me.btnCloseCell.UseVisualStyleBackColor = True
        '
        'btnDeleteCell
        '
        Me.btnDeleteCell.Location = New System.Drawing.Point(58, 48)
        Me.btnDeleteCell.Name = "btnDeleteCell"
        Me.btnDeleteCell.Size = New System.Drawing.Size(53, 27)
        Me.btnDeleteCell.TabIndex = 5
        Me.btnDeleteCell.Text = "Delete"
        Me.btnDeleteCell.UseVisualStyleBackColor = True
        '
        'btnSaveCell
        '
        Me.btnSaveCell.Location = New System.Drawing.Point(3, 48)
        Me.btnSaveCell.Name = "btnSaveCell"
        Me.btnSaveCell.Size = New System.Drawing.Size(54, 27)
        Me.btnSaveCell.TabIndex = 4
        Me.btnSaveCell.Text = "Save"
        Me.btnSaveCell.UseVisualStyleBackColor = True
        '
        'txtCell
        '
        Me.txtCell.BackColor = System.Drawing.SystemColors.Info
        Me.txtCell.Location = New System.Drawing.Point(5, 22)
        Me.txtCell.Name = "txtCell"
        Me.txtCell.Size = New System.Drawing.Size(158, 20)
        Me.txtCell.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Cell"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(783, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(36, 35)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "Add"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtIdCell
        '
        Me.txtIdCell.Location = New System.Drawing.Point(33, 0)
        Me.txtIdCell.Name = "txtIdCell"
        Me.txtIdCell.Size = New System.Drawing.Size(36, 20)
        Me.txtIdCell.TabIndex = 60
        Me.txtIdCell.Visible = False
        '
        'frmLineProduction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1360, 571)
        Me.Controls.Add(Me.pnlCell)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.pnlMachine)
        Me.Controls.Add(Me.btnAddMachine)
        Me.Controls.Add(Me.pnlSubline)
        Me.Controls.Add(Me.btnAddSubline)
        Me.Controls.Add(Me.pnlRoom)
        Me.Controls.Add(Me.btnAddRoom)
        Me.Controls.Add(Me.pnlHelpFunction)
        Me.Controls.Add(Me.btnAddFunction)
        Me.Controls.Add(Me.spdBuilding)
        Me.Controls.Add(Me.spdArea)
        Me.Controls.Add(EnhancedColumnHeaderRenderer1)
        Me.Controls.Add(EnhancedRowHeaderRenderer1)
        Me.Controls.Add(Me.spdRoom)
        Me.Controls.Add(Me.spdFunction)
        Me.Controls.Add(Me.spdSubline)
        Me.Controls.Add(Me.spdMachine)
        Me.Controls.Add(Me.spdCell)
        Me.Name = "frmLineProduction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Line Production"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.spdFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdFunction_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdArea, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdArea_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdBuilding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdBuilding_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHelpFunction_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHelpFunction.ResumeLayout(False)
        CType(Me.spdRoom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdRoom_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlRoom.ResumeLayout(False)
        Me.pnlRoom.PerformLayout()
        CType(Me.spdSubline, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSubline_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSubline.ResumeLayout(False)
        Me.pnlSubline.PerformLayout()
        CType(Me.spdMachine, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdMachine_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCell, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdCell_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlMachine.ResumeLayout(False)
        Me.pnlMachine.PerformLayout()
        Me.pnlCell.ResumeLayout(False)
        Me.pnlCell.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spdFunction As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdFunction_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdArea As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdArea_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdBuilding As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdBuilding_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnAddFunction As System.Windows.Forms.Button
    Friend WithEvents spdHelpFunction As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHelpFunction_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlHelpFunction As System.Windows.Forms.Panel
    Friend WithEvents btnCloseFunction As System.Windows.Forms.Button
    Friend WithEvents spdRoom As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdRoom_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlRoom As System.Windows.Forms.Panel
    Friend WithEvents btnCloseRoom As System.Windows.Forms.Button
    Friend WithEvents btnDeleteRoom As System.Windows.Forms.Button
    Friend WithEvents btnSaveRoom As System.Windows.Forms.Button
    Friend WithEvents txtRoom As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnAddRoom As System.Windows.Forms.Button
    Friend WithEvents spdSubline As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSubline_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlSubline As System.Windows.Forms.Panel
    Friend WithEvents btnCloseSubline As System.Windows.Forms.Button
    Friend WithEvents btnDeleteSubline As System.Windows.Forms.Button
    Friend WithEvents btnSaveSubline As System.Windows.Forms.Button
    Friend WithEvents txtSubline As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnAddSubline As System.Windows.Forms.Button
    Friend WithEvents spdMachine As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdMachine_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdCell As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdCell_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents pnlMachine As System.Windows.Forms.Panel
    Friend WithEvents btnCloseMachine As System.Windows.Forms.Button
    Friend WithEvents btnDeleteMachine As System.Windows.Forms.Button
    Friend WithEvents btnSaveMachine As System.Windows.Forms.Button
    Friend WithEvents txtMachine As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents btnAddMachine As System.Windows.Forms.Button
    Friend WithEvents pnlCell As System.Windows.Forms.Panel
    Friend WithEvents btnCloseCell As System.Windows.Forms.Button
    Friend WithEvents btnDeleteCell As System.Windows.Forms.Button
    Friend WithEvents btnSaveCell As System.Windows.Forms.Button
    Friend WithEvents txtCell As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtIdMachine As System.Windows.Forms.TextBox
    Friend WithEvents txtIdSubline As System.Windows.Forms.TextBox
    Friend WithEvents txtIdRoom As System.Windows.Forms.TextBox
    Friend WithEvents txtIdCell As System.Windows.Forms.TextBox
End Class
