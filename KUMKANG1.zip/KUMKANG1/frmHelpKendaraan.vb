﻿Public Class frmHelpKendaraan
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_KENDARAAN()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "SELECT codd_valu,codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.code_common where CODH_FLNM='CODE_MOBL'" & vbLf
      
        SQL_C += "ORDER BY codd_valu" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHelpKendaraan_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmHelpKendaraan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_KENDARAAN()
    End Sub

    Private Sub btnCloseCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCustomer.Click
        Me.Close()
    End Sub

    

    Private Sub spdHelpKendaraan_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHelpKendaraan.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHelpKendaraan_Sheet1.Cells.Item(e.Row, 0).Text
            .Help_str2 = spdHelpKendaraan_Sheet1.Cells.Item(e.Row, 1).Text



        End With

        Me.Close()
    End Sub
End Class