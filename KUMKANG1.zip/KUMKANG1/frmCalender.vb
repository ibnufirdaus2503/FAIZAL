﻿Public Class frmCalender
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInsert()
       

    End Sub
    Public Sub cmdUpdate()
    
       
    End Sub
    Public Sub cmdInquery()

        Cursor = Cursors.WaitCursor

        SQL_C = ""
        SQL_C = SQL_C + "SELECT COUNT(*) QTY FROM KKTERP.dbo.calender WHERE caln_year='" & txtYear.Text & "'"

        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr.Item(0) = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            FP_INSERT_CALENDER()
        Else
            clsCom.gv_ExeSqlReaderEnd()
            FP_LIST_HEAD()
        End If

       

        ' Call FP_LIST_HEAD()

        Cursor = Cursors.Default
        
    End Sub
    Public Sub cmdDelete()
        
    End Sub
    Private Sub FP_INIT()

    End Sub
    Private Sub FP_MODIFY()
        
    End Sub
    Private Sub FP_INSERT_CALENDER()


        SQL_C = ""
        SQL_C = SQL_C + "EXEC DATE_YEAR '" & txtYear.Text & "'" & vbCrLf

        clsCom.GP_ExeSql(SQL_C)
    End Sub

    Private Sub FP_DELETE()
       
    End Sub

    Private Sub FP_LIST_HEAD()
        Dim SQL_C As String
        Dim Dict As New Dictionary(Of String, String)

      
        SQL_C = ""
        SQL_C += " SELECT  CONVERT(VARCHAR(10),caln_date,111) tgl," & vbLf
        SQL_C += " CODE_MONT,caln_week,CODE_DAYX,caln_holi,B.codd_desc vbulan,C.codd_desc vhari," & vbLf
        SQL_C += " isnull(caln_frm1,'') caln_frm1,isnull(caln_tox1,'') caln_tox1," & vbLf
        SQL_C += " isnull(caln_frm2,'') caln_frm2,isnull(caln_tox2,'') caln_tox2," & vbLf
        SQL_C += " isnull(caln_frm3,'') caln_frm3,isnull(caln_tox3,'') caln_tox3" & vbLf
        SQL_C += " FROM KKTERP.dbo.calender A" & vbLf
        SQL_C += " LEFT JOIN KKTERP.dbo.code_common B ON B.CODH_FLNM='CODE_MONT' AND A.CODE_MONT=B.codd_valu" & vbLf
        SQL_C += " LEFT JOIN KKTERP.dbo.code_common C ON C.CODH_FLNM='CODE_DAYX' AND A.CODE_DAYX=C.codd_valu" & vbLf
        SQL_C += " WHERE caln_year='" & txtYear.Text & "'" & vbLf
        SQL_C += " ORDER BY CONVERT(VARCHAR(10),caln_date,111)" & vbLf

        ' SQL_C = "exec calender_year '2025'"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("tgl")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("vbulan")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("caln_week")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vhari")
                '.Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("cust_idxx")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("caln_frm1")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("caln_tox1")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("caln_frm2")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("caln_tox2")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("caln_frm3")
                .Cells.Item(.RowCount - 1, 10).Text = clsCom.gv_DataRdr("caln_tox3")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub


    Private Sub frmCalender_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        txtYear.Text = Year(Now)
        FP_LIST_SHIFT_UPDATE()
       
    End Sub

    Private Sub btnUpdateShift_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        pnlUpdateShift.Visible = True
        FP_LIST_SHIFT_UPDATE()
    End Sub
    Private Sub FP_LIST_SHIFT_UPDATE()
        Dim SQL_C As String
        

        SQL_C = ""
        SQL_C += "SELECT A.*,B.codd_desc" & vbLf
        SQL_C += "FROM KKTERP.dbo.shift_update A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON codh_flnm='CODE_DAYX' and B.codd_valu=CODE_DAYX" & vbLf
        SQL_C += "ORDER BY code_dayx,code_shif" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdShiftUpdate_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("CODE_SHIF")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("shif_from")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("shif_toxx")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("CODE_DAYX")
            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        pnlUpdateShift.Visible = False
    End Sub

    Private Sub btnCheckAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckAll.Click
        Dim i As Integer
        With spdShiftUpdate_Sheet1
            For i = 0 To .RowCount - 1

                .Cells.Item(i, 0).Value = True

            Next

        End With
    End Sub

    Private Sub btnUncheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUncheck.Click
        Dim i As Integer
        With spdShiftUpdate_Sheet1
            For i = 0 To .RowCount - 1

                .Cells.Item(i, 0).Value = False

            Next

        End With
    End Sub

    Private Sub btnClose_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        pnlUpdateShift.Visible = False
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        pnlUpdateShift.Visible = True
        FP_LIST_SHIFT_UPDATE()
    End Sub

    Private Sub btnUpdate_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim i As Integer
        SQL_C = ""
        SQL_C += "DELETE KKTERP.DBO.temp_update_shift"

        clsCom.GP_ExeSql(SQL_C)

        With spdShiftUpdate_Sheet1
            For i = 0 To .RowCount - 1
                SQL_C = ""
                SQL_C += "Update KKTERP.dbo.shift_update" & vbLf
                SQL_C += "SET shif_from='" & .Cells.Item(i, 3).Text & "',shif_toxx='" & .Cells.Item(i, 4).Text & "'" & vbLf
                SQL_C += "WHERE CODE_DAYX =" & .Cells.Item(i, 5).Text & " And CODE_SHIF =" & .Cells.Item(i, 2).Text & "" & vbLf

                clsCom.GP_ExeSql(SQL_C)

                If .Cells.Item(i, 0).Value = True Then
                    SQL_C = ""
                    SQL_C += " insert into KKTERP.DBO.temp_update_shift(date_from,date_toxx,CODE_DAYX,CODE_SHIF,time_from,time_toxx)values ('" & dtFrom.Text & "','" & dtTo.Text & "'," & .Cells.Item(i, 5).Text & "," & .Cells.Item(i, 2).Text & ",'" & .Cells.Item(i, 3).Text & "','" & .Cells.Item(i, 4).Text & "')"


                    clsCom.GP_ExeSql(SQL_C)

                End If

            Next
        End With

        SQL_C = ""
        SQL_C += "sp_update_shift"

        clsCom.GP_ExeSql(SQL_C)

        pnlUpdateShift.Visible = False

        FP_LIST_HEAD()

    End Sub
End Class