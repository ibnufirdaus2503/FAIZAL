﻿Public Class frmHelpPO
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST_HEAD()
        Dim idModel, idPO As Integer

        SQL_C = ""
        
        SQL_C += "SELECT ordh_idxx,ordh_poxx,convert(varchar(10),ordh_date,111) ordh_date," & vbLf
        SQL_C += "convert(varchar(10),ordh_etdh,111) ordh_etdh,ordh_nctr,convert(varchar(10),ordh_dctr,111) ordh_dctr," & vbLf
        SQL_C += "customer_name, brand_name, modl_idxx, model_name, colr_name," & vbLf
        SQL_C += "CODE_POXX,ISNULL(CODE_REAS,'') CODE_REAS ,D.codd_desc vTYPE_PO,ISNULL(E.codd_desc,'') vReason,isnull(C.CODD_DESC,'') VGENDER" & vbLf
        SQL_C += "FROM KKTERP.dbo.order_header A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vModelColorNew B ON A.mclr_idxx=B.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_GEND' AND C.codd_valu=A.CODE_GEND" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common D ON D.codh_flnm='CODE_POXX' AND D.codd_valu=A.CODE_POXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common E ON E.codh_flnm='CODE_REAS' AND E.codd_valu=A.CODE_REAS" & vbLf
        SQL_C += "order by model_name,colr_name" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPO_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                idModel = clsCom.gv_DataRdr("modl_idxx")
                idPO = clsCom.gv_DataRdr("ordh_idxx")

                .Cells.Item(.RowCount - 1, 0).Text = idPO.ToString("D7")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("ordh_poxx")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("ordh_date")

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 4).Text = idModel.ToString("D4")



                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("colr_name")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub frmHelpPO_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_HEAD()
    End Sub

    Private Sub spdPO_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdPO.CellClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdPO_Sheet1.Cells.Item(e.Row, 0).Text 'ID PO
            .Help_str2 = spdPO_Sheet1.Cells.Item(e.Row, 1).Text 'NO PO
            .Help_str3 = spdPO_Sheet1.Cells.Item(e.Row, 2).Text 'DATE PO
            .Help_str4 = spdPO_Sheet1.Cells.Item(e.Row, 3).Text 'CUST NAME
            .Help_str5 = spdPO_Sheet1.Cells.Item(e.Row, 4).Text 'ID MODEL
            .Help_str6 = spdPO_Sheet1.Cells.Item(e.Row, 5).Text ' MODEL
            .Help_str7 = spdPO_Sheet1.Cells.Item(e.Row, 6).Text 'COLR_NAME

 


        End With

        Me.Close()
    End Sub
End Class