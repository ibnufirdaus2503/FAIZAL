﻿Public Class frmHelpModelMold
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    
    Private Sub FP_LIST_HEAD()

        SQL_C = ""


        'SQL_C += "SELECT A.*," & vbLf
        'SQL_C += "B.molh_idxx, B.molh_code, B.CODE_COMP, B.modl_idxx, C.codd_desc,vend_name" & vbLf
        'SQL_C += "FROM KKTERP.dbo.Vmodel A" & vbLf
        'SQL_C += "LEFT JOIN KKTERP.dbo.mold_header B ON A.model_id=B.modl_idxx" & vbLf
        'SQL_C += "LEFT JOIN KKTERP.dbo.code_common C ON C.codh_flnm='CODE_COMP' and C.codd_valu=B.CODE_COMP" & vbLf

        'If txtModel.Text <> "" Then
        '    SQL_C += "WHERE A.model_name like '%" & txtModel.Text & "%'" & vbLf
        'End If

        'SQL_C += "order by customer_name,model_name asc" & vbLf


        SQL_C += "SELECT customer_name,brand_name,model_name,vend_name,model_id FROM KKTERP.dbo.Vmodel order by customer_name,model_name asc"

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                ' .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("customer_id")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_id")
                ' .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("customer_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("brand_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("model_name")
                ' .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("codd_desc")
                ' .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("molh_code")
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("vend_name")
            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmHelpModelMold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCariModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariModel.Click
        FP_LIST_HEAD()
    End Sub

    Private Sub btnCloseCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseCustomer.Click
        Me.Close()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

    End Sub

    Private Sub spdHead_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdHead_Sheet1.Cells.Item(e.Row, 3).Text
            .Help_str2 = spdHead_Sheet1.Cells.Item(e.Row, 4).Text
            .Help_str3 = spdHead_Sheet1.Cells.Item(e.Row, 5).Text
            .Help_str4 = spdHead_Sheet1.Cells.Item(e.Row, 6).Text
            .Help_str5 = spdHead_Sheet1.Cells.Item(e.Row, 7).Text
            .Help_str6 = spdHead_Sheet1.Cells.Item(e.Row, 1).Text
            .Help_str7 = spdHead_Sheet1.Cells.Item(e.Row, 8).Text

        End With

        Me.Close()
    End Sub
End Class