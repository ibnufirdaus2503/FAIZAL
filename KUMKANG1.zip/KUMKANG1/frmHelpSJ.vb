﻿Public Class frmHelpSJ
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_SJ()

        Dim IdModel As Integer

    


        SQL_C = ""
        SQL_C += "SELECT  A.sjxh_idxx,sjxh_noxx,convert(varchar(10),sjxh_date,111) sjxh_date ,D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.SURAT_JALANH X" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.production_good A ON A.sjxh_idxx=X.sjxh_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf

        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
        SQL_C += "where D.modl_idxx is not null" & vbLf
        ' SQL_C += "where SJXH_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
        SQL_C += "GROUP BY  A.sjxh_idxx,sjxh_noxx,convert(varchar(10),sjxh_date,111)   ,D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSJ_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("sjxh_date")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center



                .Cells.Item(.RowCount - 1, 3).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("QTY")
                .Cells.Item(.RowCount - 1, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("sjxh_idxx")







            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    Private Sub frmHelpSJ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_SJ()
    End Sub

    Private Sub btnCloseSJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSJ.Click
        Me.Close()
    End Sub

    Private Sub spdSJ_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSJ.CellClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdSJ_Sheet1.Cells.Item(e.Row, 1).Text
            .Help_str2 = spdSJ_Sheet1.Cells.Item(e.Row, 2).Text
            .Help_str3 = spdSJ_Sheet1.Cells.Item(e.Row, 8).Text
            ' .Help_str4 = spdPO_Sheet1.Cells.Item(e.Row, 3).Text



        End With

        Me.Close()
    End Sub
End Class