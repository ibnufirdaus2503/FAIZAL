﻿Imports System.Windows.Forms.DataVisualization.Charting

Public Class frmWasteReport

    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Public Sub cmdInquery()
        FP_STOCK()
        FP_LIMBAH_PERHARI()
        FP_LIMBAH_keluar()
    End Sub
    Private Sub FP_LIMBAH_keluar()

        Dim vBerat As Double
        Dim vBag As Integer



        SQL_C = ""
        SQL_C = SQL_C + "SELECT  A.mcom_idxx,G.codd_desc vcomp,model_name,colr_name,H.CODD_DESC vwaste,I.CODD_DESC vproc,model_id,BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT A.mcom_idxx,A.CODE_PRWS,A.CODE_WAST, BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,SUM(wast_weig) BERAT" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste a" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.surat_jalan_wasteh B ON A.sjws_idxx=b.sjws_idxx" & vbLf
        SQL_C = SQL_C + "WHERE CONVERT(VARCHAR(10),sjws_date,111) BETWEEN  CONVERT(VARCHAR(10),'" & dtFromOut.Value & "',111) AND CONVERT(VARCHAR(10),'" & dtToOut.Value & "',111)" & vbLf
        SQL_C = SQL_C + "GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf


        SQL_C = SQL_C + "	) A" & vbLf
        SQL_C = SQL_C + "Left Join " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,COUNT(*) BAG" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste a" & vbLf
        SQL_C = SQL_C + "INNER JOIN KKTERP.dbo.surat_jalan_wasteh B ON A.sjws_idxx=b.sjws_idxx" & vbLf
        SQL_C = SQL_C + "WHERE CONVERT(VARCHAR(10),sjws_date,111) BETWEEN  CONVERT(VARCHAR(10),'" & dtFromOut.Value & "',111) AND CONVERT(VARCHAR(10),'" & dtToOut.Value & "',111)" & vbLf
        SQL_C = SQL_C + "GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf

        SQL_C = SQL_C + "	) B ON A.MCOM_IDXX=B.MCOM_IDXX AND A.CODE_PRWS=B.CODE_PRWS AND A.CODE_WAST=B.CODE_WAST" & vbLf
        SQL_C = SQL_C + ") A" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=G.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_WAST' AND CODE_WAST=H.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common I ON I.codh_flnm='CODE_PRWS' AND CODE_PRWS=I.codd_valu" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdOut_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("model_id")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vproc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vwaste")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("BERAT")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("BAG")

                vBerat = vBerat + Val(clsCom.gv_DataRdr("BERAT"))
                vBag = vBag + clsCom.gv_DataRdr("BAG")


            End While

            lblBeratOut.Text = vBerat
            lblBagout.Text = vBag

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub
    Private Sub FP_LIMBAH_PERHARI()

        Dim vBerat As Double
        Dim vBag As Integer


        SQL_C = ""
        SQL_C = SQL_C + "SELECT  A.mcom_idxx,G.codd_desc vcomp,model_name,colr_name,H.CODD_DESC vwaste,I.CODD_DESC vproc,model_id,BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT A.mcom_idxx,A.CODE_PRWS,A.CODE_WAST, BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,SUM(wast_weig) BERAT" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste " & vbLf
        SQL_C = SQL_C + "WHERE CONVERT(VARCHAR(10),wast_date,111) BETWEEN  CONVERT(VARCHAR(10),'" & dtFrom.Value & "',111) AND CONVERT(VARCHAR(10),'" & dtTo.Value & "',111)" & vbLf
        SQL_C = SQL_C + "		GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf
        SQL_C = SQL_C + "	) A" & vbLf
        SQL_C = SQL_C + "Left Join " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,COUNT(*) BAG" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste " & vbLf
        SQL_C = SQL_C + "WHERE CONVERT(VARCHAR(10),wast_date,111) BETWEEN  CONVERT(VARCHAR(10),'" & dtFrom.Value & "',111) AND CONVERT(VARCHAR(10),'" & dtTo.Value & "',111)" & vbLf
        SQL_C = SQL_C + "		GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf
        SQL_C = SQL_C + "	) B ON A.MCOM_IDXX=B.MCOM_IDXX AND A.CODE_PRWS=B.CODE_PRWS AND A.CODE_WAST=B.CODE_WAST" & vbLf
        SQL_C = SQL_C + ") A" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=G.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_WAST' AND CODE_WAST=H.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common I ON I.codh_flnm='CODE_PRWS' AND CODE_PRWS=I.codd_valu" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPerhari_Sheet1
            .RowCount = 0
            vBerat = 0
            vBag = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("model_id")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vproc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vwaste")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("BERAT")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("BAG")

                vBerat = vBerat + Val(clsCom.gv_DataRdr("BERAT"))
                vBag = vBag + clsCom.gv_DataRdr("BAG")

            End While

            lblBeratPerhari.Text = vBerat
            lblBagPerhari.Text = vBag

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect

        End With

        clsCom.gv_ExeSqlReaderEnd()



    End Sub

    Private Sub FP_STOCK()

        Dim vBerat As Double
        Dim vBag As Integer

        SQL_C = ""
        SQL_C = SQL_C + "SELECT  A.mcom_idxx,G.codd_desc vcomp,model_name,colr_name,H.CODD_DESC vwaste,I.CODD_DESC vproc,model_id,BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "(" & vbLf
        SQL_C = SQL_C + "SELECT A.mcom_idxx,A.CODE_PRWS,A.CODE_WAST, BERAT,BAG" & vbLf
        SQL_C = SQL_C + "FROM " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,SUM(wast_weig) BERAT" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste " & vbLf
        SQL_C = SQL_C + "		WHERE sjws_idxx is null" & vbLf
        SQL_C = SQL_C + "		GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf
        SQL_C = SQL_C + "	) A" & vbLf
        SQL_C = SQL_C + "Left Join " & vbLf
        SQL_C = SQL_C + "	(" & vbLf
        SQL_C = SQL_C + "		SELECT mcom_idxx,CODE_PRWS,CODE_WAST,COUNT(*) BAG" & vbLf
        SQL_C = SQL_C + "FROM KKTERP.dbo.waste " & vbLf
        SQL_C = SQL_C + "		WHERE sjws_idxx is null" & vbLf
        SQL_C = SQL_C + "		GROUP BY mcom_idxx,CODE_PRWS,CODE_WAST" & vbLf
        SQL_C = SQL_C + "	) B ON A.MCOM_IDXX=B.MCOM_IDXX AND A.CODE_PRWS=B.CODE_PRWS AND A.CODE_WAST=B.CODE_WAST" & vbLf
        SQL_C = SQL_C + ") A" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=G.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common H ON H.codh_flnm='CODE_WAST' AND CODE_WAST=H.codd_valu" & vbLf
        SQL_C = SQL_C + "LEFT JOIN KKTERP.dbo.code_common I ON I.codh_flnm='CODE_PRWS' AND CODE_PRWS=I.codd_valu" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            vBerat = 0
            vBag = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("model_id")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("vcomp")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("vproc")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("vwaste")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("BERAT")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("BAG")

                vBerat = vBerat + Val(clsCom.gv_DataRdr("BERAT"))
                vBag = vBag + clsCom.gv_DataRdr("BAG")

            End While
            lblBeratStock.Text = vBerat
            lblBagStock.Text = vBag

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmWasteReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set this in your form load or initialization
        dtFrom.Format = DateTimePickerFormat.Custom
        dtFrom.CustomFormat = "yyyy/MM/dd"

        dtTo.Format = DateTimePickerFormat.Custom
        dtTo.CustomFormat = "yyyy/MM/dd"

        dtFromOut.Format = DateTimePickerFormat.Custom
        dtFromOut.CustomFormat = "yyyy/MM/dd"

        dtToOut.Format = DateTimePickerFormat.Custom
        dtToOut.CustomFormat = "yyyy/MM/dd"


       
    End Sub
End Class