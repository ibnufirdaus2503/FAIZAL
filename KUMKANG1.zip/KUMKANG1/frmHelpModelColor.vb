﻿Public Class frmHelpModelColor
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_MODEL_COLOR()

        
 



        SQL_C = ""
        SQL_C += "SELECT model_name,customer_name,brand_name,colr_name,vend_name,mclr_idxx " & vbLf
        SQL_C += "FROM KKTERP.dbo.vmodel_color A" & vbLf


        SQL_C = ""
        SQL_C += "SELECT  model_name,colr_name,mclr_idxx" & vbLf
        SQL_C += "FROM KKTERP.dbo.model_color D" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        

 

        If txtModel.Text <> "" Then
            SQL_C += "AND model_name like'%" & txtModel.Text & "%'"
        End If

        If txtColor.Text <> "" Then
            SQL_C += "AND colr_name like'%" & txtColor.Text & "%'"
        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdModel_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mclr_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("colr_name")
          
            End While


            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

     
    
    Private Sub btnColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnColor.Click
        FP_MODEL_COLOR()
    End Sub

  
    
    Private Sub spdModel_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellClick

    End Sub

    Private Sub spdModel_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdModel.CellDoubleClick
        ReDim clsVAR.gv_Help(0)
        With clsVAR.gv_Help(0)
            .Help_str1 = spdModel_Sheet1.Cells.Item(e.Row, 0).Text 'customer name
            .Help_str2 = spdModel_Sheet1.Cells.Item(e.Row, 1).Text 'model name
            .Help_str3 = spdModel_Sheet1.Cells.Item(e.Row, 2).Text 'brand name


        End With

        Me.Close()
    End Sub
End Class