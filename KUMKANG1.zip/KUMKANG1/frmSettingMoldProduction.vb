﻿Public Class frmSettingMoldProduction
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vRowProduct As String
    Dim vRowSize As String
    Private Sub FP_LIST_HEAD_LINE()
        Dim SQL_C As String



        SQL_C = ""
        SQL_C += " SELECT line_addr,line_desc FROM KKTERP.dbo.line_production order by line_Desc" & vbLf
      


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdLine_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("line_addr")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("line_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_HEAD_MACHINE(ByVal Addr As String)
        Dim SQL_C As String


        SQL_C = ""
        SQL_C += "SELECT A.line_addr,B.line_addr,A.line_desc,B.linm_macn,B.linm_desc,B.linm_shrt,C.*" & vbLf
        SQL_C += "FROM KKTERP.dbo.line_production A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.line_machine B ON A.line_addr=B.Line_addr" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.line_mold C ON B.linm_idxx=C.linm_idxx" & vbLf
        SQL_C += "WHERE A.line_addr='" & Addr & "'" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSettingProduction_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("linm_desc")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("lind_desc")

            End While

            ' .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub frmSettingMoldProduction_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST_HEAD_LINE()
    End Sub

    Private Sub spdLine_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdLine.CellClick
        FP_LIST_HEAD_MACHINE(spdLine.ActiveSheet.Cells(e.Row, 0).Value)
    End Sub
End Class