﻿Public Class frmGroupSize
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Private Sub FP_LIST()
        Dim SQL_C, vfrom, vTo, vGabung As String
        Dim i, j, k, seqn As Int16
        SQL_C = ""
        SQL_C += "	SELECT * FROM KKTERP.dbo.code_common WHERE CODH_FLNM='CODE_SIZE' AND COD2_VALU=1 ORDER BY CAST(COD3_VALU AS INT)" & vbLf



        clsCom.GP_ExeSqlReader(SQL_C)
        seqn = 0
        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect

            For i = 0 To .RowCount - 1
                vfrom = .Cells.Item(i, 0).Text
                For j = i To .RowCount - 1
                    vTo = .Cells.Item(j, 1).Text
                    vGabung = vfrom & "-" & vTo

                    For k = i To j
                        seqn = seqn + 1
                        SQL_C = ""
                        SQL_C = SQL_C + "INSERT INTO KKTERP.dbo.group_size (grop_size,CODE_SIZE,grop_seqn) VALUES ('" & IIf(vfrom <> vTo, vGabung, vfrom) & "','" & .Cells.Item(k, 1).Text & "'," & seqn & ")" & vbCrLf

                        clsCom.GP_ExeSql(SQL_C)



                    Next
                Next

            Next
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub


    Private Sub FP_LIST_HELP_CUSTOMER()
        Dim SQL_C As String
        SQL_C = ""
        SQL_C += "	SELECT * FROM KKTERP.dbo.code_common WHERE CODH_FLNM='CODE_SIZE' AND COD2_VALU=1 ORDER BY CAST(COD3_VALU AS INT)" & vbLf
       


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdHead_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("codd_valu")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("codd_desc")

            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub frmGroupSize_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_LIST()
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick
        
    End Sub
End Class