﻿Imports System.IO
Public Class frmScanWaste





    Dim currentDate As DateTime = DateTime.Now
    Dim vdate As String = currentDate.ToString("yyyyMMdd")
    Dim filescanWaste As String = "C:\popdata\scan\waste\" & vdate & ".txt"
   
    Dim filesendWaste As String = "C:\popdata\send\waste\" & vdate & ".txt"
    


    Dim vAddr As String
    Dim vLocationScan As String


    Private Sub frmScanIn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim popdata As New DirectoryInfo("C:\popdata")
        Dim scanWaste As New DirectoryInfo("C:\popdata\scan\waste")
        Dim sendWaste As New DirectoryInfo("C:\popdata\send\waste")
        


        If Not popdata.Exists Then
            Directory.CreateDirectory("C:\popdata")
        End If

        If Not scanWaste.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\waste")
        End If

        If Not sendWaste.Exists Then
            Directory.CreateDirectory("C:\popdata\send\waste")
        End If

       
        If Not File.Exists(filescanWaste) Then
            File.Create(filescanWaste).Dispose()

        End If

         

        If Not File.Exists(filesendWaste) Then
            File.Create(filesendWaste).Dispose()

        End If

    



        FP_READ()


    End Sub

    Private Sub txtScan_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtScan.KeyPress
        Dim skr As DateTime = DateTime.Now
        Dim skrdate As String = skr.ToString("yyyyMMddHHmmss")


        If e.KeyChar = ChrW(Keys.Enter) Then

            If Strings.Len(txtScan.Text) <> 7 Then
                txtScan.Text = ""
                lblScan.Text = "Barcode Harus 9 Digit"
                txtScan.Focus()
                Exit Sub
            Else

                lblScan.Text = txtScan.Text
                txtScan.Text = ""
            End If




            ' Baca seluruh isi file



 

            Dim fileContent As String = File.ReadAllText(filescanWaste)





            Using writer As New System.IO.StreamWriter(filescanWaste, True) ' True for append mode

                ' If Not (fileContent.Contains(vAddr & lblScan.Text & skrdate)) Then
                If Not (fileContent.Contains(vAddr & lblScan.Text)) Then
                    writer.WriteLine(vAddr & lblScan.Text)
                Else
                    lblScan.Text = "D U P L I C A T E"
                End If
            End Using
        End If

        FP_READ()

        txtScan.Focus()


    End Sub
     

    Private Sub FP_READ()
        Dim vTotal As Integer

        Dim vData As String


 


        Using reader As New StreamReader(filescanWaste)
            With spdScan_Sheet1
                .RowCount = 0
                vTotal = 0
                While Not reader.EndOfStream
                    vData = reader.ReadLine()
                    .RowCount = .RowCount + 1


                    .Cells.Item(.RowCount - 1, 0).Text = Strings.Left(vData, 10)
                    ' .Cells.Item(.RowCount - 1, 1).Text = Strings.Right(vData, 14)
                    vTotal = vTotal + 1

                End While
                spdScan.ActiveSheet.AutoSortColumn(1, False)
                lblTotal.Text = vTotal
            End With
        End Using
    End Sub

     

End Class