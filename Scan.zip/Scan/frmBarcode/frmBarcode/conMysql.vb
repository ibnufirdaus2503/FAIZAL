﻿Imports MySql.Data.MySqlClient


Module conMysql
    Public db As New MySql.Data.MySqlClient.MySqlConnection
    Public Sql As String
    Public cmd As New MySqlCommand
    Public rs As MySqlDataReader

    Sub Konek()
        Sql = "server=localhost;uid=root;database=kkt_server;pwd="

        Try
            db.ConnectionString = Sql

            db.Open()

            MsgBox("Berhasil")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Module
