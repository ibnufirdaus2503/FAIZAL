﻿Imports Microsoft.Win32 
Public Class clsCOMMAND
    Inherits clsCON
    Dim ssql As String
    
    Public Sub GP_ExeSqlReader_Dataset(ByVal ssql As String)

        GP_SetStat()

        gv_Cmd.CommandText = ssql
        gv_Data_Adp.SelectCommand = gv_Cmd
        gv_Data_Adp.SelectCommand.Connection = gv_con

        gv_DataSet.Clear()

        gv_Data_Adp.Fill(gv_DataSet)

    End Sub

    Public Sub GP_ExeSqlReader(ByVal ssql As String)

        GP_SetStat()

        gv_Cmd.CommandText = ssql
        gv_Cmd.Connection = gv_con
        gv_con.Open()
        gv_DataRdr = gv_Cmd.ExecuteReader

    End Sub

    Public Sub gv_ExeSqlReaderEnd()
        gv_DataRdr.Close()
        gv_con.Close()
    End Sub

    Public Sub GP_ExeSql(ByVal ssql As String)

        If gv_con.ConnectionString.Trim = "" Then
            GP_SetStat()
        End If
        gv_con.Close()

        gv_Cmd.CommandText = ssql
        gv_Cmd.Connection = gv_con
        gv_con.Open()
        gv_Cmd.ExecuteNonQuery()
        gv_con.Close()

    End Sub

    Public Function GF_Today() As String
        Dim sTemp As String = ""

        If gv_con.ConnectionString.Trim = "" Then
            GP_SetStat()
        End If
        Try
            ssql = ""
            ssql += " Select convert(varchar(22),Getdate(),120) as  jam " & vbLf

            gv_con.Open()
            gv_Cmd.CommandText = ssql
            gv_DataRdr = gv_Cmd.ExecuteReader
            gv_DataRdr.Read()
            sTemp = gv_DataRdr(0)
        Catch ex As Exception
            sTemp = ""
            MsgBox(ex.Message)
        Finally
            gv_DataRdr.Close()
            gv_con.Close()
        End Try

        Return sTemp
    End Function
End Class
