﻿Imports System.IO
Imports Microsoft.Win32
Imports System.Diagnostics
Public Class frmLogin
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C, vAddr As String
    Dim IP As String
    Private Sub FP_CHECK()
        Dim fileInfo As New FileInfo("C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe")
        Dim ServerInfo As New FileInfo("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe")
        Dim LocalModified As DateTime = fileInfo.LastWriteTime
        Dim ServerModified As DateTime = ServerInfo.LastWriteTime

        If txtPassword.Text = "" Then
            MsgBox("Password tidak boleh kosong")
            Exit Sub
            txtPassword.Focus()
        End If

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.user_security where secr_pass='" & txtPassword.Text & "' and secr_idxx=" & Val(txtUser.Text)



        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            lblUser.Text = "User atau password anda salah"
            Exit Sub
        Else
            clsCom.gv_ExeSqlReaderEnd()

            SimpanKeRegistry("sUserId", txtUser.Text)


        End If

        If IsProcessRunning("C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Exit Sub
        End If

        Try
            If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe") Then

                If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe") Then
                    If ServerModified > LocalModified Then

                        'Copy File dari Server
                        File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe", "C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe", overwrite:=True)

                    End If
                Else
                    'Copy File dari Server
                    File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe", "C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe", overwrite:=True)
                End If




            Else
                MessageBox.Show("File tidak ditemukan di jaringan!")
            End If
            'Catch ex As Exception
            '    MessageBox.Show("Error: " & ex.Message)
            'Catch ex As IOException When ex.Message.Contains("sedang digunakan")
            '    MessageBox.Show("File sedang digunakan oleh proses lain!")
        Catch ex As UnauthorizedAccessException
            MessageBox.Show("Tidak memiliki izin untuk menulis file!")
            ' Catch ex As DirectoryNotFoundException
            '     MessageBox.Show("Folder tujuan tidak ditemukan!")
        End Try









        'Try
        '    ' Check if source file exists
        '    If Not File.Exists("\\192.168.2.1\kkt erp\kumkang.exe") Then
        '        Throw New FileNotFoundException("Source file not found", "\\192.168.2.1\kkt erp\kumkang.exe")
        '    End If

        '    ' Delete destination file if it exists
        '    If File.Exists("C:\popdata\kumkang.exe") Then
        '        File.Delete("C:\popdata\kumkang.exe")
        '    End If

        '    ' Move (replace) the file
        '    File.Move("\\192.168.2.1\kkt erp\kumkang.exe", "C:\popdata\kumkang.exe")

        '    MessageBox.Show("File replaced successfully!")
        'Catch ex As Exception
        '    MessageBox.Show("Error replacing file: {ex.Message}")
        'End Try




        Try
            If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe") Then
                Process.Start("C:\Program Files (x86)\KKTERP\KKTI\kumkang.exe")
            Else
                MsgBox("File tidak ada")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show("Gagal menjalankan program: " & ex.Message)
        End Try

        Me.Close()
    End Sub
    Private Function IsProcessRunning(ByVal filePath As String) As Boolean
        Dim fileName As String = Path.GetFileNameWithoutExtension(filePath)
        Dim processes As Process() = Process.GetProcessesByName(fileName)
        Return processes.Length > 0
    End Function
    Private Sub SimpanKeRegistry(ByVal namaValue As String, ByVal nilai As String)
        ' Membuat atau membuka key registry
        ' Contoh menggunakan CurrentUser (HKEY_CURRENT_USER)
        Dim key As RegistryKey = Registry.CurrentUser.CreateSubKey("Software\KKTERP")

        Try
            ' Menyimpan nilai ke registry
            key.SetValue(namaValue, nilai)
            key.Close()

        Catch ex As Exception
            MessageBox.Show("Error menyimpan ke registry: " & ex.Message)
        Finally
            ' Pastikan key ditutup
            If key IsNot Nothing Then
                key.Close()
            End If
        End Try
    End Sub
    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'If File.Exists("C:\popdata\scan.exe") Then
        '    Dim lastModified As DateTime = File.GetLastWriteTime("C:\popdata\scan.exe")
        '    MessageBox.Show(lastModified)
        'Else
        '    MessageBox.Show("File does not exist")
        'End If
 
    End Sub


    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        FP_CHECK()

    End Sub
  

    Private Sub txtUser_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtUser.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then

            If Strings.Len(txtUser.Text) <> 5 Then
                MsgBox("Harus 5 Digit")
                Exit Sub
            End If

            SQL_C = ""
            SQL_C += "SELECT COUNT(*) QTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.user_security where secr_idxx=" & Val(txtUser.Text)



            clsCom.GP_ExeSqlReader(SQL_C)
            clsCom.gv_DataRdr.Read()

            If clsCom.gv_DataRdr("QTY") = 0 Then
                clsCom.gv_ExeSqlReaderEnd()

                lblUser.Text = "User Tidak Ada"
                Exit Sub
            Else
                clsCom.gv_ExeSqlReaderEnd()

                SQL_C = ""
                SQL_C += "SELECT *" & vbLf
                SQL_C += "FROM KKTERP.dbo.user_security where secr_idxx=" & Val(txtUser.Text)

                clsCom.GP_ExeSqlReader(SQL_C)
                clsCom.gv_DataRdr.Read()

                lblUser.Text = clsCom.gv_DataRdr("secr_user")
                txtPassword.Focus()

                clsCom.gv_ExeSqlReaderEnd()

            End If
        End If
    End Sub

  
 

    Private Sub txtPassword_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPassword.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            FP_CHECK()
        End If
    End Sub

     
    Private Sub btnCloseChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseChange.Click
        pnlChange.Visible = False
    End Sub

    Private Sub btnChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChange.Click

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.user_security where   secr_idxx=" & Val(txtUser.Text)



        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            MsgBox("User Tidak Ada")
            txtUser.Text = ""
            txtUser.Focus()

        Else
            clsCom.gv_ExeSqlReaderEnd()

            pnlChange.Visible = True
            txtOld.Text = ""
            txtNew.Text = ""
            txtNew.Enabled = False
            txtOld.Focus()

        End If

       

    End Sub

    Private Sub txtPassword_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPassword.TextChanged

    End Sub

    Private Sub txtUser_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtUser.TextChanged

    End Sub

    Private Sub txtOld_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtOld.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            FP_CHECK_GANTI_PASSWORD()
        End If
    End Sub
    Sub FP_CHECK_GANTI_PASSWORD()

        
        If txtOld.Text = "" Then
            MsgBox("Password tidak boleh kosong")
            Exit Sub
            txtPassword.Focus()
        End If

        SQL_C = ""
        SQL_C += "SELECT COUNT(*) QTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.user_security where secr_pass='" & txtOld.Text & "' and secr_idxx=" & Val(txtUser.Text)



        clsCom.GP_ExeSqlReader(SQL_C)
        clsCom.gv_DataRdr.Read()

        If clsCom.gv_DataRdr("QTY") = 0 Then
            clsCom.gv_ExeSqlReaderEnd()

            MsgBox("User atau password anda salah")
            Exit Sub
        Else
            clsCom.gv_ExeSqlReaderEnd()
            txtNew.Enabled = True
            txtNew.Focus()



        End If
    End Sub
    

    Private Sub btnUpdatePassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdatePassword.Click
        If txtNew.Text <> "" Then
            SQL_C = ""
            SQL_C += "update KKTERP.dbo.user_security set secr_pass='" & txtNew.Text & "'  where secr_idxx=" & Val(txtUser.Text)

            clsCom.GP_ExeSql(SQL_C)

            MsgBox("Password Berhasil di ganti")
            pnlChange.Visible = False
            txtPassword.Focus()
        Else
            MsgBox("Password tidak boleh kosong")
            txtNew.Focus()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub Panel3_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel3.Paint

    End Sub
End Class