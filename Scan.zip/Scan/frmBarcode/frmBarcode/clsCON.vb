﻿Public Class clsCON
    Inherits clsVAR

    Public Sub GP_SetStat()
        Dim sConString As String = String.Empty



        sConString = ""
        ' sConString += "PROVIDER=SQLOLEDB;SERVER=172.16.0.11;UID=PRTM;PWD=PRTM;DATABASE=PRTMERP"
        'sConString += "PROVIDER=SQLOLEDB;SERVER=192.168.2.10;UID=sa;PWD=kumkang;DATABASE=KKTERP"
        ' sConString += "Provider=MSOLEDBSQL;Server=" & clsVAR.gv_ip_address & ";UID=KKTI;PWD=KKTI0707;DATABASE=KKTERP;"
        sConString += "Provider=MSOLEDBSQL;Server=192.168.2.3;UID=sa;PWD=kumkang;DATABASE=KKTERP;"
        '   sConString += "PROVIDER=SQLOLEDB;SERVER=LAPTOP-GVVF28ET;UID=sa;PWD=kumkang;DATABASE=KKTERP"


        If gv_con.State = ConnectionState.Open Then gv_con.Close()

        gv_con.ConnectionString = sConString
    End Sub
End Class
