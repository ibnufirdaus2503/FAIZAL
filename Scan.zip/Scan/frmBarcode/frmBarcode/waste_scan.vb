﻿Imports System.IO
Imports Microsoft.Win32
Imports System.Diagnostics
Public Class waste_scan
    Dim currentDate As DateTime = DateTime.Now
    Dim vdate As String = currentDate.ToString("yyyyMMdd")
    Dim filescanWaste As String = "C:\popdata\scan\waste\" & vdate & ".txt"

    Dim filesendWaste As String = "C:\popdata\send\waste\" & vdate & ".txt"
    Private Function IsProcessRunning(ByVal filePath As String) As Boolean
        Dim fileName As String = Path.GetFileNameWithoutExtension(filePath)
        Dim processes As Process() = Process.GetProcessesByName(fileName)
        Return processes.Length > 0
    End Function
    Private Sub waste_scan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim popdata As New DirectoryInfo("C:\popdata")
        Dim scanWaste As New DirectoryInfo("C:\popdata\scan\waste")
        Dim sendWaste As New DirectoryInfo("C:\popdata\send\waste")



        If Not popdata.Exists Then
            Directory.CreateDirectory("C:\popdata")
        End If

        If Not scanWaste.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\waste")
        End If

        If Not sendWaste.Exists Then
            Directory.CreateDirectory("C:\popdata\send\waste")
        End If


        If Not File.Exists(filescanWaste) Then
            File.Create(filescanWaste).Dispose()

        End If



        If Not File.Exists(filesendWaste) Then
            File.Create(filesendWaste).Dispose()

        End If




        If IsProcessRunning(clsVAR.gv_path_local & "scanwaste.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Me.Close()
        End If
        If IsProcessRunning(clsVAR.gv_path_local & "sendwaste.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Me.Close()
        End If

        Dim filescan As New FileInfo(clsVAR.gv_path_local & "scanwaste.exe")
        Dim Serverscan As New FileInfo("\\" & clsVAR.gv_ip_address & "\kkt erp\scanwaste.exe")
        Dim LocalModifiedScan As DateTime = filescan.LastWriteTime
        Dim ServerModifiedScan As DateTime = Serverscan.LastWriteTime

        Dim fileSend As New FileInfo(clsVAR.gv_path_local & "sendwaste.exe")
        Dim ServerSend As New FileInfo("\\" & clsVAR.gv_ip_address & "\kkt erp\sendwaste.exe")
        Dim LocalModifiedSend As DateTime = fileSend.LastWriteTime
        Dim ServerModifiedSend As DateTime = ServerSend.LastWriteTime



        If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\sendwaste.exe") Then

            If File.Exists(clsVAR.gv_path_local & "sendwaste.exe") Then
                If ServerModifiedSend > LocalModifiedSend Then

                    'Copy File dari Server
                    File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\sendwaste.exe", clsVAR.gv_path_local & "sendwaste.exe", overwrite:=True)

                End If
            Else
                'Copy File dari Server
                File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\sendwaste.exe", clsVAR.gv_path_local & "sendwaste.exe", overwrite:=True)
            End If

        Else
            MessageBox.Show("File tidak ditemukan di jaringan!")
        End If

        If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\scanwaste.exe") Then

            If File.Exists(clsVAR.gv_path_local & "scanwaste.exe") Then
                If ServerModifiedSend > LocalModifiedSend Then

                    'Copy File dari Server
                    File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\scanwaste.exe", clsVAR.gv_path_local & "scanwaste.exe", overwrite:=True)

                End If
            Else
                'Copy File dari Server
                File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\scanwaste.exe", clsVAR.gv_path_local & "scanwaste.exe", overwrite:=True)
            End If

        Else
            MessageBox.Show("File tidak ditemukan di jaringan!")
        End If


        If IsProcessRunning(clsVAR.gv_path_local & "scanwaste.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Exit Sub
        End If
        If IsProcessRunning("C:\popdata\sendwaste.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Exit Sub
        End If


        Try
            If File.Exists(clsVAR.gv_path_local & "scanwaste.exe") Then
                Process.Start(clsVAR.gv_path_local & "scanwaste.exe")
            Else
                MsgBox("File tidak ada")
                Exit Sub
            End If


            If File.Exists(clsVAR.gv_path_local & "sendwaste.exe") Then
                Process.Start(clsVAR.gv_path_local & "sendwaste.exe")
            Else
                MsgBox("File tidak ada")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show("Gagal menjalankan program: " & ex.Message)
        End Try


 

        Me.Close()
    End Sub
End Class