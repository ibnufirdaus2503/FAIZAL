﻿Imports System.IO.Ports
Public Class frmTimbangan
    Dim WithEvents serialPort As New SerialPort

    Private Sub frmTimbangan_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If serialPort.IsOpen Then
            serialPort.Close()
        End If
    End Sub
    Private Sub frmTimbangan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Atur port sesuai yang digunakan oleh timbangan
        serialPort.PortName = "COM1" ' Ganti sesuai COM timbangan
        serialPort.BaudRate = 9600
        serialPort.Parity = Parity.None
        serialPort.DataBits = 8
        serialPort.StopBits = StopBits.One
        serialPort.Encoding = System.Text.Encoding.ASCII

        Try
            serialPort.Open()
        Catch ex As Exception
            MessageBox.Show("Gagal membuka port: " & ex.Message)
        End Try
    End Sub

    Private Sub serialPort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles serialPort.DataReceived
        Dim data As String = serialPort.ReadLine() ' Atau ReadExisting
     
        TextBox1.Text = data.Trim()

    End Sub
End Class