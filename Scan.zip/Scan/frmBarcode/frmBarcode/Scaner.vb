﻿
Imports System.IO
Imports Microsoft.Win32
Imports System.Diagnostics
Public Class Scaner
    Dim currentDate As DateTime = DateTime.Now
    Dim vdate As String = currentDate.ToString("yyyyMMdd")
    Dim filescanBLR As String = "C:\popdata\scan\BLR\" & vdate & ".txt"
    Dim filescanING As String = "C:\popdata\scan\ING\" & vdate & ".txt"
    Dim filescanOTG As String = "C:\popdata\scan\OTG\" & vdate & ".txt"
    Dim filescanIFG As String = "C:\popdata\scan\IFG\" & vdate & ".txt"
    Dim filesendBLR As String = "C:\popdata\send\BLR\" & vdate & ".txt"
    Dim filesendING As String = "C:\popdata\send\ING\" & vdate & ".txt"
    Dim filesendnOTG As String = "C:\popdata\send\OTG\" & vdate & ".txt"
    Dim filesendIFG As String = "C:\popdata\send\IFG\" & vdate & ".txt"

    Dim fileAddr As String = "C:\popdata\addr.txt"
    Dim vAddr As String
    Dim vLocationScan As String
    Private Function IsProcessRunning(ByVal filePath As String) As Boolean
        Dim fileName As String = Path.GetFileNameWithoutExtension(filePath)
        Dim processes As Process() = Process.GetProcessesByName(fileName)
        Return processes.Length > 0
    End Function
    Private Sub Scaner_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load




      
        Dim popdata As New DirectoryInfo("C:\popdata")
        Dim scanBLR As New DirectoryInfo("C:\popdata\scan\BLR")
        Dim scanING As New DirectoryInfo("C:\popdata\scan\ING")
        Dim scanOTG As New DirectoryInfo("C:\popdata\scan\OTG")
        Dim scanIFG As New DirectoryInfo("C:\popdata\scan\IFG")
        Dim sendBLR As New DirectoryInfo("C:\popdata\send\BLR")
        Dim sendING As New DirectoryInfo("C:\popdata\send\ING")
        Dim sendOTG As New DirectoryInfo("C:\popdata\send\OTG")
        Dim sendIFG As New DirectoryInfo("C:\popdata\send\IFG")


        If Not popdata.Exists Then
            Directory.CreateDirectory("C:\popdata")
        End If

        If Not File.Exists(fileAddr) Then
            File.Create(fileAddr).Dispose()

            Using writer As New System.IO.StreamWriter(fileAddr, True) ' True for append mode

                writer.WriteLine("1")

            End Using

        End If


        If Not scanBLR.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\BLR")
        End If

        If Not scanING.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\ING")
        End If

        If Not scanOTG.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\OTG")
        End If

        If Not scanIFG.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\IFG")
        End If

        If Not sendBLR.Exists Then
            Directory.CreateDirectory("C:\popdata\send\BLR")
        End If

        If Not sendING.Exists Then
            Directory.CreateDirectory("C:\popdata\send\ING")
        End If

        If Not sendOTG.Exists Then
            Directory.CreateDirectory("C:\popdata\send\OTG")
        End If

        If Not sendIFG.Exists Then
            Directory.CreateDirectory("C:\popdata\send\IFG")
        End If

      

        If Not File.Exists(filescanBLR) Then
            File.Create(filescanBLR).Dispose()

        End If



        If Not File.Exists(filescanING) Then
            File.Create(filescanING).Dispose()

        End If

        If Not File.Exists(filescanOTG) Then
            File.Create(filescanOTG).Dispose()

        End If

        If Not File.Exists(filescanIFG) Then
            File.Create(filescanIFG).Dispose()

        End If




        If Not File.Exists(filesendBLR) Then
            File.Create(filesendBLR).Dispose()

        End If

        If Not File.Exists(filesendING) Then
            File.Create(filesendING).Dispose()

        End If

        If Not File.Exists(filesendnOTG) Then
            File.Create(filesendnOTG).Dispose()

        End If

        If Not File.Exists(filesendIFG) Then
            File.Create(filesendIFG).Dispose()

        End If

        '---

        If IsProcessRunning("C:\Program Files (x86)\KKTERP\KKTI\scan.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Me.Close()
        End If
        If IsProcessRunning("C:\Program Files (x86)\KKTERP\KKTI\send.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Me.Close()
        End If

        Dim filescan As New FileInfo("C:\Program Files (x86)\KKTERP\KKTI\scan.exe")
        Dim Serverscan As New FileInfo("\\" & clsVAR.gv_ip_address & "\kkt erp\scan.exe")
        Dim LocalModifiedScan As DateTime = filescan.LastWriteTime
        Dim ServerModifiedScan As DateTime = Serverscan.LastWriteTime

        Dim fileSend As New FileInfo("C:\Program Files (x86)\KKTERP\KKTI\send.exe")
        Dim ServerSend As New FileInfo("\\" & clsVAR.gv_ip_address & "\kkt erp\send.exe")
        Dim LocalModifiedSend As DateTime = fileSend.LastWriteTime
        Dim ServerModifiedSend As DateTime = ServerSend.LastWriteTime



        If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\send.exe") Then

            If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\send.exe") Then
                If ServerModifiedSend > LocalModifiedSend Then

                    'Copy File dari Server
                    File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\send.exe", "C:\Program Files (x86)\KKTERP\KKTI\send.exe", overwrite:=True)

                End If
            Else
                'Copy File dari Server
                File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\send.exe", "C:\Program Files (x86)\KKTERP\KKTI\send.exe", overwrite:=True)
            End If

        Else
            MessageBox.Show("File tidak ditemukan di jaringan!")
        End If

        If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\scan.exe") Then

            If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\scan.exe") Then
                If ServerModifiedSend > LocalModifiedSend Then

                    'Copy File dari Server
                    File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\scan.exe", "C:\Program Files (x86)\KKTERP\KKTI\scan.exe", overwrite:=True)

                End If
            Else
                'Copy File dari Server
                File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\scan.exe", "C:\Program Files (x86)\KKTERP\KKTI\scan.exe", overwrite:=True)
            End If

        Else
            MessageBox.Show("File tidak ditemukan di jaringan!")
        End If


        If IsProcessRunning("C:\Program Files (x86)\KKTERP\KKTI\scan.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Exit Sub
        End If
        If IsProcessRunning("C:\popdata\send.exe") Then
            MessageBox.Show("Aplikasi sedang berjalan!")
            Exit Sub
        End If


        Try
            If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\scan.exe") Then
                Process.Start("C:\Program Files (x86)\KKTERP\KKTI\scan.exe")
            Else
                MsgBox("File tidak ada")
                Exit Sub
            End If


            If File.Exists("C:\Program Files (x86)\KKTERP\KKTI\send.exe") Then
                Process.Start("C:\Program Files (x86)\KKTERP\KKTI\send.exe")
            Else
                MsgBox("File tidak ada")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show("Gagal menjalankan program: " & ex.Message)
        End Try



        'If File.Exists("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe") Then

        '    If File.Exists("C:\popdata\kumkang.exe") Then
        '        If ServerModifiedScan > LocalModifiedScan Then

        '            'Copy File dari Server
        '            File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\scan.exe", "C:\popdata\scan.exe", overwrite:=True)

        '        End If
        '    Else
        '        'Copy File dari Server
        '        File.Copy("\\" & clsVAR.gv_ip_address & "\kkt erp\kumkang.exe", "C:\popdata\kumkang.exe", overwrite:=True)
        '    End If




        'Else
        '    MessageBox.Show("File tidak ditemukan di jaringan!")
        'End If



        Me.Close()

    End Sub


End Class