﻿Imports System.IO

Public Class frmSendScanIn
    Dim currentDate As DateTime = DateTime.Now
    Dim vdate As String = currentDate.ToString("yyyyMMdd")
    Dim filescanBLR As String = "C:\popdata\scan\BLR\" & vdate & ".txt"
    Dim filescanING As String = "C:\popdata\scan\ING\" & vdate & ".txt"
    Dim filescanOTG As String = "C:\popdata\scan\OTG\" & vdate & ".txt"
    Dim filescanIFG As String = "C:\popdata\scan\IFG\" & vdate & ".txt"
    Dim filesendBLR As String = "C:\popdata\send\BLR\" & vdate & ".txt"
    Dim filesendING As String = "C:\popdata\send\ING\" & vdate & ".txt"
    Dim filesendOTG As String = "C:\popdata\send\OTG\" & vdate & ".txt"
    Dim filesendIFG As String = "C:\popdata\send\IFG\" & vdate & ".txt"

    Dim fileAddr As String = "C:\popdata\addr.txt"
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C, vAddr, vLocationScan, vLocationSend As String
    Private Sub FP_SHIFT()

      

        SQL_C += "EXEC SP_SHIFT" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        lblDate.Text = clsCom.gv_DataRdr("Vdate")
        lblShif.Text = clsCom.gv_DataRdr("VSHIFT")


        'lblDate.Text = "2025/06/08"
        'lblShif.Text = 1



        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_ADDR()

        Using reader As New StreamReader(fileAddr)

            While Not reader.EndOfStream
                vAddr = reader.ReadLine()


            End While

        End Using

        If vAddr = 1 Then
            lblAddress.Text = "1. Scan In External CMP"
        ElseIf vAddr = 2 Then
            lblAddress.Text = "2. Scan In After Grinding"
        ElseIf vAddr = 3 Then
            lblAddress.Text = "3. Scan Out After Grinding"
        ElseIf vAddr = 4 Then
            lblAddress.Text = "4. Scan Out Finish Good"
        End If
    End Sub
    Private Sub FP_SEND_DATA()
        Dim vBarcode As Integer
        Dim vTotal As Integer

        SQL_C = ""
        If vAddr = 1 Then
            SQL_C += "SELECT PROD_SCIT,CONVERT(VARCHAR(10),PROD_SCIN,111) TGL," & vbLf
            SQL_C += "lotd_size, mols_size,prod_qtty,PROD_IDXX,model_name,codd_desc,colr_name " & vbLf
            SQL_C += "from KKTERP.dbo.production A" & vbLf
        ElseIf vAddr = 2 Then
            SQL_C += "SELECT PROD_INGT,CONVERT(VARCHAR(10),PROD_INGR,111) TGL," & vbLf
            SQL_C += "lotd_size, mols_size,prod_qtty,PROD_IDXX,model_name,codd_desc,colr_name " & vbLf
            SQL_C += "from KKTERP.dbo.production A" & vbLf
        ElseIf vAddr = 3 Then
            SQL_C += "SELECT CONVERT(VARCHAR(10),PROD_OTGR,111) TGL," & vbLf
            SQL_C += "lotd_size, mols_size,prod_qtty,PROD_IDXX,model_name,codd_desc,colr_name " & vbLf
            SQL_C += "from KKTERP.dbo.production A" & vbLf
        
        ElseIf vAddr = 4 Then
            SQL_C += "SELECT  PROD_OTGT,CONVERT(VARCHAR(10),PROD_deli,111) TGL," & vbLf
            SQL_C += "lotd_size, mols_size,prod_qtty,PROD_IDXX,model_name,codd_desc,colr_name " & vbLf
            SQL_C += "from KKTERP.dbo.production_GOOD A" & vbLf
        End If
 
        
            SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf
            If vAddr = 1 Then
                SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_SCIN,111)='" & lblDate.Text & "' AND prod_opcd='CMP' " & vbLf
            SQL_C += "ORDER BY PROD_SCIT DESC" & vbLf
            ElseIf vAddr = 2 Then
                SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_INGR,111)='" & lblDate.Text & "' AND prod_opcd='CMP' " & vbLf
            SQL_C += "ORDER BY PROD_INGT  DESC" & vbLf
            ElseIf vAddr = 3 Then
                SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_OTGR,111)='" & lblDate.Text & "' AND prod_opcd='CMP'  " & vbLf
            SQL_C += "ORDER BY PROD_OTGT DESC" & vbLf
        ElseIf vAddr = 4 Then
            SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_deli,111)='" & lblDate.Text & "' AND prod_opcd='CPX'  " & vbLf
            SQL_C += "ORDER BY PROD_deli DESC" & vbLf
            End If



            clsCom.GP_ExeSqlReader(SQL_C)

            With spdModel_Sheet1
                .RowCount = 0
                vTotal = 0
                While clsCom.gv_DataRdr.Read

                    .RowCount = .RowCount + 1
                    vBarcode = clsCom.gv_DataRdr("PROD_IDXX")

                .Cells.Item(.RowCount - 1, 0).Text = vBarcode.ToString("D9")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("TGL")
                    .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("lotd_size")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("prod_qtty")

                    vTotal = vTotal + clsCom.gv_DataRdr("prod_qtty")


                End While

                '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
            End With

            clsCom.gv_ExeSqlReaderEnd()

            lblPrs.Text = vTotal

    End Sub
    Private Sub frmSendScanIn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        FP_SHIFT()

        FP_ADDR()
        Timer1.Enabled = True
        FP_READ()
        FP_SEND()

        FP_SEND_DATA()

    End Sub

    Private Sub FP_SEND()
        Dim vData As String

        If vAddr = 1 Then
            vLocationScan = filescanBLR
            vLocationSend = filesendBLR
        ElseIf vAddr = 2 Then
            vLocationScan = filescanING
            vLocationSend = filesendING
        ElseIf vAddr = 3 Then
            vLocationScan = filescanOTG
            vLocationSend = filesendOTG
        ElseIf vAddr = 4 Then
            vLocationScan = filescanIFG
            vLocationSend = filesendIFG

        End If

        Using reader As New StreamReader(vLocationScan)
            With spdScan_Sheet1
                .RowCount = 0
                While Not reader.EndOfStream
                    vData = reader.ReadLine()
                    Dim fileContent As String = File.ReadAllText(vLocationSend)
                    Using writer As New System.IO.StreamWriter(vLocationSend, True) ' True for append mode MNNMNMNMMNNMNMNMMNMNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM

                        If Not (fileContent.Contains(vData)) Then

                            If vAddr = 1 Then


                                ' SQL_C += "UPDATE KKTERP.dbo.production set prod_scin='" & Strings.Left(Strings.Right(vData, 14), 4) & "-" & Strings.Mid(Strings.Right(vData, 14), 5, 2) & "-" & Strings.Mid(Strings.Right(vData, 14), 7, 2) & " " & Strings.Left(Strings.Right(vData, 6), 2) & ":" & Strings.Left(Strings.Right(vData, 4), 2) & ":" & Strings.Right(vData, 2) & "' where prod_idxx=" & Val(Strings.Right(Strings.Left(vData, 7), 6)) & vbLf
                                SQL_C = ""
                                SQL_C += "UPDATE KKTERP.dbo.production set prod_scih= DATEPART(HOUR,GETDATE()),prod_updt=getdate() ,CODE_SHIF=" & Strings.Right(lblShif.Text, 1) & ",prod_scin=getdate(),prod_scit='" & lblDate.Text & "'  where prod_idxx=" & Val(Strings.Right(vData, 9)) & vbLf
                            ElseIf vAddr = 2 Then
                                SQL_C = ""
                                SQL_C += "UPDATE KKTERP.dbo.production set prod_ingh= DATEPART(HOUR,GETDATE()),prod_ingt=getdate(), CODE_SHIF=" & Strings.Right(lblShif.Text, 1) & ",prod_ingr='" & lblDate.Text & "'   where prod_idxx=" & Val(Strings.Right(vData, 9)) & vbLf

                            ElseIf vAddr = 3 Then
                                SQL_C = ""
                                SQL_C += "UPDATE KKTERP.dbo.production set prod_otgh= DATEPART(HOUR,GETDATE()),prod_otgt=getdate(), CODE_SHIF=" & Strings.Right(lblShif.Text, 1) & ",prod_otgr='" & lblDate.Text & "'   where prod_idxx=" & Val(Strings.Right(vData, 9)) & vbLf

                            ElseIf vAddr = 4 Then
                                SQL_C = ""
                                SQL_C += "UPDATE KKTERP.dbo.production_good set prod_delh= DATEPART(HOUR,GETDATE()),prod_updt=getdate(), prod_dels=" & Strings.Right(lblShif.Text, 1) & ",prod_deli='" & lblDate.Text & "'   where prod_idxx=" & Val(Strings.Right(vData, 9)) & vbLf


                            End If

                            clsCom.GP_ExeSql(SQL_C)

                            writer.WriteLine(vData)
                        End If
                    End Using
                End While

            End With
        End Using

       

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Label1.Text > 9 Then
            Timer1.Enabled = False
            FP_SEND()
            FP_READ()
            FP_SEND_DATA()



            Label1.Text = 1
            Timer1.Enabled = True
        Else
            Label1.Text = Label1.Text + 1
        End If
    End Sub

    Private Sub FP_READ()
        Dim vData As String

        If vAddr = 1 Then
            vLocationScan = filescanBLR
            vLocationSend = filesendBLR
        ElseIf vAddr = 2 Then
            vLocationScan = filescanING
            vLocationSend = filesendING
        ElseIf vAddr = 3 Then
            vLocationScan = filescanOTG
            vLocationSend = filesendOTG
        ElseIf vAddr = 4 Then
            vLocationScan = filescanIFG
            vLocationSend = filesendIFG

        End If
        Using reader As New StreamReader(vLocationSend)
            With spdScan_Sheet1
                .RowCount = 0
                While Not reader.EndOfStream
                    vData = reader.ReadLine()
                    .RowCount = .RowCount + 1


                    .Cells.Item(.RowCount - 1, 0).Text = Strings.Right(vData, 9)
                    '.Cells.Item(.RowCount - 1, 1).Text = Strings.Right(vData, 14)

                End While
                spdScan.ActiveSheet.AutoSortColumn(1, False)

            End With
        End Using
        lblSend.Text = spdScan_Sheet1.RowCount
        lblBag.Text = spdModel_Sheet1.RowCount

    End Sub
End Class