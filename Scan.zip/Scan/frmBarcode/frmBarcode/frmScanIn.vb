﻿Imports System.IO



Public Class frmScanIn
    Dim currentDate As DateTime = DateTime.Now
    Dim vdate As String = currentDate.ToString("yyyyMMdd")
    Dim filescanBLR As String = "C:\popdata\scan\BLR\" & vdate & ".txt"
    Dim filescanING As String = "C:\popdata\scan\ING\" & vdate & ".txt"
    Dim filescanOTG As String = "C:\popdata\scan\OTG\" & vdate & ".txt"
    Dim filescanIFG As String = "C:\popdata\scan\IFG\" & vdate & ".txt"
    Dim filesendBLR As String = "C:\popdata\send\BLR\" & vdate & ".txt"
    Dim filesendING As String = "C:\popdata\send\ING\" & vdate & ".txt"
    Dim filesendnOTG As String = "C:\popdata\send\OTG\" & vdate & ".txt"
    Dim filesendIFG As String = "C:\popdata\send\IFG\" & vdate & ".txt"

    Dim fileAddr As String = "C:\popdata\addr.txt"
    Dim vAddr As String
    Dim vLocationScan As String


    Private Sub frmScanIn_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim popdata As New DirectoryInfo("C:\popdata")
        Dim scanBLR As New DirectoryInfo("C:\popdata\scan\BLR")
        Dim scanING As New DirectoryInfo("C:\popdata\scan\ING")
        Dim scanOTG As New DirectoryInfo("C:\popdata\scan\OTG")
        Dim scanIFG As New DirectoryInfo("C:\popdata\scan\IFG")
        Dim sendBLR As New DirectoryInfo("C:\popdata\send\BLR")
        Dim sendING As New DirectoryInfo("C:\popdata\send\ING")
        Dim sendOTG As New DirectoryInfo("C:\popdata\send\OTG")
        Dim sendIFG As New DirectoryInfo("C:\popdata\send\IFG")


        If Not popdata.Exists Then
            Directory.CreateDirectory("C:\popdata")
        End If

        If Not scanBLR.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\BLR")
        End If

        If Not scanING.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\ING")
        End If

        If Not scanOTG.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\OTG")
        End If

        If Not scanIFG.Exists Then
            Directory.CreateDirectory("C:\popdata\scan\IFG")
        End If

        If Not sendBLR.Exists Then
            Directory.CreateDirectory("C:\popdata\send\BLR")
        End If

        If Not sendING.Exists Then
            Directory.CreateDirectory("C:\popdata\send\ING")
        End If

        If Not sendOTG.Exists Then
            Directory.CreateDirectory("C:\popdata\send\OTG")
        End If

        If Not sendIFG.Exists Then
            Directory.CreateDirectory("C:\popdata\send\IFG")
        End If





        If Not File.Exists(filescanBLR) Then
            File.Create(filescanBLR).Dispose()

        End If

        If Not File.Exists(filescanING) Then
            File.Create(filescanING).Dispose()

        End If

        If Not File.Exists(filescanOTG) Then
            File.Create(filescanOTG).Dispose()

        End If

        If Not File.Exists(filescanIFG) Then
            File.Create(filescanIFG).Dispose()

        End If




        If Not File.Exists(filesendBLR) Then
            File.Create(filesendBLR).Dispose()

        End If

        If Not File.Exists(filesendING) Then
            File.Create(filesendING).Dispose()

        End If

        If Not File.Exists(filesendnOTG) Then
            File.Create(filesendnOTG).Dispose()

        End If

        If Not File.Exists(filesendIFG) Then
            File.Create(filesendIFG).Dispose()

        End If

        FP_ADDR()

        FP_READ()


    End Sub

    Private Sub txtScan_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtScan.KeyPress
        Dim skr As DateTime = DateTime.Now
        Dim skrdate As String = skr.ToString("yyyyMMddHHmmss")


        If e.KeyChar = ChrW(Keys.Enter) Then

            If Strings.Len(txtScan.Text) <> 9 Then
                txtScan.Text = ""
                lblScan.Text = "Barcode Harus 9 Digit"
                txtScan.Focus()
                Exit Sub
            Else

                lblScan.Text = txtScan.Text
                txtScan.Text = ""
            End If




            ' Baca seluruh isi file




            If vAddr = 1 Then
                vLocationScan = filescanBLR
            ElseIf vAddr = 2 Then
                vLocationScan = filescanING
            ElseIf vAddr = 3 Then
                vLocationScan = filescanOTG
            ElseIf vAddr = 4 Then
                vLocationScan = filescanIFG

            End If

            Dim fileContent As String = File.ReadAllText(vLocationScan)





            Using writer As New System.IO.StreamWriter(vLocationScan, True) ' True for append mode

                ' If Not (fileContent.Contains(vAddr & lblScan.Text & skrdate)) Then
                If Not (fileContent.Contains(vAddr & lblScan.Text)) Then
                    writer.WriteLine(vAddr & lblScan.Text)
                Else
                    lblScan.Text = "D U P L I C A T E"
                End If
            End Using
        End If

        FP_READ()

        txtScan.Focus()


    End Sub
    Private Sub FP_ADDR()

        Using reader As New StreamReader(fileAddr)
          
            While Not reader.EndOfStream
                vAddr = reader.ReadLine()
                

            End While
           
        End Using

        If vAddr = 1 Then
            lblAddress.Text = "1. Scan In External CMP"
        ElseIf vAddr = 2 Then
            lblAddress.Text = "2. Scan In After Grinding"
        ElseIf vAddr = 3 Then
            lblAddress.Text = "3. Scan Out After Grinding"
        ElseIf vAddr = 4 Then
            lblAddress.Text = "4.Finish Good"

        End If
    End Sub

    Private Sub FP_READ()
        Dim vTotal As Integer

        Dim vData As String



        If vAddr = 1 Then
            vLocationScan = filescanBLR
        ElseIf vAddr = 2 Then
            vLocationScan = filescanING
        ElseIf vAddr = 3 Then
            vLocationScan = filescanOTG
        ElseIf vAddr = 4 Then
            vLocationScan = filescanIFG

        End If
                      

        Using reader As New StreamReader(vLocationScan)
            With spdScan_Sheet1
                .RowCount = 0
                vTotal = 0
                While Not reader.EndOfStream
                    vData = reader.ReadLine()
                    .RowCount = .RowCount + 1


                    .Cells.Item(.RowCount - 1, 0).Text = Strings.Left(vData, 10)
                    ' .Cells.Item(.RowCount - 1, 1).Text = Strings.Right(vData, 14)
                    vTotal = vTotal + 1

                End While
                spdScan.ActiveSheet.AutoSortColumn(1, False)
                lblTotal.Text = vTotal
            End With
        End Using
    End Sub

     
    Private Sub txtScan_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtScan.TextChanged

    End Sub
End Class