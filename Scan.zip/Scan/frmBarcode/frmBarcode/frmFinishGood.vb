﻿Imports System.IO
Public Class frmFinishGood

    Dim filePath As String = "C:\barcode\barcode.txt"
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vSize As Integer
    Dim vaddr As Integer
    Dim Pcomponent As String
    Dim PMoldCode As String
    Dim PModel_Id As String
    Dim PModel_Name As String
    Dim vColor_id As String
    Dim vSize_component As String
    Dim PCustomerName As String
    Dim vMcom As Integer
    Dim vMolhId As Integer

    Private Sub FP_PRINT_BARCODE()
        Dim Id_Model, Barcode As Integer


        SQL_C = ""
        SQL_C += "SELECT TOP 10 PROD_IDXX, X.MCOM_IDXX,X.MOLH_IDXX,MOLH_CODE,CODD_DESC,CUSTOMER_NAME,MODEL_NAME,MODEL_ID,COLR_NAME,pack_cp,PROD_QTTY,MOLS_SIZE" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good  X" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.DBO.MATERIAL_COMPONENT A ON A.MCOM_IDXX=X.MCOM_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.CODE_COMMON B ON B.CODH_FLNM='CODE_COMP' AND B.CODD_VALU=CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL_COLOR C ON A.MCLR_IDXX=C.MCLR_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MOLD_HEADER D ON D.MODL_IDXX=C.MODL_IDXX AND D.CODE_COMP=A.CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.vMODEL E ON D.MODL_IDXX=E.MODeL_ID " & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=C.colr_idxx" & vbLf
        SQL_C += "where Convert(VARCHAR(10), prod_date, 111) = '" & lblDate.Text & "'" & vbLf
        SQL_C += "ORDER BY PROD_UPDT DESC" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdPrintUlang_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                Id_Model = clsCom.gv_DataRdr("MODEL_ID")
                Barcode = clsCom.gv_DataRdr("PROD_IDXX")

                .Cells.Item(.RowCount - 1, 1).Text = Barcode.ToString("D9")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("MOLS_SIZE")
                .Cells.Item(.RowCount - 1, 3).Text = Id_Model.ToString("D4")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("colr_name")


                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("CUSTOMER_NAME")

                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("MOLH_CODE")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("PROD_QTTY")




            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_SHIFT()

        SQL_C = ""
        SQL_C += "SELECT tgl,VSHIFT" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT CONVERT(VARCHAR(10),caln_date,111) tgl," & vbLf
        SQL_C += "		CASE" & vbLf
        SQL_C += "		WHEN GETDATE() BETWEEN caln_frm1 AND caln_tox1 then 'SHIFT-1'" & vbLf
        SQL_C += "		WHEN GETDATE() BETWEEN caln_frm2 AND caln_tox2 then 'SHIFT-2'" & vbLf
        SQL_C += "		WHEN GETDATE() BETWEEN caln_frm3 AND caln_tox3 then 'SHIFT-3'" & vbLf
        SQL_C += "		END VSHIFT  " & vbLf
        SQL_C += "FROM KKTERP.dbo.calender " & vbLf
        SQL_C += " WHERE(Convert(VARCHAR(10), caln_date, 111))" & vbLf
        SQL_C += "between(Convert(VARCHAR(10), DateAdd(Day, -1, getdate()), 111))" & vbLf
        SQL_C += " AND  CONVERT(VARCHAR(10),getdate(),111)  " & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "WHERE(VSHIFT Is Not NULL)" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()

        lblDate.Text = clsCom.gv_DataRdr("tgl")
        lblShift.Text = clsCom.gv_DataRdr("VSHIFT")

      

    End Sub
    Private Sub FP_DETAIL()



        SQL_C = ""
        SQL_C += "SELECT grop_seqn,a.mols_size,isnull(qtty,0) qtty " & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT distinct grop_seqn,mols_size" & vbLf
        SQL_C += "FROM KKTERP.dbo.production " & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B  ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "where convert(varchar(10),prod_otgr,111) between dateadd(day,-3,convert(varchar(10),prod_Date,111)) and convert(varchar(10),getdate(),111)" & vbLf
        SQL_C += "and mcom_idxx=" & vMcom & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "Left Join " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT mcom_idxx,mols_size,isnull(sum(prod_qtty),0) qtty   " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good " & vbLf
        SQL_C += "where Convert(VARCHAR(10), prod_date, 111) = '" & lblDate.Text & "' And CODE_SHIF = " & Strings.Right(lblShift.Text, 1) & " and mcom_idxx=" & vMcom & vbLf
        SQL_C += "group by mcom_idxx,mols_size" & vbLf
        SQL_C += ") B ON A.mols_size=b.mols_size" & vbLf
        SQL_C += "ORDER BY grop_seqn" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("qtty")




            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_HEAD()
        Dim id_model As Integer

     

        SQL_C = ""
        SQL_C += "SELECT A.*,isnull(qtty,0) qtty" & vbLf
        SQL_C += "FROM (" & vbLf
        SQL_C += "SELECT DISTINCT X.MCOM_IDXX,X.MOLH_IDXX,MOLH_CODE,CODD_DESC,CUSTOMER_NAME,MODEL_NAME,MODEL_ID,COLR_NAME,pack_cp" & vbLf
        SQL_C += "FROM KKTERP.dbo.production X" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.DBO.MATERIAL_COMPONENT A ON A.MCOM_IDXX=X.MCOM_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.CODE_COMMON B ON B.CODH_FLNM='CODE_COMP' AND B.CODD_VALU=CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MODEL_COLOR C ON A.MCLR_IDXX=C.MCLR_IDXX" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.MOLD_HEADER D ON D.MODL_IDXX=C.MODL_IDXX AND D.CODE_COMP=A.CODE_COMP" & vbLf
        SQL_C += "LEFT JOIN KKTERP.DBO.vMODEL E ON D.MODL_IDXX=E.MODeL_ID " & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=C.colr_idxx" & vbLf
        SQL_C += "where  cONVERT(VARCHAR(10),prod_otgr,111)" & vbLf
        SQL_C += "between(Convert(VARCHAR(10), DateAdd(Day, -3, getdate()), 111))" & vbLf
        SQL_C += " AND  CONVERT(VARCHAR(10),getdate(),111)  " & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN (" & vbLf
        SQL_C += "SELECT mcom_idxx,isnull(sum(prod_qtty),0) qtty   " & vbLf
        SQL_C += "FROM KKTERP.dbo.production_good " & vbLf
        SQL_C += "where Convert(VARCHAR(10), prod_date, 111) = '" & lblDate.Text & "' And CODE_SHIF = " & Strings.Right(lblShift.Text, 1) & "" & vbLf
        SQL_C += "group by mcom_idxx" & vbLf
        SQL_C += ") B ON A.mcom_idxx=B.mcom_idxx" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdProd_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                id_model = clsCom.gv_DataRdr("MODEL_ID")

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = id_model.ToString("D4")
                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("pack_cp")
                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("CUSTOMER_NAME")

                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("MOLH_CODE")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("qtty")




            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
   
    Private Sub FP_SUM_HOUR()
        Dim i As Integer

        SQL_C = ""
        SQL_C += "SELECT prod_hour,sum(prod_qtty) QTTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_GOOD" & vbLf
        '  SQL_C += "WHERE    subs_idxx=" & spdLine_Sheet1.Cells.Item(spdLine_Sheet1.ActiveRowIndex, 0).Text & " AND mcom_idxx=" & spdModel_Sheet1.Cells.Item(spdModel_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 1).Text & "' AND prod_grad='A' AND CONVERT(VARCHAR(10),PROD_DATE,111)=  Convert(VARCHAR(10),'" & dtTgl.Value & "', 111)" & vbLf
        SQL_C += "WHERE       prod_opcd='CPX' AND prod_grad='A' AND CONVERT(VARCHAR(10),PROD_DATE,111)=  Convert(VARCHAR(10),'" & lblDate.Text & "', 111)" & vbLf
       
        SQL_C += "AND PROD_GOOD IS NOT NULL" & vbLf


        SQL_C += "GROUP BY prod_hour" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)



        While clsCom.gv_DataRdr.Read

            If clsCom.gv_DataRdr("prod_hour") >= 7 And clsCom.gv_DataRdr("prod_hour") <= 18 Then
                With spdHour1_Sheet1
                    For i = 0 To 11
                        If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("prod_hour") Then
                            .Cells.Item(0, i).Text = clsCom.gv_DataRdr("QTTY")
                        End If

                    Next
                End With
            Else
                With spdHour2_Sheet1
                    For i = 0 To 11
                        If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("prod_hour") Then
                            .Cells.Item(0, i).Text = clsCom.gv_DataRdr("QTTY")
                        End If

                    Next
                End With
            End If


        End While

        '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect


        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_LIST_SIZE()

        SQL_C = ""
        SQL_C += " SELECT * FROM KKTERP.dbo.Func_Production_Distinct_size (CONVERT(VARCHAR(10),GETDATE(),111),'TRM','A'," & vSize & ")" & vbLf


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mols_size")

                .Cells.Item(.RowCount - 1, 1).Row.Height = 40
                '   .Cells.Item(.RowCount - 1, 1).Column.Width = 105
                




            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()

    End Sub

    
    Private Sub frmFinishGood_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim folderInfo As New DirectoryInfo("C:\barcode")
        
 


        If Not folderInfo.Exists Then
            Directory.CreateDirectory("C:\barcode")
        End If



        If Not File.Exists(filePath) Then

            Try
                ' Create an empty file
                File.Create(filePath).Dispose()
                FP_Barcode()

            Catch ex As Exception
                MessageBox.Show("Error creating file: " & ex.Message)
            End Try
        Else
            File.WriteAllText(filePath, String.Empty)
            'FP_Barcode()
        End If
        FP_SHIFT()

        FP_SUM_HOUR()


        FP_HEAD()
        FP_PRINT_BARCODE()
    End Sub

     

    Private Sub FP_Barcode()
        Dim vBarcode As Integer

        Try
            Using writer As New StreamWriter(filePath)
                'writer.WriteLine("^XA")
                'writer.WriteLine("^LH105,0")
                'writer.WriteLine("^FO0,10 ^GB390,220,4^FS")
                'writer.WriteLine("^FO0,10 ^GB390,50,4^FS")
                'writer.WriteLine("^FO0,55 ^GB390,90,4^FS")
                'writer.WriteLine("^FO0,55 ^GB100,90,4^FS")
                'writer.WriteLine("^FO0,140 ^GB100,90,4^FS")
                'writer.WriteLine("^FO100,200^GB290,0,3^FS")
                'writer.WriteLine("^FO10,23^A0N,30,20^FD" & spdModel_Sheet1.Cells.Item(spdModel_Sheet1.ActiveRowIndex, 0).Text & "^FS")
                'writer.WriteLine("^FO170,25^A0N,25,25^FD" & Now() & "^FS")
                'writer.WriteLine("^FO10,70^A0N,35,35^FD" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "^FS")
                'writer.WriteLine("^FO10,110^A0N,30,30^FD 12 PRS^FS")
                'writer.WriteLine("^FO140,70^A0N,50,50^FDII7649012^FS")
                'writer.WriteLine("^FO105,115^A0N,20,20^FDNIKE AIR MAX PLUS GS^FS")
                'writer.WriteLine("^FO20,145")
                'writer.WriteLine("^BQN,4,3")
                'writer.WriteLine("^FDMM,0000001753940^FS")
                'writer.WriteLine("^FO105,205^A0N,25,25^FD0000001753940^FS")
                'writer.WriteLine("^FO105,160^A0N,40,40^FD" & spdProd_Sheet1.Cells.Item(spdProd_Sheet1.ActiveRowIndex, 4).Text & "^FS")
                'writer.WriteLine("^FO305,205^A0N,25,25^FD KMK^FS")
                'writer.WriteLine("^XZ")


                'writer.WriteLine("^XA")
                'writer.WriteLine("^LH105,0")
                'writer.WriteLine("^FO0,10 ^GB390,220,4^FS")
                'writer.WriteLine("^FO0,10 ^GB390,50,4^FS")
                'writer.WriteLine("^FO0,55 ^GB390,90,4^FS")
                'writer.WriteLine("^FO0,55 ^GB100,90,4^FS")
                'writer.WriteLine("^FO0,140 ^GB100,90,4^FS")
                'writer.WriteLine("^FO100,200^GB290,0,3^FS")


                SQL_C = ""
                SQL_C += " SELECT IDENT_CURRENT('product_good') AS LastID" & vbLf


                clsCom.GP_ExeSqlReader(SQL_C)

                clsCom.gv_DataRdr.Read()

                vBarcode = clsCom.gv_DataRdr("LastID") + 1
                clsCom.gv_ExeSqlReaderEnd()

                txtBarcode.Text = vBarcode.ToString("D9")



                writer.WriteLine("^XA")
                writer.WriteLine("^LH10,0")
                writer.WriteLine("^FO0,10 ^GB500,340,4^FS")
                writer.WriteLine("^FO0,10 ^GB500,50,4^FS")
                writer.WriteLine("^FO0,55 ^GB500,60,4^FS")
                writer.WriteLine("^FO0,55 ^GB200,60,4^FS")
                writer.WriteLine("^FO0,111 ^GB150,60,4^FS")
                writer.WriteLine("^FO0,167 ^GB500,60,4^FS")
                writer.WriteLine("^FO0,225 ^GB100,125,4^FS")
                writer.WriteLine("^FO270,225 ^GB230,125,4^FS")
                writer.WriteLine("^FO10,23^A0N,30,20^FD^FS")
                writer.WriteLine("^FO250,25^A0N,25,25^FD" & Now & "^FS")
                writer.WriteLine("^FO10,70^A0N,35,35^FD^FS")
                writer.WriteLine("^FO9,75^A0N,30,30^FD" & Pcomponent & "^FS") 'COMPONENT
                writer.WriteLine("^FO205,75^A0N,30,30^FDETD: ^FS") 'kosong
                writer.WriteLine("^FO105,70^A0N,50,50^FD^FS")
                writer.WriteLine("^FO105,115^A0N,20,20^FD^FS")
                writer.WriteLine("^FO20,250")
                writer.WriteLine("^BQN,4,3")
                writer.WriteLine("^FDMM," & txtBarcode.Text & "^FS") 'BARCODE
                writer.WriteLine("^FO290,320^A0N,25,25^FD " & PMoldCode & "^FS") 'MOLD CODE
                writer.WriteLine("^FO105,320^A0N,25,25^FD" & txtBarcode.Text & "^FS") 'BARCODE
                writer.WriteLine("^FO9,126^A0N,40,40^FD" & PModel_Id & "^FS")  'ID MODEL
                writer.WriteLine("^FO155,126^A0N,40,40^FD" & PModel_Name & "^FS") 'NAMA MODEL
                writer.WriteLine("^FO9,180^A0N,40,40^FD" & vColor_id & "^FS") 'WARNA
                writer.WriteLine("^FO120,260^A0N,40,40^FD" & lblWIP.Text & " PRS^FS")
                writer.WriteLine("^FO290,260^A0N,50,50^FD" & vSize_component & "^FS") 'SIZE
                writer.WriteLine("^FO5,25^A0N,25,25^FD" & PCustomerName & "^FS") 'CUSTOMER NAME
                writer.WriteLine("^XZ")


                Dim sCommand As String
                sCommand = " print  C:\barcode\barcode.txt"
                Call Shell("cmd.exe /c " & sCommand, vbHide)



            End Using

        Catch ex As Exception
            Console.WriteLine("Error writing file: " & ex.Message)
        End Try
    End Sub

    Private Sub spdModel_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs)
        FP_LIST_SIZE()


    End Sub

    Private Sub btnPack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        SQL_C = ""
        SQL_C += "INSERT INTO [dbo].[production_good]" & vbLf
        SQL_C += "  ([prod_date]" & vbLf
        SQL_C += "  ,[prod_opcd]" & vbLf
        SQL_C += "  ,[prod_qtty]" & vbLf
        SQL_C += "   ,[prod_hour]" & vbLf
        SQL_C += "  ,[prod_updt]" & vbLf
        SQL_C += "  ,[CODE_SHIF]" & vbLf

        SQL_C += "   ,[mcom_idxx]" & vbLf
        SQL_C += "   ,[molh_idxx]" & vbLf
        SQL_C += "   ,[mols_size]" & vbLf
        SQL_C += "   ,[prod_grad])" & vbLf
        SQL_C += " VALUES(" & vbLf
        SQL_C += "  CONVERT(VARCHAR(10),'" & lblDate.Text & "',111)" & vbLf
        SQL_C += "  ,'FGD'" & vbLf
        SQL_C += "  ,100" & vbLf
        SQL_C += "   ,  DATEPART(HOUR,GETDATE())  " & vbLf
        SQL_C += "  ,GETDATE()" & vbLf
        SQL_C += "  ," & Strings.Right(lblShift.Text, 1) & "" & vbLf
        SQL_C += "   ," & vMcom & "" & vbLf
        SQL_C += "   ," & vMolhId & "" & vbLf
        SQL_C += "   ,'" & vSize_component & "'" & vbLf
        SQL_C += "   ,'A')" & vbLf

        clsCom.GP_ExeSql(SQL_C)
        FP_Barcode()
    End Sub

    
    Private Sub spdProd_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdProd.CellClick
        vMcom = spdProd_Sheet1.Cells.Item(e.Row, 0).Text
        vMolhId = spdProd_Sheet1.Cells.Item(e.Row, 5).Text

        FP_DETAIL()
        btnPack.Text = spdProd_Sheet1.Cells.Item(e.Row, 6).Text

        Pcomponent = spdProd_Sheet1.Cells.Item(e.Row, 3).Text
        PMoldCode = spdProd_Sheet1.Cells.Item(e.Row, 8).Text
        PModel_Id = spdProd_Sheet1.Cells.Item(e.Row, 1).Text
        PModel_Name = spdProd_Sheet1.Cells.Item(e.Row, 2).Text
        PCustomerName = spdProd_Sheet1.Cells.Item(e.Row, 7).Text



    End Sub

   

    Private Sub btnPack_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPack.Click
        SQL_C = ""
        SQL_C += "INSERT INTO [dbo].[production_good]" & vbLf
        SQL_C += "  ([prod_date]" & vbLf
        SQL_C += "  ,[prod_opcd]" & vbLf
        SQL_C += "  ,[prod_qtty]" & vbLf
        SQL_C += "   ,[prod_hour]" & vbLf
        SQL_C += "  ,[prod_updt]" & vbLf
        SQL_C += "  ,[CODE_SHIF]" & vbLf

        SQL_C += "   ,[mcom_idxx]" & vbLf
        SQL_C += "   ,[molh_idxx]" & vbLf
        SQL_C += "   ,[mols_size]" & vbLf
        SQL_C += "   ,[prod_grad] " & vbLf
         
        SQL_C += "   ,[prod_good])" & vbLf

        SQL_C += " VALUES(" & vbLf
        SQL_C += "  CONVERT(VARCHAR(10),'" & lblDate.Text & "',111)" & vbLf
        SQL_C += "  ,'CPX'" & vbLf
        SQL_C += "  ," & btnPack.Text & "" & vbLf
        SQL_C += "   ,  DATEPART(HOUR,GETDATE())  " & vbLf
        SQL_C += "  ,GETDATE()" & vbLf
        SQL_C += "  ," & Strings.Right(lblShift.Text, 1) & "" & vbLf
        SQL_C += "   ," & vMcom & "" & vbLf
        SQL_C += "   ," & vMolhId & "" & vbLf
        SQL_C += "   ,'" & vSize_component & "'" & vbLf
        SQL_C += "   ,'A',getdate())" & vbLf

        clsCom.GP_ExeSql(SQL_C)

        lblWIP.Text = btnPack.Text

        FP_Barcode()

        lblWIP.Text = ""

        FP_SUM_HOUR()
        FP_HEAD()
        FP_DETAIL()
        FP_PRINT_BARCODE()
    End Sub

    Private Sub btnEnter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnter.Click
        SQL_C = ""
        SQL_C += "INSERT INTO [dbo].[production_good]" & vbLf
        SQL_C += "  ([prod_date]" & vbLf
        SQL_C += "  ,[prod_opcd]" & vbLf
        SQL_C += "  ,[prod_qtty]" & vbLf
        SQL_C += "   ,[prod_hour]" & vbLf
        SQL_C += "  ,[prod_updt]" & vbLf
        SQL_C += "  ,[CODE_SHIF]" & vbLf

        SQL_C += "   ,[mcom_idxx]" & vbLf
        SQL_C += "   ,[molh_idxx]" & vbLf
        SQL_C += "   ,[mols_size]" & vbLf
        SQL_C += "   ,[prod_grad] " & vbLf

        SQL_C += "   ,[prod_good])" & vbLf

        SQL_C += " VALUES(" & vbLf
        SQL_C += "  CONVERT(VARCHAR(10),'" & lblDate.Text & "',111)" & vbLf
        SQL_C += "  ,'CPX'" & vbLf
        SQL_C += "  ," & lblWIP.Text & "" & vbLf
        SQL_C += "   ,  DATEPART(HOUR,GETDATE())  " & vbLf
        SQL_C += "  ,GETDATE()" & vbLf
        SQL_C += "  ," & Strings.Right(lblShift.Text, 1) & "" & vbLf
        SQL_C += "   ," & vMcom & "" & vbLf
        SQL_C += "   ," & vMolhId & "" & vbLf
        SQL_C += "   ,'" & vSize_component & "'" & vbLf
        SQL_C += "   ,'A',getdate())" & vbLf

        clsCom.GP_ExeSql(SQL_C)

        lblWIP.Text = btnPack.Text

        FP_Barcode()

        lblWIP.Text = ""

        FP_SUM_HOUR()
        FP_PRINT_BARCODE()
        FP_HEAD()
        FP_DETAIL()
    End Sub

    Private Sub spdPrintUlang_ButtonClicked(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.EditorNotifyEventArgs) Handles spdPrintUlang.ButtonClicked
        Using writer As New StreamWriter(filePath)
            
 


            'writer.WriteLine("^XA")
            'writer.WriteLine("^LH10,0")
            'writer.WriteLine("^FO0,10 ^GB500,340,4^FS")
            'writer.WriteLine("^FO0,10 ^GB500,50,4^FS")
            'writer.WriteLine("^FO0,55 ^GB500,60,4^FS")
            'writer.WriteLine("^FO0,55 ^GB200,60,4^FS")
            'writer.WriteLine("^FO0,111 ^GB150,60,4^FS")
            'writer.WriteLine("^FO0,167 ^GB500,60,4^FS")
            'writer.WriteLine("^FO0,225 ^GB100,125,4^FS")
            'writer.WriteLine("^FO270,225 ^GB230,125,4^FS")
            'writer.WriteLine("^FO10,23^A0N,30,20^FD^FS")
            'writer.WriteLine("^FO250,25^A0N,25,25^FD" & Now & "^FS")
            'writer.WriteLine("^FO10,70^A0N,35,35^FD^FS")
            'writer.WriteLine("^FO9,75^A0N,30,30^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 5).Text & "^FS") 'COMPONENT
            'writer.WriteLine("^FO205,75^A0N,30,30^FDETD: ^FS") 'kosong
            'writer.WriteLine("^FO105,70^A0N,50,50^FD^FS")
            'writer.WriteLine("^FO105,115^A0N,20,20^FD^FS")
            'writer.WriteLine("^FO20,250")
            'writer.WriteLine("^BQN,4,3")
            'writer.WriteLine("^FDMM," & spdPrintUlang_Sheet1.Cells.Item(e.Row, 1).Text & "^FS") 'BARCODE
            'writer.WriteLine("^FO290,320^A0N,25,25^FD " & spdPrintUlang_Sheet1.Cells.Item(e.Row, 8).Text & "^FS") 'MOLD CODE
            'writer.WriteLine("^FO105,320^A0N,25,25^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 1).Text & "^FS") 'BARCODE
            'writer.WriteLine("^FO9,126^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 3).Text & "^FS")  'ID MODEL
            'writer.WriteLine("^FO155,126^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 4).Text & "^FS") 'NAMA MODEL
            'writer.WriteLine("^FO9,180^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 6).Text & "^FS") 'WARNA
            'writer.WriteLine("^FO120,260^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 9).Text & " PRS^FS")
            'writer.WriteLine("^FO290,260^A0N,50,50^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 2).Text & "^FS") 'SIZE
            'writer.WriteLine("^FO5,25^A0N,25,25^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 7).Text & "^FS") 'CUSTOMER NAME
            'writer.WriteLine("^XZ")


            writer.WriteLine("^XA")
            writer.WriteLine("^LH150,5")
            writer.WriteLine("^FO0,10 ^GB540,380,4^FS")
            writer.WriteLine("^FO0,10 ^GB540,50,4^FS")
            writer.WriteLine("^FO0,55 ^GB540,60,4^FS")
            writer.WriteLine("^FO0,55 ^GB200,60,4^FS")
            writer.WriteLine("^FO0,111 ^GB150,60,4^FS")
            writer.WriteLine("^FO0,167 ^GB540,60,4^FS")
            writer.WriteLine("^FO0,225 ^GB100,163,4^FS")
            writer.WriteLine("^FO270,225 ^GB270,163,4^FS")
            writer.WriteLine("^FO10,23^A0N,30,20^FD^FS")
            writer.WriteLine("^FO250,25^A0N,25,25^FD" & Now & "^FS")
            writer.WriteLine("^FO10,70^A0N,35,35^FD^FS")
            writer.WriteLine("^FO9,75^A0N,30,30^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 5).Text & "^FS") 'COMPONENT
            writer.WriteLine("^FO205,75^A0N,30,30^FDETD: ^FS") 'kosong
            writer.WriteLine("^FO105,70^A0N,50,50^FD^FS")
            writer.WriteLine("^FO105,115^A0N,20,20^FD^FS")
            writer.WriteLine("^FO20,250")
            writer.WriteLine("^BQN,4,3")
            writer.WriteLine("^FDMM,0" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 1).Text & "^FS") 'BARCODE
            writer.WriteLine("^FO290,320^A0N,25,25^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 8).Text & "^FS") 'MOLD CODE
            writer.WriteLine("^FO105,320^A0N,25,25^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 1).Text & "^FS") 'BARCODE
            writer.WriteLine("^FO9,126^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 3).Text & "^FS")  'ID MODEL
            writer.WriteLine("^FO155,126^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 4).Text & "^FS") 'NAMA MODEL
            writer.WriteLine("^FO9,180^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 6).Text & "^FS") 'WARNA
            writer.WriteLine("^FO120,260^A0N,40,40^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 9).Text & " PRS^FS")
            writer.WriteLine("^FO290,260^A0N,50,50^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 2).Text & "^FS") 'SIZE
            writer.WriteLine("^FO5,25^A0N,25,25^FD" & spdPrintUlang_Sheet1.Cells.Item(e.Row, 7).Text & "^FS") 'CUSTOMER NAME
            writer.WriteLine("^XZ")


            Dim sCommand As String
            sCommand = " print  C:\barcode\barcode.txt"
            Call Shell("cmd.exe /c " & sCommand, vbHide)



        End Using
    End Sub

     
    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick
        vSize_component = spdSize_Sheet1.Cells.Item(e.Row, 0).Text
        lblWIP.Text = ""
    End Sub

    Private Sub spdPrintUlang_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdPrintUlang.CellClick

    End Sub
End Class