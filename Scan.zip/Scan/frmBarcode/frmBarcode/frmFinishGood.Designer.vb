﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFinishGood
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim EnhancedColumnHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer1 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer2 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer5 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer6 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer3 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer7 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedColumnHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer
        Dim EnhancedRowHeaderRenderer4 As FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer = New FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer
        Dim EnhancedScrollBarRenderer1 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle1 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle2 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle3 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer1 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle4 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType1 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer2 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim EnhancedScrollBarRenderer3 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle5 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle6 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle7 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer2 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle8 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType2 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer4 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim EnhancedScrollBarRenderer5 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle9 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle10 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle11 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer3 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle12 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType3 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer6 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim cultureInfo As System.Globalization.CultureInfo = New System.Globalization.CultureInfo("en-US", False)
        Dim EnhancedScrollBarRenderer7 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle13 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle14 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle15 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer4 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle16 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType4 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer8 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim EnhancedScrollBarRenderer9 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim NamedStyle17 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("ColumnHeaderSeashell")
        Dim NamedStyle18 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("RowHeaderSeashell")
        Dim NamedStyle19 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("CornerSeashell")
        Dim EnhancedCornerRenderer5 As FarPoint.Win.Spread.CellType.EnhancedCornerRenderer = New FarPoint.Win.Spread.CellType.EnhancedCornerRenderer
        Dim NamedStyle20 As FarPoint.Win.Spread.NamedStyle = New FarPoint.Win.Spread.NamedStyle("DataAreaDefault")
        Dim GeneralCellType5 As FarPoint.Win.Spread.CellType.GeneralCellType = New FarPoint.Win.Spread.CellType.GeneralCellType
        Dim EnhancedScrollBarRenderer10 As FarPoint.Win.Spread.EnhancedScrollBarRenderer = New FarPoint.Win.Spread.EnhancedScrollBarRenderer
        Dim ButtonCellType1 As FarPoint.Win.Spread.CellType.ButtonCellType = New FarPoint.Win.Spread.CellType.ButtonCellType
        Dim TextCellType3 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Dim TextCellType4 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.lblDate = New System.Windows.Forms.Label
        Me.lblShift = New System.Windows.Forms.Label
        Me.lblShift1 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.spdSize = New FarPoint.Win.Spread.FpSpread
        Me.spdSize_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdHour2 = New FarPoint.Win.Spread.FpSpread
        Me.spdHour2_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdHour1 = New FarPoint.Win.Spread.FpSpread
        Me.spdHour1_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.spdProd = New FarPoint.Win.Spread.FpSpread
        Me.spdProd_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.btnPack = New System.Windows.Forms.Button
        Me.btnEnter = New System.Windows.Forms.Button
        Me.lblWIP = New System.Windows.Forms.Label
        Me.btnWIP0 = New System.Windows.Forms.Button
        Me.btnWIP9 = New System.Windows.Forms.Button
        Me.btnWIP8 = New System.Windows.Forms.Button
        Me.btnWIP7 = New System.Windows.Forms.Button
        Me.btnWIP6 = New System.Windows.Forms.Button
        Me.btnWIP4 = New System.Windows.Forms.Button
        Me.btnWIP5 = New System.Windows.Forms.Button
        Me.btnWIP3 = New System.Windows.Forms.Button
        Me.btnWIP2 = New System.Windows.Forms.Button
        Me.btnWIP1 = New System.Windows.Forms.Button
        Me.txtBarcode = New System.Windows.Forms.TextBox
        Me.spdPrintUlang = New FarPoint.Win.Spread.FpSpread
        Me.spdPrintUlang_Sheet1 = New FarPoint.Win.Spread.SheetView
        Me.Panel3.SuspendLayout()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHour2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHour2_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHour1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdHour1_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdProd_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdPrintUlang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spdPrintUlang_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        EnhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer1.Name = "EnhancedColumnHeaderRenderer1"
        EnhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer1.TextRotationAngle = 0
        EnhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer1.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer1.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer1.Name = "EnhancedRowHeaderRenderer1"
        EnhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer1.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer1.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer2.Name = "EnhancedColumnHeaderRenderer2"
        EnhancedColumnHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer2.TextRotationAngle = 0
        EnhancedRowHeaderRenderer2.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer2.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer2.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer2.Name = "EnhancedRowHeaderRenderer2"
        EnhancedRowHeaderRenderer2.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer2.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer2.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer2.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer2.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer2.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer5.Name = "EnhancedColumnHeaderRenderer5"
        EnhancedColumnHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer5.TextRotationAngle = 0
        EnhancedRowHeaderRenderer5.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer5.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer5.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer5.Name = "EnhancedRowHeaderRenderer5"
        EnhancedRowHeaderRenderer5.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer5.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer5.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer5.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer5.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer5.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer6.Name = "EnhancedColumnHeaderRenderer6"
        EnhancedColumnHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer6.TextRotationAngle = 0
        EnhancedRowHeaderRenderer6.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer6.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer6.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer6.Name = "EnhancedRowHeaderRenderer6"
        EnhancedRowHeaderRenderer6.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer6.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer6.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer6.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer6.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer6.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer3.Name = "EnhancedColumnHeaderRenderer3"
        EnhancedColumnHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer3.TextRotationAngle = 0
        EnhancedRowHeaderRenderer3.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer3.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer3.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer3.Name = "EnhancedRowHeaderRenderer3"
        EnhancedRowHeaderRenderer3.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer3.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer3.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer3.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer3.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer3.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer7.Name = "EnhancedColumnHeaderRenderer7"
        EnhancedColumnHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer7.TextRotationAngle = 0
        EnhancedRowHeaderRenderer7.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer7.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer7.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer7.Name = "EnhancedRowHeaderRenderer7"
        EnhancedRowHeaderRenderer7.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer7.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer7.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer7.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer7.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer7.TextRotationAngle = 0
        EnhancedColumnHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedColumnHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedColumnHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedColumnHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedColumnHeaderRenderer4.Name = "EnhancedColumnHeaderRenderer4"
        EnhancedColumnHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedColumnHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedColumnHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedColumnHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedColumnHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedColumnHeaderRenderer4.TextRotationAngle = 0
        EnhancedRowHeaderRenderer4.ActiveBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedRowHeaderRenderer4.BackColor = System.Drawing.SystemColors.Control
        EnhancedRowHeaderRenderer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnhancedRowHeaderRenderer4.ForeColor = System.Drawing.SystemColors.ControlText
        EnhancedRowHeaderRenderer4.Name = "EnhancedRowHeaderRenderer4"
        EnhancedRowHeaderRenderer4.NormalGridLineColor = System.Drawing.Color.SlateGray
        EnhancedRowHeaderRenderer4.RightToLeft = System.Windows.Forms.RightToLeft.No
        EnhancedRowHeaderRenderer4.SelectedActiveBackgroundColor = System.Drawing.Color.Gray
        EnhancedRowHeaderRenderer4.SelectedBackgroundColor = System.Drawing.Color.LightGray
        EnhancedRowHeaderRenderer4.SelectedGridLineColor = System.Drawing.Color.CadetBlue
        EnhancedRowHeaderRenderer4.TextRotationAngle = 0
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Tomato
        Me.Panel3.Controls.Add(Me.lblDate)
        Me.Panel3.Controls.Add(Me.lblShift)
        Me.Panel3.Controls.Add(Me.lblShift1)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Location = New System.Drawing.Point(6, 6)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1408, 36)
        Me.Panel3.TabIndex = 106
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Tomato
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblDate.Location = New System.Drawing.Point(1067, 5)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(87, 31)
        Me.lblDate.TabIndex = 97
        Me.lblDate.Text = "DATE"
        '
        'lblShift
        '
        Me.lblShift.AutoSize = True
        Me.lblShift.BackColor = System.Drawing.Color.Tomato
        Me.lblShift.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShift.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblShift.Location = New System.Drawing.Point(1245, 5)
        Me.lblShift.Name = "lblShift"
        Me.lblShift.Size = New System.Drawing.Size(160, 31)
        Me.lblShift.TabIndex = 96
        Me.lblShift.Text = "S H I F T - 2"
        '
        'lblShift1
        '
        Me.lblShift1.AutoSize = True
        Me.lblShift1.BackColor = System.Drawing.Color.Tomato
        Me.lblShift1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShift1.ForeColor = System.Drawing.Color.White
        Me.lblShift1.Location = New System.Drawing.Point(8, 0)
        Me.lblShift1.Name = "lblShift1"
        Me.lblShift1.Size = New System.Drawing.Size(265, 31)
        Me.lblShift1.TabIndex = 91
        Me.lblShift1.Text = "F I N I S H   G O O D"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(10, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = " "
        '
        'spdSize
        '
        Me.spdSize.AccessibleDescription = "spdSize, Sheet1, Row 0, Column 0, "
        Me.spdSize.BackColor = System.Drawing.SystemColors.Control
        Me.spdSize.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer1
        Me.spdSize.HorizontalScrollBar.TabIndex = 6
        Me.spdSize.Location = New System.Drawing.Point(832, 52)
        Me.spdSize.Name = "spdSize"
        NamedStyle1.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle1.Renderer = EnhancedColumnHeaderRenderer5
        NamedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle2.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle2.Renderer = EnhancedRowHeaderRenderer5
        NamedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle3.BackColor = System.Drawing.Color.DimGray
        NamedStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle3.Renderer = EnhancedCornerRenderer1
        NamedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle4.BackColor = System.Drawing.SystemColors.Window
        NamedStyle4.CellType = GeneralCellType1
        NamedStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle4.Renderer = GeneralCellType1
        Me.spdSize.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle1, NamedStyle2, NamedStyle3, NamedStyle4})
        Me.spdSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdSize.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdSize_Sheet1})
        Me.spdSize.Size = New System.Drawing.Size(189, 361)
        Me.spdSize.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdSize.TabIndex = 108
        Me.spdSize.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdSize.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdSize.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer2
        Me.spdSize.VerticalScrollBar.TabIndex = 7
        Me.spdSize.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdSize_Sheet1
        '
        Me.spdSize_Sheet1.Reset()
        Me.spdSize_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdSize_Sheet1.ColumnCount = 2
        Me.spdSize_Sheet1.RowCount = 1
        Me.spdSize_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "S I Z E"
        Me.spdSize_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "QTY"
        Me.spdSize_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdSize_Sheet1.ColumnHeader.Rows.Get(0).Height = 34.0!
        Me.spdSize_Sheet1.Columns.Get(0).CellType = TextCellType1
        Me.spdSize_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdSize_Sheet1.Columns.Get(0).Label = "S I Z E"
        Me.spdSize_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdSize_Sheet1.Columns.Get(0).Width = 70.0!
        Me.spdSize_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdSize_Sheet1.Columns.Get(1).Label = "QTY"
        Me.spdSize_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdSize_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdSize_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdSize_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdSize_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdHour2
        '
        Me.spdHour2.AccessibleDescription = "spdHour2, Sheet1, Row 0, Column 0, "
        Me.spdHour2.BackColor = System.Drawing.SystemColors.Control
        Me.spdHour2.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHour2.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHour2.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer3
        Me.spdHour2.HorizontalScrollBar.TabIndex = 28
        Me.spdHour2.Location = New System.Drawing.Point(8, 555)
        Me.spdHour2.Name = "spdHour2"
        NamedStyle5.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle6.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle7.BackColor = System.Drawing.Color.DimGray
        NamedStyle7.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer2.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer2.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer2.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle7.Renderer = EnhancedCornerRenderer2
        NamedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle8.BackColor = System.Drawing.SystemColors.Window
        NamedStyle8.CellType = GeneralCellType2
        NamedStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle8.Renderer = GeneralCellType2
        Me.spdHour2.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle5, NamedStyle6, NamedStyle7, NamedStyle8})
        Me.spdHour2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHour2.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHour2_Sheet1})
        Me.spdHour2.Size = New System.Drawing.Size(606, 98)
        Me.spdHour2.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHour2.TabIndex = 110
        Me.spdHour2.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHour2.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHour2.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer4
        Me.spdHour2.VerticalScrollBar.TabIndex = 29
        Me.spdHour2.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHour2_Sheet1
        '
        Me.spdHour2_Sheet1.Reset()
        Me.spdHour2_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHour2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHour2_Sheet1.ColumnCount = 12
        Me.spdHour2_Sheet1.RowCount = 1
        Me.spdHour2_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour2_Sheet1.Cells.Get(0, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "19"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "20"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "21"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "22"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "23"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "24"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "1"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "2"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "3"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "4"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "5"
        Me.spdHour2_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "6"
        Me.spdHour2_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHour2_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        Me.spdHour2_Sheet1.Columns.Get(0).Label = "19"
        Me.spdHour2_Sheet1.Columns.Get(0).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(1).Label = "20"
        Me.spdHour2_Sheet1.Columns.Get(1).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(2).Label = "21"
        Me.spdHour2_Sheet1.Columns.Get(2).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(3).Label = "22"
        Me.spdHour2_Sheet1.Columns.Get(3).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(4).Label = "23"
        Me.spdHour2_Sheet1.Columns.Get(4).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(6).Label = "1"
        Me.spdHour2_Sheet1.Columns.Get(6).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(7).Label = "2"
        Me.spdHour2_Sheet1.Columns.Get(7).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(8).Label = "3"
        Me.spdHour2_Sheet1.Columns.Get(8).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(9).Label = "4"
        Me.spdHour2_Sheet1.Columns.Get(9).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(10).Label = "5"
        Me.spdHour2_Sheet1.Columns.Get(10).Width = 61.0!
        Me.spdHour2_Sheet1.Columns.Get(11).Label = "6"
        Me.spdHour2_Sheet1.Columns.Get(11).Width = 61.0!
        Me.spdHour2_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHour2_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHour2_Sheet1.Rows.Get(0).Height = 35.0!
        Me.spdHour2_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHour2_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdHour1
        '
        Me.spdHour1.AccessibleDescription = "spdHour1, Sheet1, Row 0, Column 0, "
        Me.spdHour1.BackColor = System.Drawing.SystemColors.Control
        Me.spdHour1.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHour1.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer5.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer5.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer5.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer5.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer5.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHour1.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer5
        Me.spdHour1.HorizontalScrollBar.TabIndex = 26
        Me.spdHour1.Location = New System.Drawing.Point(7, 420)
        Me.spdHour1.Name = "spdHour1"
        NamedStyle9.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle9.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle9.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle10.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle10.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle10.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle11.BackColor = System.Drawing.Color.DimGray
        NamedStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle11.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer3.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer3.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer3.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle11.Renderer = EnhancedCornerRenderer3
        NamedStyle11.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle12.BackColor = System.Drawing.SystemColors.Window
        NamedStyle12.CellType = GeneralCellType3
        NamedStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle12.Renderer = GeneralCellType3
        Me.spdHour1.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle9, NamedStyle10, NamedStyle11, NamedStyle12})
        Me.spdHour1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdHour1.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdHour1_Sheet1})
        Me.spdHour1.Size = New System.Drawing.Size(606, 98)
        Me.spdHour1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdHour1.TabIndex = 109
        Me.spdHour1.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdHour1.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer6.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer6.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer6.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer6.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer6.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdHour1.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer6
        Me.spdHour1.VerticalScrollBar.TabIndex = 27
        Me.spdHour1.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdHour1_Sheet1
        '
        Me.spdHour1_Sheet1.Reset()
        Me.spdHour1_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdHour1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdHour1_Sheet1.ColumnCount = 12
        Me.spdHour1_Sheet1.RowCount = 1
        Me.spdHour1_Sheet1.Cells.Get(0, 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 10).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdHour1_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdHour1_Sheet1.Cells.Get(0, 10).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdHour1_Sheet1.Cells.Get(0, 10).ParseFormatString = "n"
        Me.spdHour1_Sheet1.Cells.Get(0, 10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdHour1_Sheet1.Cells.Get(0, 11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "7"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "8"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "9"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "10"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "11"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "12"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "13"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "14"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "15"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "16"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "17"
        Me.spdHour1_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "18"
        Me.spdHour1_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdHour1_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        Me.spdHour1_Sheet1.Columns.Get(0).Label = "7"
        Me.spdHour1_Sheet1.Columns.Get(0).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(1).Label = "8"
        Me.spdHour1_Sheet1.Columns.Get(1).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(2).Label = "9"
        Me.spdHour1_Sheet1.Columns.Get(2).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(3).Label = "10"
        Me.spdHour1_Sheet1.Columns.Get(3).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(4).Label = "11"
        Me.spdHour1_Sheet1.Columns.Get(4).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(5).Label = "12"
        Me.spdHour1_Sheet1.Columns.Get(5).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(6).Label = "13"
        Me.spdHour1_Sheet1.Columns.Get(6).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(7).Label = "14"
        Me.spdHour1_Sheet1.Columns.Get(7).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(8).Label = "15"
        Me.spdHour1_Sheet1.Columns.Get(8).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(9).Label = "16"
        Me.spdHour1_Sheet1.Columns.Get(9).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(10).Label = "17"
        Me.spdHour1_Sheet1.Columns.Get(10).Width = 61.0!
        Me.spdHour1_Sheet1.Columns.Get(11).Label = "18"
        Me.spdHour1_Sheet1.Columns.Get(11).Width = 61.0!
        Me.spdHour1_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdHour1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdHour1_Sheet1.Rows.Get(0).Height = 35.0!
        Me.spdHour1_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdHour1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'spdProd
        '
        Me.spdProd.AccessibleDescription = "spdProd, Sheet1, Row 0, Column 0, 0"
        Me.spdProd.BackColor = System.Drawing.SystemColors.Control
        Me.spdProd.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdProd.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer7.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer7.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer7.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer7.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer7.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdProd.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer7
        Me.spdProd.HorizontalScrollBar.TabIndex = 8
        Me.spdProd.Location = New System.Drawing.Point(6, 51)
        Me.spdProd.Name = "spdProd"
        NamedStyle13.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle13.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle13.Renderer = EnhancedColumnHeaderRenderer6
        NamedStyle13.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle14.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle14.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle14.Renderer = EnhancedRowHeaderRenderer6
        NamedStyle14.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle15.BackColor = System.Drawing.Color.DimGray
        NamedStyle15.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle15.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer4.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer4.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer4.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle15.Renderer = EnhancedCornerRenderer4
        NamedStyle15.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle16.BackColor = System.Drawing.SystemColors.Window
        NamedStyle16.CellType = GeneralCellType4
        NamedStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle16.Renderer = GeneralCellType4
        Me.spdProd.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle13, NamedStyle14, NamedStyle15, NamedStyle16})
        Me.spdProd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdProd.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdProd_Sheet1})
        Me.spdProd.Size = New System.Drawing.Size(823, 363)
        Me.spdProd.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdProd.TabIndex = 145
        Me.spdProd.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdProd.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer8.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer8.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer8.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer8.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer8.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdProd.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer8
        Me.spdProd.VerticalScrollBar.TabIndex = 9
        Me.spdProd.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdProd_Sheet1
        '
        Me.spdProd_Sheet1.Reset()
        Me.spdProd_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdProd_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdProd_Sheet1.ColumnCount = 10
        Me.spdProd_Sheet1.RowCount = 1
        Me.spdProd_Sheet1.Cells.Get(0, 0).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 0).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 0).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 0).Value = 0
        Me.spdProd_Sheet1.Cells.Get(0, 1).Value = "1"
        Me.spdProd_Sheet1.Cells.Get(0, 2).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 2).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 2).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 2).Value = 2
        Me.spdProd_Sheet1.Cells.Get(0, 3).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 3).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 3).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 3).Value = 3
        Me.spdProd_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 4).Value = 4
        Me.spdProd_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 5).Value = 5
        Me.spdProd_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 6).Value = 6
        Me.spdProd_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 7).Value = 7
        Me.spdProd_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 8).Value = 8
        Me.spdProd_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdProd_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdProd_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdProd_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdProd_Sheet1.Cells.Get(0, 9).Value = 9
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "ID Model"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "M o d e l"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "Component"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "C o l o r"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Molh ID"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "Pack CP"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Customer"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Mold Code"
        Me.spdProd_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "QTY"
        Me.spdProd_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdProd_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        Me.spdProd_Sheet1.Columns.Get(0).Label = "ID"
        Me.spdProd_Sheet1.Columns.Get(0).Visible = False
        Me.spdProd_Sheet1.Columns.Get(0).Width = 44.0!
        Me.spdProd_Sheet1.Columns.Get(1).CellType = TextCellType2
        Me.spdProd_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(1).Label = "ID Model"
        Me.spdProd_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(1).Width = 76.0!
        Me.spdProd_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(2).Label = "M o d e l"
        Me.spdProd_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(2).Width = 181.0!
        Me.spdProd_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(3).Label = "Component"
        Me.spdProd_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(3).Width = 108.0!
        Me.spdProd_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(4).Label = "C o l o r"
        Me.spdProd_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(4).Width = 221.0!
        Me.spdProd_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(5).Label = "Molh ID"
        Me.spdProd_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(5).Visible = False
        Me.spdProd_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(6).Label = "Pack CP"
        Me.spdProd_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(6).Visible = False
        Me.spdProd_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(7).Label = "Customer"
        Me.spdProd_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(7).Visible = False
        Me.spdProd_Sheet1.Columns.Get(7).Width = 135.0!
        Me.spdProd_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(8).Label = "Mold Code"
        Me.spdProd_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(8).Width = 122.0!
        Me.spdProd_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdProd_Sheet1.Columns.Get(9).Label = "QTY"
        Me.spdProd_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdProd_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdProd_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdProd_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdProd_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'btnPack
        '
        Me.btnPack.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPack.Location = New System.Drawing.Point(1024, 52)
        Me.btnPack.Name = "btnPack"
        Me.btnPack.Size = New System.Drawing.Size(390, 61)
        Me.btnPack.TabIndex = 174
        Me.btnPack.Text = "Qty Pack"
        Me.btnPack.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnter.Location = New System.Drawing.Point(1024, 300)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(390, 109)
        Me.btnEnter.TabIndex = 173
        Me.btnEnter.Text = "ENTER"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblWIP
        '
        Me.lblWIP.AutoSize = True
        Me.lblWIP.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWIP.Location = New System.Drawing.Point(1177, 123)
        Me.lblWIP.Name = "lblWIP"
        Me.lblWIP.Size = New System.Drawing.Size(0, 40)
        Me.lblWIP.TabIndex = 172
        Me.lblWIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnWIP0
        '
        Me.btnWIP0.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP0.Location = New System.Drawing.Point(1342, 242)
        Me.btnWIP0.Name = "btnWIP0"
        Me.btnWIP0.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP0.TabIndex = 171
        Me.btnWIP0.Text = "0"
        Me.btnWIP0.UseVisualStyleBackColor = True
        '
        'btnWIP9
        '
        Me.btnWIP9.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP9.Location = New System.Drawing.Point(1264, 242)
        Me.btnWIP9.Name = "btnWIP9"
        Me.btnWIP9.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP9.TabIndex = 170
        Me.btnWIP9.Text = "9"
        Me.btnWIP9.UseVisualStyleBackColor = True
        '
        'btnWIP8
        '
        Me.btnWIP8.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP8.Location = New System.Drawing.Point(1184, 242)
        Me.btnWIP8.Name = "btnWIP8"
        Me.btnWIP8.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP8.TabIndex = 169
        Me.btnWIP8.Text = "8"
        Me.btnWIP8.UseVisualStyleBackColor = True
        '
        'btnWIP7
        '
        Me.btnWIP7.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP7.Location = New System.Drawing.Point(1104, 242)
        Me.btnWIP7.Name = "btnWIP7"
        Me.btnWIP7.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP7.TabIndex = 168
        Me.btnWIP7.Text = "7"
        Me.btnWIP7.UseVisualStyleBackColor = True
        '
        'btnWIP6
        '
        Me.btnWIP6.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP6.Location = New System.Drawing.Point(1024, 242)
        Me.btnWIP6.Name = "btnWIP6"
        Me.btnWIP6.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP6.TabIndex = 167
        Me.btnWIP6.Text = "6"
        Me.btnWIP6.UseVisualStyleBackColor = True
        '
        'btnWIP4
        '
        Me.btnWIP4.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP4.Location = New System.Drawing.Point(1262, 184)
        Me.btnWIP4.Name = "btnWIP4"
        Me.btnWIP4.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP4.TabIndex = 165
        Me.btnWIP4.Text = "4"
        Me.btnWIP4.UseVisualStyleBackColor = True
        '
        'btnWIP5
        '
        Me.btnWIP5.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP5.Location = New System.Drawing.Point(1340, 184)
        Me.btnWIP5.Name = "btnWIP5"
        Me.btnWIP5.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP5.TabIndex = 166
        Me.btnWIP5.Text = "5"
        Me.btnWIP5.UseVisualStyleBackColor = True
        '
        'btnWIP3
        '
        Me.btnWIP3.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP3.Location = New System.Drawing.Point(1184, 184)
        Me.btnWIP3.Name = "btnWIP3"
        Me.btnWIP3.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP3.TabIndex = 164
        Me.btnWIP3.Text = "3"
        Me.btnWIP3.UseVisualStyleBackColor = True
        '
        'btnWIP2
        '
        Me.btnWIP2.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP2.Location = New System.Drawing.Point(1104, 184)
        Me.btnWIP2.Name = "btnWIP2"
        Me.btnWIP2.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP2.TabIndex = 163
        Me.btnWIP2.Text = "2"
        Me.btnWIP2.UseVisualStyleBackColor = True
        '
        'btnWIP1
        '
        Me.btnWIP1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWIP1.Location = New System.Drawing.Point(1024, 184)
        Me.btnWIP1.Name = "btnWIP1"
        Me.btnWIP1.Size = New System.Drawing.Size(74, 52)
        Me.btnWIP1.TabIndex = 162
        Me.btnWIP1.Text = "1"
        Me.btnWIP1.UseVisualStyleBackColor = True
        '
        'txtBarcode
        '
        Me.txtBarcode.Location = New System.Drawing.Point(1313, 158)
        Me.txtBarcode.Name = "txtBarcode"
        Me.txtBarcode.Size = New System.Drawing.Size(103, 20)
        Me.txtBarcode.TabIndex = 175
        Me.txtBarcode.Visible = False
        '
        'spdPrintUlang
        '
        Me.spdPrintUlang.AccessibleDescription = "spdPrintUlang, Sheet1, Row 0, Column 0, "
        Me.spdPrintUlang.BackColor = System.Drawing.SystemColors.Control
        Me.spdPrintUlang.HorizontalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdPrintUlang.HorizontalScrollBar.Name = ""
        EnhancedScrollBarRenderer9.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer9.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer9.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer9.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer9.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdPrintUlang.HorizontalScrollBar.Renderer = EnhancedScrollBarRenderer9
        Me.spdPrintUlang.HorizontalScrollBar.TabIndex = 26
        Me.spdPrintUlang.Location = New System.Drawing.Point(619, 420)
        Me.spdPrintUlang.Name = "spdPrintUlang"
        NamedStyle17.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle17.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle17.Renderer = EnhancedColumnHeaderRenderer7
        NamedStyle17.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle18.BackColor = System.Drawing.Color.CadetBlue
        NamedStyle18.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle18.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        NamedStyle18.Renderer = EnhancedRowHeaderRenderer7
        NamedStyle18.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle19.BackColor = System.Drawing.Color.DimGray
        NamedStyle19.ForeColor = System.Drawing.SystemColors.ControlText
        NamedStyle19.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        EnhancedCornerRenderer5.ActiveBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedCornerRenderer5.GridLineColor = System.Drawing.Color.Empty
        EnhancedCornerRenderer5.NormalBackgroundColor = System.Drawing.Color.SlateGray
        NamedStyle19.Renderer = EnhancedCornerRenderer5
        NamedStyle19.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        NamedStyle20.BackColor = System.Drawing.SystemColors.Window
        NamedStyle20.CellType = GeneralCellType5
        NamedStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        NamedStyle20.Renderer = GeneralCellType5
        Me.spdPrintUlang.NamedStyles.AddRange(New FarPoint.Win.Spread.NamedStyle() {NamedStyle17, NamedStyle18, NamedStyle19, NamedStyle20})
        Me.spdPrintUlang.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.spdPrintUlang.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.spdPrintUlang_Sheet1})
        Me.spdPrintUlang.Size = New System.Drawing.Size(795, 233)
        Me.spdPrintUlang.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Seashell
        Me.spdPrintUlang.TabIndex = 176
        Me.spdPrintUlang.VerticalScrollBar.Buttons = New FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton")
        Me.spdPrintUlang.VerticalScrollBar.Name = ""
        EnhancedScrollBarRenderer10.ArrowColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowHoveredColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ArrowSelectedColor = System.Drawing.Color.DarkSlateGray
        EnhancedScrollBarRenderer10.ButtonBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.ButtonBorderColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBackgroundColor = System.Drawing.Color.SlateGray
        EnhancedScrollBarRenderer10.ButtonHoveredBorderColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBackgroundColor = System.Drawing.Color.DarkGray
        EnhancedScrollBarRenderer10.ButtonSelectedBorderColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarBackgroundColor = System.Drawing.Color.CadetBlue
        EnhancedScrollBarRenderer10.TrackBarSelectedBackgroundColor = System.Drawing.Color.SlateGray
        Me.spdPrintUlang.VerticalScrollBar.Renderer = EnhancedScrollBarRenderer10
        Me.spdPrintUlang.VerticalScrollBar.TabIndex = 27
        Me.spdPrintUlang.VisualStyles = FarPoint.Win.VisualStyles.Off
        '
        'spdPrintUlang_Sheet1
        '
        Me.spdPrintUlang_Sheet1.Reset()
        Me.spdPrintUlang_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.spdPrintUlang_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        Me.spdPrintUlang_Sheet1.ColumnCount = 10
        Me.spdPrintUlang_Sheet1.RowCount = 1
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 1).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 1).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 1).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 1).Value = 1
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 3).Value = "2"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 4).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 4).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 4).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 4).Value = 3
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 5).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 5).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 5).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 5).Value = 4
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 6).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 6).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 6).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 6).Value = 5
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 7).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 7).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 7).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 7).Value = 6
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 8).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 8).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 8).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 8).Value = 7
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 9).ParseFormatInfo = CType(cultureInfo.NumberFormat.Clone, System.Globalization.NumberFormatInfo)
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberDecimalDigits = 0
        CType(Me.spdPrintUlang_Sheet1.Cells.Get(0, 9).ParseFormatInfo, System.Globalization.NumberFormatInfo).NumberGroupSizes = New Integer() {0}
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 9).ParseFormatString = "n"
        Me.spdPrintUlang_Sheet1.Cells.Get(0, 9).Value = 8
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "-"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "ID BARCODE"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "Size"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "ID Model"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "M o d e l"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "Component"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "C o l o r"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "Customer"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "Mold Code"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "QTY"
        Me.spdPrintUlang_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderSeashell"
        Me.spdPrintUlang_Sheet1.ColumnHeader.Rows.Get(0).Height = 42.0!
        ButtonCellType1.ButtonColor2 = System.Drawing.SystemColors.ButtonFace
        ButtonCellType1.Text = "Print"
        Me.spdPrintUlang_Sheet1.Columns.Get(0).CellType = ButtonCellType1
        Me.spdPrintUlang_Sheet1.Columns.Get(0).Label = "-"
        Me.spdPrintUlang_Sheet1.Columns.Get(1).CellType = TextCellType3
        Me.spdPrintUlang_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(1).Label = "ID BARCODE"
        Me.spdPrintUlang_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(2).Label = "Size"
        Me.spdPrintUlang_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(3).CellType = TextCellType4
        Me.spdPrintUlang_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(3).Label = "ID Model"
        Me.spdPrintUlang_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(3).Width = 76.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(4).Label = "M o d e l"
        Me.spdPrintUlang_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(4).Width = 181.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(5).Label = "Component"
        Me.spdPrintUlang_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(5).Width = 108.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(6).Label = "C o l o r"
        Me.spdPrintUlang_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(6).Width = 221.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(7).Label = "Customer"
        Me.spdPrintUlang_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(7).Width = 135.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(8).Label = "Mold Code"
        Me.spdPrintUlang_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(8).Width = 122.0!
        Me.spdPrintUlang_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
        Me.spdPrintUlang_Sheet1.Columns.Get(9).Label = "QTY"
        Me.spdPrintUlang_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
        Me.spdPrintUlang_Sheet1.RowHeader.Columns.Default.Resizable = True
        Me.spdPrintUlang_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderSeashell"
        Me.spdPrintUlang_Sheet1.SheetCornerStyle.Parent = "CornerSeashell"
        Me.spdPrintUlang_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'frmFinishGood
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1420, 667)
        Me.Controls.Add(Me.spdPrintUlang)
        Me.Controls.Add(Me.txtBarcode)
        Me.Controls.Add(Me.btnPack)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblWIP)
        Me.Controls.Add(Me.btnWIP0)
        Me.Controls.Add(Me.btnWIP9)
        Me.Controls.Add(Me.btnWIP8)
        Me.Controls.Add(Me.btnWIP7)
        Me.Controls.Add(Me.btnWIP6)
        Me.Controls.Add(Me.btnWIP4)
        Me.Controls.Add(Me.btnWIP5)
        Me.Controls.Add(Me.btnWIP3)
        Me.Controls.Add(Me.btnWIP2)
        Me.Controls.Add(Me.btnWIP1)
        Me.Controls.Add(Me.spdProd)
        Me.Controls.Add(Me.spdHour2)
        Me.Controls.Add(Me.spdHour1)
        Me.Controls.Add(Me.spdSize)
        Me.Controls.Add(Me.Panel3)
        Me.Name = "frmFinishGood"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Finish Good"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.spdSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdSize_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHour2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHour2_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHour1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdHour1_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdProd_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdPrintUlang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spdPrintUlang_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents lblShift As System.Windows.Forms.Label
    Friend WithEvents lblShift1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents spdSize As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdSize_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdHour2 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHour2_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdHour1 As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdHour1_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents spdProd As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdProd_Sheet1 As FarPoint.Win.Spread.SheetView
    Friend WithEvents btnPack As System.Windows.Forms.Button
    Friend WithEvents btnEnter As System.Windows.Forms.Button
    Friend WithEvents lblWIP As System.Windows.Forms.Label
    Friend WithEvents btnWIP0 As System.Windows.Forms.Button
    Friend WithEvents btnWIP9 As System.Windows.Forms.Button
    Friend WithEvents btnWIP8 As System.Windows.Forms.Button
    Friend WithEvents btnWIP7 As System.Windows.Forms.Button
    Friend WithEvents btnWIP6 As System.Windows.Forms.Button
    Friend WithEvents btnWIP4 As System.Windows.Forms.Button
    Friend WithEvents btnWIP5 As System.Windows.Forms.Button
    Friend WithEvents btnWIP3 As System.Windows.Forms.Button
    Friend WithEvents btnWIP2 As System.Windows.Forms.Button
    Friend WithEvents btnWIP1 As System.Windows.Forms.Button
    Friend WithEvents txtBarcode As System.Windows.Forms.TextBox
    Friend WithEvents spdPrintUlang As FarPoint.Win.Spread.FpSpread
    Friend WithEvents spdPrintUlang_Sheet1 As FarPoint.Win.Spread.SheetView
End Class
