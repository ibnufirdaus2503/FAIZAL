﻿Public Class frmProduction
    Dim clsCom As clsCOMMAND = New clsCOMMAND()
    Dim SQL_C As String
    Dim vColor As Integer
    Dim vmcom_id As Integer
    Private Sub FP_DELIVERY_SIZE()
        SQL_C = ""
        SQL_C += "SELECT grop_Seqn,MOLS_SIZE,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "("
        SQL_C += "select A.sjxh_idxx,mcom_idxx,A.sjxh_noxx,cust_name" & vbLf
        SQL_C += "from KKTERP.dbo.surat_jalanh A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.surat_jaland B ON A.sjxh_idxx=B.sjxh_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.customer C ON C.cust_idxx=a.cust_idxx" & vbLf
        SQL_C += "where  Convert(VARCHAR(10), sjxh_date,111) ='" & lblDate.Text & "' AND A.sjxh_idxx=" & spdDelivery_Sheet1.Cells.Item(spdDelivery_Sheet1.ActiveRowIndex, 0).Text & vbLf
        SQL_C += "AND mcom_idxx=" & spdDelivery_Sheet1.Cells.Item(spdDelivery_Sheet1.ActiveRowIndex, 1).Text & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.production_good B ON A.sjxh_idxx=B.sjxh_idxx AND A.mcom_idxx=B.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN  KKTERP.dbo.data_size C ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "GROUP BY grop_Seqn,MOLS_SIZE" & vbLf
        SQL_C += "order by grop_seqn"


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDeliverySize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTY")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With
    End Sub
    Private Sub FP_DELIVERY()
        Dim IdModel As Integer

        SQL_C = ""
        SQL_C += "SELECT sjxh_idxx,cust_name,sjxh_noxx,D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT A.sjxh_idxx,A.mcom_idxx,sjxh_noxx,molh_idxx,cust_name,SUM(prod_qtty) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "	(" & vbLf
        SQL_C += "		select A.sjxh_idxx,mcom_idxx,A.sjxh_noxx,cust_name" & vbLf
        SQL_C += "		from KKTERP.dbo.surat_jalanh A" & vbLf
        SQL_C += "		LEFT JOIN KKTERP.dbo.surat_jaland B ON A.sjxh_idxx=B.sjxh_idxx" & vbLf
        SQL_C += "      LEFT JOIN KKTERP.dbo.customer C ON C.cust_idxx=A.cust_idxx" & vbLf
        SQL_C += "		where  Convert(VARCHAR(10), sjxh_date,111) ='" & lblDate.Text & "'" & vbLf
        SQL_C += "	) A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.production_good B ON A.sjxh_idxx=B.sjxh_idxx AND A.mcom_idxx=B.mcom_idxx" & vbLf
        SQL_C += "GROUP BY A.sjxh_idxx,A.mcom_idxx,sjxh_noxx,molh_idxx,cust_name" & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
        SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdDelivery_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("sjxh_idxx")

                .Cells.Item(.RowCount - 1, 1).Text = clsCom.gv_DataRdr("mcom_idxx")

                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("sjxh_noxx")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("cust_name")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


                .Cells.Item(.RowCount - 1, 4).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 7).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 8).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 9).Text = clsCom.gv_DataRdr("QTY")





            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SCAN_SIZE(ByVal vmcom_idxx As Integer)

        If lblOPCD.Text <> "QCX" And lblOPCD.Text <> "FGS" And lblOPCD.Text <> "PDV" Then
            SQL_C = ""
            SQL_C += "SELECT grop_seqn,mols_size,sum(prod_qtty) QTTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production A" & vbLf
            SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf

            If lblOPCD.Text = "BLR" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_scin,111)  ='" & lblDate.Text & "'" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            ElseIf lblOPCD.Text = "ING" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_ingr,111)  ='" & lblDate.Text & "'" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            ElseIf lblOPCD.Text = "OTG" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111)  ='" & lblDate.Text & "'" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            ElseIf lblOPCD.Text = "AGS" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111) IS   NULL AND PROD_INGR IS NOT NULL" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            End If


            SQL_C += "GROUP BY grop_seqn,mols_size" & vbLf
            SQL_C += "order by grop_seqn"
        Else
            SQL_C = ""
            SQL_C += "SELECT grop_seqn,mols_size,sum(prod_qtty) QTTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production_good a" & vbLf
            SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
            If lblOPCD.Text = "QCX" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_date,111)  ='" & lblDate.Text & "'" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx

            ElseIf lblOPCD.Text = "FGS" Then
                SQL_C += "WHERE  PROD_DELI IS NULL" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            ElseIf lblOPCD.Text = "PDV" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_DELI,111)  ='" & lblDate.Text & "'" & vbLf
                SQL_C += "AND mcom_idxx=" & vmcom_idxx
            End If
            SQL_C += "GROUP BY grop_seqn,mols_size" & vbLf
            SQL_C += "order by grop_seqn"
        End If

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdScanSize_Sheet1
            .ColumnCount = 0
            While clsCom.gv_DataRdr.Read
                .ColumnCount = .ColumnCount + 1


                .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("mols_size")
                .Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("QTTY")
                .Cells.Item(0, .ColumnCount - 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(0, .ColumnCount - 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With
    End Sub
    Private Sub FP_SUM_HOUR(ByVal vmcom_idxx As Integer)
        Dim i As Integer

        If lblOPCD.Text <> "AGS" And lblOPCD.Text <> "FGS" Then
            If lblOPCD.Text <> "QCX" And lblOPCD.Text <> "PDV" Then


                If lblOPCD.Text = "BLR" Then
                    SQL_C = ""
                    SQL_C += "SELECT prod_scih prod_hour,sum(prod_qtty) QTTY" & vbLf
                    SQL_C += "FROM KKTERP.dbo.production" & vbLf
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_scin,111)  ='" & lblDate.Text & "'" & vbLf
                    SQL_C += "AND MCOM_IDXX=" & vmcom_idxx
                    SQL_C += "GROUP BY prod_scih" & vbLf
                ElseIf lblOPCD.Text = "ING" Then
                    SQL_C = ""
                    SQL_C += "SELECT prod_ingh prod_hour,sum(prod_qtty) QTTY" & vbLf
                    SQL_C += "FROM KKTERP.dbo.production" & vbLf
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_ingr,111)  ='" & lblDate.Text & "'" & vbLf
                    SQL_C += "AND MCOM_IDXX=" & vmcom_idxx
                    SQL_C += "GROUP BY prod_ingh" & vbLf
                ElseIf lblOPCD.Text = "OTG" Then
                    SQL_C = ""
                    SQL_C += "SELECT prod_otgh prod_hour,sum(prod_qtty) QTTY" & vbLf
                    SQL_C += "FROM KKTERP.dbo.production" & vbLf
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111)  ='" & lblDate.Text & "'" & vbLf
                    SQL_C += "AND MCOM_IDXX=" & vmcom_idxx
                    SQL_C += "GROUP BY prod_otgh" & vbLf
                ElseIf lblOPCD.Text = "AGS" Then
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111) IS   NULL AND PROD_INGR IS NOT NULL" & vbLf
                End If


            Else
                SQL_C = ""
                SQL_C += "SELECT prod_hour,sum(prod_qtty) QTTY" & vbLf
                SQL_C += "FROM KKTERP.dbo.production_good" & vbLf
                If lblOPCD.Text = "QCX" Then
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_Date,111)  ='" & lblDate.Text & "'" & vbLf
                ElseIf lblOPCD.Text = "PDV" Then
                    SQL_C += "WHERE  Convert(VARCHAR(10), prod_DELI,111)  ='" & lblDate.Text & "'" & vbLf
                End If
                SQL_C += "GROUP BY prod_hour" & vbLf

            End If


            clsCom.GP_ExeSqlReader(SQL_C)

            While clsCom.gv_DataRdr.Read


                With spdHour1_Sheet1
                    For i = 0 To 23
                        If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("prod_hour") Then
                            .Cells.Item(0, i).Text = clsCom.gv_DataRdr("QTTY")
                        End If

                    Next
                End With


            End While

            '  .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect


            clsCom.gv_ExeSqlReaderEnd()
        End If
    End Sub
    Private Sub FP_HEADER_SCAN()
        Dim IdModel As Integer

        If lblOPCD.Text = "QCX" Or lblOPCD.Text = "FGS" Or lblOPCD.Text = "PDV" Then
            SQL_C = ""
            SQL_C += "SELECT  isnull(D.modl_idxx,'') modl_idxx,isnull(A.mcom_idxx,'') mcom_idxx,isnull(codd_desc,'') codd_desc,isnull(model_name,'') model_name,isnull(colr_name,'') colr_name,isnull(molh_idxx,'') molh_idxx,isnull(SUM(prod_qtty),0) QTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production_good A" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

            If lblOPCD.Text = "QCX" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_date,111)  ='" & lblDate.Text & "'" & vbLf
            ElseIf lblOPCD.Text = "FGS" Then
                SQL_C += "WHERE  PROD_DELI IS NULL" & vbLf
                '  SQL_C += "AND A.mcom_idxx=" & vmcom_idxx
            ElseIf lblOPCD.Text = "PDV" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), PROD_DELI,111)  ='" & lblDate.Text & "'" & vbLf
            End If
            SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf
        Else
            SQL_C = ""
            SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production A" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

            If lblOPCD.Text = "BLR" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_scin,111)  ='" & lblDate.Text & "'" & vbLf
            ElseIf lblOPCD.Text = "ING" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_ingr,111)  ='" & lblDate.Text & "'" & vbLf
            ElseIf lblOPCD.Text = "OTG" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111)  ='" & lblDate.Text & "'" & vbLf
            ElseIf lblOPCD.Text = "AGS" Then
                SQL_C += "WHERE  Convert(VARCHAR(10), prod_otgr,111) IS   NULL AND PROD_INGR IS NOT NULL" & vbLf
            End If

            SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

        End If


        clsCom.GP_ExeSqlReader(SQL_C)

        With spdScan_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read

                .RowCount = .RowCount + 1
                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                IdModel = clsCom.gv_DataRdr("modl_idxx")
                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")


                .Cells.Item(.RowCount - 1, 1).Text = IdModel.ToString("D4")
                .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")
                .Cells.Item(.RowCount - 1, 6).Text = clsCom.gv_DataRdr("QTY")





            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()


    End Sub
    Private Sub FP_CLEAR()
        Dim j As Integer

        With spdSizeReport_Sheet1
            .ColumnCount = 3
            
            For j = 0 To 8
                .Cells.Item(j, 2).Text = ""
            Next

        End With
    End Sub
    Private Sub FP_HEADER()

        'If lblType.Text = "WIP" Then
        '    SQL_C = ""
        '    SQL_C += " SELECT DISTINCT grop_seqn, MOLS_SIZE " & vbLf
        '    SQL_C += "FROM KKTERP.dbo.production_wipx A" & vbLf
        '    SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        '    SQL_C += "WHERE CONVERT(VARCHAR(10),wipx_DATE ,111)='" & lblDate.Text & "' AND WIPX_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
        '    SQL_C += "ORDER BY grop_seqn" & vbLf
        'ElseIf lblType.Text = "CGR" Then
        '    SQL_C = ""
        '    SQL_C += " SELECT DISTINCT grop_seqn, MOLS_SIZE " & vbLf
        '    SQL_C += "FROM KKTERP.dbo.production_CGRADE A" & vbLf
        '    SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        '    SQL_C += "WHERE CONVERT(VARCHAR(10),CGRD_DATE,111)='" & lblDate.Text & "' AND CGRD_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
        '    SQL_C += "ORDER BY grop_seqn" & vbLf

        'ElseIf lblType.Text = "PRD" Then
        '    SQL_C = ""
        '    SQL_C += " SELECT DISTINCT grop_seqn, MOLS_SIZE " & vbLf
        '    SQL_C += "FROM KKTERP.dbo.production_PROD A" & vbLf
        '    SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        '    SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_DATE,111)='" & lblDate.Text & "' AND PROD_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & vbLf
        '    SQL_C += "ORDER BY grop_seqn" & vbLf

        'End If

        If lblOPCD.Text = "CPX" Or lblOPCD.Text = "GRD" Then

            SQL_C = ""
            SQL_C += "SELECT distinct grop_seqn,mols_size" & vbLf
            SQL_C += "FROM KKTERP.dbo.production  A" & vbLf
            SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
            If lblOPCD.Text = "CPX" Then
                SQL_C += "where convert(varchar(10),prod_otgr,111) between dateadd(day,-3,convert(varchar(10),GETDATE(),111)) and convert(varchar(10),getdate(),111)" & vbLf
            Else
                SQL_C += "where convert(varchar(10),prod_scin,111) between dateadd(day,-3,convert(varchar(10),GETDATE(),111)) and convert(varchar(10),getdate(),111)" & vbLf
            End If
            SQL_C += "ORDER BY grop_seqn" & vbLf

        ElseIf lblOPCD.Text = "TRM" Then
            SQL_C = ""
            SQL_C += "SELECT distinct grop_seqn,mols_size" & vbLf
            SQL_C += "FROM KKTERP.dbo.production_PROD  A" & vbLf
            SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
            SQL_C += "where convert(varchar(10),prod_DATE,111) between dateadd(day,-3,convert(varchar(10),GETDATE(),111)) and convert(varchar(10),getdate(),111)" & vbLf
            SQL_C += "ORDER BY grop_seqn" & vbLf
        Else

        End If

            clsCom.GP_ExeSqlReader(SQL_C)

            With spdSizeReport_Sheet1

                While clsCom.gv_DataRdr.Read
                    .ColumnCount = .ColumnCount + 1


                    .ColumnHeader.Columns.Item(.ColumnCount - 1).Width = 60
                    .ColumnHeader.Cells.Item(0, .ColumnCount - 1).Text = clsCom.gv_DataRdr("MOLS_SIZE")
                End While

                .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
            End With



            clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SIZE_SUMMARY()
        Dim i, j, vtotal As Integer

        With spdSizeReport_Sheet1
            For i = 0 To .RowCount - 1
                vtotal = 0
                For j = 3 To .ColumnCount - 1
                    vtotal = vtotal + Val(.Cells.Item(i, j).Text)
                    .Cells.Item(i, 2).Text = vtotal
                    .Cells.Item(i, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(i, 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center
                Next
            Next

        End With

        
    End Sub
    Private Sub FP_SIZE_REPORT()

        Dim i As Integer






        SQL_C = ""
        SQL_C += "SELECT 'PRD' VTYPE, grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE,SUM(PROD_QTTY) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT DISTINCT grop_seqn,CODE_UNIT,ISNULL(CODE_LRXX,0) CODE_LRXX,MOLS_SIZE,PROD_QTTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_PROD A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "WHERE CONVERT(VARCHAR(10),PROD_DATE,111)='" & lblDate.Text & "' AND PROD_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX= " & vmcom_id & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE" & vbLf
        SQL_C += "        UNION ALL " & vbLf
        SQL_C += "SELECT 'WIP' VTYPE, grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE,SUM(WIPX_QTTY) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT DISTINCT grop_seqn,CODE_UNIT,ISNULL(CODE_LRXX,0) CODE_LRXX,MOLS_SIZE,WIPX_QTTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_WIPX A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "WHERE CONVERT(VARCHAR(10),WIPX_DATE,111)='" & lblDate.Text & "' AND WIPX_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX=" & vmcom_id & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE" & vbLf
        SQL_C += "        UNION ALL " & vbLf
        SQL_C += "SELECT 'CGR' VTYPE, grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE,SUM(CGRD_QTTY) QTY" & vbLf
        SQL_C += "FROM " & vbLf
        SQL_C += "(" & vbLf
        SQL_C += "SELECT DISTINCT grop_seqn,CODE_UNIT,ISNULL(CODE_LRXX,0) CODE_LRXX,MOLS_SIZE,CGRD_QTTY" & vbLf
        SQL_C += "FROM KKTERP.dbo.production_CGRADE A" & vbLf
        SQL_C += "INNER JOIN KKTERP.dbo.DATA_SIZE B ON GROP_SIZE=MOLS_SIZE" & vbLf
        SQL_C += "WHERE CONVERT(VARCHAR(10),CGRD_DATE,111)='" & lblDate.Text & "' AND CGRD_OPCD='" & lblOPCD.Text & "'  AND A.MCOM_IDXX=" & vmcom_id & vbLf
        SQL_C += ") A" & vbLf
        SQL_C += "GROUP BY grop_seqn,CODE_UNIT,CODE_LRXX,MOLS_SIZE" & vbLf

        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSizeReport_Sheet1

            While clsCom.gv_DataRdr.Read

                For i = 3 To .ColumnCount - 1
                    If .ColumnHeader.Cells.Item(0, i).Text = clsCom.gv_DataRdr("MOLS_SIZE") Then
                        If clsCom.gv_DataRdr("VTYPE") = "PRD" Then

                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 0, i).Text = clsCom.gv_DataRdr("QTY")
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 0, i).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 0, i).HorizontalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                        ElseIf clsCom.gv_DataRdr("VTYPE") = "WIP" Then
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 3, i).Text = clsCom.gv_DataRdr("QTY")
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 3, i).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 3, i).HorizontalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 3, i).ForeColor = Color.Blue
                        ElseIf clsCom.gv_DataRdr("VTYPE") = "CGR" Then
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 6, i).Text = clsCom.gv_DataRdr("QTY")
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 6, i).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 6, i).HorizontalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                            .Cells.Item(clsCom.gv_DataRdr("CODE_LRXX") + 6, i).ForeColor = Color.Red
                        End If
                    End If
                Next





            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With



        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    'Private Sub FP_DETAIL_HOUR()

    '    SQL_C = ""
    '    SQL_C += "SELECT codd_valu,PROD_HOUR,SUM(PROD_QTTY) QTY" & vbLf
    '    SQL_C += "FROM KKTERP.dbo.PRODUCTION A" & vbLf
    '    SQL_C += "LEFT JOIN KKTERP.dbo.code_common B ON B.codh_flnm='CODE_HOUR' AND B.codd_desc=prod_hour" & vbLf
    '    SQL_C += "WHERE(Convert(VARCHAR(10), PROD_SCIN, 111) = Convert(VARCHAR(10), GETDATE(), 111))" & vbLf
    '    SQL_C += "GROUP BY codd_valu,PROD_HOUR" & vbLf




    '    clsCom.GP_ExeSqlReader(SQL_C)

    '    With spdHour_Sheet1

    '        While clsCom.gv_DataRdr.Read

    '            .Cells.Item(0, clsCom.gv_DataRdr("codd_valu") + 3).Text = clsCom.gv_DataRdr("QTY")
    '            .Cells.Item(1, clsCom.gv_DataRdr("codd_valu") + 3).Text = clsCom.gv_DataRdr("QTY")




    '        End While

    '        .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
    '    End With

    '    clsCom.gv_ExeSqlReaderEnd()
    'End Sub
    Private Sub frmProduction_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        FP_SHIFT()

    End Sub
    Private Sub FP_SIZE(ByVal vmcom_idxx As Integer)




        If lblOPCD.Text = "CPX" Or lblOPCD.Text = "GRD" Or lblOPCD.Text = "TRM" Then

            SQL_C = ""
            SQL_C += "SELECT distinct grop_seqn,mols_size" & vbLf
            SQL_C += "FROM KKTERP.dbo.production  A" & vbLf
            SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf

            If lblOPCD.Text = "GRD" Then
                SQL_C += "where mcom_idxx=" & vmcom_idxx & " and convert(varchar(10),prod_scin,111) between dateadd(day,-3,convert(varchar(10),getdate(),111)) and convert(varchar(10),getdate(),111)" & vbLf


            Else
                SQL_C += "where mcom_idxx=" & vmcom_idxx & " and convert(varchar(10),prod_otgr,111) between dateadd(day,-3,convert(varchar(10),prod_otgr,111)) and convert(varchar(10),getdate(),111)" & vbLf
            End If
            SQL_C += "ORDER BY grop_seqn" & vbLf

            'ElseIf lblOPCD.Text = "TRM" Then
            '    SQL_C = ""
            '    SQL_C += "SELECT distinct grop_seqn,mols_size" & vbLf
            '    SQL_C += "FROM KKTERP.dbo.production_PROD  A" & vbLf
            '    SQL_C += "LEFT JOIN  KKTERP.dbo.data_size B ON grop_size=mols_size AND CODE_SIZE=MOLS_SIZE" & vbLf
            '    SQL_C += "where mcom_idxx=" & vmcom_idxx & " and PROD_OPCD='CPX' AND convert(varchar(10),prod_DATE,111) between dateadd(day,-3,convert(varchar(10),prod_Date,111)) and convert(varchar(10),getdate(),111)" & vbLf
            '    SQL_C += "ORDER BY grop_seqn" & vbLf

        End If




        clsCom.GP_ExeSqlReader(SQL_C)

        With spdSize_Sheet1
            .RowCount = 0
            While clsCom.gv_DataRdr.Read
                .RowCount = .RowCount + 1

                .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mols_size")


            End While

            .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
        End With

        clsCom.gv_ExeSqlReaderEnd()
    End Sub
    Private Sub FP_SHIFT()



        SQL_C = ""
        SQL_C += "exec KKTERP.dbo.sp_shift"

        clsCom.GP_ExeSqlReader(SQL_C)

        clsCom.gv_DataRdr.Read()
        If clsCom.gv_DataRdr("vdate") <> "" Then
            lblDate.Text = clsCom.gv_DataRdr("vdate")
            lblShift.Text = clsCom.gv_DataRdr("VSHIFT")
        End If
        clsCom.gv_ExeSqlReaderEnd()

        'lblDate.Text = "2025/06/08"
        'lblShift.Text = "1"


    End Sub
    Private Sub FP_HEAD()
        Dim IdModel As Integer

        If lblOPCD.Text = "CPX" Or lblOPCD.Text = "GRD" Or lblOPCD.Text = "TRM" Then

            SQL_C = ""
            SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production A" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

            If lblOPCD.Text = "GRD" Then
                SQL_C += "where cONVERT(VARCHAR(10),prod_scin,111) between Convert(VARCHAR(10), DateAdd(Day, -3, getdate()), 111)  AND convert(varchar(10),'" & lblDate.Text & "',111)" & vbLf

            Else
                SQL_C += "where cONVERT(VARCHAR(10),prod_otgr,111) between Convert(VARCHAR(10), DateAdd(Day, -3, getdate()), 111)  AND convert(varchar(10),'" & lblDate.Text & "',111)" & vbLf
            End If

        ElseIf lblOPCD.Text = "TRM" Then
            SQL_C = ""
            SQL_C += "SELECT  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx,SUM(prod_qtty) QTY" & vbLf
            SQL_C += "FROM KKTERP.dbo.production_PROD A" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.material_component C ON A.mcom_idxx=C.mcom_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.model_color D ON D.mclr_idxx=C.mclr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.vmodel E ON E.model_id =D.modl_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.color F ON F.colr_idxx=D.colr_idxx" & vbLf
            SQL_C += "LEFT JOIN KKTERP.dbo.code_common G ON G.codh_flnm='CODE_COMP' AND CODE_COMP=codd_valu" & vbLf

            SQL_C += "where prod_opcd='CPX' AND cONVERT(VARCHAR(10),prod_date,111) between Convert(VARCHAR(10), DateAdd(Day, -3, getdate()), 111)  AND convert(varchar(10),'" & lblDate.Text & "',111)" & vbLf


        End If


            SQL_C += "GROUP BY  D.modl_idxx,A.mcom_idxx,codd_desc,model_name,colr_name,molh_idxx" & vbLf

            clsCom.GP_ExeSqlReader(SQL_C)

            With spdHead_Sheet1
                .RowCount = 0
                While clsCom.gv_DataRdr.Read

                    .RowCount = .RowCount + 1
                    .RowHeader.Rows.Item(.RowCount - 1).Height = 40

                    IdModel = clsCom.gv_DataRdr("modl_idxx")
                    .Cells.Item(.RowCount - 1, 0).Text = clsCom.gv_DataRdr("mcom_idxx")


                    .Cells.Item(.RowCount - 1, 1).Text = IdModel.ToString("D4")
                    .Cells.Item(.RowCount - 1, 1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(.RowCount - 1, 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center

                    .Cells.Item(.RowCount - 1, 2).Text = clsCom.gv_DataRdr("model_name")
                    .Cells.Item(.RowCount - 1, 2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center

                    .Cells.Item(.RowCount - 1, 3).Text = clsCom.gv_DataRdr("codd_desc")
                    .Cells.Item(.RowCount - 1, 3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(.RowCount - 1, 4).Text = clsCom.gv_DataRdr("colr_name")
                    .Cells.Item(.RowCount - 1, 4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center
                    .Cells.Item(.RowCount - 1, 5).Text = clsCom.gv_DataRdr("molh_idxx")




                End While

                .OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect
            End With

            clsCom.gv_ExeSqlReaderEnd()
    End Sub

    Private Sub btnInGrinding_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCode2.Click
        lblAddress.Text = btnCode2.Text
    End Sub

    Private Sub spdHead_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdHead.CellClick

       
        vmcom_id = spdHead_Sheet1.Cells.Item(e.Row, 0).Text

        If lblOPCD.Text = "" Then
            MsgBox("SILAHKAN PILIH PROCESS")
            Exit Sub

        End If

        FP_SIZE(spdHead_Sheet1.Cells.Item(e.Row, 0).Text)

        FP_CLEAR()
        FP_HEADER()

        FP_SIZE_REPORT()
        FP_SIZE_SUMMARY()
    End Sub

   

    Private Sub btnCode1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCode1.Click, btnCode10.Click, btnCode11.Click, btnCode2.Click, btnCode3.Click, btnCode4.Click, btnCode4.Click, btnCode5.Click, btnCode6.Click, btnCode7.Click, btnCode8.Click, btnCode9.Click, btnCode12.Click
        Dim i As Integer
        For Each ctrl As Control In pnlButton.Controls
            If TypeOf ctrl Is Button Then
                ctrl.BackColor = Color.Brown
            End If
        Next

        Dim button As Button = CType(sender, Button)
        button.BackColor = Color.Tomato
        lblOPCD.Text = button.Tag
        lblAddress.Text = button.Text


        With spdHour1_Sheet1
            For i = 0 To 23

                .Cells.Item(0, i).Text = ""
            Next
        End With


      
        If lblOPCD.Text <> "DLV" Then

            If button.Tag = "GRD" Or button.Tag = "CPX" Or button.Tag = "TRM" Then
                tabHeader.SelectedIndex = 0

                FP_HEAD()
                FP_CLEAR()
                spdSize_Sheet1.RowCount = 0
            Else
                tabHeader.SelectedIndex = 1
                spdScanSize_Sheet1.ColumnCount = 0

                FP_HEADER_SCAN()
            End If
        Else
            tabHeader.SelectedIndex = 2
            spdDelivery_Sheet1.RowCount = 0
            spdDeliverySize_Sheet1.ColumnCount = 0

            FP_DELIVERY()
        End If


    End Sub

    Private Sub btnWIP1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWIP1.Click, btnWIP2.Click, btnWIP3.Click, btnWIP4.Click, btnWIP5.Click, btnWIP6.Click, btnWIP7.Click, btnWIP8.Click, btnWIP9.Click, btnWIP0.Click
        Dim button As Button = CType(sender, Button)
        If lblAngka.Text = "0" Then
            lblAngka.Text = ""
        End If
        lblAngka.Text += button.Text
    End Sub

    Private Sub btnBackSpace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBackSpace.Click
        If lblAngka.Text.Length = 1 Then
            lblAngka.Text = 0
        Else
            lblAngka.Text = Strings.Left(lblAngka.Text, lblAngka.Text.Length - 1)
        End If

    End Sub

    Private Sub btnPair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPair.Click
        If lblType.Text = "" Then
            MsgBox("SILAHKAN PILIH PRODUCTION, WIP , C-GRADE")
            Exit Sub

        End If

        If lblType.Text = "WIP" Then

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_wipx WHERE CODE_UNIT=1 AND wipx_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),wipx_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_wipx (wipx_date,code_shif,wipx_opcd,wipx_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,wipx_updt) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",1," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate())"

            clsCom.GP_ExeSql(SQL_C)
        ElseIf lblType.Text = "CGR" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_cgrade WHERE CODE_UNIT=1 AND cgrd_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),cgrd_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_cgrade (cgrd_date,code_shif,cgrd_opcd,cgrd_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,cgrd_updt) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",1," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate())"

            clsCom.GP_ExeSql(SQL_C)


        ElseIf lblType.Text = "PRD" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_prod WHERE CODE_UNIT=1 AND prod_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),prod_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_prod (prod_date,code_shif,prod_opcd,prod_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,prod_updt) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",1," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate())"

            clsCom.GP_ExeSql(SQL_C)

        End If

        FP_CLEAR()
        FP_HEADER()
        FP_SIZE_REPORT()
        FP_SIZE_SUMMARY()


    End Sub

    

    Private Sub btnProduction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProduction.Click, btnWIP.Click, btnCgrade.Click
        For Each ctrl As Control In pnlProduction.Controls
            If TypeOf ctrl Is Button Then
                ctrl.BackColor = Color.Brown
            End If
        Next

        Dim button As Button = CType(sender, Button)
        button.BackColor = Color.Tomato

        lblType.Text = button.Tag

        '  FP_CLEAR()


        
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lblAngka.Text = 0
    End Sub

    Private Sub btnKanan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKanan.Click
        If lblType.Text = "WIP" Then

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_wipx WHERE CODE_UNIT=4 AND CODE_LRXX=1 AND wipx_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),wipx_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_wipx (wipx_date,code_shif,wipx_opcd,wipx_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,wipx_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),1)"


            clsCom.GP_ExeSql(SQL_C)
        ElseIf lblType.Text = "CGR" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_CGRADE WHERE CODE_UNIT=4 AND CODE_LRXX=1 AND cgrd_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),cgrd_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_CGRADE (cgrd_date,code_shif,cgrd_opcd,cgrd_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,cgrd_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),1)"


            clsCom.GP_ExeSql(SQL_C)

        ElseIf lblType.Text = "PRD" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_PROD WHERE CODE_UNIT=4 AND CODE_LRXX=1 AND PROD_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),PROD_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_PROD (PROD_date,code_shif,PROD_opcd,PROD_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,PROD_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),1)"


            clsCom.GP_ExeSql(SQL_C)


        End If

        FP_CLEAR()
        FP_HEADER()
        FP_SIZE_REPORT()
        FP_SIZE_SUMMARY()

       
    End Sub

    Private Sub btnKiri_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKiri.Click

        If lblType.Text = "WIP" Then

            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_wipx WHERE CODE_UNIT=4 AND CODE_LRXX=2 AND wipx_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),wipx_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_wipx (wipx_date,code_shif,wipx_opcd,wipx_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,wipx_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),2)"


            clsCom.GP_ExeSql(SQL_C)
        ElseIf lblType.Text = "CGR" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_cgrade WHERE CODE_UNIT=4 AND CODE_LRXX=2 AND cgrd_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),cgrd_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_cgrade (cgrd_date,code_shif,cgrd_opcd,cgrd_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,cgrd_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),2)"


            clsCom.GP_ExeSql(SQL_C)
        ElseIf lblType.Text = "PRD" Then
            SQL_C = ""
            SQL_C += "DELETE KKTERP.dbo.production_prod WHERE CODE_UNIT=4 AND CODE_LRXX=2 AND PROD_opcd='" & lblOPCD.Text & "' AND CONVERT(VARCHAR(10),PROD_date,111)='" & lblDate.Text & "' AND   code_shif=" & Strings.Right(lblShift.Text, 1) & " AND mcom_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & " AND molh_idxx=" & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & " AND mols_size='" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "'"

            clsCom.GP_ExeSql(SQL_C)


            SQL_C = ""
            SQL_C += "INSERT INTO KKTERP.dbo.production_prod (PROD_date,code_shif,PROD_opcd,PROD_qtty,CODE_UNIT, mcom_idxx,molh_idxx,mols_size,PROD_updt,CODE_LRXX) values ('" & lblDate.Text & "'," & Strings.Right(lblShift.Text, 1) & ",'" & lblOPCD.Text & "'," & lblAngka.Text & ",4," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 0).Text & "," & spdHead_Sheet1.Cells.Item(spdHead_Sheet1.ActiveRowIndex, 5).Text & ",'" & spdSize_Sheet1.Cells.Item(spdSize_Sheet1.ActiveRowIndex, 0).Text & "',getdate(),2)"


            clsCom.GP_ExeSql(SQL_C)

        End If

        FP_CLEAR()
        FP_HEADER()
        FP_SIZE_REPORT()
        FP_SIZE_SUMMARY()

        
    End Sub

    Private Sub spdSize_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdSize.CellClick
        lblAngka.Text = "0"
    End Sub

    Private Sub spdScan_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdScan.CellClick
        Dim i As Integer

        With spdHour1_Sheet1
            For i = 0 To 23

                .Cells.Item(0, i).Text = ""
            Next
        End With

        
        FP_SCAN_SIZE(spdScan_Sheet1.Cells.Item(e.Row, 0).Text)
        FP_SUM_HOUR(spdScan_Sheet1.Cells.Item(e.Row, 0).Text)


    End Sub

    Private Sub spdDelivery_CellClick(ByVal sender As System.Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles spdDelivery.CellClick
        FP_DELIVERY_SIZE()
    End Sub
End Class