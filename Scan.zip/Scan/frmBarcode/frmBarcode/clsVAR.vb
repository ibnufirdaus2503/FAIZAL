﻿Imports System.Data
Imports System.Data.OleDb

Public Class clsVAR
    Public Structure Var_Help
        Dim Help_str1 As String
        Dim Help_str2 As String
        Dim Help_str3 As String
        Dim Help_str4 As String
        Dim Help_str5 As String
        Dim Help_str6 As String
        Dim Help_str7 As String
        Dim Help_str8 As String
        Dim Help_str9 As String
        Dim Help_str10 As String

        Dim Help_Num1 As Integer
        Dim Help_Num2 As Integer
        Dim Help_Num3 As Integer
        Dim Help_Num4 As Integer
        Dim Help_Num5 As Integer
        Dim Help_Num6 As Integer
        Dim Help_Num7 As Integer
        Dim Help_Num8 As Integer
        Dim Help_Num9 As Integer
        Dim Help_Num10 As Integer

        Dim Help_Date1 As Date
        Dim Help_Date2 As Date
        Dim Help_Date3 As Date
        Dim Help_Date4 As Date
        Dim Help_Date5 As Date
        Dim Help_Date6 As Date
        Dim Help_Date7 As Date
        Dim Help_Date8 As Date
        Dim Help_Date9 As Date
        Dim Help_Date10 As Date


    End Structure
    Public gv_con As OleDbConnection = New OleDbConnection
    Public gv_Cmd As OleDbCommand = New OleDbCommand
    Public gv_Cmd_1 As OleDbCommand = New OleDbCommand
    Public gv_Data_Adp As OleDbDataAdapter = New OleDbDataAdapter
    Public gv_DataSet As DataSet = New DataSet
    Public gv_DataRdr As OleDbDataReader 
    Public Shared login As Boolean = False

    Public Shared gv_ip_address As String = "192.168.2.10"
    Public Shared gv_path_local As String = "C:\Program Files (x86)\KKTERP\KKTI\"
    Public gv_today As String
    Public Shared gv_Help() As Var_Help
    Public Shared gv_Form_Type As String
    Public Shared gv_Form_Type_2 As String
    Public Shared gv_Penilai As String
    Public Shared gv_sUserId As String

End Class
